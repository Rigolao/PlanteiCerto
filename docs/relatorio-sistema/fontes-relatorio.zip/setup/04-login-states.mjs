// Faz login pela UI uma vez por conta e salva o storageState (evita rate limit de auth nos agentes).
import path from 'node:path';
import fs from 'node:fs';
import { ACCOUNTS, DIRS } from '../harness/config.mjs';
import { newContext, loginUI, finish } from '../harness/shot.mjs';

const only = process.argv.slice(2);
for (const key of Object.keys(ACCOUNTS)) {
  if (only.length && !only.includes(key)) continue;
  const ctx = await newContext({ auth: 'none', gate: true });
  const page = await ctx.newPage();
  try {
    await loginUI(page, key);
    const dest = path.join(DIRS.state, `${key}.json`);
    await ctx.storageState({ path: dest });
    const st = JSON.parse(fs.readFileSync(dest, 'utf8'));
    const keys = (st.origins?.[0]?.localStorage || []).map(e => e.name);
    console.log(`✔ ${key}: state salvo (${keys.filter(k => k.startsWith('sb-')).length} chave(s) sb-*, ${keys.length} total)`);
  } catch (e) {
    console.error(`✘ ${key}: ${e.message.split('\n')[0]}`);
    await page.screenshot({ path: path.join(DIRS.logs, `login-fail-${key}.png`) }).catch(() => {});
  } finally { await ctx.close(); }
}
await finish();
