// Baixa os 12 PDFs públicos (guias + critérios) do storage da VPS e sobe no storage local.
import fs from 'node:fs';
import path from 'node:path';
import { API, DIRS } from '../harness/config.mjs';
import { storageUpload } from '../harness/supa.mjs';

const SRC = 'https://api.planteicerto.com.br/storage/v1/object/public';
const FILES = [
  ...Array.from({ length: 10 }, (_, i) => ['guias', `guia${i + 1}.pdf`]),
  ['criterios', 'parametrizacao_simples.pdf'],
  ['criterios', 'parametrizacao_tecnica.pdf'],
];
const cache = path.join(DIRS.artefatos, 'pdfs-storage');
fs.mkdirSync(cache, { recursive: true });

let ok = 0;
for (const [bucket, file] of FILES) {
  const local = path.join(cache, `${bucket}__${file}`);
  let buf;
  if (fs.existsSync(local)) buf = fs.readFileSync(local);
  else {
    const r = await fetch(`${SRC}/${bucket}/${file}`);
    if (!r.ok) { console.warn(`SKIP ${bucket}/${file}: ${r.status}`); continue; }
    buf = Buffer.from(await r.arrayBuffer());
    fs.writeFileSync(local, buf);
  }
  const up = await storageUpload(bucket, file, buf, 'application/pdf');
  const check = await fetch(`${API}/storage/v1/object/public/${bucket}/${file}`, { method: 'HEAD' });
  console.log(`${bucket}/${file}: ${buf.length} bytes, upload ${up.status}, public HEAD ${check.status}`);
  if (check.ok) ok++;
}
console.log(`OK: ${ok}/${FILES.length}`);
process.exit(ok === FILES.length ? 0 : 1);
