// Projetos e pontos demo para a conta projetista + favoritos para a conta user. Idempotente.
import { ACCOUNTS } from '../harness/config.mjs';
import { rest, adminFindUser, sql } from '../harness/supa.mjs';

const proj = await adminFindUser(ACCOUNTS.projetista.email);
const user = await adminFindUser(ACCOUNTS.user.email);
if (!proj || !user) throw new Error('contas demo ausentes — rode 02-users.mjs');

const P1 = 'Arborização Rua Prudente de Moraes';
const P2 = 'Praça Sete de Setembro (em planejamento)';

// limpeza idempotente
await rest(`/projects?user_id=eq.${proj.id}`, { method: 'DELETE' });

const { data: [p1] } = await rest('/projects', { method: 'POST', prefer: 'return=representation', body: {
  user_id: proj.id, nome: P1,
  descricao: 'Plantio de 6 exemplares na calçada da Rua Prudente de Moraes (Ribeirão Preto/SP), priorizando espécies nativas e compatíveis com a fiação existente.',
  centro_lat: -21.17668, centro_lng: -47.82145, centro_zoom: 18,
}});

const POINTS = [
  [-21.17610, -47.82150, 1,   'Calçada norte, em frente ao nº 1220'],
  [-21.17633, -47.82148, 145, 'Recuo de 2,5 m, sem fiação — ipê-amarelo'],
  [-21.17656, -47.82146, 131, 'Berço 1,0 × 1,0 m'],
  [-21.17679, -47.82144, 2,   'Sob fiação convencional'],
  [-21.17702, -47.82142, 41,  'Esquina — palmeira, sem projeção de copa'],
  [-21.17725, -47.82140, 99,  'Canteiro ampliado'],
];
const ids = POINTS.map(p => p[2]);
const names = sql(`select id||'='||nome_popular||' ('||nome_cientifico||', ativa='||ativa||')' from public.trees where id in (${ids.join(',')}) order by id`);
console.log('espécies:', names.replace(/\n/g, ' | '));
await rest('/points', { method: 'POST', body: POINTS.map(([lat, lng, tree_id, observacao]) => ({ project_id: p1.id, tree_id, lat, lng, observacao })) });

const { data: [p2] } = await rest('/projects', { method: 'POST', prefer: 'return=representation', body: {
  user_id: proj.id, nome: P2,
  descricao: 'Projeto em fase de levantamento: praça de bairro ainda sem pontos de plantio definidos.',
  centro_lat: -21.17668, centro_lng: -47.82145, centro_zoom: 17,
}});

// favoritos da conta user
await rest(`/user_favorites?user_id=eq.${user.id}`, { method: 'DELETE' });
await rest('/user_favorites', { method: 'POST', body: [1, 145, 99].map(tree_id => ({ user_id: user.id, tree_id })) });

const { data: check } = await rest(`/projects?select=nome,points(count)&user_id=eq.${proj.id}&order=created_at`);
console.log(JSON.stringify(check));
console.log('favoritos user:', (await rest(`/user_favorites?select=tree_id&user_id=eq.${user.id}`)).data.map(f => f.tree_id).join(','));
console.log('p1', p1.id, '| p2', p2.id);
