// Dumps para os apêndices do relatório (espécies, colunas de trees, RLS, questionário).
import fs from 'node:fs';
import path from 'node:path';
import { DIRS } from '../harness/config.mjs';
import { sql } from '../harness/supa.mjs';
import { STEPS, QUESTIONNAIRE } from '../harness/wizard.mjs';

const A = DIRS.artefatos;

// 1) espécies (CSV)
const csv = sql(`copy (select id, nome_popular, nome_cientifico, origem, porte_altura_classe, copa_classe, decidua_perenifolia, compat_fiacao, altura_adulta_max_m, diametro_copa_adulto_max_m, ativa, (dap_10a_cm is not null) as tem_projecao_10a from public.trees order by nome_popular collate "pt-BR-x-icu") to stdout with csv header`, { tuplesOnly: false });
fs.writeFileSync(path.join(A, 'especies.csv'), csv + '\n');
console.log('especies.csv linhas:', csv.split('\n').length - 1);

// 2) colunas de trees + CHECKs + comentários
const cols = sql(`select ordinal_position||'\t'||column_name||'\t'||data_type||'\t'||is_nullable||'\t'||coalesce(column_default,'')||'\t'||coalesce(col_description('public.trees'::regclass, ordinal_position),'') from information_schema.columns where table_schema='public' and table_name='trees' order by ordinal_position`);
const checks = sql(`select conname||'\t'||pg_get_constraintdef(oid) from pg_constraint where conrelid='public.trees'::regclass and contype='c' order by conname`);
let md = '# Colunas da tabela public.trees (extraído do banco local após as 5 migrations)\n\n| # | Coluna | Tipo | Nulo? | Default | Comentário |\n|---|---|---|---|---|---|\n';
for (const l of cols.split('\n')) { const [n, c, t, nul, d, com] = l.split('\t'); md += `| ${n} | \`${c}\` | ${t} | ${nul} | ${d ? '`' + d + '`' : ''} | ${(com || '').replace(/\|/g, '/')} |\n`; }
md += '\n## Constraints CHECK\n\n| Constraint | Definição |\n|---|---|\n';
for (const l of checks.split('\n')) { const [n, d] = l.split('\t'); md += `| \`${n}\` | \`${d}\` |\n`; }
fs.writeFileSync(path.join(A, 'colunas-trees.md'), md);
console.log('colunas-trees.md:', cols.split('\n').length, 'colunas,', checks.split('\n').length, 'checks');

// 3) tabelas públicas (todas) resumidas + RLS + triggers + buckets
const tables = sql(`select table_name||'\t'||string_agg(column_name||':'||data_type, ', ' order by ordinal_position) from information_schema.columns where table_schema='public' group by table_name order by table_name`);
const pol = sql(`select schemaname||'.'||tablename||'\t'||policyname||'\t'||cmd||'\t'||array_to_string(roles,',')||'\t'||coalesce(qual,'')||'\t'||coalesce(with_check,'') from pg_policies where schemaname in ('public','storage') order by schemaname, tablename, policyname`);
const trg = sql(`select event_object_schema||'.'||event_object_table||'\t'||trigger_name||'\t'||action_timing||' '||event_manipulation||'\t'||action_statement from information_schema.triggers where trigger_schema in ('public','auth') order by event_object_schema, event_object_table, trigger_name`);
const buckets = sql(`select id||'\t'||public||'\t'||coalesce(file_size_limit::text,'')||'\t'||coalesce(array_to_string(allowed_mime_types,','),'') from storage.buckets order by id`);
const fns = sql(`select p.proname||'\t'||pg_get_function_result(p.oid)||'\t'||l.lanname||'\t'||case when p.prosecdef then 'SECURITY DEFINER' else '' end from pg_proc p join pg_namespace n on n.oid=p.pronamespace join pg_language l on l.oid=p.prolang where n.nspname='public' order by 1`);
let db = '# Esquema do banco (extraído do banco local)\n\n## Tabelas públicas\n\n';
for (const l of tables.split('\n')) { const [t, c] = l.split('\t'); db += `### ${t}\n\n${c}\n\n`; }
db += '## Políticas RLS (public + storage)\n\n| Tabela | Política | Comando | Roles | USING | WITH CHECK |\n|---|---|---|---|---|---|\n';
for (const l of pol.split('\n')) { const [t, p, c, r, q, w] = l.split('\t'); db += `| ${t} | ${p} | ${c} | ${r} | \`${(q || '').replace(/\|/g, '/').slice(0, 200)}\` | \`${(w || '').replace(/\|/g, '/').slice(0, 200)}\` |\n`; }
db += '\n## Triggers\n\n| Tabela | Trigger | Evento | Ação |\n|---|---|---|---|\n';
for (const l of trg.split('\n')) { const [t, n, e, a] = l.split('\t'); db += `| ${t} | ${n} | ${e} | \`${a}\` |\n`; }
db += '\n## Funções (schema public)\n\n| Função | Retorno | Linguagem | Segurança |\n|---|---|---|---|\n';
for (const l of fns.split('\n')) { const [n, r, la, s] = l.split('\t'); db += `| ${n} | ${r} | ${la} | ${s} |\n`; }
db += '\n## Buckets de storage\n\n| Bucket | Público | Limite | MIME permitidos |\n|---|---|---|---|\n';
for (const l of buckets.split('\n')) { const [b, p, li, m] = l.split('\t'); db += `| ${b} | ${p} | ${li} | ${m} |\n`; }
fs.writeFileSync(path.join(A, 'esquema-banco.md'), db);
console.log('esquema-banco.md:', pol.split('\n').length, 'políticas,', trg.split('\n').length, 'triggers,', buckets.split('\n').length, 'buckets');

// 4) questionário
fs.writeFileSync(path.join(A, 'questionario.json'), JSON.stringify({ grupos: QUESTIONNAIRE, passos: STEPS }, null, 2));
let q = `# Questionário de recomendação — ${STEPS.length} passos (após flattenQuestions; q2_8 vira q2_8a–d)\n\n| # | id | Grupo | Tipo | Pergunta | Opções (valor → rótulo) | Condicional | Multi |\n|---|---|---|---|---|---|---|---|\n`;
STEPS.forEach((s, i) => {
  const opts = s.options.map(o => `\`${o.value}\` → ${o.label}`).join('<br>');
  const cond = s.showIf ? `só se \`${s.showIf.questionId}\` ∈ {${s.showIf.values.join(', ')}}` : '';
  q += `| ${i + 1} | \`${s.id}\` | ${s.group} · ${s.groupLabel} | ${s.type} | ${s.text}${s.helpText ? `<br><em>${s.helpText}</em>` : ''} | ${opts} | ${cond} | ${s.multiSelect ? 'até 2' : ''} |\n`;
});
fs.writeFileSync(path.join(A, 'questionario.md'), q);
console.log('questionario.md:', STEPS.length, 'passos');
