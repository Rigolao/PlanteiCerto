// Cria as 4 contas demo (confirmadas) e promove o admin. Idempotente.
import { ACCOUNTS } from '../harness/config.mjs';
import { adminCreateUser, sql } from '../harness/supa.mjs';

for (const [key, a] of Object.entries(ACCOUNTS)) {
  const r = await adminCreateUser(a);
  console.log(`${key}: ${r.created ? 'criado' : 'já existia'} ${r.user?.id ?? '(sem id!)'}`);
}
sql(`update public.profiles set role='admin' where email='${ACCOUNTS.admin.email}'`);
sql(`update public.profiles set role='user' where email<>'${ACCOUNTS.admin.email}'`);
console.log(sql(`select email||' | '||role||' | '||coalesce(nome,'?') from public.profiles order by email`));
