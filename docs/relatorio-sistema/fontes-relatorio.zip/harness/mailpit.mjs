// Mailpit local (todos os e-mails de auth caem aqui).
import { MAILPIT } from './config.mjs';

export async function listMessages(query) {
  const url = query ? `${MAILPIT}/api/v1/search?query=${encodeURIComponent(query)}&limit=50` : `${MAILPIT}/api/v1/messages?limit=50`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`mailpit ${url} -> ${res.status}`);
  return (await res.json()).messages || [];
}

export async function getMessage(id) {
  const res = await fetch(`${MAILPIT}/api/v1/message/${id}`);
  if (!res.ok) throw new Error(`mailpit message ${id} -> ${res.status}`);
  return res.json();
}

/** Última mensagem enviada para `email` (aguarda até timeoutMs). Retorna {summary, message, links}. */
export async function waitForMessageTo(email, { timeoutMs = 20000, sinceMs = Date.now() - 60000 } = {}) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeoutMs) {
    const msgs = await listMessages(`to:"${email}"`);
    const fresh = msgs.filter(m => new Date(m.Created).getTime() >= sinceMs)
      .sort((a, b) => new Date(b.Created) - new Date(a.Created));
    if (fresh.length) {
      const message = await getMessage(fresh[0].ID);
      return { summary: fresh[0], message, links: extractLinks(message) };
    }
    await new Promise(r => setTimeout(r, 1000));
  }
  throw new Error(`Nenhum e-mail para ${email} em ${timeoutMs} ms`);
}

export function extractLinks(message) {
  const src = `${message.HTML || ''}\n${message.Text || ''}`;
  const links = [...src.matchAll(/https?:\/\/[^\s"'<>)]+/g)].map(m => m[0].replace(/&amp;/g, '&'));
  return [...new Set(links)];
}

/** Link de verificação do GoTrue (confirm signup / recovery). */
export function verifyLink(links) {
  return links.find(l => /\/auth\/v1\/verify\?/.test(l)) || links.find(l => /token/.test(l)) || null;
}
