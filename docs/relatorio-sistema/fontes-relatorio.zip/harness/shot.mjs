// Helper de captura compartilhado por todos os agentes (Playwright 1.62, Chromium do cache).
import { chromium } from 'playwright';
import fs from 'node:fs';
import path from 'node:path';
import { ROOT, BASE, ACCOUNTS, VIEWPORTS, DIRS } from './config.mjs';
import { record, flush, setAgent } from './manifest.mjs';

export { setAgent };
let browser;

export async function launch() {
  browser ??= await chromium.launch({
    headless: true,
    args: ['--force-color-profile=srgb', '--font-render-hinting=none', '--disable-lcd-text', '--hide-scrollbars'],
  });
  return browser;
}

/**
 * Novo contexto isolado.
 *  theme: 'light' | 'dark'      viewport: 'desktop' | 'mobile'
 *  auth: 'none' | 'user' | 'projetista' | 'admin' | 'colega'  (usa state/<auth>.json)
 *  gate: true => pula a tela de proteção (localStorage ip_unlocked); false => mostra o gate
 */
export async function newContext({ theme = 'light', viewport = 'desktop', auth = 'none', gate = true, agent, geolocation } = {}) {
  if (agent) setAgent(agent);
  const statePath = path.join(DIRS.state, `${auth}.json`);
  if (auth !== 'none' && !fs.existsSync(statePath)) throw new Error(`storageState ausente: ${statePath} (rode setup/04-login-states.mjs)`);
  const ctx = await (await launch()).newContext({
    ...VIEWPORTS[viewport],
    locale: 'pt-BR',
    timezoneId: 'America/Sao_Paulo',
    colorScheme: theme === 'dark' ? 'dark' : 'light',
    reducedMotion: 'reduce',
    serviceWorkers: 'block',
    acceptDownloads: true,
    storageState: auth === 'none' ? undefined : statePath,
    ...(geolocation ? { geolocation, permissions: ['geolocation'] } : {}),
  });
  await ctx.addInitScript(([g, t]) => {
    try {
      if (!location.origin.startsWith('http')) return;
      if (g) localStorage.setItem('ip_unlocked', 'true'); else localStorage.removeItem('ip_unlocked');
      localStorage.setItem('planteicerto-ui-theme', t);
    } catch {}
  }, [gate, theme]);
  ctx.setDefaultTimeout(20000);
  ctx.__meta = { theme, viewport, auth, agent: agent ?? null };
  return ctx;
}

export async function goto(page, route, { waitFor, settle = 400, timeout = 30000 } = {}) {
  await page.goto(BASE + route, { waitUntil: 'domcontentloaded', timeout });
  await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {});
  if (waitFor) await page.waitForSelector(waitFor, { state: 'visible', timeout });
  await waitForImages(page);
  await page.waitForTimeout(settle);
}

export async function waitForImages(page, timeout = 15000) {
  await page.waitForFunction(
    () => [...document.images].every(i => i.complete || i.loading === 'lazy'),
    null, { timeout },
  ).catch(() => {});
}

/** Espera os tiles do Leaflet (Esri) terminarem de carregar. Nunca lança. */
export async function waitForTiles(page, { timeout = 25000, settle = 700 } = {}) {
  await page.waitForFunction(() => {
    const t = document.querySelectorAll('.leaflet-tile');
    return t.length > 0 && [...t].every(i => i.complete && i.naturalWidth > 0);
  }, null, { timeout }).catch(() => {});
  await page.waitForTimeout(settle);
}

function urlInfo(page) {
  try { const u = new URL(page.url()); return u.pathname + u.search; } catch { return ''; }
}

/**
 * Captura e registra no manifesto. NUNCA lança: falha vira status 'failed'.
 * opts: { fullPage, clip, element, waitFor, settle, title, flow, route, mask, allowTall }
 */
export async function shot(page, id, opts = {}) {
  const file = path.join(DIRS.shots, `${id}.png`);
  const meta = {
    id, ...page.context().__meta,
    title: opts.title ?? '', flow: opts.flow ?? '', area: id.replace(/^\d+-/, '').split('-')[0],
    route: opts.route ?? urlInfo(page),
  };
  try {
    if (opts.waitFor) await page.waitForSelector(opts.waitFor, { state: 'visible' });
    await page.waitForTimeout(opts.settle ?? 250);
    if (opts.fullPage && !opts.allowTall && !opts.element) {
      const h = await page.evaluate(() => document.documentElement.scrollHeight);
      if (h > 3200) return shotTall(page, id, { ...opts, height: h, meta });
    }
    const target = opts.element ? page.locator(opts.element).first() : page;
    const buf = await target.screenshot({
      path: file, animations: 'disabled', caret: 'hide', mask: opts.mask,
      ...(opts.element ? {} : { fullPage: !!opts.fullPage, clip: opts.clip }),
    });
    record({ ...meta, file: `shots/${id}.png`, status: 'ok', bytes: buf.length, capturedAt: new Date().toISOString() });
    console.log(`✔ ${id}`);
  } catch (e) {
    record({ ...meta, file: null, status: 'failed', note: String(e.message).slice(0, 300), capturedAt: new Date().toISOString() });
    console.warn(`✘ NÃO CAPTURADO ${id}: ${String(e.message).split('\n')[0]}`);
  }
}

/** Página muito alta: fatia em partes de até 2600px (-p1, -p2, ...). */
async function shotTall(page, id, { height, meta, mask }) {
  const width = page.viewportSize().width;
  const step = 2500, size = 2600;
  const parts = [];
  for (let y = 0, n = 1; y < height; y += step, n++) {
    const pid = `${id}-p${n}`;
    const file = path.join(DIRS.shots, `${pid}.png`);
    const buf = await page.screenshot({ path: file, fullPage: true, animations: 'disabled', caret: 'hide', mask,
      clip: { x: 0, y, width, height: Math.min(size, height - y) } });
    record({ ...meta, id: pid, file: `shots/${pid}.png`, status: 'ok', bytes: buf.length, part: n, capturedAt: new Date().toISOString() });
    parts.push(pid);
    if (n >= 4) break; // limite de segurança
  }
  console.log(`✔ ${id} (fatiado em ${parts.length} partes: ${parts.join(', ')})`);
  return parts;
}

/** Toast do sonner (~4 s): o waiter é criado ANTES da ação. */
export async function shotToast(page, action, id, opts = {}) {
  const wait = page.waitForSelector('[data-sonner-toast]', { timeout: 8000 }).catch(() => null);
  await action();
  await wait;
  await shot(page, id, { settle: 150, ...opts });
}

/** Login pela UI (Header "Entrar" → AuthModal). Usado pelo setup; agentes reutilizam storageState. */
export async function loginUI(page, key) {
  const a = ACCOUNTS[key];
  if (!a) throw new Error(`conta desconhecida: ${key}`);
  await goto(page, '/');
  await page.locator('header button', { hasText: 'Entrar' }).first().click();
  await page.getByPlaceholder('seu@email.com').fill(a.email);
  await page.getByPlaceholder('******').fill(a.password);
  await page.locator('form button[type="submit"]').click();
  await page.waitForSelector('header button:has-text("Entrar")', { state: 'detached', timeout: 20000 });
  await page.waitForTimeout(500);
}

/** Se a sessão expirou (header mostra "Entrar"), refaz login e regrava o state. */
export async function ensureAuth(page, key) {
  if (await page.locator('header button:has-text("Entrar")').count()) {
    await loginUI(page, key);
    await page.context().storageState({ path: path.join(DIRS.state, `${key}.json`) });
  }
}

/** Dispara `trigger` e salva o download em artefatos/<name>. Retorna o caminho. */
export async function captureDownload(page, trigger, name, { timeout = 60000 } = {}) {
  const [dl] = await Promise.all([page.waitForEvent('download', { timeout }), trigger()]);
  const dest = path.join(DIRS.artefatos, name ?? dl.suggestedFilename());
  await dl.saveAs(dest);
  return dest;
}

export async function finish() { flush(); if (browser) { await browser.close(); browser = null; } }
