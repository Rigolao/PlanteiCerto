// Driver data-driven do questionário de recomendação (importa o .ts do repo via type-stripping do Node 22).
import { REPO } from './config.mjs';

const m = await import(`${REPO}/src/data/questionnaire.ts`);
export const QUESTIONNAIRE = m.questionnaire;
export const STEPS = m.flattenQuestions(m.questionnaire);          // 25 passos (q2_8 -> q2_8a..d)
export const byId = Object.fromEntries(STEPS.map(s => [s.id, s]));

/** Passo atualmente exibido (pelo texto da pergunta). */
export async function currentStep(page) {
  const qText = (await page.locator('h3.font-display').first().innerText()).trim();
  const step = STEPS.find(s => s.text.trim() === qText);
  if (!step) throw new Error(`pergunta não reconhecida: "${qText}"`);
  const header = (await page.locator('text=/^Pergunta \\d+ de \\d+$/').first().innerText()).trim();
  return { step, header };
}

/** Clica a(s) opção(ões) do passo atual. values: string | string[] (labels resolvidos do questionário). */
export async function answer(page, step, values) {
  for (const v of [].concat(values)) {
    const opt = step.options.find(o => o.value === v);
    if (!opt) throw new Error(`opção ${v} não existe em ${step.id}`);
    await page.locator('button', { hasText: opt.label }).first().click();
    await page.waitForTimeout(120);
  }
}

export const nextButton = page => page.locator('button', { hasText: /^(Próximo|Ver Resultados)$/ }).last();

/**
 * Percorre o wizard respondendo `answers` ({ q1_1:'calcada', q1_2:['sombra','fauna'], ... }).
 * hooks.beforeAnswer(step, header, page) / hooks.afterAnswer(step, header, page) para capturas.
 * Para no diálogo "Finalizar questionário?" (não confirma) a menos que hooks.confirm === true.
 */
export async function runWizard(page, answers, hooks = {}) {
  for (let guard = 0; guard < 40; guard++) {
    const { step, header } = await currentStep(page);
    await hooks.beforeAnswer?.(step, header, page);
    if (answers[step.id] === undefined) throw new Error(`sem resposta para ${step.id}`);
    await answer(page, step, answers[step.id]);
    await hooks.afterAnswer?.(step, header, page);
    const btn = nextButton(page);
    const last = (await btn.innerText()).includes('Ver Resultados');
    await btn.click();
    await page.waitForTimeout(250);
    if (last) break;
  }
  if (hooks.confirm) {
    await page.locator('button', { hasText: 'Ver Recomendações' }).click();
  }
}

/** Conjunto de respostas "típico" (calçada residencial, sem fiação) — 24 passos visíveis. */
export const ANSWERS_PADRAO = {
  q1_1: 'calcada', q1_2: ['sombra', 'nativas'],
  q2_1: '2_3', q2_2: '1_2', q2_3: 'sim', q2_4: '1_2', q2_5: 'nao', q2_7: 'gt_2',
  q2_8a: 'gt_6', q2_8b: 'gt_4', q2_8c: 'gt_1_5', q2_8d: 'gt_1_5',
  q3_1: 'sol_pleno', q3_2: 'umido', q3_3: 'bom', q3_4: 'sim', q3_5: 'nao', q3_6: 'sim',
  q4_1: 'nao', q4_2: 'sim', q4_3: 'nao', q4_4: 'nao',
  q5_1: 'sim', q5_2: 'sim',
};
/** Com fiação convencional (habilita q2_6) — 25 passos. */
export const ANSWERS_FIACAO = { ...ANSWERS_PADRAO, q2_5: 'sim_convencional', q2_6: 'lt_4' };
/** Zero resultados: guia rebaixada a < 1,5 m elimina todas as espécies. */
export const ANSWERS_ZERO = { ...ANSWERS_PADRAO, q2_8c: 'lt_1_5' };
