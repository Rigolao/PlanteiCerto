// Servidor estático mínimo para o Chromium do build (evita restrições de file://).
// Rotas: /scratch/* -> $SCRATCH ; /pdfjs/* -> $REPO/node_modules/pdfjs-dist
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { ROOT, REPO } from './config.mjs';

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.mjs': 'text/javascript', '.css': 'text/css',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml', '.pdf': 'application/pdf',
  '.json': 'application/json', '.txt': 'text/plain; charset=utf-8', '.md': 'text/markdown; charset=utf-8', '.woff2': 'font/woff2', '.wasm': 'application/wasm' };
const MAP = { '/scratch/': ROOT, '/pdfjs/': path.join(REPO, 'node_modules', 'pdfjs-dist') };

export function startServer(port = 0) {
  return new Promise(resolve => {
    const srv = http.createServer((req, res) => {
      const url = decodeURIComponent(new URL(req.url, 'http://x').pathname);
      const prefix = Object.keys(MAP).find(p => url.startsWith(p));
      if (!prefix) { res.writeHead(404); return res.end('not found'); }
      const file = path.normalize(path.join(MAP[prefix], url.slice(prefix.length)));
      if (!file.startsWith(MAP[prefix]) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404); return res.end('not found'); }
      res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Access-Control-Allow-Origin': '*' });
      fs.createReadStream(file).pipe(res);
    });
    srv.listen(port, '127.0.0.1', () => resolve({ server: srv, base: `http://127.0.0.1:${srv.address().port}`, close: () => new Promise(r => srv.close(r)) }));
  });
}
