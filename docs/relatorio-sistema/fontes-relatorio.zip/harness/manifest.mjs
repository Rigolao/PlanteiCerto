// Manifesto de capturas: uma entrada por screenshot, gravada a cada record() (resiliente a falhas).
import fs from 'node:fs';
import path from 'node:path';
import { DIRS } from './config.mjs';

let agent = 'orq';
let entries = null;

export function setAgent(name) { agent = String(name).toLowerCase(); entries = null; }
function file() { return path.join(DIRS.manifests, `${agent}.json`); }
function load() {
  if (entries) return entries;
  try { entries = JSON.parse(fs.readFileSync(file(), 'utf8')); } catch { entries = []; }
  return entries;
}
export function record(entry) {
  const list = load();
  const i = list.findIndex(e => e.id === entry.id);
  const merged = { agent: agent.toUpperCase(), ...entry };
  if (i >= 0) list[i] = merged; else list.push(merged);
  fs.writeFileSync(file(), JSON.stringify(list, null, 2));
  return merged;
}
export function flush() { if (entries) fs.writeFileSync(file(), JSON.stringify(entries, null, 2)); }
export function all() { return load(); }
