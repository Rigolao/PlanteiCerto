// Gera capitulos/95-indice-de-telas.md a partir dos manifestos (todas as capturas, status e onde são citadas).
import fs from 'node:fs';
import path from 'node:path';
import { ROOT, DIRS } from './config.mjs';

const CAP = process.env.CAP_DIR || path.join(ROOT, 'capitulos');
const entries = [];
for (const m of fs.readdirSync(DIRS.manifests).filter(f => f.endsWith('.json'))) {
  for (const e of JSON.parse(fs.readFileSync(path.join(DIRS.manifests, m), 'utf8'))) entries.push(e);
}
const refs = new Map(); // id -> [capítulos]
for (const f of fs.readdirSync(CAP).filter(f => f.endsWith('.md') && !f.startsWith('95-'))) {
  const md = fs.readFileSync(path.join(CAP, f), 'utf8');
  for (const m of md.matchAll(/\.\.\/shots\/([^)\s]+?)\.png/g)) { const id = m[1]; if (!refs.has(id)) refs.set(id, new Set()); refs.get(id).add(f.replace(/\.md$/, '')); }
}
const ok = entries.filter(e => e.status === 'ok' && !e.id.startsWith('00-')).sort((a, b) => a.id.localeCompare(b.id));
const failed = entries.filter(e => e.status === 'failed').sort((a, b) => a.id.localeCompare(b.id));
const esc = s => String(s ?? '').replace(/\|/g, '/').replace(/\n/g, ' ');
let md = `# Índice de capturas de tela\n\nTabela de todas as capturas realizadas na aplicação em execução (${ok.length} imagens válidas, ${failed.length} tentativas registradas como não capturadas). O identificador é o nome do arquivo de imagem; "Capítulo" indica onde a figura é usada.\n\n| Id | Título | Rota | Viewport / tema | Conta | Capítulo |\n|---|---|---|---|---|---|\n`;
for (const e of ok) md += `| \`${e.id}\` | ${esc(e.title)} | \`${esc(e.route)}\` | ${e.viewport} / ${e.theme} | ${e.auth} | ${[...(refs.get(e.id) || [])].join(', ') || '—'} |\n`;
if (failed.length) {
  md += `\n## Capturas não realizadas\n\n| Id | Motivo registrado | Agente |\n|---|---|---|\n`;
  for (const e of failed) md += `| \`${e.id}\` | ${esc(e.note).slice(0, 160)} | ${e.agent} |\n`;
}
const unref = ok.filter(e => !refs.has(e.id) && !/-p\d+$/.test(e.id));
if (unref.length) md += `\n## Capturas não referenciadas em nenhum capítulo\n\n${unref.map(e => `- \`${e.id}\` — ${esc(e.title)}`).join('\n')}\n`;
fs.writeFileSync(path.join(CAP, '95-indice-de-telas.md'), md);
console.log(`índice: ${ok.length} ok, ${failed.length} failed, ${unref.length} não referenciadas; referências nos capítulos: ${refs.size}`);
