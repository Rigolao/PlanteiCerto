// Helpers para REST (PostgREST), Admin API (GoTrue), Storage e SQL (psql via docker) no Supabase local.
import { execFileSync } from 'node:child_process';
import { API, ANON, SERVICE_ROLE } from './config.mjs';

function headers(extra = {}, key = SERVICE_ROLE) {
  return { apikey: key, Authorization: `Bearer ${key}`, 'Content-Type': 'application/json', ...extra };
}

/** REST com service_role (bypassa RLS). Ex.: rest('/trees?select=id&limit=1') */
export async function rest(pathAndQuery, { method = 'GET', body, prefer, key } = {}) {
  const res = await fetch(`${API}/rest/v1${pathAndQuery}`, {
    method,
    headers: headers(prefer ? { Prefer: prefer } : {}, key),
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let data; try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!res.ok) throw new Error(`REST ${method} ${pathAndQuery} -> ${res.status}: ${text.slice(0, 300)}`);
  return { status: res.status, data, headers: res.headers };
}

/** Mesmo que rest(), mas com a anon key (respeita RLS, visão de visitante). */
export const restAnon = (p, o = {}) => rest(p, { ...o, key: ANON });

/** Admin API: cria usuário confirmado. Idempotente (422/"already" => retorna existente). */
export async function adminCreateUser({ email, password, nome }) {
  const res = await fetch(`${API}/auth/v1/admin/users`, {
    method: 'POST', headers: headers(),
    body: JSON.stringify({ email, password, email_confirm: true, user_metadata: { nome } }),
  });
  const data = await res.json().catch(() => ({}));
  if (res.ok) return { created: true, user: data };
  if (res.status === 422 || /already|exists|registered/i.test(JSON.stringify(data))) {
    const found = await adminFindUser(email);
    return { created: false, user: found };
  }
  throw new Error(`adminCreateUser ${email} -> ${res.status}: ${JSON.stringify(data).slice(0, 300)}`);
}

export async function adminFindUser(email) {
  const res = await fetch(`${API}/auth/v1/admin/users?page=1&per_page=200`, { headers: headers() });
  const data = await res.json();
  return (data.users || []).find(u => u.email?.toLowerCase() === email.toLowerCase()) || null;
}

/** Admin API: altera senha/atributos de um usuário. */
export async function adminUpdateUser(id, attrs) {
  const res = await fetch(`${API}/auth/v1/admin/users/${id}`, { method: 'PUT', headers: headers(), body: JSON.stringify(attrs) });
  if (!res.ok) throw new Error(`adminUpdateUser -> ${res.status}: ${await res.text()}`);
  return res.json();
}

/** Storage: upload (upsert) de um Buffer em bucket/path. */
export async function storageUpload(bucket, objectPath, buffer, contentType) {
  const res = await fetch(`${API}/storage/v1/object/${bucket}/${objectPath}`, {
    method: 'POST',
    headers: { apikey: SERVICE_ROLE, Authorization: `Bearer ${SERVICE_ROLE}`, 'Content-Type': contentType, 'x-upsert': 'true' },
    body: buffer,
  });
  return { ok: res.ok, status: res.status, body: await res.text() };
}

/** SQL direto no Postgres local via docker exec (psql não está instalado no host). */
export function sql(query, { tuplesOnly = true } = {}) {
  const args = ['exec', '-i', 'supabase_db_PlanteiCerto', 'psql', '-U', 'postgres', '-d', 'postgres', '-v', 'ON_ERROR_STOP=1'];
  if (tuplesOnly) args.push('-tA');
  args.push('-c', query);
  return execFileSync('docker', args, { encoding: 'utf8' }).trim();
}

/** Contagem exata de uma tabela/filtro via PostgREST (content-range). */
export async function count(pathAndQuery, key) {
  const res = await fetch(`${API}/rest/v1${pathAndQuery}`, { headers: headers({ Prefer: 'count=exact', Range: '0-0' }, key) });
  const cr = res.headers.get('content-range') || '';
  return Number(cr.split('/')[1] ?? NaN);
}
