// Monta capitulos/*.md em um HTML único (capa + sumário + capítulos) e imprime em PDF via Chromium.
// Env opcionais: CAP_DIR, OUT_NAME (default PlanteiCerto-Relatorio-Sistema), JPEG_Q (82), MAX_W (1400)
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { marked } from 'marked';
import sharp from 'sharp';
import { chromium } from 'playwright';
import { ROOT, REPO, DIRS } from './config.mjs';
import { startServer } from './serve.mjs';

const CAP = process.env.CAP_DIR || path.join(ROOT, 'capitulos');
const OUT = path.join(ROOT, 'out');
const WEB = path.join(ROOT, 'shots-web');
const NAME = process.env.OUT_NAME || 'PlanteiCerto-Relatorio-Sistema';
const JPEG_Q = Number(process.env.JPEG_Q || 82);
const MAX_W = Number(process.env.MAX_W || 1400);
fs.mkdirSync(OUT, { recursive: true }); fs.mkdirSync(WEB, { recursive: true });

// ---------- 1) imagens PNG -> JPEG reduzido ----------
let converted = 0;
for (const f of fs.readdirSync(DIRS.shots).filter(f => f.endsWith('.png'))) {
  const src = path.join(DIRS.shots, f), dst = path.join(WEB, f.replace(/\.png$/, '.jpg'));
  if (fs.existsSync(dst) && fs.statSync(dst).mtimeMs >= fs.statSync(src).mtimeMs) continue;
  const isMobile = /-mobile/.test(f);
  let img = sharp(src);
  const meta = await img.metadata();
  if (!isMobile && meta.width > MAX_W) img = img.resize({ width: MAX_W });
  let buf = await img.flatten({ background: '#ffffff' }).jpeg({ quality: JPEG_Q, mozjpeg: true }).toBuffer();
  if (buf.length > 450_000) buf = await sharp(buf).jpeg({ quality: 70, mozjpeg: true }).toBuffer();
  fs.writeFileSync(dst, buf); converted++;
}
console.log(`imagens convertidas agora: ${converted}; total em shots-web: ${fs.readdirSync(WEB).length}`);

// ---------- 2) Markdown -> HTML ----------
const files = fs.readdirSync(CAP).filter(f => /^\d{2}-.*\.md$/.test(f)).sort();
if (!files.length) throw new Error(`nenhum capítulo em ${CAP}`);
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const slug = s => String(s).replace(/<[^>]+>/g, '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
const usedIds = new Set();
const uniq = id => { let x = id || 'sec', i = 2; while (usedIds.has(x)) x = `${id}-${i++}`; usedIds.add(x); return x; };
const toc = []; const figures = []; const missing = []; let chapter = 0, section = 0, figure = 0, mermaidCount = 0;

marked.use({
  gfm: true, breaks: false,
  renderer: {
    heading({ tokens, depth }) {
      let text = this.parser.parseInline(tokens);
      if (depth <= 2) text = text.replace(/^\s*\d+(?:\.\d+)*\.?\s+(?=\S)/, '').replace(/^\s*\d+(?:\.\d+)+\s+/, '');
      let label = text;
      if (depth === 1) { chapter++; section = 0; label = `${chapter}. ${text}`; }
      else if (depth === 2) { section++; label = `${chapter}.${section} ${text}`; }
      const id = uniq(slug(text));
      if (depth <= 2) toc.push({ depth, id, label });
      return `<h${depth} id="${id}">${label}</h${depth}>\n`;
    },
    image({ href, title, text }) {
      const base = path.basename(href).replace(/\.png$/i, '');
      const jpg = path.join(WEB, `${base}.jpg`);
      figure++;
      const cap = `Figura ${figure} — ${esc(text || title || base)}`;
      if (!fs.existsSync(jpg)) { missing.push(base); return `<figure class="missing"><div class="missing-box">Imagem não disponível: ${esc(base)}</div><figcaption>${cap}</figcaption></figure>`; }
      figures.push(base);
      const port = /-mobile/.test(base) || /pdfgen/.test(base) ? ' portrait' : '';
      return `<figure class="shot${port}"><img src="/scratch/shots-web/${encodeURIComponent(base)}.jpg" alt="${esc(text || base)}" loading="eager"><figcaption>${cap}</figcaption></figure>`;
    },
    code({ text, lang }) {
      if ((lang || '').trim() === 'mermaid') { mermaidCount++; return `<div class="mermaid-wrap"><pre class="mermaid">${esc(text)}</pre></div>\n`; }
      return `<pre class="code"><code>${esc(text)}</code></pre>\n`;
    },
    html({ text }) { return /^<!--/.test(text.trim()) ? '' : text; },
  },
});

let body = '';
const chapterList = [];
for (const f of files) {
  const md = fs.readFileSync(path.join(CAP, f), 'utf8');
  const html = marked.parse(md);
  body += `<section class="chapter" id="cap-${f.slice(0, 2)}" data-file="${esc(f)}">\n${html}\n</section>\n`;
  chapterList.push(f);
}

// ---------- 3) capa + sumário ----------
let gitRev = ''; try { gitRev = execFileSync('git', ['-C', REPO, 'rev-parse', '--short', 'HEAD'], { encoding: 'utf8' }).trim(); } catch {}
let manifestCount = 0; try { for (const m of fs.readdirSync(DIRS.manifests)) manifestCount += JSON.parse(fs.readFileSync(path.join(DIRS.manifests, m), 'utf8')).filter(e => e.status === 'ok').length; } catch {}
const hoje = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
const cover = `
<section class="cover">
  <div class="cover-band"></div>
  <p class="cover-kicker">Documentação técnica e funcional</p>
  <h1 class="cover-title">PlanteiCerto</h1>
  <p class="cover-sub">Relatório do Sistema — telas, fluxos, arquitetura, modelo de dados e algoritmo de recomendação</p>
  <dl class="cover-meta">
    <dt>Aplicação</dt><dd>PlanteiCerto — apoio à escolha e ao planejamento de espécies para arborização urbana</dd>
    <dt>Versão do código</dt><dd>commit <code>${esc(gitRev || 'n/d')}</code> (branch master)</dd>
    <dt>Data de geração</dt><dd>${esc(hoje)}</dd>
    <dt>Capturas de tela</dt><dd>${figures.length} figuras inseridas (${manifestCount} capturas registradas)</dd>
    <dt>Ambiente das capturas</dt><dd>aplicação executada localmente (Vite) com Supabase local (Docker) e dados de demonstração; fotos das espécies servidas pelo storage de produção</dd>
  </dl>
  <p class="cover-note">Este documento foi gerado automaticamente a partir do código-fonte e da execução real da aplicação, para servir de base à redação da dissertação. Descrições textuais acompanham cada captura para permitir leitura sem as imagens.</p>
</section>
<section class="toc">
  <h1 class="toc-title">Sumário</h1>
  <ol class="toc-list">
    ${toc.map(t => `<li class="lvl${t.depth}"><a href="#${t.id}">${t.label}</a></li>`).join('\n    ')}
  </ol>
</section>`;

const CSS = `
@page { size: A4; }
html { font: 10.5pt/1.5 -apple-system, "Helvetica Neue", Helvetica, Arial, sans-serif; color: #1c2820; -webkit-print-color-adjust: exact; print-color-adjust: exact; font-variant-ligatures: none; font-feature-settings: "liga" 0, "clig" 0, "dlig" 0; }
body { margin: 0; }
section.chapter, section.toc { page-break-before: always; break-before: page; }
h1 { font-size: 19pt; color: #1b4d2b; border-bottom: 2px solid #226437; padding-bottom: 4pt; margin: 0 0 12pt; }
h2 { font-size: 14pt; color: #226437; margin: 18pt 0 8pt; break-after: avoid; }
h3 { font-size: 11.5pt; margin: 14pt 0 6pt; break-after: avoid; }
h4 { font-size: 10.5pt; margin: 10pt 0 4pt; }
p { margin: 0 0 7pt; orphans: 3; widows: 3; }
ul, ol { margin: 0 0 7pt; padding-left: 18pt; }
li { margin-bottom: 2pt; }
a { color: #226437; text-decoration: none; }
code { font-family: "SF Mono", Menlo, Consolas, monospace; font-size: 9pt; background: #f1f5f2; padding: 0 2pt; border-radius: 2pt; }
pre.code { background: #f4f6f4; border: 1px solid #dce4de; padding: 6pt 8pt; font-size: 8.2pt; line-height: 1.35; white-space: pre-wrap; word-break: break-word; break-inside: avoid; border-radius: 3pt; }
pre.code code { background: none; padding: 0; font-size: inherit; }
blockquote { margin: 6pt 0; padding: 5pt 10pt; border-left: 3px solid #d97706; background: #fff8ea; color: #5b4300; }
table { border-collapse: collapse; width: 100%; font-size: 8.6pt; margin: 6pt 0 10pt; }
th, td { border: 1px solid #d5ded8; padding: 3pt 5pt; text-align: left; vertical-align: top; }
th { background: #e9f1eb; color: #1b4d2b; }
thead { display: table-header-group; }
tr { break-inside: avoid; }
figure { margin: 10pt 0 12pt; text-align: center; break-inside: avoid; }
figure.shot img { max-width: 100%; max-height: 19.5cm; border: 1px solid #cfd8d2; border-radius: 3pt; box-shadow: 0 1px 3px rgba(0,0,0,.08); }
figure.portrait img { max-height: 18cm; }
figcaption { font-size: 8.5pt; color: #5f6b64; margin-top: 4pt; }
figure.missing .missing-box { border: 1.5px dashed #b45309; color: #92400e; background: #fffbeb; padding: 14pt; font-size: 9pt; }
.mermaid-wrap { text-align: center; margin: 8pt 0 12pt; break-inside: avoid; }
.mermaid-wrap:not(.rotated) svg { max-width: 100%; height: auto; max-height: 18.5cm; }
.mermaid-wrap.rotated svg { max-width: none; max-height: none; }
pre.mermaid { margin: 0; background: none; border: 0; padding: 0; font-family: inherit; }
.fig-note { font-size: 8.5pt; color: #6b7c72; font-style: italic; margin: 6pt 0 2pt; text-align: center; }
.warn { color: #b91c1c; font-size: 9pt; }
hr { border: 0; border-top: 1px solid #dce4de; margin: 12pt 0; }
img { max-width: 100%; }
/* capa */
section.cover { height: 257mm; position: relative; padding-top: 30mm; }
.cover-band { position: absolute; left: -18mm; right: -18mm; top: -20mm; height: 22mm; background: #226437; }
.cover-kicker { text-transform: uppercase; letter-spacing: .12em; font-size: 9pt; color: #6b7c72; margin: 0 0 6pt; }
.cover-title { font-size: 40pt; border: 0; margin: 0 0 8pt; color: #1b4d2b; }
.cover-sub { font-size: 14pt; color: #33463b; margin: 0 0 26pt; max-width: 150mm; line-height: 1.35; }
.cover-meta { display: grid; grid-template-columns: 38mm 1fr; gap: 4pt 10pt; font-size: 10pt; margin: 0 0 22pt; }
.cover-meta dt { color: #6b7c72; } .cover-meta dd { margin: 0; }
.cover-note { font-size: 9.5pt; color: #4b5a51; border-top: 1px solid #dce4de; padding-top: 10pt; max-width: 160mm; }
/* sumário */
.toc-title { border: 0; }
.toc-list { list-style: none; padding: 0; margin: 0; columns: 1; font-size: 9.6pt; }
.toc-list li.lvl1 { font-weight: 700; margin-top: 7pt; }
.toc-list li.lvl2 { margin-left: 14pt; font-weight: 400; }
`;

const html = `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>${esc(NAME)}</title><style>${CSS}</style></head><body>
${cover}
${body}
<script src="/scratch/vendor/mermaid.min.js"></script>
<script>
(async () => {
  window.__mermaidErrors = [];
  try {
    mermaid.initialize({ startOnLoad: false, theme: 'neutral', securityLevel: 'loose', suppressErrorRendering: true,
      themeVariables: { fontFamily: '-apple-system, Helvetica, Arial, sans-serif', fontSize: '16px' },
      flowchart: { useMaxWidth: false, htmlLabels: true, nodeSpacing: 40, rankSpacing: 55, padding: 12 },
      er: { useMaxWidth: false, fontSize: 16, minEntityWidth: 120 },
      sequence: { useMaxWidth: false, actorFontSize: 18, messageFontSize: 16, noteFontSize: 14, width: 190, height: 56, boxMargin: 12, messageMargin: 40, mirrorActors: false },
      class: { useMaxWidth: false }, state: { useMaxWidth: false } });
    for (const n of document.querySelectorAll('pre.mermaid')) {
      try { await mermaid.run({ nodes: [n] }); }
      catch (e) { const msg = String(e && e.message || e); window.__mermaidErrors.push(msg); n.insertAdjacentHTML('beforebegin', '<p class="warn">Diagrama não renderizado: ' + msg.slice(0, 160).replace(/</g, '&lt;') + '</p>'); }
    }
  } catch (e) { window.__mermaidErrors.push(String(e)); }
  // diagramas muito largos: girar 90° para caber legíveis na página (A4 retrato, área útil ~174 x 233 mm)
  for (const svg of document.querySelectorAll('pre.mermaid svg')) {
    let w, h; const vb = svg.getAttribute('viewBox');
    if (vb) { [, , w, h] = vb.split(/[\s,]+/).map(Number); } else { const bb = svg.getBoundingClientRect(); w = bb.width; h = bb.height; }
    if (!w || !h) continue;
    const availW = 657, availH = 860;
    if (w / h > 1.7 && w > availW) {
      const scale = Math.min(availH / w, availW / h);
      const dw = Math.floor(w * scale), dh = Math.floor(h * scale);
      const wrap = svg.closest('.mermaid-wrap'); wrap.classList.add('rotated');
      svg.style.width = dw + 'px'; svg.style.height = dh + 'px'; svg.style.display = 'block';
      svg.style.transform = 'rotate(90deg) translateY(-100%)'; svg.style.transformOrigin = 'top left';
      wrap.style.width = dh + 'px'; wrap.style.height = dw + 'px'; wrap.style.margin = '8pt auto'; wrap.style.overflow = 'hidden';
      wrap.insertAdjacentHTML('beforebegin', '<p class="fig-note">Diagrama a seguir exibido em orientação paisagem (girado 90°) para preservar a legibilidade.</p>');
    }
  }
  window.__mermaidDone = true;
})();
</script>
</body></html>`;
fs.writeFileSync(path.join(OUT, 'relatorio.html'), html);
console.log(`capítulos: ${files.length}; headings no sumário: ${toc.length}; figuras: ${figures.length}; ausentes: ${missing.length}; mermaid: ${mermaidCount}`);
if (missing.length) console.warn('IMAGENS AUSENTES:', missing.join(', '));

// ---------- 4) imprimir ----------
const { base, close } = await startServer();
const browser = await chromium.launch();
const page = await browser.newPage();
const problems = [];
page.on('console', m => { if (m.type() === 'error') problems.push('console: ' + m.text().slice(0, 200)); });
page.on('requestfailed', r => problems.push('requestfailed: ' + r.url()));
await page.goto(`${base}/scratch/out/relatorio.html`, { waitUntil: 'load', timeout: 180000 });
await page.waitForFunction(() => window.__mermaidDone === true, null, { timeout: 180000 });
await page.waitForFunction(() => [...document.images].every(i => i.complete), null, { timeout: 180000 }).catch(() => problems.push('timeout esperando imagens'));
const mermaidErrors = await page.evaluate(() => window.__mermaidErrors);
const badImgs = await page.evaluate(() => [...document.images].filter(i => !i.naturalWidth).map(i => i.getAttribute('src')));
const svgCount = await page.evaluate(() => document.querySelectorAll('pre.mermaid svg, .mermaid-wrap svg').length);
const pdfPath = path.join(OUT, `${NAME}.pdf`);
await page.pdf({
  path: pdfPath, format: 'A4', printBackground: true, outline: true, tagged: true, displayHeaderFooter: true, preferCSSPageSize: false,
  headerTemplate: `<div style="font-family:-apple-system,Helvetica,Arial;font-size:7.5px;width:100%;padding:0 14mm;color:#6b7c72;display:flex;justify-content:space-between"><span>PlanteiCerto — Relatório do Sistema</span><span>Documentação de telas, fluxos e arquitetura</span></div>`,
  footerTemplate: `<div style="font-family:-apple-system,Helvetica,Arial;font-size:7.5px;width:100%;padding:0 14mm;color:#6b7c72;text-align:right">página <span class="pageNumber"></span> de <span class="totalPages"></span></div>`,
  margin: { top: '18mm', bottom: '16mm', left: '18mm', right: '18mm' },
});
await browser.close(); await close();
const size = fs.statSync(pdfPath).size;
console.log(`PDF: ${pdfPath} (${(size / 1048576).toFixed(1)} MB); mermaid renderizados: ${svgCount}/${mermaidCount}; erros mermaid: ${mermaidErrors.length}; imagens quebradas: ${badImgs.length}; problemas: ${problems.length}`);
if (mermaidErrors.length) console.warn('MERMAID:', mermaidErrors.map(e => e.slice(0, 200)).join('\n  '));
if (badImgs.length) console.warn('IMAGENS QUEBRADAS:', badImgs.join(', '));
if (problems.length) console.warn(problems.slice(0, 10).join('\n'));
fs.writeFileSync(path.join(OUT, 'build-info.json'), JSON.stringify({ name: NAME, files, toc, figures, missing, mermaidCount, svgCount, mermaidErrors, badImgs, problems, size, generatedAt: new Date().toISOString() }, null, 2));
