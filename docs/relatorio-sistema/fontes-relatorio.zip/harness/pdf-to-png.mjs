// Rasteriza um PDF (ex.: o relatório jsPDF gerado pelo app) em PNGs via Chromium + pdf.js do repo,
// e extrai o texto por página (Node + pdfjs legacy). Uso: node harness/pdf-to-png.mjs <pdf> <prefixo-id> [scale]
import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { chromium } from 'playwright';
import { ROOT, REPO, DIRS } from './config.mjs';
import { startServer } from './serve.mjs';
import { record, setAgent } from './manifest.mjs';

const [pdfArg, prefix = '39-pdfgen-pagina', scaleArg = '2'] = process.argv.slice(2);
if (!pdfArg) { console.error('uso: node harness/pdf-to-png.mjs <arquivo.pdf> [prefixo-id] [scale]'); process.exit(2); }
const pdfPath = path.resolve(pdfArg);
const rel = path.relative(ROOT, pdfPath);
if (rel.startsWith('..')) throw new Error('o PDF precisa estar dentro do scratchpad');

// 1) texto (Node)
const pdfjs = await import(pathToFileURL(path.join(REPO, 'node_modules/pdfjs-dist/legacy/build/pdf.mjs')).href);
const doc = await pdfjs.getDocument({ data: new Uint8Array(fs.readFileSync(pdfPath)), useSystemFonts: true }).promise;
let text = '';
for (let i = 1; i <= doc.numPages; i++) {
  const tc = await (await doc.getPage(i)).getTextContent();
  text += `\n===== Página ${i} =====\n` + tc.items.map(it => it.str).join(' ').replace(/\s+/g, ' ') + '\n';
}
fs.writeFileSync(pdfPath.replace(/\.pdf$/i, '.txt'), text.trim() + '\n');
console.log(`páginas: ${doc.numPages}; texto salvo em ${path.basename(pdfPath).replace(/\.pdf$/i, '.txt')}`);

// 2) imagens (Chromium + pdf.js servido por HTTP)
const { base, close } = await startServer();
const html = `<!doctype html><meta charset="utf-8"><script type="module">
import * as pdfjs from '/pdfjs/build/pdf.mjs';
pdfjs.GlobalWorkerOptions.workerSrc = '/pdfjs/build/pdf.worker.mjs';
window.renderPdf = async (url, scale, only) => {
  const doc = await pdfjs.getDocument({ url }).promise; const out = [];
  for (let i = 1; i <= doc.numPages; i++) {
    if (only && !only.includes(i)) continue;
    const p = await doc.getPage(i); const vp = p.getViewport({ scale });
    const c = document.createElement('canvas'); c.width = vp.width; c.height = vp.height;
    await p.render({ canvasContext: c.getContext('2d'), viewport: vp }).promise;
    out.push([i, c.toDataURL('image/png')]);
  }
  return out;
};
window.__ready = true;
</script>`;
const tmp = path.join(DIRS.logs, 'pdfjs-render.html');
fs.writeFileSync(tmp, html);
const browser = await chromium.launch();
const page = await browser.newPage();
page.on('console', m => { if (m.type() === 'error') console.warn('[browser]', m.text()); });
await page.goto(`${base}/scratch/logs/pdfjs-render.html`);
await page.waitForFunction(() => window.__ready === true, null, { timeout: 30000 });
const only = process.env.PAGES ? process.env.PAGES.split(',').map(Number) : null;
const urls = await page.evaluate(([u, s, o]) => window.renderPdf(u, s, o), [`${base}/scratch/${rel.split(path.sep).join('/')}`, Number(scaleArg), only]);
setAgent('orq');
urls.forEach(([pageNo, u]) => {
  const id = `${prefix}-${pageNo}`;
  const file = path.join(DIRS.shots, `${id}.png`);
  fs.writeFileSync(file, Buffer.from(u.split(',')[1], 'base64'));
  if (!process.env.NO_MANIFEST) record({ id, file: `shots/${id}.png`, area: 'pdfgen', flow: 'relatorio-pdf', route: '(arquivo PDF gerado pelo app)', title: `Relatório PDF gerado pelo app — página ${pageNo}`, viewport: 'pdf', theme: 'light', auth: 'projetista', status: 'ok', bytes: fs.statSync(file).size, capturedAt: new Date().toISOString() });
  console.log(`✔ ${id}`);
});
await browser.close(); await close();
