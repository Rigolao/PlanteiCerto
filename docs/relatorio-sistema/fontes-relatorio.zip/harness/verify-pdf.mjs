// Verifica o PDF final: páginas, tamanho, texto pesquisável, bookmarks, cobertura de capturas e vazamento de segredos.
import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { ROOT, REPO, DIRS, GATE, SERVICE_ROLE, ANON } from './config.mjs';

const NAME = process.env.OUT_NAME || 'PlanteiCerto-Relatorio-Sistema';
const CAP = process.env.CAP_DIR || path.join(ROOT, 'capitulos');
const pdfPath = path.join(ROOT, 'out', `${NAME}.pdf`);
const out = [];
const log = (s) => { out.push(s); console.log(s); };
const pdfjs = await import(pathToFileURL(path.join(REPO, 'node_modules/pdfjs-dist/legacy/build/pdf.mjs')).href);
const doc = await pdfjs.getDocument({ data: new Uint8Array(fs.readFileSync(pdfPath)), useSystemFonts: true }).promise;
const size = fs.statSync(pdfPath).size;
log(`Arquivo: ${pdfPath}`);
log(`Páginas: ${doc.numPages} | Tamanho: ${(size / 1048576).toFixed(1)} MB ${size > 40 * 1048576 ? '✘ (>40 MB)' : size > 32 * 1048576 ? '⚠ (>32 MB)' : '✔'}`);

let full = ''; const perPage = [];
for (let i = 1; i <= doc.numPages; i++) {
  const tc = await (await doc.getPage(i)).getTextContent();
  const t = tc.items.map(it => it.str).join(' ').replace(/\s+/g, ' ');
  perPage.push(t.length); full += `\n[p${i}] ` + t;
}
fs.writeFileSync(path.join(ROOT, 'out', 'texto-extraido.txt'), full);
const lowText = perPage.filter(n => n < 200).length;
log(`Texto extraído: ${full.length} caracteres; páginas com < 200 caracteres: ${lowText} (${(100 * lowText / doc.numPages).toFixed(0)}%)`);

const outline = await doc.getOutline();
const countOutline = (items) => (items || []).reduce((n, it) => n + 1 + countOutline(it.items), 0);
log(`Bookmarks (outline): ${outline ? countOutline(outline) : 0} itens, ${outline ? outline.length : 0} de nível 1 ${outline && outline.length >= 10 ? '✔' : '⚠'}`);

const anchors = ['Elementos visíveis', 'Rota:', 'Fluxo passo a passo', 'Sumário'];
for (const a of anchors) log(`Âncora "${a}": ${(full.match(new RegExp(a.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g')) || []).length} ocorrências`);
const uiStrings = ['Confirme seu e-mail', 'Aguardando vinculação', 'Ver Recomendações', 'Acesso restrito a administradores', 'Mostrando', 'Gerenciar Árvores', 'Nenhuma espécie compatível'];
for (const s of uiStrings) log(`String de UI "${s}": ${full.includes(s) ? '✔' : '✘ ausente'}`);

// segredos
const secrets = [];
const add = (label, v) => { if (v && v.length >= 6) secrets.push([label, v]); };
add('gate password', GATE.password); add('service_role', SERVICE_ROLE); add('anon', ANON);
try { for (const l of fs.readFileSync(path.join(REPO, '.env.development'), 'utf8').split('\n')) { const m = l.match(/^(SUPABASE_ACCESS_TOKEN|VITE_SUPABASE_ANON_KEY)=(.+)$/); if (m) add(m[1], m[2].trim().replace(/^"|"$/g, '')); } } catch {}
try { const infra = fs.readFileSync(path.join(REPO, 'INFRAESTRUTURA.md'), 'utf8'); for (const ip of new Set(infra.match(/\b\d{1,3}(?:\.\d{1,3}){3}\b/g) || [])) if (!/^(127\.|0\.0\.0\.0|10\.0\.0\.|172\.1[6-9]\.|192\.168\.)/.test(ip)) add('IP ' + ip, ip); } catch {}
const patterns = [/sbp_[A-Za-z0-9]{10,}/, /eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9\.[A-Za-z0-9._-]{20,}/, /sb_secret_[A-Za-z0-9_-]{8,}/, /BEGIN (RSA|OPENSSH) PRIVATE KEY/, /postgres:[^@\s]{6,}@/];
let leaks = 0;
for (const [label, v] of secrets) if (full.includes(v)) { leaks++; log(`✘ VAZAMENTO: ${label} aparece no texto do PDF`); }
for (const p of patterns) { const m = full.match(p); if (m) { leaks++; log(`✘ PADRÃO SUSPEITO: ${p} → "${m[0].slice(0, 30)}…"`); } }
log(`Segredos: ${leaks ? `${leaks} problema(s) ✘` : 'nenhum encontrado ✔'}`);

// cobertura
const entries = []; for (const m of fs.readdirSync(DIRS.manifests).filter(f => f.endsWith('.json'))) entries.push(...JSON.parse(fs.readFileSync(path.join(DIRS.manifests, m), 'utf8')));
const okIds = new Set(entries.filter(e => e.status === 'ok').map(e => e.id));
const failed = entries.filter(e => e.status === 'failed');
const refIds = new Set(); let chaptersText = '';
for (const f of fs.readdirSync(CAP).filter(f => f.endsWith('.md'))) { const md = fs.readFileSync(path.join(CAP, f), 'utf8'); chaptersText += md; for (const m of md.matchAll(/\.\.\/shots\/([^)\s]+?)\.png/g)) refIds.add(m[1]); }
const refMissingFile = [...refIds].filter(id => !fs.existsSync(path.join(DIRS.shots, `${id}.png`)));
const okUnref = [...okIds].filter(id => !refIds.has(id) && !/-p\d+$/.test(id) && !id.startsWith('00-'));
const failedNoNote = failed.filter(e => !chaptersText.includes(e.id) && !chaptersText.includes('NÃO CAPTURADO'));
log(`Capturas ok: ${okIds.size} | referenciadas nos capítulos: ${refIds.size} | referências sem arquivo: ${refMissingFile.length} | ok não referenciadas: ${okUnref.length} | failed: ${failed.length} (sem menção: ${failedNoNote.length})`);
if (refMissingFile.length) log('  Referências sem arquivo: ' + refMissingFile.join(', '));
if (okUnref.length) log('  Não referenciadas: ' + okUnref.join(', '));
const naoCapt = (chaptersText.match(/NÃO CAPTURADO/g) || []).length;
log(`Marcadores "NÃO CAPTURADO" nos capítulos: ${naoCapt}`);
try { const bi = JSON.parse(fs.readFileSync(path.join(ROOT, 'out', 'build-info.json'), 'utf8')); log(`Build: ${bi.files.length} capítulos, ${bi.figures.length} figuras, ${bi.missing.length} imagens ausentes, mermaid ${bi.svgCount}/${bi.mermaidCount}, erros mermaid ${bi.mermaidErrors.length}, imagens quebradas ${bi.badImgs.length}`); } catch {}
fs.writeFileSync(path.join(ROOT, 'out', 'verificacao.txt'), out.join('\n') + '\n');
