# Apêndice B — Esquema Completo do Banco

Extração feita do banco local (PostgreSQL 17) depois de aplicadas as cinco migrations de `supabase/migrations/` e a carga de `supabase/seed.sql`.

## B.1 Colunas de `public.trees`

As 51 colunas da tabela central, na ordem física. A coluna "Comentário" reproduz os comentários gravados no catálogo do banco pela migration de projeção de 10 anos.

| # | Coluna | Tipo | Nulo? | Default | Comentário |
|---|---|---|---|---|---|
| 1 | `id` | integer | NÃO | `nextval('trees_id_seq'::regclass)` |  |
| 2 | `foto` | text | SIM |  |  |
| 3 | `nome_cientifico` | text | NÃO |  |  |
| 4 | `nome_popular` | text | NÃO |  |  |
| 5 | `origem` | text | NÃO |  |  |
| 6 | `decidua_perenifolia` | text | SIM |  |  |
| 7 | `epoca_floracao` | text | SIM |  |  |
| 8 | `epoca_frutificacao` | text | SIM |  |  |
| 9 | `altura_adulta_max_m` | numeric | SIM |  |  |
| 10 | `porte_altura_classe` | text | SIM |  |  |
| 11 | `diametro_copa_adulto_max_m` | numeric | SIM |  |  |
| 12 | `copa_classe` | text | SIM |  |  |
| 13 | `dap_adulto_max_cm` | numeric | SIM |  |  |
| 14 | `altura_primeira_bifurcacao_m` | text | SIM |  |  |
| 15 | `forma_copa` | text | SIM |  |  |
| 16 | `faixa_serv_min_m_recomendada` | numeric | SIM |  |  |
| 17 | `berco_area_min_m2_recomendada` | numeric | SIM |  |  |
| 18 | `volume_solo_min_m3_recomendado` | numeric | SIM |  |  |
| 19 | `compat_fiacao` | text | SIM |  |  |
| 20 | `potencial_dano_calcada_1a5` | smallint | SIM |  |  |
| 21 | `tolerancia_sol_pleno` | boolean | SIM |  |  |
| 22 | `tolerancia_meia_sombra` | boolean | SIM |  |  |
| 23 | `tolerancia_sombra` | boolean | SIM |  |  |
| 24 | `tolerancia_seca_1a5` | smallint | SIM |  |  |
| 25 | `tolerancia_encharcamento_1a5` | smallint | SIM |  |  |
| 26 | `tolerancia_poluicao_atmosferica_1a5` | smallint | SIM |  |  |
| 27 | `tolerancia_compactacao_solo_1a5` | smallint | SIM |  |  |
| 28 | `tolerancia_ventos_fortes_1a5` | smallint | SIM |  |  |
| 29 | `potencial_sujeira_1a5` | smallint | SIM |  |  |
| 30 | `presenca_espinhos` | boolean | SIM |  |  |
| 31 | `presenca_subst_irritantes` | boolean | SIM |  |  |
| 32 | `atracao_fauna_1a5` | smallint | SIM |  |  |
| 33 | `tolerancia_poda_1a5` | smallint | SIM |  |  |
| 34 | `potencial_sombra_1a5` | smallint | SIM |  |  |
| 35 | `contribuicao_biodiversidade_1a5` | smallint | SIM |  |  |
| 36 | `ativa` | boolean | NÃO | `true` |  |
| 37 | `dap_10a_cm` | numeric | SIM |  | DAP projetado aos 10 anos (cm), cenario boas condicoes, muda inicial 3 cm |
| 38 | `dap_10a_min_cm` | numeric | SIM |  |  |
| 39 | `dap_10a_max_cm` | numeric | SIM |  |  |
| 40 | `altura_10a_m` | numeric | SIM |  | Altura projetada aos 10 anos (m), cenario boas condicoes, muda inicial 1,5 m |
| 41 | `altura_10a_min_m` | numeric | SIM |  |  |
| 42 | `altura_10a_max_m` | numeric | SIM |  |  |
| 43 | `biomassa_aerea_10a_kg` | numeric | SIM |  |  |
| 44 | `carbono_armazenado_10a_kg` | numeric | SIM |  | Carbono na biomassa aerea aos 10 anos (kg C) = biomassa x 0,47 |
| 45 | `co2e_10a_kg` | numeric | SIM |  | CO2 equivalente aos 10 anos (kg) = carbono x 3,6667 |
| 46 | `sobrevivencia_10a_pct` | numeric | SIM |  |  |
| 47 | `co2e_esperado_por_muda_10a_kg` | numeric | SIM |  | CO2e esperado por muda plantada aos 10 anos (kg), ja ponderado pela sobrevivencia |
| 48 | `classe_bvoc` | text | SIM |  | Classe de emissao de compostos organicos volateis biogenicos |
| 49 | `evidencia_bvoc` | text | SIM |  |  |
| 50 | `confianca_bvoc` | text | SIM |  |  |
| 51 | `exibir_aviso_bvoc` | boolean | SIM | `false` | Sinaliza que a classificacao BVOC tem baixa evidencia e merece ressalva na UI |

## B.2 Restrições `CHECK` de `public.trees`

| Constraint | Definição |
|---|---|
| `trees_atracao_fauna_1a5_check` | `CHECK (((atracao_fauna_1a5 >= 1) AND (atracao_fauna_1a5 <= 5)))` |
| `trees_classe_bvoc_check` | `CHECK ((classe_bvoc = ANY (ARRAY['baixo'::text, 'moderado'::text, 'alto'::text, 'desconhecido'::text, 'indeterminado'::text])))` |
| `trees_compat_fiacao_check` | `CHECK ((compat_fiacao = ANY (ARRAY['N'::text, 'A'::text, 'C'::text])))` |
| `trees_confianca_bvoc_check` | `CHECK ((confianca_bvoc = ANY (ARRAY['baixa'::text, 'baixa-média'::text, 'média'::text, 'média-alta'::text])))` |
| `trees_contribuicao_biodiversidade_1a5_check` | `CHECK (((contribuicao_biodiversidade_1a5 >= 1) AND (contribuicao_biodiversidade_1a5 <= 5)))` |
| `trees_copa_classe_check` | `CHECK ((copa_classe = ANY (ARRAY['Grande'::text, 'Média'::text, 'Pequena'::text])))` |
| `trees_decidua_perenifolia_check` | `CHECK ((decidua_perenifolia = ANY (ARRAY['Perenifólia'::text, 'Decídua'::text, 'Semidecídua'::text])))` |
| `trees_origem_check` | `CHECK ((origem = ANY (ARRAY['Nativa BR'::text, 'Exótica'::text])))` |
| `trees_porte_altura_classe_check` | `CHECK ((porte_altura_classe = ANY (ARRAY['Grande'::text, 'Médio'::text, 'Pequeno'::text])))` |
| `trees_potencial_dano_calcada_1a5_check` | `CHECK (((potencial_dano_calcada_1a5 >= 1) AND (potencial_dano_calcada_1a5 <= 5)))` |
| `trees_potencial_sombra_1a5_check` | `CHECK (((potencial_sombra_1a5 >= 1) AND (potencial_sombra_1a5 <= 5)))` |
| `trees_potencial_sujeira_1a5_check` | `CHECK (((potencial_sujeira_1a5 >= 1) AND (potencial_sujeira_1a5 <= 5)))` |
| `trees_sobrevivencia_10a_pct_check` | `CHECK (((sobrevivencia_10a_pct >= (0)::numeric) AND (sobrevivencia_10a_pct <= (100)::numeric)))` |
| `trees_tolerancia_compactacao_solo_1a5_check` | `CHECK (((tolerancia_compactacao_solo_1a5 >= 1) AND (tolerancia_compactacao_solo_1a5 <= 5)))` |
| `trees_tolerancia_encharcamento_1a5_check` | `CHECK (((tolerancia_encharcamento_1a5 >= 1) AND (tolerancia_encharcamento_1a5 <= 5)))` |
| `trees_tolerancia_poda_1a5_check` | `CHECK (((tolerancia_poda_1a5 >= 1) AND (tolerancia_poda_1a5 <= 5)))` |
| `trees_tolerancia_poluicao_atmosferica_1a5_check` | `CHECK (((tolerancia_poluicao_atmosferica_1a5 >= 1) AND (tolerancia_poluicao_atmosferica_1a5 <= 5)))` |
| `trees_tolerancia_seca_1a5_check` | `CHECK (((tolerancia_seca_1a5 >= 1) AND (tolerancia_seca_1a5 <= 5)))` |
| `trees_tolerancia_ventos_fortes_1a5_check` | `CHECK (((tolerancia_ventos_fortes_1a5 >= 1) AND (tolerancia_ventos_fortes_1a5 <= 5)))` |

## B.3 Colunas das demais tabelas

### `public.profiles`

| Coluna | Tipo | Nulo? | Observação |
|---|---|---|---|
| `id` | uuid | NÃO | Chave primária e chave estrangeira para `auth.users(id)` com `ON DELETE CASCADE` |
| `nome` | text | SIM | Preenchido pelo gatilho `handle_new_user()` a partir dos metadados do cadastro |
| `email` | text | SIM | Cópia do e-mail de `auth.users` |
| `role` | text | NÃO | Padrão `'user'`; valores usados pela aplicação: `'user'` e `'admin'` |
| `created_at` | timestamptz | SIM | Padrão `now()` |

Comentário da tabela: "Perfis de usuário com controle de role (user/admin)".

### `public.projects`

| Coluna | Tipo | Nulo? | Observação |
|---|---|---|---|
| `id` | uuid | NÃO | Chave primária, padrão `uuid_generate_v4()` |
| `user_id` | uuid | NÃO | Chave estrangeira para `auth.users(id)` com `ON DELETE CASCADE` |
| `nome` | text | NÃO | Validado no cliente entre 3 e 100 caracteres |
| `descricao` | text | NÃO | Padrão `''`; validado no cliente com até 500 caracteres |
| `centro_lat` | double precision | NÃO | Padrão `-21.1767` |
| `centro_lng` | double precision | NÃO | Padrão `-47.8208` |
| `centro_zoom` | smallint | NÃO | Padrão `14` |
| `created_at` | timestamptz | NÃO | Padrão `now()` |

### `public.points`

| Coluna | Tipo | Nulo? | Observação |
|---|---|---|---|
| `id` | uuid | NÃO | Chave primária, padrão `gen_random_uuid()` |
| `project_id` | uuid | NÃO | Chave estrangeira para `projects(id)` com `ON DELETE CASCADE` |
| `tree_id` | integer | SIM | Chave estrangeira para `trees(id)` com `ON DELETE SET NULL` |
| `lat` | double precision | NÃO | Latitude do plantio |
| `lng` | double precision | NÃO | Longitude do plantio |
| `observacao` | text | NÃO | Padrão `''`; até 300 caracteres pela interface |
| `created_at` | timestamptz | SIM | Padrão `now()`; define a ordem de listagem dos pontos |

### `public.user_favorites`

| Coluna | Tipo | Nulo? | Observação |
|---|---|---|---|
| `id` | uuid | NÃO | Chave primária |
| `user_id` | uuid | NÃO | Chave estrangeira para `auth.users(id)` com `ON DELETE CASCADE` |
| `tree_id` | integer | NÃO | Chave estrangeira para `trees(id)` com `ON DELETE CASCADE` |
| `created_at` | timestamptz | NÃO | Padrão `now()` |

Restrição adicional: `UNIQUE (user_id, tree_id)`.

## B.4 Índices

Todos B-tree: `idx_points_project_id`, `idx_points_tree_id`, `idx_projects_user_id`, `idx_trees_nome_popular`, `idx_trees_origem`, `idx_user_favorites_tree_id`, `idx_user_favorites_user_id`.

## B.5 Funções do esquema `public`

| Função | Retorno | Linguagem | Segurança | Definição resumida |
|---|---|---|---|---|
| `get_my_role()` | text | SQL, `STABLE` | `SECURITY DEFINER` | `SELECT role FROM public.profiles WHERE id = auth.uid()` |
| `handle_new_user()` | trigger | PL/pgSQL | `SECURITY DEFINER` | Insere em `public.profiles` usando `raw_user_meta_data->>'nome'`, depois `->>'full_name'`, depois `split_part(email, '@', 1)` |
| `prevent_role_self_escalation()` | trigger | PL/pgSQL | `SECURITY DEFINER` | Levanta a exceção "Alteração de role não permitida" quando `OLD.role <> NEW.role` e `get_my_role() <> 'admin'` |
| `email_exists(p_email text)` | boolean | SQL, `STABLE`, `search_path = ''` | `SECURITY DEFINER` | `exists(select 1 from auth.users where lower(email) = lower(trim(p_email)))`; execução revogada de `public`, `anon` e `authenticated`, concedida apenas a `service_role` |

## B.6 Gatilhos

| Tabela | Gatilho | Evento | Função |
|---|---|---|---|
| `auth.users` | `on_auth_user_created` | `AFTER INSERT FOR EACH ROW` | `handle_new_user()` |
| `public.profiles` | `enforce_role_protection` | `BEFORE UPDATE FOR EACH ROW` | `prevent_role_self_escalation()` |

## B.7 Políticas de RLS das tabelas públicas

RLS está habilitada nas cinco tabelas. Predicados reproduzidos das definições em `supabase/migrations/20260702000000_baseline_from_prod.sql`, com a formatação compactada em uma linha.

| Tabela | Política | Comando | Predicado (`USING` ou `WITH CHECK`) |
|---|---|---|---|
| `public.trees` | Public read trees | SELECT | `(ativa = true) OR EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')` |
| `public.trees` | Admin insert trees | INSERT | `EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')` |
| `public.trees` | Admin update trees | UPDATE | `EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')` |
| `public.trees` | Admin delete trees | DELETE | `EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')` |
| `public.profiles` | Users can read own profile | SELECT | `auth.uid() = id` |
| `public.profiles` | Users can update own profile | UPDATE | `auth.uid() = id` |
| `public.profiles` | Admins can read all profiles | SELECT | `get_my_role() = 'admin'` |
| `public.profiles` | Admins can update any profile | UPDATE | `get_my_role() = 'admin'` |
| `public.projects` | Users can view own projects | SELECT | `auth.uid() = user_id` |
| `public.projects` | Users can create own projects | INSERT | `auth.uid() = user_id` |
| `public.projects` | Users can update own projects | UPDATE | `auth.uid() = user_id` |
| `public.projects` | Users can delete own projects | DELETE | `auth.uid() = user_id` |
| `public.points` | Users can manage own project points | ALL | `EXISTS (SELECT 1 FROM projects WHERE projects.id = points.project_id AND projects.user_id = auth.uid())` |
| `public.points` | Users can read own project points | SELECT | `EXISTS (SELECT 1 FROM projects WHERE projects.id = points.project_id AND projects.user_id = auth.uid())` |
| `public.points` | Admins can read all points | SELECT | `get_my_role() = 'admin'` |
| `public.user_favorites` | Users can view own favorites | SELECT | `auth.uid() = user_id` |
| `public.user_favorites` | Users can add favorites | INSERT | `auth.uid() = user_id` |
| `public.user_favorites` | Users can remove favorites | DELETE | `auth.uid() = user_id` |

Os `GRANT` do esquema concedem `ALL` sobre tabelas, sequências e funções a `anon`, `authenticated` e `service_role`; o controle efetivo é exercido pelas políticas acima.

## B.8 Buckets e políticas de armazenamento

| Bucket | Público | Conteúdo |
|---|---|---|
| `avatars` | Sim | Fotos de perfil, gravadas em `{user_id}/{uuid}.{ext}` |
| `criterios` | Sim | Os dois PDFs de parametrização da página "Quem Somos" |
| `guias` | Sim | Os dez guias de arborização em PDF |
| `tree-images` | Sim | Fotos das espécies enviadas pelo painel administrativo |

| Bucket | Política | Comando | Quem pode |
|---|---|---|---|
| `tree-images` | Public read tree images | SELECT | Qualquer um |
| `tree-images` | Admin upload tree images | INSERT | Administradores (subconsulta em `profiles`) |
| `tree-images` | Admin update tree images | UPDATE | Administradores |
| `tree-images` | Admin delete tree images | DELETE | Administradores |
| `avatars` | public_avatars | SELECT | Qualquer um |
| `avatars` | insert_avatars | INSERT | Papel `authenticated` |
| `avatars` | update_avatars | UPDATE | Papel `authenticated` |
| `avatars` | delete_avatars | DELETE | Papel `authenticated` |
| `guias` | Public Read Guias | SELECT | Qualquer um |
| `guias` | Temp Public Insert Guias | INSERT | Qualquer um, sem autenticação — ver capítulo de limitações |

O bucket `criterios` não tem política de escrita: apenas `service_role`, que ignora RLS, consegue gravar nele. O checklist pós-restauração documentado em `INFRAESTRUTURA.md` espera exatamente **1 gatilho** em `auth.users` e **10 políticas** em `storage.objects`.

## B.9 Migrations e carga inicial

| Arquivo | Data | Conteúdo |
|---|---|---|
| `20260702000000_baseline_from_prod.sql` | 2026-07-02 | Extensões, cinco tabelas, índices, três funções, gatilho `enforce_role_protection`, RLS e políticas |
| `20260702000001_auth_storage_from_prod.sql` | 2026-07-02 | Gatilho `on_auth_user_created`, quatro buckets e dez políticas de `storage.objects` |
| `20260702000002_email_exists_rpc.sql` | 2026-07-02 | Função `email_exists` com concessão restrita a `service_role` |
| `20260802000000_add_projecao_10a_to_trees.sql` | 2026-08-02 | 15 colunas de projeção, 3 novas restrições `CHECK`, comentários com as fórmulas e carga de 149 linhas |
| `20260908000000_apply_lorenzi_v1_validated_structure.sql` | 2026-09-08 | 23 correções de altura com porte e 13 de hábito foliar, guardadas por valor esperado |

Carga inicial: `supabase/seed.sql`, um único `INSERT INTO public.trees` com 51 colunas e 167 linhas, seguido de `setval('trees_id_seq', 198, true)`. Migrations antigas estão arquivadas em `supabase/_archive/` e não são executadas.
