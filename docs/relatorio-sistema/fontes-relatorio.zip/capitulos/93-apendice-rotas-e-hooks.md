# Apêndice D — Rotas, Hooks, Funções de Borda e Variáveis de Ambiente

## D.1 Rotas

Declaradas em `src/App.tsx:41-62`. Todas as páginas são carregadas sob demanda com `React.lazy` (`src/App.tsx:16-23`), de modo que cada rota corresponde a um pacote JavaScript separado. A árvore inteira está envolvida por `ErrorBoundary` e, dentro dele, por `IPProtectionGate`.

| Rota | Componente de página | Arquivo | Guarda | Layout |
|---|---|---|---|---|
| `/` | `TreesPage` | `src/pages/TreesPage.tsx` | nenhuma (pública) | `Layout` (cabeçalho comum) |
| `/quem-somos` | `AboutPage` | `src/pages/AboutPage.tsx` | nenhuma (pública) | `Layout` |
| `/recomendacao` | `RecommendationPage` | `src/pages/RecommendationPage.tsx` | nenhuma (pública); os resultados exigem Supabase configurado | `Layout` |
| `/projetos` | `ProjectsPage` | `src/pages/ProjectsPage.tsx` | `ProtectedRoute` | `Layout` |
| `/perfil` | `ProfilePage` | `src/pages/ProfilePage.tsx` | `ProtectedRoute` | `Layout` |
| `/reset-password` | `ResetPasswordPage` | `src/pages/ResetPasswordPage.tsx` | `ProtectedRoute` (acessada pelo link enviado por e-mail) | `Layout` |
| `/admin/arvores` | `AdminTreesPage` | `src/pages/AdminTreesPage.tsx` | `AdminRoute` | `AdminLayout` (barra lateral própria) |
| `/admin/equipe` | `AdminUsersPage` | `src/pages/AdminUsersPage.tsx` | `AdminRoute` | `AdminLayout` |
| qualquer outra | — | — | — | **Não existe rota curinga**: a URL não corresponde a nada e a página fica em branco |

Comportamento dos guardas:

| Guarda | Arquivo | Enquanto carrega | Sem sessão | Sem permissão |
|---|---|---|---|---|
| `ProtectedRoute` | `src/components/auth/ProtectedRoute.tsx` | Indicador "Carregando..." | `Navigate` para `/` preservando `state.from` | não se aplica |
| `AdminRoute` | `src/components/auth/AdminRoute.tsx` | "Verificando permissões..." enquanto sessão ou perfil carregam | `Navigate` para `/` com `state.from` | Aviso único "Acesso restrito a administradores." e `Navigate` para `/` |

Além das rotas, `src/App.tsx:64-67` monta globalmente o `Toaster` do `sonner` em `bottom-center` com cores semânticas, o `InstallPWABanner` e os dois componentes de telemetria da Vercel.

Divisão manual de pacotes em `vite.config.ts:10-14`: `vendor-map` (`leaflet`, `react-leaflet`), `vendor-pdf` (`jspdf`, `html2canvas`) e `vendor-react` (`react`, `react-dom`, `react-router-dom`).

## D.2 Hooks de dados

Configuração global do `QueryClient` em `src/main.tsx:11-22`: `staleTime` de 5 minutos, `gcTime` de 10 minutos, `retry: 1` para consultas e mutações, `refetchOnWindowFocus: false`.

| Hook | Arquivo | Tipo | Operação | Chave de cache | `staleTime` | Habilitado quando | Comportamento em falha |
|---|---|---|---|---|---|---|---|
| `useTrees` | `src/hooks/useTrees.ts` | consulta | `trees.select('*').order('id')` | `['trees']` | 15 min | sempre | Devolve as 22 espécies de `src/data/trees.ts` em erro, dado nulo ou lista vazia |
| `useRecommendation` | `src/hooks/useRecommendation.ts` | mutação | `functions.invoke('recommend-trees', { body: { answers } })` | — | — | sempre | Lança `Error`; sem Supabase, lança "Supabase não está configurado" |
| `useProfile` | `src/hooks/useProfile.ts` | consulta | `profiles.select('*').eq('id', user.id).single()` | `['profile', user?.id]` | 5 min | `!!user && isSupabaseConfigured()` | Registra no console e devolve `null` |
| `useFavorites` | `src/hooks/useFavorites.ts` | consulta + mutação | `user_favorites.select('tree_id')`; alternância com `insert`/`delete` | `['favorites', user?.id]` | 5 min | `!!user && isSupabaseConfigured()` | Atualização otimista com reversão em `onError` e invalidação em `onSettled` |
| `useProjects` | `src/hooks/useProjects.ts` | consulta + 4 mutações | `projects.select('*, points(count)')`; `createProject`, `updateProject`, `deleteProject`, `updateMapCenter` | `['projects', user?.id]` | padrão (5 min) | `!!user` | Avisos via `sonner` em criar, editar e excluir; `updateMapCenter` falha em silêncio |
| `useProjectPoints` | `src/hooks/useProjectPoints.ts` | estado local | `points.select('*').eq('project_id')` com `addPoint`, `updatePoint`, `removePoint` | não usa React Query | — | `projectId` não nulo | Mantém o estado anterior; avisos via `sonner` |
| `useAdminUsers` | `src/hooks/useAdminUsers.ts` | consulta | `profiles.select('*').order('created_at')` | `['admin-users']` | 2 min | `isSupabaseConfigured()` | Aviso de erro e lista vazia |
| `useUpdateRole` | `src/hooks/useAdminUsers.ts` | mutação | `profiles.update({ role }).eq('id', id)` | invalida `['admin-users']` e `['profile']` | — | — | Aviso "Erro ao alterar permissão: …" |
| `useCreateTree` | `src/hooks/useAdminTrees.ts` | mutação | `trees.insert(tree)` | invalida `['trees']` | — | — | Aviso com a mensagem do erro |
| `useUpdateTree` | `src/hooks/useAdminTrees.ts` | mutação | `trees.update(tree).eq('id', id)` | invalida `['trees']` | — | — | Aviso com a mensagem do erro |
| `useDeleteTree` | `src/hooks/useAdminTrees.ts` | mutação | `trees.delete().eq('id', id)` | invalida `['trees']` | — | — | Aviso com a mensagem do erro |
| `useTreeUsageCount` | `src/hooks/useAdminTrees.ts` | consulta | `points` com `count: 'exact', head: true` filtrado por `tree_id` | `['tree-usage', treeId]` | 30 s | `treeId !== null` | Devolve 0 |
| `useUploadTreeImage` | `src/hooks/useAdminTrees.ts` | mutação | `storage.from('tree-images').upload(...)` e `getPublicUrl` | — | — | — | Propaga o erro ao formulário |
| `useTreeFilters` | `src/hooks/useTreeFilters.ts` | puro (memo) | filtro em memória por termo e `FiltroAtributo` | — | — | — | **Código morto**: nenhum importador |

Contextos: `AuthContext` (`src/contexts/AuthContext.tsx`) expõe `user`, `session`, `loading`, `signIn`, `signUp`, `signInWithGoogle`, `resetPassword`, `updatePassword`, `updateProfile` e `signOut`; `ThemeContext` (`src/contexts/ThemeContext.tsx`) expõe `theme` e `setTheme`, com persistência em `localStorage` sob `planteicerto-ui-theme`.

## D.3 Funções de borda

Ambas declaradas com `verify_jwt = false` em `supabase/config.toml:440-444`, isto é, acessíveis sem sessão autenticada.

### `recommend-trees`

Arquivo: `supabase/functions/recommend-trees/index.ts`.

**Requisição** — `POST`, corpo JSON:

```json
{ "answers": { "q1_1": "calcada", "q1_2": "sombra,nativas", "q3_1": "sol_pleno" } }
```

Os valores são sempre cadeias de caracteres; a pergunta de múltipla escolha `q1_2` chega com os valores unidos por vírgula. O método `OPTIONS` é tratado para a negociação de CORS, cuja lista de origens vem de `ALLOWED_ORIGINS` (separada por vírgulas), com `http://localhost:5173` e `http://localhost:4173` como padrão, e resposta acompanhada de `Vary: Origin`.

**Resposta 200** — JSON:

```json
{
  "trees": [
    {
      "id": 145,
      "nome_popular": "Ipê-amarelo",
      "score": 91,
      "scoreBreakdown": [ { "label": "Insolação (sol pleno)", "points": 20, "maxPoints": 20 } ]
    }
  ],
  "eliminated_count": 37,
  "criteriaSummary": { "eliminatory": [], "classificatory": [] }
}
```

Cada item de `trees` é a linha completa da tabela `trees`, incluindo as colunas de projeção de 10 anos, acrescida de `score` (0 a 100) e `scoreBreakdown`.

**Erros** — `400` com `{"error":"Campo \"answers\" é obrigatório"}`; `500` com `{"error":"Erro ao buscar espécies","details":"…"}`; `500` com `{"error":"Erro interno","details":"…"}`.

**Registros estruturados** — `recommendation_request` (com `answers_count`), `recommendation_success` (com `total_trees`, `eliminated_count` e `trees_returned`) e `recommendation_error` (com `reason` em `invalid_input`, `db_query_failed` ou `unhandled_exception`).

### `check-email-exists`

Arquivo: `supabase/functions/check-email-exists/index.ts`.

**Requisição** — `POST` com `{ "email": "pessoa@exemplo.com" }`.

**Resposta 200** — `{ "exists": true }` ou `{ "exists": false }`.

**Erros** — `403` "Origem não autorizada." (verificação de origem feita no servidor, porque o gateway pode sobrescrever os cabeçalhos de CORS); `429` "Muitas tentativas. Aguarde um minuto."; `400` "E-mail inválido." ou "Requisição inválida."; `500` "Erro ao verificar e-mail.".

**Comportamento** — limite de 10 requisições por minuto por IP, mantido em memória do processo e perdido a cada reinício a frio; validação de formato e de comprimento máximo de 320 caracteres; consulta por `rpc('email_exists', { p_email })` com cliente de chave de serviço, sem persistir sessão.

## D.4 Variáveis de ambiente, por nome

Nenhum valor é reproduzido aqui. Os nomes abaixo foram obtidos por busca dos acessos a `import.meta.env` em `src/` e a `Deno.env.get` em `supabase/functions/`.

| Variável | Onde é lida | Papel |
|---|---|---|
| `VITE_SUPABASE_URL` | `src/lib/supabase.ts:3`, `src/pages/AboutPage.tsx` | Endereço da API do Supabase; também compõe as URLs públicas dos PDFs no Storage |
| `VITE_SUPABASE_ANON_KEY` | `src/lib/supabase.ts:4` | Chave pública do cliente; junto com a anterior determina `isSupabaseConfigured()` |
| `VITE_GATE_PASSWORD` | `src/components/auth/IPProtectionGate.tsx:19` | Senha do portão de proteção intelectual; por ser `VITE_`, é embutida no pacote entregue ao navegador |
| `SUPABASE_URL` | `supabase/functions/*/index.ts` | Endereço interno usado pelas funções de borda |
| `SUPABASE_SERVICE_ROLE_KEY` | `supabase/functions/*/index.ts` | Chave de serviço usada pelas funções de borda; ignora RLS |
| `ALLOWED_ORIGINS` | `supabase/functions/recommend-trees/index.ts:3` | Lista de origens aceitas pelo CORS, separadas por vírgula |

Em desenvolvimento, as três variáveis `VITE_` devem ficar em `.env.development.local`, porque o Vite dá precedência a `.env.development` sobre `.env.local` (`DESENVOLVIMENTO.md`). Todos os arquivos `.env*` são excluídos pelo `.gitignore` e nenhum está versionado. Em produção, as variáveis `VITE_` são definidas no painel da Vercel e as demais no arquivo de ambiente da VPS.
