# Editor de projeto — mapa, pontos e estatísticas

Abrir um projeto na lista substitui a página inteira pelo **editor de projeto**: um painel fixo (`fixed inset-0 top-16`, ou seja, colado abaixo do cabeçalho do site) que combina um mapa de satélite com a lista dos pontos de plantio. É nele que o usuário marca onde cada muda será plantada, vincula uma espécie do catálogo a cada marca, revisa o resumo ambiental e gera o relatório em PDF.

Arquivos-fonte: `src/components/projects/ProjectEditor.tsx` (orquestra tudo), `PointsPanel.tsx`, `PointActionsMenu.tsx`, `TreeSelectionDialog.tsx`, `ProjectStatsModal.tsx`, `BottomSheet.tsx`, `src/components/map/{ProjectMap,MapClickHandler,MapSearchBox,MyLocationButton,TreeMarker}.tsx` e o hook `src/hooks/useProjectPoints.ts`.

**Estrutura da tela**

- **Barra superior do editor:** botão de voltar (seta à esquerda), nome do projeto, linha de resumo "N árvores · N espécies" e, à direita, os botões "Estatísticas" (ícone de barras) e "Relatório" (ícone de documento). Ambos ficam a 40% de opacidade e desabilitados enquanto o projeto não tiver **nenhum ponto salvo**.
- **Desktop (≥ 1024 px):** mapa ocupando toda a largura disponível à esquerda e o `PointsPanel` fixo de 340 px à direita, separados por uma borda.
- **Mobile (< 1024 px):** mapa em tela cheia e o mesmo painel dentro de uma folha inferior arrastável (`BottomSheet`) com três paradas: 150 px, 50% e 90% da altura.
- **Importante para quem lê o DOM:** os dois layouts são renderizados simultaneamente (um deles apenas escondido por CSS). Portanto existem sempre duas instâncias do mapa e duas do painel na página.

**Camadas do mapa.** São duas camadas Esri sobrepostas: `World_Imagery` (a imagem de satélite) e `World_Boundaries_and_Places` com opacidade 0,7 (os rótulos de ruas, bairros e pontos de referência que aparecem em branco sobre a imagem). A atribuição "© Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community" fica no rodapé do mapa. O zoom máximo é 18 (padrão do Leaflet para essas camadas): ao chegar lá o botão "+" fica cinza e desabilitado.

**Agrupamento de marcadores.** Os pinos são renderizados dentro de um `MarkerClusterGroup` (`maxClusterRadius: 50`). Com os seis pontos do projeto de demonstração, espaçados cerca de 25 m entre si ao longo da mesma calçada, o agrupamento **não se desfaz nem no zoom máximo**: o usuário vê bolhas verdes numeradas e precisa clicar em uma delas para que os pinos individuais se abram em leque. O agrupamento só é desligado durante a geração do PDF (`disableClustering`), para que o mapa impresso mostre todas as espécies.

**Persistência silenciosa do enquadramento.** Qualquer pan/zoom dispara `moveend` → `updateMapCenter`, que grava `centro_lat`, `centro_lng` e `centro_zoom` no projeto. Não há aviso visual disso. Ao reabrir, o `MapBoundsFitter` ainda reenquadra automaticamente para conter todos os pontos (com `maxZoom: 16`); com um único ponto, centraliza nele no zoom 16.

**Não existe arrastar marcador.** O código não define `draggable` nos pinos: para mudar um ponto de lugar é preciso removê-lo e criar outro.

---

### Editor de um projeto sem pontos

![Editor com mapa de satélite e painel vazio](../shots/32-editor-vazio.png)

**Rota:** `/projetos` → clique na linha "Praça Sete de Setembro (em planejamento)" · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Barra do editor: seta de voltar, "Praça Sete de Setembro (em planejamento)" e, abaixo, "0 árvores · 0 espécies". À direita, "Estatísticas" e "Relatório" **esmaecidos** (desabilitados).
- Mapa de satélite de Ribeirão Preto com rótulo "Subsetor Oeste-1" sobre a imagem; controles "+/−" no canto superior esquerdo; caixa de busca arredondada "Buscar endereço, CEP ou cidade..." no topo central; botão circular de GPS (alvo) no canto superior direito.
- Faixa escura translúcida na base do mapa: "Clique no mapa para adicionar um ponto de plantio".
- Painel à direita: cabeçalho com ícone de pinheiro, "Pontos do Projeto" e o contador "0 salvos"; no centro, círculo verde-claro com pinheiro, "**Nenhuma árvore plantada ainda**" e "Clique no mapa para adicionar pontos de plantio ao seu projeto.".

**Ações possíveis / o que acontece:**
- Clicar em qualquer lugar do mapa cria um **ponto pendente** (ainda não salvo).
- "Estatísticas" e "Relatório" não respondem enquanto não houver pontos salvos.
- A seta de voltar retorna à lista de projetos.

**Estados relacionados:** `32-editor-ponto-pendente`, `34-editor-split`

---

### Dashboard de um projeto vazio

**NÃO CAPTURADO:** o `ProjectStatsModal` possui um estado vazio previsto no código ("Nenhuma árvore plantada ainda" / "Adicione pontos no mapa para ver as estatísticas.", com ícone de árvore em um cartão tracejado), mas ele é **inalcançável pela interface**: o único botão que abre o modal é desabilitado exatamente quando `points.length === 0`. Tentativas de acionar o botão por script foram bloqueadas pelo React, que ignora eventos de clique em elementos cujo `disabled` está definido nas props. Vale registrar como código morto na prática — o mesmo acontece com o trecho do PDF que trataria de um projeto sem pontos.

---

### Ponto pendente, aguardando vinculação

![Pino âmbar Pendente no mapa e seção Aguardando vinculação no painel](../shots/32-editor-ponto-pendente.png)

**Rota:** `/projetos` → editor → clique no mapa · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- No ponto clicado do mapa, um pino **âmbar** com o rótulo "Pendente" e a pontinha triangular apontando para a coordenada.
- No painel, acima da lista, uma faixa amarela com o título em maiúsculas "AGUARDANDO VINCULAÇÃO" e, dentro dela, um cartão claro com ícone de alfinete, o rótulo "Ponto #1" e dois botões: "Descartar" (texto discreto) e "**Vincular**" (botão âmbar preenchido).
- O contador do painel continua "0 salvos" e o cabeçalho do editor continua "0 árvores · 0 espécies" — **pontos pendentes não contam**, e por isso os botões "Estatísticas"/"Relatório" seguem desabilitados.

**Ações possíveis / o que acontece:**
- "Vincular" → abre o diálogo "Selecionar Árvore".
- "Descartar" → remove o pino pendente imediatamente, sem confirmação e sem toast (verificado: a seção some da tela).
- Novos cliques no mapa acumulam pontos pendentes ("Ponto #2", "Ponto #3"…).
- Passar o mouse sobre o pino âmbar mostra o tooltip "Ponto Pendente: Vincule uma árvore na lista" (definido em `TreeMarker.tsx`).
- Tentar sair com pontos pendentes dispara um `window.confirm` nativo com o texto **"Você tem pontos pendentes que não foram salvos. Certeza que deseja sair?"** — confirmado na execução. Diálogos nativos não aparecem em captura de tela; cancelando, permanece-se no editor.

**Estados relacionados:** `33-editor-dialogo-fechado`, `33-editor-toast-adicionada`

---

### Diálogo "Selecionar Árvore" — estado inicial

![Diálogo Selecionar Árvore com campos vazios](../shots/33-editor-dialogo-fechado.png)

**Rota:** editor → "Vincular" · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Caixa centralizada sobre fundo escurecido com desfoque. Cabeçalho: "**Selecionar Árvore**" e a linha de apoio "Escolha a espécie para este ponto no mapa"; "×" à direita.
- Campo de busca com lupa e placeholder "Buscar por nome ou espécie..." (combobox, `aria-expanded=false`).
- Bloco "OBSERVAÇÃO (opcional)" com textarea de placeholder "Comentário sobre esta muda ou local..." e contador "0/300".
- Rodapé com "Cancelar" e "**Confirmar Seleção**" — este último **desabilitado** (cinza) enquanto nenhuma espécie estiver escolhida.

**Ações possíveis / o que acontece:**
- Clicar/focar o campo abre a lista de espécies; setas ↑/↓ navegam, Enter escolhe, Esc fecha a lista.
- "Cancelar", "×" ou clique fora fecham o diálogo — o ponto pendente continua no mapa.

**Estados relacionados:** `33-editor-dropdown`, `33-editor-especie-selecionada`

---

### Lista de espécies aberta

![Dropdown com miniaturas de espécies](../shots/33-editor-dropdown.png)

**Rota:** editor → "Vincular" → foco no campo de busca · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Lista suspensa (role `listbox`) logo abaixo do campo, com rolagem própria (altura máxima ~256 px). Cada item traz **miniatura quadrada da foto**, nome popular em destaque e nome científico em itálico: "Oiti / *Licania tomentosa*", "Resedá extremosa / *Lagerstroemia indica*", "Pata-de-vaca / *Bauhinia forficata*", "Sabão-de-soldado / *Sapindus saponaria*", "Uvaia…".
- Foram contadas **146 opções** — exatamente as espécies ativas do catálogo (as inativas só aparecem se já estiverem vinculadas ao ponto em edição).
- O item sob o cursor recebe fundo verde-claro.

**Ações possíveis / o que acontece:**
- Clicar em um item seleciona a espécie, fecha a lista e limpa o texto digitado.
- Digitar filtra por nome popular **ou** científico (busca por substring, sem acento-insensibilidade).

**Estados relacionados:** `33-editor-busca-vazia`, `33-editor-especie-selecionada`

---

### Busca sem resultados

![Dropdown exibindo Nenhuma árvore encontrada](../shots/33-editor-busca-vazia.png)

**Rota:** editor → diálogo → digitar termo inexistente ("zzzzz") · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Campo com o texto "zzzzz" e borda verde de foco.
- Lista reduzida a uma única linha centralizada e cinza: "**Nenhuma árvore encontrada**".
- Abaixo, a observação vazia (0/300) e "Confirmar Seleção" ainda desabilitado.

**Ações possíveis / o que acontece:**
- Apagar/alterar o termo repovoa a lista; não há botão de limpar busca.

**Estados relacionados:** `33-editor-dropdown`

---

### Espécie escolhida, com prévia e observação

![Diálogo com a espécie Ipê-amarelo selecionada e observação preenchida](../shots/33-editor-especie-selecionada.png)

**Rota:** editor → diálogo → escolha de espécie · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Campo de busca novamente vazio (o termo é limpo após escolher).
- **Cartão de prévia** com borda esquerda verde: nome "Ipê-amarelo", científico "*Tabebuia chrysotricha*" e um "×" à direita (`title="Remover seleção"`). Nesta captura a miniatura da foto ainda não havia terminado de carregar e aparece em branco.
- Textarea de observação preenchida com "Muda de teste para o relatório — calçada leste." e contador **47/300**.
- "Confirmar Seleção" agora **habilitado** (verde-escuro).

**Ações possíveis / o que acontece:**
- "×" no cartão limpa a seleção e desabilita novamente o botão de confirmar.
- "Confirmar Seleção" grava o ponto em `points` (projeto, espécie, latitude, longitude, observação), remove o pendente correspondente e fecha o diálogo.

**Estados relacionados:** `33-editor-toast-adicionada`, `33-editor-painel-1ponto`

---

### Toast "Árvore adicionada com sucesso!"

![Toast verde de árvore adicionada, com o mapa reenquadrando](../shots/33-editor-toast-adicionada.png)

**Rota:** editor → "Confirmar Seleção" · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Toast verde "Árvore adicionada com sucesso!" na base da tela.
- O mapa está no meio do reenquadramento automático para o novo ponto: parte dos tiles ainda não carregou (áreas cinza ao redor do quadrado central), e o pino verde "Ipê-amarelo" aparece no centro.
- Cabeçalho já atualizado para "1 árvore · 1 espécie" e painel para "1 salvo"; "Estatísticas" e "Relatório" ficaram habilitados.

**Ações possíveis / o que acontece:**
- Nada é exigido; em caso de falha o hook emite "Erro ao adicionar a árvore no projeto." e, adicionalmente, o editor mostra o `alert` nativo "Houve um erro ao vincular a árvore ao servidor. Tente novamente." (não observado).

**Estados relacionados:** `33-editor-painel-1ponto`

---

### Editor com um ponto vinculado

![Editor com um pino nomeado e uma linha no painel](../shots/33-editor-painel-1ponto.png)

**Rota:** editor do projeto após vincular a primeira árvore · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Pino verde-escuro em formato de etiqueta com o texto "Ipê-amarelo" sobre a imagem de satélite.
- Painel com uma linha: miniatura da foto, "**Ipê-amarelo**", "*Tabebuia chrysotricha*", pill verde "Nativa", pill cinza "Médio" e o botão "⋮" à direita.
- Cabeçalho "1 árvore · 1 espécie"; botões "Estatísticas" e "Relatório" em cor plena.

**Ações possíveis / o que acontece:**
- Clicar na linha (ou no pino) seleciona o ponto; clicar de novo desmarca.
- "⋮" abre o menu de ações do ponto.

**Estados relacionados:** `33-editor-menu-ponto`, `34-editor-ponto-selecionado`

---

### Menu de ações de um ponto

![Menu suspenso com Editar espécie e Remover](../shots/33-editor-menu-ponto.png)

**Rota:** editor → botão "⋮" na linha do painel · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Pequeno menu (role `menu`) ancorado abaixo do botão, com duas opções: "**Editar espécie**" (ícone de lápis, texto padrão) e "**Remover**" (ícone de lixeira, texto vermelho).

**Ações possíveis / o que acontece:**
- "Editar espécie" → reabre o diálogo "Selecionar Árvore" em modo edição.
- "Remover" → abre a confirmação "Remover árvore".
- Clique fora ou `Esc` fecham o menu.

**Estados relacionados:** `33-editor-dialogo-edicao`, `33-editor-remover-confirm`

---

### Diálogo em modo edição

![Diálogo Selecionar Árvore pré-preenchido](../shots/33-editor-dialogo-edicao.png)

**Rota:** editor → "⋮" → "Editar espécie" · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Mesmo diálogo do cadastro, porém já com o cartão de prévia preenchido ("Ipê-amarelo / *Tabebuia chrysotricha*", agora com a miniatura carregada) e a observação anterior no textarea ("Muda de teste para o relatório — calçada leste.", 47/300).
- "Confirmar Seleção" habilitado desde o início.
- Não há indicação textual de que se trata de edição: o título continua "Selecionar Árvore".

**Ações possíveis / o que acontece:**
- Trocar a espécie e/ou o texto e confirmar → `updatePoint` altera `tree_id` e `observacao` do mesmo ponto (a coordenada não muda).

**Estados relacionados:** `33-editor-toast-atualizada`

---

### Toast "Dados da árvore atualizados!"

![Toast de atualização de dados da árvore](../shots/33-editor-toast-atualizada.png)

**Rota:** editor → confirmação da edição · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Toast verde "Dados da árvore atualizados!" na base.
- Painel e mapa inalterados (mesma espécie, nova observação) — o texto da observação só reaparece no tooltip do pino e no diálogo.

**Ações possíveis / o que acontece:**
- Em caso de erro: toast "Erro ao atualizar os dados da árvore." e `alert` "Houve um erro ao editar a árvore no servidor. Tente novamente." (não observados).

**Estados relacionados:** `34-editor-tooltip-pin`

---

### Confirmação "Remover árvore"

![Modal de confirmação para remover a árvore do projeto](../shots/33-editor-remover-confirm.png)

**Rota:** editor → "⋮" → "Remover" · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Cartão centralizado com ícone de lixeira em círculo vermelho-claro, título "**Remover árvore**" e o texto "Deseja remover esta árvore do seu projeto? Esta ação não pode ser desfeita.".
- Botões "Cancelar" e "**Remover**" (vermelho).
- Ao fundo ainda aparece o toast "Dados da árvore atualizados!" do passo anterior.

**Ações possíveis / o que acontece:**
- "Remover" apaga a linha em `points` e o pino some do mapa.

**Estados relacionados:** `33-editor-toast-removida`

---

### Toast "Árvore removida do mapa."

![Editor de volta ao estado vazio com toast de remoção](../shots/33-editor-toast-removida.png)

**Rota:** editor após confirmar a remoção · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Toast verde "Árvore removida do mapa." (com ponto final, diferente dos demais).
- Painel de volta ao estado vazio ("Nenhuma árvore plantada ainda"), contador "0 salvos", cabeçalho "0 árvores · 0 espécies" e os botões "Estatísticas"/"Relatório" novamente esmaecidos.

**Ações possíveis / o que acontece:**
- Não há desfazer; é preciso marcar o ponto de novo.

**Estados relacionados:** `32-editor-vazio`

---

### Editor completo — projeto com seis árvores (desktop)

![Editor com mapa satélite mostrando um agrupamento de 6 pinos e painel com seis linhas](../shots/34-editor-split.png)

**Rota:** `/projetos` → "Arborização Rua Prudente de Moraes" · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Cabeçalho: "Arborização Rua Prudente de Moraes" e "6 árvores · 6 espécies"; "Estatísticas" e "Relatório" habilitados (o segundo em verde-escuro preenchido).
- Mapa reenquadrado automaticamente para conter todos os pontos: no centro, uma **bolha verde com o número "6"** — todos os marcadores estão agrupados nesse nível de zoom.
- Painel à direita, "6 salvos", com as seis linhas na ordem de criação: Oiti (*Licania tomentosa*, Nativa/Médio), Dedaleira (*Lafoensia pacari*, Nativa/Grande), Resedá extremosa (*Lagerstroemia indica*, **Exótica**/Médio), Jerivá (*Syagrus romanzoffiana*, Nativa/Médio), Ipê-roxo-de-bola (*Handroanthus impetiginosus*, Nativa/Grande) e Ipê-amarelo (*Tabebuia chrysotricha*, Nativa/Médio). Cada linha tem miniatura da foto e o botão "⋮".

**Ações possíveis / o que acontece:**
- Clicar na bolha aproxima o mapa ao limite do agrupamento; no zoom máximo, "explode" os pinos em leque.
- Clicar em uma linha seleciona o ponto correspondente.

**Estados relacionados:** `34-editor-zoom-maximo`, `34-editor-cluster-aberto`, `36-editor-split-dark`

---

### Zoom máximo — pinos ainda parcialmente agrupados

![Mapa no zoom 18 com um pino Oiti e duas bolhas numeradas](../shots/34-editor-zoom-maximo.png)

**Rota:** editor → dois cliques em "+" · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Imagem de satélite bem mais detalhada (telhados, carros e árvores individuais visíveis) do trecho da Rua Prudente de Moraes.
- Um pino nomeado "**Oiti**" na parte superior e duas bolhas verdes: "**3**" no centro e "**2**" mais abaixo.
- O botão "+" do controle de zoom está cinza/desabilitado — o limite (zoom 18) foi atingido.

**Ações possíveis / o que acontece:**
- Como os pontos estão a ~25 m uns dos outros e o raio de agrupamento é de 50 px, o agrupamento persiste mesmo no zoom máximo; para ver todos os nomes é necessário clicar nas bolhas.

**Estados relacionados:** `34-editor-cluster-aberto`

---

### Agrupamento aberto (pinos em leque)

![Pinos Jerivá e Ipê-roxo-de-bola abertos ao lado da bolha 3](../shots/34-editor-cluster-aberto.png)

**Rota:** editor no zoom máximo → clique em uma bolha · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- A bolha inferior "2" se abriu em dois marcadores lado a lado, rotulados "**Jerivá**" e "**Ipê-roxo-de-bola**", ligados por finas linhas ao ponto de origem.
- Continuam na tela o pino "Oiti" e a bolha "3".
- Foram contabilizados 3 pinos individuais e 2 agrupamentos nesse estado.

**Ações possíveis / o que acontece:**
- Clicar no mapa fora dos pinos fecha o leque — e, atenção, **cria um novo ponto pendente**, já que qualquer clique no mapa é interpretado como nova marcação.
- Clicar em um pino seleciona o ponto correspondente no painel.

**Estados relacionados:** `34-editor-tooltip-pin`, `34-editor-ponto-selecionado`

---

### Tooltip de um marcador

![Tooltip mostrando Oiti - Calçada norte, em frente ao nº 1220](../shots/34-editor-tooltip-pin.png)

**Rota:** editor → mouse sobre um pino · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Balão branco à direita do pino com o texto "**Oiti - Calçada norte, em frente ao nº 1220**", isto é, nome popular + " - " + observação registrada no ponto. Sem observação, o tooltip traz apenas o nome popular.

**Ações possíveis / o que acontece:**
- O tooltip é só informativo; some ao tirar o cursor.

**Estados relacionados:** `33-editor-dialogo-edicao` (onde a observação é editada)

---

### Ponto selecionado

![Pino azul Oiti e primeira linha do painel destacada](../shots/34-editor-ponto-selecionado.png)

**Rota:** editor → clique em um pino (ou na linha correspondente) · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- O pino "Oiti" mudou de verde para **azul**, com leve aumento de escala e sombra azulada; continua acima dos demais.
- No painel, a linha "Oiti" ganhou fundo azul-claro, borda esquerda azul e o nome em azul; as outras linhas seguem neutras.
- O tooltip permanece visível porque o cursor ainda está sobre o pino.

**Ações possíveis / o que acontece:**
- Clicar novamente (no pino ou na linha) desmarca o ponto e devolve a cor verde.
- A seleção é apenas visual: não abre formulário nem altera dados. O painel rola automaticamente até a linha selecionada quando ela está fora de vista.

**Estados relacionados:** `34-editor-split`

---

### Busca de endereço — termo digitado

![Caixa de busca com o termo Ribeirão Preto](../shots/34-editor-busca-preenchida.png)

**Rota:** editor → campo "Buscar endereço, CEP ou cidade..." · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Campo arredondado com lupa à esquerda, o texto "Ribeirão Preto" e, à direita, o botão circular verde com seta (`title="Buscar Local"`), habilitado porque há texto.
- Enquanto a requisição corre, o botão exibe um spinner e o campo fica desabilitado (estado não capturado isoladamente).

**Ações possíveis / o que acontece:**
- Enter ou clique na seta disparam a busca. O componente distingue dois casos: se o texto casar com o padrão de CEP (`00000-000` ou `00000000`), consulta a BrasilAPI e, se necessário, o Nominatim com campos estruturados; caso contrário, faz busca livre no Nominatim restrita ao Brasil (`countrycodes=br`, 1 resultado).

**Estados relacionados:** `34-editor-busca-resultado`, `34-editor-busca-erro`

---

### Busca bem-sucedida

![Mapa reposicionado no centro de Ribeirão Preto](../shots/34-editor-busca-resultado.png)

**Rota:** editor → busca por "Ribeirão Preto" · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- O mapa voou (animação de 1,5 s) para o centro da cidade, no zoom 17: aparecem os rótulos "Ribeirão Preto", "Setor Central", "Praça XV de Novembro", "Mercadão Municipal", "Rodoviário" e "Pedro II".
- O campo de busca **foi esvaziado** automaticamente e não há mensagem de sucesso.
- Os seis pontos do projeto ficaram fora do enquadramento — o painel à direita continua com as seis linhas e a primeira (Oiti) ainda selecionada em azul.

**Ações possíveis / o que acontece:**
- Não há botão "voltar ao projeto": para reenquadrar é preciso navegar manualmente ou reabrir o projeto (o reenquadramento automático só ocorre na montagem).
- O novo centro é persistido no projeto pelo evento `moveend`.

**Estados relacionados:** `34-editor-split`

---

### Busca com erro (CEP inexistente)

![Mensagem vermelha CEP não encontrado abaixo da caixa de busca](../shots/34-editor-busca-erro.png)

**Rota:** editor → busca por "00000-000" · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Campo com o texto "00000-000" e, logo abaixo, uma faixa vermelha-clara arredondada com o texto "**CEP não encontrado**".
- O mapa permanece onde estava (centro de Ribeirão Preto, do passo anterior).

**Ações possíveis / o que acontece:**
- A mensagem permanece até a próxima busca (não expira sozinha).
- Outras mensagens previstas no código, não capturadas: "Localização exata não encontrada" (busca textual sem resultado) e "Erro ao buscar o local" (falha de rede/exceção).

**Estados relacionados:** `34-editor-busca-resultado`

---

### GPS — "Minha Localização"

![Toast Localização encontrada após acionar o GPS](../shots/34-editor-minha-localizacao.png)

**Rota:** editor → botão circular de alvo no canto superior direito do mapa · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro (geolocalização simulada em -21,1767 / -47,8208)

**Elementos visíveis:**
- Toast verde "**Localização encontrada!**" na base da tela.
- O mapa ainda está no meio da animação de voo até a coordenada (a captura pegou o deslocamento em curso); a faixa "CEP não encontrado" da busca anterior continua visível.
- Enquanto localiza, o botão troca o ícone de alvo por um spinner e fica desabilitado.

**Ações possíveis / o que acontece:**
- Sucesso → `flyTo` até a posição do usuário no zoom 18 + toast de sucesso. Nenhum marcador é criado: o botão apenas reposiciona o mapa.
- Falha ou permissão negada → toast "Não foi possível obter sua localização. Verifique as permissões de GPS."; navegador sem suporte → "Geolocalização não suportada pelo seu navegador." (nenhum dos dois capturado).

**Estados relacionados:** `34-editor-busca-erro`

---

### Dashboard do Projeto (estatísticas)

![Modal Dashboard do Projeto com totais, origem e porte](../shots/34-editor-estatisticas.png)

**Rota:** editor → botão "Estatísticas" · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Cabeçalho com ícone de gráfico, título "**Dashboard do Projeto**" e subtítulo "Resumo do impacto ambiental do seu plantio".
- Três cartões numéricos: "TOTAL **6** Árvores mapeadas", "ESPÉCIES **6** Tipos diferentes" e "COBERTURA **659** m² de copa estimada".
- Bloco "Origem das Espécies": à esquerda "**83%** Nativas (5)", à direita "Exóticas (1) **17%**" e uma barra horizontal preenchida em verde até 83%, o restante em amarelo. Abaixo, o veredito "Excelente! Você priorizou espécies nativas da região.".
- Bloco "Distribuição por Porte" com três barras rotuladas: "Pequeno **0**", "Médio **4**" e "Grande **2**".
- Botão "Fechar" no canto inferior direito.

**Ações possíveis / o que acontece:**
- Fechar pelo botão, pelo "×", por `Esc` ou clicando fora.
- Como os números são calculados no cliente: cobertura = soma de π·(diâmetro de copa adulta ÷ 2)² de cada árvore (6 exemplares → 659 m²); o veredito muda para "Bom equilíbrio entre nativas e exóticas." entre 41% e 70% de nativas e para "Considere aumentar o número de nativas para beneficiar o ecossistema local." abaixo disso.

**Estados relacionados:** `35-relatorio-gerando` (o PDF repete diversidade, cobertura e % de nativas)

---

### Mobile — folha inferior no menor encaixe (150 px)

![Editor em celular com mapa cheio e folha inferior recolhida](../shots/36-editor-sheet-minimo-mobile.png)

**Rota:** `/projetos` → projeto · **Quem acessa:** dono do projeto · **Viewport/tema:** mobile (390 × 844) claro

**Elementos visíveis:**
- Cabeçalho do site reduzido (logo + hambúrguer) e, abaixo, a barra do editor com seta de voltar, nome truncado "Arborização Rua Prudent…", "6 árvores · 6 espécies" e dois **botões apenas com ícone** (gráfico e documento) — os rótulos "Estatísticas"/"Relatório" ficam ocultos abaixo de 640 px.
- Mapa ocupando quase toda a tela, com a bolha verde "6" no centro, caixa de busca no topo (sobrepondo os controles +/−) e botão de GPS à direita.
- Dica escura "**Toque para adicionar ponto**" logo acima da folha.
- Folha branca arredondada na base, com a alça cinza no topo, o cabeçalho "Pontos do Projeto / 6 salvos" e o começo da primeira linha (Oiti).

**Ações possíveis / o que acontece:**
- Arrastar a alça para cima expande a folha até 50% e 90% da altura; arrastar para baixo retorna.
- Com a folha em 90%, tocar no mapa recolhe a folha de volta a 150 px.

**Estados relacionados:** `36-editor-sheet-meio-mobile`, `36-editor-sheet-alto-mobile`

---

### Mobile — folha no encaixe intermediário (50%)

![Folha inferior ocupando metade da tela com quatro espécies visíveis](../shots/36-editor-sheet-meio-mobile.png)

**Rota:** editor móvel → arrastar a alça para cima · **Quem acessa:** dono do projeto · **Viewport/tema:** mobile claro

**Elementos visíveis:**
- A folha passou a 422 px de altura (50% de 844 px, valor medido no atributo `style`), cobrindo a metade inferior do mapa.
- Lista com Oiti, Dedaleira, Resedá extremosa (pill âmbar "Exótica"), Jerivá e o início de Ipê-roxo-de-bola, todos com miniatura, nome científico em itálico, pills e o botão "⋮".
- A dica "Toque para adicionar ponto" já não aparece (fica atrás da folha).

**Ações possíveis / o que acontece:**
- Rolagem interna da lista; o restante do comportamento é igual ao do desktop.

**Estados relacionados:** `36-editor-sheet-alto-mobile`

---

### Mobile — folha no encaixe máximo (90%)

![Folha inferior quase em tela cheia com as seis espécies](../shots/36-editor-sheet-alto-mobile.png)

**Rota:** editor móvel → arrastar a alça até o topo · **Quem acessa:** dono do projeto · **Viewport/tema:** mobile claro

**Elementos visíveis:**
- Folha com 759,6 px de altura (90%), cobrindo o mapa e parte da barra do editor — o nome do projeto aparece cortado atrás da folha.
- As seis linhas visíveis de uma vez (Oiti, Dedaleira, Resedá extremosa, Jerivá, Ipê-roxo-de-bola, Ipê-amarelo).
- Abaixo da última linha sobra uma faixa branca: a área rolável tem `height: calc(100% - 20px)`, e a lista termina antes do fim da folha.

**Ações possíveis / o que acontece:**
- Tocar no mapa (na faixa que sobrou no topo) devolve a folha ao encaixe de 150 px.

**Estados relacionados:** `36-editor-sheet-minimo-mobile`

---

### Editor no tema escuro

![Editor de projeto com tema escuro](../shots/36-editor-split-dark.png)

**Rota:** `/projetos` → projeto · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop escuro

**Elementos visíveis:**
- Barra do editor e painel em cinza-escuro, textos claros; a borda entre mapa e painel fica mais sutil.
- O mapa de satélite não muda (imagens de sensoriamento remoto não têm variante escura) e a caixa de busca ganha fundo escuro translúcido.
- As pills "Nativa" (verde) e "Exótica" (âmbar) usam tons mais escuros e texto mais claro.

**Ações possíveis / o que acontece:**
- Sem diferenças funcionais.

**Estados relacionados:** `34-editor-split`

---

## Fluxo passo a passo — adicionar um ponto no mapa

1. Na lista de projetos, o usuário clica no projeto desejado; o editor abre em tela cheia com o mapa de satélite e o painel lateral (ver `32-editor-vazio`).
2. Clica sobre o local da calçada onde a muda será plantada. Surge um pino âmbar "Pendente" e, no painel, a faixa "AGUARDANDO VINCULAÇÃO" com "Ponto #1", "Descartar" e "Vincular" (ver `32-editor-ponto-pendente`). O ponto ainda não existe no banco.
3. Clica em "Vincular": abre o diálogo "Selecionar Árvore" com busca, observação e o botão "Confirmar Seleção" desabilitado (ver `33-editor-dialogo-fechado`).
4. Abre a lista (146 espécies ativas, com miniatura, nome popular e científico — ver `33-editor-dropdown`) ou digita para filtrar; se o termo não casar com nada, aparece "Nenhuma árvore encontrada" (ver `33-editor-busca-vazia`).
5. Escolhe a espécie: um cartão de prévia é exibido e o campo de busca é limpo. Opcionalmente escreve uma observação (até 300 caracteres) sobre a muda ou o local (ver `33-editor-especie-selecionada`).
6. Clica em "Confirmar Seleção": o ponto é gravado, o pendente desaparece e surge o toast "Árvore adicionada com sucesso!" (ver `33-editor-toast-adicionada`).
7. O mapa reenquadra, o pino passa a exibir o nome da espécie e a linha correspondente aparece no painel com pills de origem e porte; o cabeçalho passa a contar a árvore e libera "Estatísticas"/"Relatório" (ver `33-editor-painel-1ponto`).
8. Se o usuário tentar voltar à lista com algum ponto pendente não vinculado, o navegador exibe a confirmação nativa "Você tem pontos pendentes que não foram salvos. Certeza que deseja sair?".

## Fluxo passo a passo — editar e remover um ponto

1. No painel, o usuário clica no botão "⋮" da linha do ponto; abre-se o menu com "Editar espécie" e "Remover" (ver `33-editor-menu-ponto`).
2. "Editar espécie" reabre o diálogo já preenchido com a espécie e a observação atuais (ver `33-editor-dialogo-edicao`). Alterando qualquer um dos dois e confirmando, aparece "Dados da árvore atualizados!" (ver `33-editor-toast-atualizada`). A coordenada não é editável.
3. "Remover" abre a confirmação "Remover árvore", que avisa que a ação não pode ser desfeita (ver `33-editor-remover-confirm`).
4. Confirmando, o ponto some do mapa e do painel e aparece "Árvore removida do mapa."; com zero pontos, o painel volta ao estado vazio e os botões do topo são desabilitados (ver `33-editor-toast-removida`).
5. Para mudar um ponto de lugar não há arraste: remove-se o ponto e cria-se outro na posição correta.
