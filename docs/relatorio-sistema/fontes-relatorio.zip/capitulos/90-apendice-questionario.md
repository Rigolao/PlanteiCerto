# Apêndice A — Questionário de Recomendação

Os 25 passos efetivamente apresentados ao usuário, na ordem em que aparecem, tal como declarados em `src/data/questionnaire.ts` e depois de aplicada a função `flattenQuestions()`, que substitui a pergunta-contêiner `q2_8` por suas quatro subperguntas `q2_8a` a `q2_8d`.

O vetor `questionnaire` tem 22 entradas; a expansão de `q2_8` produz os 25 passos abaixo. A coluna **Condicional** indica a única pergunta de exibição condicional (`showIf`), e a coluna **Multi** indica a única pergunta de seleção múltipla. O texto em itálico dentro da coluna da pergunta é o `helpText` do componente. Os valores da coluna de opções são exatamente os enviados à função de recomendação.

| Grupo | Tema | Passos | Tipo predominante |
|---|---|---|---|
| 1 | Contexto e Objetivos | 2 | Classificatório |
| 2 | Espaço e Interferências | 11 | Eliminatório |
| 3 | Condições Ecológicas e Ambientais | 6 | Misto (4) e classificatório (2) |
| 4 | Preferências e Manutenção | 4 | Misto (3) e classificatório (1) |
| 5 | Preferências Botânicas | 2 | Classificatório |

| # | id | Grupo | Tipo | Pergunta | Opções (valor → rótulo) | Condicional | Multi |
|---|---|---|---|---|---|---|---|
| 1 | `q1_1` | 1 · Contexto e Objetivos | classificatorio | Qual o tipo de local de plantio? | `calcada` → Calçada em frente a lote/residência<br>`canteiro_central` → Canteiro central de avenida<br>`praca_parque` → Praça ou parque (área interna)<br>`rotatorio` → Rotatória ou trevo viário |  |  |
| 2 | `q1_2` | 1 · Contexto e Objetivos | classificatorio | Qual o principal objetivo com a árvore? (escolha até 2)<br>*Selecione até 2 opções.* | `sombra` → Sombra e conforto térmico<br>`embelezamento` → Embelezamento e floração<br>`fauna` → Atração de fauna (aves/polinizadores)<br>`baixa_manutencao` → Baixa manutenção / pouca sujeira<br>`qualidade_ar` → Melhorar qualidade do ar e biodiversidade<br>`nativas` → Valorizar espécies nativas da região |  | até 2 |
| 3 | `q2_1` | 2 · Espaço e Interferências | eliminatorio | Qual a largura total da calçada (m)? | `lt_1` → Menos de 1 m<br>`1_2` → 1 a 2 m<br>`2_3` → 2 a 3 m<br>`3_4` → 3 a 4 m<br>`gt_4` → Mais de 4 m |  |  |
| 4 | `q2_2` | 2 · Espaço e Interferências | eliminatorio | Qual a largura efetiva da faixa de serviço (m)?<br>*Faixa onde a árvore será plantada, entre o meio-fio e a faixa livre.* | `lt_1` → Menos de 1 m<br>`1_2` → 1 a 2 m<br>`2_3` → 2 a 3 m<br>`3_4` → 3 a 4 m<br>`gt_4` → Mais de 4 m |  |  |
| 5 | `q2_3` | 2 · Espaço e Interferências | eliminatorio | É necessário manter faixa livre acessível de 1,20 m (ABNT NBR 9050)?<br>*Calçadas com fluxo de pedestres precisam de faixa livre mínima de 1,20 m.* | `sim` → Sim<br>`nao` → Não |  |  |
| 6 | `q2_4` | 2 · Espaço e Interferências | eliminatorio | Qual a dimensão disponível para o berço/cova (m²)? | `lt_1` → Menos de 1 m²<br>`1_2` → 1 a 2 m²<br>`gt_2` → Mais de 2 m² |  |  |
| 7 | `q2_5` | 2 · Espaço e Interferências | eliminatorio | Existe fiação aérea no local? | `nao` → Não há fiação<br>`sim_convencional` → Sim, convencional<br>`sim_protegida` → Sim, isolada/protegida |  |  |
| 8 | `q2_6` | 2 · Espaço e Interferências | eliminatorio | Qual a distância até a fiação aérea (m)? | `lt_4` → Menos de 4 m<br>`gt_4` → 4 m ou mais | só se `q2_5` ∈ {sim_convencional, sim_protegida} |  |
| 9 | `q2_7` | 2 · Espaço e Interferências | eliminatorio | Qual o recuo da edificação em relação à calçada? | `nenhum` → Sem recuo (construção na divisa)<br>`lt_2` → Menos de 2 m<br>`gt_2` → 2 m ou mais |  |  |
| 10 | `q2_8a` | 2 · Espaço e Interferências | eliminatorio | Qual a distância até a esquina mais próxima (m)?<br>*Mínimo recomendado: 6 m (Cartilha de Arborização, p.16).* | `lt_6` → Menos de 6 m<br>`gt_6` → 6 m ou mais |  |  |
| 11 | `q2_8b` | 2 · Espaço e Interferências | eliminatorio | Qual a distância até o poste de iluminação mais próximo (m)?<br>*Mínimo recomendado: 4 m (Cartilha de Arborização, p.16).* | `lt_4` → Menos de 4 m<br>`gt_4` → 4 m ou mais |  |  |
| 12 | `q2_8c` | 2 · Espaço e Interferências | eliminatorio | Qual a distância até a guia rebaixada (rampa de acessibilidade) mais próxima (m)?<br>*Mínimo recomendado: 1,5 m (Cartilha de Arborização, p.16).* | `lt_1_5` → Menos de 1,5 m<br>`gt_1_5` → 1,5 m ou mais |  |  |
| 13 | `q2_8d` | 2 · Espaço e Interferências | eliminatorio | Qual a distância até a boca-de-lobo ou caixa de inspeção mais próxima (m)?<br>*Mínimo recomendado: 1,5 m (Cartilha de Arborização, p.16).* | `lt_1_5` → Menos de 1,5 m<br>`gt_1_5` → 1,5 m ou mais |  |  |
| 14 | `q3_1` | 3 · Condições Ecológicas e Ambientais | misto | Qual a condição de insolação do local? | `sol_pleno` → Sol pleno (mais de 6h de sol direto)<br>`meia_sombra` → Meia sombra (3 a 6h de sol)<br>`sombra` → Sombra (menos de 3h de sol) |  |  |
| 15 | `q3_2` | 3 · Condições Ecológicas e Ambientais | misto | Como é a umidade do solo no local? | `seco` → Seco (bem drenado)<br>`umido` → Úmido (moderado)<br>`encharcado` → Encharcado (alagável) |  |  |
| 16 | `q3_3` | 3 · Condições Ecológicas e Ambientais | misto | Qual a qualidade do solo? | `bom` → Bom (solo natural, permeável)<br>`ruim` → Ruim (compactado, entulho, aterro) |  |  |
| 17 | `q3_4` | 3 · Condições Ecológicas e Ambientais | misto | Haverá irrigação regular no primeiro ano? | `sim` → Sim<br>`nao` → Não |  |  |
| 18 | `q3_5` | 3 · Condições Ecológicas e Ambientais | classificatorio | O local é muito exposto a ventos fortes? | `sim` → Sim, local ventoso<br>`nao` → Não, local abrigado |  |  |
| 19 | `q3_6` | 3 · Condições Ecológicas e Ambientais | classificatorio | O local sofre com ilha de calor (necessidade de sombra extra)? | `sim` → Sim, priorizar espécies com alto potencial de sombra<br>`nao` → Não |  |  |
| 20 | `q4_1` | 4 · Preferências e Manutenção | misto | A queda de folhas, flores ou frutos é um problema no local? | `sim` → Sim, quero minimizar sujeira<br>`nao` → Não, sem restrição |  |  |
| 21 | `q4_2` | 4 · Preferências e Manutenção | misto | A presença de espinhos ou substâncias irritantes é um problema? | `sim` → Sim, quero evitar<br>`nao` → Não, sem restrição |  |  |
| 22 | `q4_3` | 4 · Preferências e Manutenção | misto | É necessário evitar atração de abelhas ou insetos? | `sim` → Sim, quero minimizar<br>`nao` → Não, sem restrição |  |  |
| 23 | `q4_4` | 4 · Preferências e Manutenção | classificatorio | Haverá poda profissional periódica? | `sim` → Sim, haverá manutenção profissional<br>`nao` → Não, manutenção mínima |  |  |
| 24 | `q5_1` | 5 · Preferências Botânicas | classificatorio | Há preferência por espécies nativas do Brasil? | `sim` → Sim, priorizar nativas<br>`nao` → Não é uma prioridade |  |  |
| 25 | `q5_2` | 5 · Preferências Botânicas | classificatorio | Há preferência por espécies que atraiam fauna (aves, polinizadores)? | `sim` → Sim, priorizar<br>`nao` → Não é uma prioridade |  |  |
