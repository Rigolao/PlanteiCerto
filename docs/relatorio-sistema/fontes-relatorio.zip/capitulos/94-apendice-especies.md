# Apêndice E — Catálogo de Espécies

As 167 espécies registradas na tabela `public.trees` do banco local, em ordem alfabética por nome popular (comparação insensível a acentos e a maiúsculas; empates desfeitos pelo `id`). Os dados foram extraídos diretamente do banco depois de aplicadas as cinco migrations e a carga de `supabase/seed.sql`, o que inclui as correções editoriais de altura e hábito da migration de 2026-09-08.

Resumo: **167 espécies no total**, das quais **146 ativas** e 21 inativas; **129 nativas do Brasil** e 38 exóticas; **149 com projeção de crescimento em 10 anos**. Entre as ativas, a única sem projeção é o Jerivá (`id` 41), por ser palmeira.

Convenções das colunas: **Fiação** traduz `compat_fiacao`, em que `N` significa incompatível com rede aérea, `A` compatível com cuidados e `C` compatível; **Altura máx.** é `altura_adulta_max_m` em metros e **Copa máx.** é `diametro_copa_adulto_max_m` em metros, ambos referentes ao porte adulto máximo; **Ativa** indica visibilidade pública (`ativa = true`); **Projeção 10a** indica se a espécie tem os campos de projeção preenchidos. Células com travessão não têm valor no banco.

| id | Nome popular | Nome científico | Origem | Porte | Copa | Folhagem | Fiação | Altura máx. (m) | Copa máx. (m) | Ativa | Projeção 10a |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 28 | Abacateiro; Abacate | Persea americana | Exótica | Grande | Grande | Perenifólia | N (incompatível) | 20 | 10 | Não | Não |
| 36 | Acerola | Malpighia emarginata | Exótica | Pequeno | Média | Perenifólia | C (compatível) | 5 | 4 | Não | Não |
| 26 | Acerola; Aceroleira; Cereja-das-antilhas; Cerejeira-do-Pará | Malpighia glabra L. | Exótica | Pequeno | Média | Perenifólia | C (compatível) | 6 | 4 | Não | Não |
| 8 | Açoita-cavalo | Luehea divaricata Mart. | Nativa BR | Grande | Grande | Decídua | N (incompatível) | 25 | 8 | Sim | Sim |
| 108 | Açoita-cavalo | Luehea divaricata | Nativa BR | Grande | Grande | Decídua | N (incompatível) | 25 | 10 | Sim | Sim |
| 9 | Aldrago | Pterocarpus violaceus Vogel | Nativa BR | Médio | Média | Perenifólia | A (com cuidados) | 14 | — | Sim | Sim |
| 10 | Aldrago miúdo | Pterocarpus rohrii Vahl | Nativa BR | Grande | Grande | Perenifólia | N (incompatível) | 20 | 10 | Sim | Sim |
| 80 | Aldrago miúdo | Pterocarpus rohrii | Nativa BR | Médio | Média | Semidecídua | A (com cuidados) | 12 | 7 | Sim | Sim |
| 13 | Alecrim-de-campinas | Holocalyx balansae Micheli | Nativa BR | Grande | Grande | Semidecídua | N (incompatível) | 25 | 12 | Sim | Sim |
| 96 | Alecrim-de-campinas | Holocalyx balansae | Nativa BR | Grande | Grande | Semidecídua | N (incompatível) | 25 | 10 | Sim | Sim |
| 95 | Aleluia, pau-fava | Senna macranthera | Nativa BR | Pequeno | Pequena | Decídua | C (compatível) | 6 | 5 | Sim | Sim |
| 12 | Alfeneiro-do-japão | Ligustrum lucidum W.T. Aiton | Exótica | Médio | Média | Perenifólia | A (com cuidados) | 15 | 10 | Sim | Sim |
| 93 | Alfeneiro-do-japão | Ligustrum lucidum | Exótica | Médio | Média | Perenifólia | A (com cuidados) | 12 | 7 | Sim | Sim |
| 14 | Algodão-do-brejo | Hibiscus pernambucensis | Nativa BR | Pequeno | Pequena | Perenifólia | C (compatível) | 6 | 4 | Sim | Sim |
| 15 | Almecega | Protium heptaphyllum (Aubl.) Marchand | Nativa BR | Grande | Média | Perenifólia | A (com cuidados) | 20 | 12 | Não | Sim |
| 87 | Almecega | Protium heptaphyllum | Nativa BR | Grande | Grande | Perenifólia | N (incompatível) | 20 | 15 | Sim | Sim |
| 16 | Amarelinho | Helietta apiculata | Nativa BR | Grande | Média | Semidecídua | A (com cuidados) | 18 | — | Sim | Sim |
| 11 | Amendoim-do-campo | Platypodium elegans Vogel | Nativa BR | Médio | Média | Semidecídua | N (incompatível) | 12 | 15 | Sim | Sim |
| 82 | Amendoim-do-campo | Platypodium elegans | Nativa BR | Médio | Grande | Semidecídua | N (incompatível) | 12 | 20 | Sim | Sim |
| 109 | Amoreira | Morus nigra | Exótica | Médio | Média | Decídua | C (compatível) | 12 | 7 | Sim | Sim |
| 18 | Angelim-doce | Andira fraxinifolia | Nativa BR | Médio | Grande | Perenifólia | N (incompatível) | 12 | 20 | Sim | Sim |
| 17 | Araçá | Psidium cattleianum Sabine | Nativa BR | Pequeno | Pequena | Perenifólia | C (compatível) | 6 | 5 | Sim | Sim |
| 19 | Araçarana | Calyptranthes clusiifolia (Miq.) O.Berg | Nativa BR | Médio | Média | Perenifólia | A (com cuidados) | 15 | — | Sim | Sim |
| 97 | Araçarana | Calyptranthes clusiifolia | Nativa BR | Pequeno | Pequena | Perenifólia | C (compatível) | 5 | 2,5 | Sim | Sim |
| 20 | Aroeira-pimenteira | Schinus terebinthifolius | Nativa BR | Médio | Média | Perenifólia | C (compatível) | 15 | 12 | Sim | Sim |
| 98 | Aroeira-pimenteira | Schinus terebinthifolia | Nativa BR | Médio | Média | Perenifólia | C (compatível) | 15 | 12 | Sim | Sim |
| 21 | Astrapéia | Dombeya wallichii | Exótica | Médio | Média | Semidecídua | C (compatível) | 12 | — | Sim | Sim |
| 22 | Bico-de-pato | Machaerium aculeatum | Nativa BR | Médio | Média | Decídua | A (com cuidados) | 12 | 7 | Sim | Sim |
| 110 | Cabreúva-amarela | Myrocarpus frondosus | Nativa BR | Grande | Grande | Decídua | N (incompatível) | 30 | 20 | Sim | Sim |
| 111 | Cabreúva-vermelha | Myroxylon peruiferum L.f. | Nativa BR | Grande | Grande | Semidecídua | N (incompatível) | 35 | — | Sim | Sim |
| 30 | Cajá-manga; cajarana; taperebá-do-sertão | Spondias dulcis | Exótica | Grande | Grande | Decídua | N (incompatível) | 20 | 8 | Não | Não |
| 76 | Calicarpa | Callicarpa reevesii | Exótica | Pequeno | Pequena | Semidecídua | C (compatível) | 7 | — | Sim | Sim |
| 112 | Calistemon | Callistemon viminalis | Exótica | Pequeno | Pequena | Perenifólia | C (compatível) | 6 | 5 | Sim | Sim |
| 113 | Calistemon | Callistemon imperialis | Exótica | Pequeno | Pequena | Perenifólia | C (compatível) | 6 | 5 | Sim | Sim |
| 77 | Camboatá | Cupania vernalis | Nativa BR | Grande | Grande | Semidecídua | N (incompatível) | 22 | 18 | Sim | Sim |
| 114 | Cambuci | Campomanesia phaea | Nativa BR | Pequeno | Pequena | Perenifólia | C (compatível) | 5 | 5 | Sim | Sim |
| 115 | Cambuí | Myrciaria tenella | Nativa BR | Pequeno | Pequena | Perenifólia | C (compatível) | 6 | 3 | Sim | Sim |
| 116 | Canafístula | Peltophorum dubium | Nativa BR | Grande | Grande | Semidecídua | N (incompatível) | 25 | 20 | Sim | Sim |
| 88 | Canela amarela | Ocotea velutina (Nees) Rohwer | Nativa BR | Grande | Grande | Semidecídua | N (incompatível) | 25 | 15 | Sim | Sim |
| 81 | Canela cheirosa | Endlicheria paniculata | Nativa BR | Médio | Média | Semidecídua | A (com cuidados) | 12 | 7 | Sim | Sim |
| 83 | Canela sassafrás | Ocotea odorifera | Nativa BR | Grande | Grande | Perenifólia | N (incompatível) | 25 | 20 | Sim | Sim |
| 84 | Capororoca | Rapanea ferruginea Aubl. Mez | Nativa BR | Médio | Média | Decídua | A (com cuidados) | 12 | 7 | Sim | Sim |
| 117 | Capororoca | Rapanea ferruginea | Nativa BR | Médio | Média | Decídua | C (compatível) | 12 | — | Sim | Sim |
| 85 | Capororoca-do-cerrado | Myrsine guianensis | Nativa BR | Médio | Média | Perenifólia | N (incompatível) | 8 | 15 | Sim | Sim |
| 118 | Caputuna-preta | Metrodorea nigra | Nativa BR | Pequeno | Grande | Semidecídua | N (incompatível) | 5 | 18 | Sim | Sim |
| 119 | Caqui-do-mato, olho-de-boi | Matayba eleagnoides | Nativa BR | Médio | Média | Semidecídua | A (com cuidados) | 14 | — | Sim | Sim |
| 79 | Cassia imperial | Senna fistula | Exótica | Médio | Média | Decídua | C (compatível) | 15 | 12 | Sim | Sim |
| 120 | Cassia imperial | Senna fistula (L.) H.S.Irwin & Barneby | Exótica | Médio | Média | Decídua | C (compatível) | 12 | — | Sim | Sim |
| 121 | Cassia javanesa, cassia rosa | Cassia javanica | Exótica | Grande | Grande | Decídua | N (incompatível) | 20 | 12 | Sim | Sim |
| 122 | Catiguá | Trichilia hirta L. | Nativa BR | Médio | Média | Semidecídua | A (com cuidados) | 14 | 7 | Sim | Sim |
| 89 | Catiguá vermelho | Trichilia claussenii C.DC. | Nativa BR | Médio | Média | Semidecídua | A (com cuidados) | 14 | 7 | Sim | Sim |
| 123 | Catiguá vermelho | Trichilia claussenii | Nativa BR | Médio | Grande | Semidecídua | N (incompatível) | 12 | — | Sim | Sim |
| 124 | Cedro | Cedrela fissilis | Nativa BR | Grande | Grande | Decídua | N (incompatível) | 40 | 15 | Sim | Sim |
| 125 | Cerejeira-do-rio-grande | Hexachlamys edulis | Nativa BR | Pequeno | Média | Decídua | C (compatível) | 6 | 6 | Sim | Sim |
| 126 | Chichá | Sterculia chicha St. Hil. | Nativa BR | Grande | Grande | Perenifólia | N (incompatível) | 20 | — | Sim | Sim |
| 127 | Copaíba | Copaifera langsdorffii | Nativa BR | Grande | Grande | Semidecídua | N (incompatível) | 35 | 20 | Sim | Sim |
| 128 | Coração-de-negro | Poecilanthe parviflora | Nativa BR | Grande | Grande | Perenifólia | N (incompatível) | 25 | 15 | Sim | Sim |
| 129 | Corrupita, abricó-de-macaco | Couroupita guianensis | Nativa BR | Médio | Grande | Perenifólia | N (incompatível) | 15 | 10 | Sim | Sim |
| 130 | Craveiro-da-índia | Syzygium aromaticum | Exótica | Médio | Média | Perenifólia | A (com cuidados) | 10 | 4 | Sim | Sim |
| 131 | Dedaleira | Lafoensia pacari | Nativa BR | Grande | Grande | Decídua | N (incompatível) | 18 | 15 | Sim | Sim |
| 132 | Embira-de-sapo, feijão cru | Lonchocarpus muehlbergianus | Nativa BR | Médio | Média | Decídua | A (com cuidados) | 15 | 8 | Sim | Sim |
| 35 | Escova-de-garrafa | Callistemon rigidus | Exótica | Pequeno | Pequena | Perenifólia | C (compatível) | 7 | 5 | Não | Não |
| 133 | Falsa murta | Murraya paniculata | Exótica | Pequeno | Pequena | Perenifólia | C (compatível) | 6 | 5 | Sim | Sim |
| 134 | Falso-timbó, ingá-bravo | Lonchocarpus guilleminianus | Nativa BR | Grande | Grande | Semidecídua | N (incompatível) | 18 | 10 | Sim | Sim |
| 94 | Farinha seca | Albizia hasslerii | Nativa BR | Grande | Grande | Decídua | N (incompatível) | 20 | 10 | Sim | Sim |
| 6 | Farinha-seca | Albizia niopoides (Spruce ex Benth.) Burkart | Nativa BR | Grande | Grande | Semidecídua | N (incompatível) | 35 | 20 | Não | Sim |
| 135 | Faveira, sucupira lisa | Pterodon emarginatus | Nativa BR | Grande | Grande | Decídua | N (incompatível) | 16 | 10 | Sim | Sim |
| 136 | Folha-de-castanha | Ouratea castaneifolia | Nativa BR | Pequeno | Pequena | Perenifólia | C (compatível) | 7 | 3 | Sim | Sim |
| 100 | Fruta-do-conde | Annona squamosa | Exótica | Médio | Média | Decídua | C (compatível) | 8 | 6 | Não | Não |
| 137 | Fruto-de-pombo, murta-branca | Allophyllus edulis | Nativa BR | Médio | Média | Semidecídua | C (compatível) | 10 | — | Sim | Sim |
| 138 | Genipapo | Genipa americana | Nativa BR | Médio | Grande | Semidecídua | N (incompatível) | 14 | 10 | Sim | Sim |
| 38 | Goiaba | Psidium guajava | Nativa BR | Médio | Média | Perenifólia | C (compatível) | 10 | 8 | Não | Não |
| 139 | Grumixama | Eugenia brasiliensis | Nativa BR | Médio | Média | Semidecídua | A (com cuidados) | 10 | 7 | Sim | Sim |
| 7 | Guaçatonga | Casearia sylvestris Sw. | Nativa BR | Pequeno | Pequena | Perenifólia | C (compatível) | 6 | 5 | Sim | Sim |
| 140 | Guaçatonga | Casearia sylvestris | Nativa BR | Pequeno | Pequena | Perenifólia | C (compatível) | 6 | 10 | Sim | Sim |
| 141 | Guaraiuva | Savia dictyocarpa | Nativa BR | Grande | Média | Semidecídua | A (com cuidados) | 25 | 15 | Sim | Sim |
| 142 | Guarantã | Esenbeckia leiocarpa | Nativa BR | Grande | Grande | Semidecídua | N (incompatível) | 30 | 20 | Sim | Sim |
| 143 | Guaritá | Astronium graveolens | Nativa BR | Grande | Média | Decídua | N (incompatível) | 30 | 10 | Sim | Sim |
| 144 | Ingá do brejo | Inga uruguensis | Nativa BR | Médio | Média | Perenifólia | A (com cuidados) | 15 | 8 | Sim | Sim |
| 90 | Ingá-orelha | Inga aurita | Nativa BR | Médio | Média | Perenifólia | A (com cuidados) | 15 | 12 | Não | Não |
| 145 | Ipê-amarelo | Tabebuia chrysotricha | Nativa BR | Médio | Pequena | Decídua | C (compatível) | 10 | 5 | Sim | Sim |
| 146 | Ipê-amarelo | Tabebuia aurea | Nativa BR | Médio | Média | Perenifólia | A (com cuidados) | 14 | 6 | Sim | Sim |
| 147 | Ipê-amarelo | Tabebuia ochracea | Nativa BR | Médio | Média | Decídua | A (com cuidados) | 14 | 6 | Sim | Sim |
| 148 | Ipê-amarelo | Tabebuia serratifolia | Nativa BR | Grande | Grande | Decídua | N (incompatível) | 20 | 10 | Sim | Sim |
| 149 | Ipê-amarelo-da-mata | Tabebuia vellosoi | Nativa BR | Grande | Grande | Decídua | N (incompatível) | 25 | 8 | Sim | Sim |
| 43 | Ipê-amarelo-de-jardim | Tecoma stans | Exótica | Pequeno | Pequena | Semidecídua | C (compatível) | 6 | 3 | Não | Não |
| 150 | Ipê-amarelo-do-brejo | Handroanthus umbellatus | Nativa BR | Médio | Média | Decídua | A (com cuidados) | 10 | 6 | Sim | Sim |
| 32 | Ipê-branco | Handroanthus albus | Nativa BR | Grande | Grande | Decídua | N (incompatível) | 30 | 20 | Não | Sim |
| 104 | Ipê-branco | Tabebuia roseo-alba | Nativa BR | Médio | Média | Decídua | A (com cuidados) | 14 | 10 | Sim | Sim |
| 151 | Ipê-rosa | Tabebuia pentaphylla | Exótica | Grande | Grande | Decídua | N (incompatível) | 20 | 12 | Sim | Sim |
| 154 | Ipê-roxo | Tabebuia heptaphylla | Nativa BR | Grande | Grande | Decídua | N (incompatível) | 20 | 20 | Sim | Sim |
| 152 | Ipê-roxo-anão | Tabebuia avellanedae var. paulensis | Nativa BR | Médio | Pequena | Decídua | C (compatível) | 8 | 5 | Sim | Sim |
| 91 | Ipê-roxo-da-mata | Tabebuia avellanedae | Nativa BR | Grande | Grande | Decídua | N (incompatível) | 35 | 15 | Sim | Sim |
| 23 | Ipê-roxo-de-bola | Handroanthus impetiginosus (Mart. ex DC.) Mattos | Nativa BR | Grande | Grande | Decídua | N (incompatível) | 18 | 8 | Sim | Sim |
| 99 | Ipê-roxo-de-bola | Handroanthus impetiginosus | Nativa BR | Grande | Grande | Decídua | N (incompatível) | 35 | 20 | Sim | Sim |
| 153 | Ipê-roxo-de-bola | Tabebuia impetiginosa | Nativa BR | Grande | Grande | Decídua | N (incompatível) | 30 | 15 | Sim | Sim |
| 29 | Jabuticaba; Jabuticabeira | Plinia cauliflora (Mart.) Kausel | Nativa BR | Médio | Média | Semidecídua | A (com cuidados) | 15 | 6 | Não | Não |
| 155 | Jacarandá paulista | Machaerium villosum | Nativa BR | Grande | Grande | Decídua | N (incompatível) | 25 | 12 | Não | Sim |
| 156 | Jacarandá-da-Bahia | Dalbergia nigra | Nativa BR | Grande | Grande | Semidecídua | N (incompatível) | 20 | 15 | Sim | Sim |
| 157 | Jambo amarelo | Syzygium jambos (L.) Alston | Exótica | Médio | Média | Perenifólia | A (com cuidados) | 12 | 7 | Sim | Sim |
| 158 | Jambo vermelho | Syzygium malaccense | Exótica | Médio | Média | Perenifólia | A (com cuidados) | 12 | 7 | Sim | Sim |
| 159 | Jatobá | Hymenaea courbaril L. | Nativa BR | Grande | Grande | Semidecídua | N (incompatível) | 20 | 12 | Sim | Sim |
| 160 | Jatobá-do-cerrado | Hymenaea stigonocarpa | Nativa BR | Médio | Média | Semidecídua | A (com cuidados) | 9 | 6 | Sim | Sim |
| 161 | Jequitibá branco | Cariniana estrellensis | Nativa BR | Grande | Grande | Semidecídua | N (incompatível) | 35 | 25 | Sim | Sim |
| 162 | Jequitibá rosa | Cariniana legalis (Mart.) Kuntze | Nativa BR | Grande | Grande | Decídua | N (incompatível) | 60 | 20 | Sim | Sim |
| 41 | Jerivá | Syagrus romanzoffiana | Nativa BR | Médio | Média | Perenifólia | A (com cuidados) | 15 | 8 | Sim | Não |
| 163 | Lofântera | Lophanthera lactescens | Nativa BR | Grande | Média | Perenifólia | A (com cuidados) | 20 | 6 | Sim | Sim |
| 164 | Louro pardo | Cordia trichotoma | Nativa BR | Grande | Grande | Decídua | N (incompatível) | 30 | 10 | Sim | Sim |
| 165 | Magnólia | Magnolia grandiflora | Exótica | Grande | Grande | Perenifólia | N (incompatível) | 20 | 8 | Sim | Sim |
| 166 | Magnólia amarela | Michelia champaca | Exótica | Grande | Grande | Perenifólia | N (incompatível) | 25 | 10 | Sim | Sim |
| 167 | Manacá-da-serra | Tibouchina mutabilis | Nativa BR | Médio | Média | Semidecídua | A (com cuidados) | 12 | 6 | Sim | Sim |
| 168 | Maria-mole | Guapira opposita | Nativa BR | Médio | Média | Perenifólia | A (com cuidados) | 15 | 5 | Sim | Sim |
| 169 | Marinheiro, camboatã | Guarea guidonia | Nativa BR | Grande | Grande | Perenifólia | N (incompatível) | 20 | 8 | Sim | Sim |
| 170 | Melaleuca | Melaleuca leucadendron | Exótica | Médio | Média | Perenifólia | A (com cuidados) | 15 | 6 | Sim | Sim |
| 171 | Mirindiba | Lafoensia glyptocarpa | Nativa BR | Grande | Grande | Semidecídua | N (incompatível) | 20 | 8 | Sim | Sim |
| 105 | Monguba | Pachira aquatica Aubl. | Nativa BR | Médio | Grande | Perenifólia | N (incompatível) | 14 | 10 | Sim | Sim |
| 172 | Mulungu | Erythrina falcata | Nativa BR | Grande | Grande | Decídua | N (incompatível) | 20 | 10 | Sim | Sim |
| 173 | Mulungu | Erythrina mulungu | Nativa BR | Médio | Média | Decídua | A (com cuidados) | 12 | 6 | Sim | Sim |
| 174 | Nó-de-porco, resedá nacional | Physocalymma scaberrimum | Nativa BR | Grande | Grande | Decídua | N (incompatível) | 20 | 8 | Sim | Sim |
| 1 | Oiti | Licania tomentosa | Nativa BR | Médio | Grande | Perenifólia | N (incompatível) | 15 | 10 | Sim | Sim |
| 175 | Olho-de-cabra | Ormosia arborea | Nativa BR | Grande | Grande | Semidecídua | N (incompatível) | 20 | 10 | Sim | Sim |
| 176 | Paineira | Ceiba speciosa | Nativa BR | Grande | Grande | Decídua | N (incompatível) | 20 | 12 | Sim | Sim |
| 39 | Palmeira-bambu | Rhapis excelsa | Exótica | Pequeno | Pequena | Perenifólia | C (compatível) | 3 | 2 | Não | Não |
| 103 | Palmeira-bambu | Rhapis excelsa (Thunb.) A.J.Henry | Exótica | Pequeno | Pequena | Perenifólia | C (compatível) | 4 | 3 | Não | Não |
| 40 | Palmeira-real | Roystonea oleracea | Exótica | Grande | Grande | Perenifólia | N (incompatível) | 25 | 10 | Não | Não |
| 3 | Pata-de-vaca | Bauhinia forficata | Nativa BR | Médio | Média | Semidecídua | A (com cuidados) | 9 | 5 | Sim | Sim |
| 177 | Pata-de-vaca | Bauhinia variegata | Exótica | Médio | Média | Semidecídua | A (com cuidados) | 10 | 6 | Sim | Sim |
| 178 | Pata-de-vaca | Bauhinia blakeana | Exótica | Médio | Média | Perenifólia | A (com cuidados) | 8 | 5 | Sim | Sim |
| 179 | Pata-de-vaca rosa | Bauhinia monandra | Exótica | Médio | Média | Semidecídua | A (com cuidados) | 12 | 6 | Sim | Sim |
| 180 | Pata-de-vaca roxa | Bauhinia purpurea | Exótica | Médio | Média | Semidecídua | A (com cuidados) | 10 | 6 | Sim | Sim |
| 181 | Pau cigarra | Senna multijuga | Nativa BR | Médio | Média | Semidecídua | A (com cuidados) | 10 | 6 | Sim | Sim |
| 182 | Pau d'alho | Gallesia integrifolia | Nativa BR | Grande | Grande | Semidecídua | N (incompatível) | 30 | 15 | Sim | Sim |
| 183 | Pau mulato | Calycophyllum spruceanum | Nativa BR | Grande | Grande | Perenifólia | N (incompatível) | 25 | 10 | Sim | Sim |
| 184 | Pau-brasil | Caesalpinia echinata | Nativa BR | Médio | Média | Semidecídua | A (com cuidados) | 12 | 7 | Sim | Sim |
| 185 | Pau-de-tucano | Vochysia tucanorum | Nativa BR | Médio | Média | Decídua | A (com cuidados) | 12 | 7 | Sim | Sim |
| 186 | Pau-ferro | Caesalpinia leiostachya | Nativa BR | Grande | Grande | Decídua | N (incompatível) | 20 | 10 | Sim | Sim |
| 78 | Pau-marfim | Balfourodendron riedelianum | Nativa BR | Grande | Grande | Semidecídua | N (incompatível) | 35 | 20 | Sim | Sim |
| 187 | Pau-pereira | Platycyamus regnellii | Nativa BR | Grande | Média | Semidecídua | N (incompatível) | 20 | 10 | Sim | Sim |
| 106 | Pau-rei | Pterygota brasiliensis Allemão | Nativa BR | Grande | Grande | Perenifólia | N (incompatível) | 35 | 15 | Sim | Sim |
| 188 | Pau-rei | Pterygota brasiliensis | Nativa BR | Grande | Grande | Semidecídua | N (incompatível) | 30 | 15 | Sim | Sim |
| 189 | Pau-ripa | Luetzelburgia auriculata | Nativa BR | Grande | Grande | Semidecídua | N (incompatível) | 22 | 12 | Sim | Sim |
| 197 | Pau-terra, jundiaí | Qualea jundiahy | Nativa BR | Grande | Grande | Semidecídua | N (incompatível) | 20 | 8 | Sim | Sim |
| 92 | Pau-terra-mirim | Qualea parviflora | Nativa BR | Médio | Média | Semidecídua | A (com cuidados) | 10 | 8 | Sim | Sim |
| 190 | Peito-do-pombo | Tapirira guianensis | Nativa BR | Médio | Média | Perenifólia | A (com cuidados) | 14 | 6 | Sim | Sim |
| 191 | Peroba poca | Aspidosperma cylindrocarpon | Nativa BR | Grande | Grande | Semidecídua | N (incompatível) | 16 | 10 | Sim | Sim |
| 192 | Peroba rosa | Aspidosperma polyneuron | Nativa BR | Grande | Grande | Perenifólia | N (incompatível) | 30 | 12 | Sim | Sim |
| 193 | Pindaiva | Duguetia lanceolata | Nativa BR | Grande | Pequena | Perenifólia | N (incompatível) | 20 | 5 | Sim | Sim |
| 34 | pingo-de-ouro; violeteira | Duranta erecta L. | Exótica | Pequeno | Pequena | Perenifólia | C (compatível) | 6 | 4 | Não | Não |
| 27 | Pinha | Annona squamosa L. | Exótica | Pequeno | Média | Decídua | C (compatível) | 7 | 6 | Não | Não |
| 194 | Pinha-do-brejo | Magnolia ovata (syn. Talauma ovata) | Nativa BR | Grande | Média | Perenifólia | A (com cuidados) | 30 | 6 | Sim | Sim |
| 25 | Pitangueira | Eugenia uniflora | Nativa BR | Médio | Média | Semidecídua | C (compatível) | 12 | 6 | Sim | Sim |
| 31 | Primavera | Bougainvillea glabra Choisy | Nativa BR | Médio | Média | Semidecídua | A (com cuidados) | 10 | 6 | Não | Não |
| 195 | Quaresmeira | Tibouchina granulosa | Nativa BR | Médio | Média | Perenifólia | A (com cuidados) | 12 | 5 | Sim | Sim |
| 196 | Quereltéria | Koelreuteria paniculata | Exótica | Médio | Pequena | Decídua | C (compatível) | 8 | 4 | Sim | Sim |
| 86 | Rabo-de-cutia | Stifftia crysantha | Nativa BR | Pequeno | Pequena | Perenifólia | C (compatível) | 3,5 | 5 | Sim | Sim |
| 107 | Rabo-de-cutia | Stifftia crysantha Mikan | Nativa BR | Pequeno | Pequena | Perenifólia | C (compatível) | 3,5 | — | Sim | Sim |
| 198 | Resedá de folha graúda | Lagerstroemia speciosa | Exótica | Médio | Média | Semidecídua | A (com cuidados) | 15 | 7 | Sim | Sim |
| 2 | Resedá extremosa | Lagerstroemia indica | Exótica | Médio | Pequena | Decídua | A (com cuidados) | 8 | 5 | Sim | Sim |
| 4 | Sabão-de-soldado | Sapindus saponaria | Nativa BR | Médio | Média | Perenifólia | C (compatível) | 9 | 8 | Sim | Sim |
| 70 | Sapateiro, tobocuva | Pera glabrata | Nativa BR | Médio | Média | Perenifólia | A (com cuidados) | 10 | 5 | Sim | Sim |
| 75 | Sapucaia | Lecythis pisonis | Nativa BR | Grande | Grande | Semidecídua | N (incompatível) | 30 | 20 | Sim | Sim |
| 71 | Sibipiruna | Caesalpinia peltophoroides | Nativa BR | Grande | Grande | Semidecídua | N (incompatível) | 16 | 10 | Sim | Sim |
| 72 | Sombreiro | Clitoria fairchildiana | Nativa BR | Médio | Grande | Decídua | A (com cuidados) | 12 | 8 | Sim | Sim |
| 73 | Suinã | Erythrina speciosa | Nativa BR | Pequeno | Pequena | Decídua | C (compatível) | 6 | 4 | Sim | Sim |
| 74 | Tarumã-do-cerrado | Vitex polygama | Nativa BR | Médio | Média | Decídua | A (com cuidados) | 10 | 5 | Sim | Sim |
| 44 | Tuia | Thuja occidentalis | Exótica | Médio | Média | Perenifólia | N (incompatível) | 15 | 6 | Não | Não |
| 5 | Uvaia | Eugenia pyriformis Cambess. | Nativa BR | Médio | Média | Semidecídua | C (compatível) | 13 | 7 | Sim | Sim |
