# Estimativas Ambientais

O sistema produz dois tipos de estimativa ambiental, com naturezas metodológicas bastante distintas. A **projeção de crescimento em 10 anos** é um dado tabelado, calculado fora do sistema e carregado no banco espécie a espécie. A **estimativa de cobertura de copa** é um cálculo geométrico feito em tempo de execução sobre os pontos de um projeto. Nenhuma das duas participa da pontuação da recomendação.

## Projeção de crescimento em 10 anos

### Cenário e origem dos dados

A projeção adota um cenário único e fixo para todas as espécies: muda inicial de **DAP 3 cm e altura 1,5 m**, plantada em **boas condições**, com horizonte de **10 anos**. Como esses três parâmetros são constantes, não viraram colunas do banco — estão embutidos como texto de interface na constante `CENARIO_PROJECAO`, "Muda de DAP 3 cm e altura 1,5 m, plantada em boas condições." (`src/components/trees/TreeDetailModal.tsx:30`), e como comentários nas colunas do banco.

A origem dos números é uma planilha fornecida pelo orientador, `dados_app_projecao_10_anos_especies_cartilha.xlsx`, aba `projecao_10a_app`, processada pelo script `scripts/gerar_migration_projecao_10a.py`. O script tem dois modos: `mapear`, que lê a tabela `trees` do Postgres local e escreve o arquivo de correspondência `scripts/mapa_projecao_10a.csv`; e `sql`, que gera a migration de carga a partir desse CSV. O cabeçalho do script explica por que a correspondência é versionada em arquivo e não resolvida por consulta: a planilha usa um identificador próprio (`especie_id`, de 1 a 136) que não coincide com `trees.id`, e adota nomenclatura taxonômica atualizada enquanto o banco ainda registra sinônimos antigos — o exemplo citado no próprio código é `Tabebuia chrysotricha` no banco contra `Handroanthus chrysotrichus` na planilha. A decisão consequente é explícita: a migration grava uma lista de `trees.id`, "nunca por `WHERE nome_cientifico = ...`".

O mapa resultante tem 149 linhas e registra o método de casamento de cada uma: **110 por nome científico, 30 por nome popular e 9 por decisão manual** (`override`, usada quando o casamento automático era ambíguo). Em 26 dessas linhas o gênero registrado no banco difere do gênero na planilha, o que dimensiona a extensão do problema de sinonímia taxonômica.

### Colunas e fórmulas

A migration `supabase/migrations/20260802000000_add_projecao_10a_to_trees.sql` acrescenta **15 colunas** a `trees`: `dap_10a_cm`, `dap_10a_min_cm`, `dap_10a_max_cm`, `altura_10a_m`, `altura_10a_min_m`, `altura_10a_max_m`, `biomassa_aerea_10a_kg`, `carbono_armazenado_10a_kg`, `co2e_10a_kg`, `sobrevivencia_10a_pct` e `co2e_esperado_por_muda_10a_kg` (todas `numeric`), mais `classe_bvoc`, `evidencia_bvoc`, `confianca_bvoc` (texto) e `exibir_aviso_bvoc` (booleano, padrão falso).

As duas conversões centrais estão documentadas como comentários das próprias colunas, o que as torna consultáveis diretamente no catálogo do banco:

- **Carbono armazenado** = biomassa aérea × **0,47** (`carbono_armazenado_10a_kg`), isto é, assume-se que 47 % da massa seca é carbono.
- **CO₂ equivalente** = carbono × **3,6667** (`co2e_10a_kg`), a razão entre as massas molares do CO₂ e do carbono (44/12).
- **CO₂e esperado por muda** já vem ponderado pela taxa de sobrevivência (`co2e_esperado_por_muda_10a_kg`), de modo que representa o retorno esperado por muda plantada, e não por árvore sobrevivente.

As colunas `_min_` e `_max_` de DAP e altura carregam a faixa de incerteza da planilha, e `sobrevivencia_10a_pct` está restrita ao intervalo de 0 a 100 por `CHECK`.

A classificação de **BVOC** — compostos orgânicos voláteis biogênicos — é qualitativa e vem acompanhada de metadados de qualidade: `classe_bvoc` assume `baixo`, `moderado`, `alto`, `desconhecido` ou `indeterminado`; `evidencia_bvoc` registra a procedência da atribuição, majoritariamente fatores de gênero do i-Tree, com anotações como "sem fator localizado" quando não houve base; `confianca_bvoc` assume `baixa`, `baixa-média`, `média` ou `média-alta`; e `exibir_aviso_bvoc` é o interruptor que faz a interface mostrar uma ressalva. Essa separação entre valor e confiança no valor é metodologicamente relevante para a dissertação, porque torna auditável a diferença entre um dado medido e uma extrapolação de gênero.

### Cobertura do catálogo

A carga preenche **149 das 167 espécies**. Entre as 146 espécies ativas, **145 têm projeção**; a única exceção é o **Jerivá** (`id` 41), excluído por ser palmeira: como registra o comentário em `src/components/trees/TreeDetailModal.tsx:47-50`, palmeiras não seguem a alometria de DAP em que a projeção se baseia. As demais linhas sem projeção estão entre as espécies inativas.

### Onde a projeção aparece na interface

No **detalhe da espécie**, a seção "Projeção em 10 anos" só é renderizada quando `dap_10a_cm` não é nulo (`src/components/trees/TreeDetailModal.tsx:52`). Ela apresenta até seis blocos: DAP em centímetros com duas casas e a faixa "entre X e Y cm"; Altura em metros, também com faixa; "CO₂e capturado" em quilogramas; "CO₂e esperado por muda", com a nota "já descontada a mortalidade"; "Sobrevivência" em porcentagem; e "Biomassa aérea" em quilogramas, com o detalhe "N kg de carbono". Em seguida vem a etiqueta "Emissão de BVOC:" com o rótulo traduzido (Baixa, Moderada, Alta, Desconhecida ou Indeterminada) e, quando `exibir_aviso_bvoc` é verdadeiro, a ressalva "Classificação de BVOC com evidência limitada (evidência) — confiança X.". A frase do cenário fecha a seção. Todos os números são formatados com `toLocaleString('pt-BR')`.

No **catálogo**, a projeção alimenta dois critérios de ordenação, adicionados posteriormente: "Maior captura de CO₂ (10 anos)" e "Maior crescimento em altura (10 anos)" (`src/components/trees/TreesToolbar.tsx:81-82`), implementados em `src/pages/TreesPage.tsx:115-119` como diferenças decrescentes de `co2e_esperado_por_muda_10a_kg` e de `altura_10a_m`, com `?? 0` para os nulos — o que faz as espécies sem projeção aparecerem no fim da lista. No **formulário administrativo**, uma seção recolhível "Projeção de Crescimento (10 anos)" permite editar os 15 campos (`src/components/admin/TreeFormModal.tsx`).

### O que a projeção não faz

A função de recomendação recebe essas colunas — o `select('*')` as traz e a interface `Tree` da função as declara — mas **não as utiliza em nenhuma regra eliminatória nem em nenhum peso**. O próprio código anota: "Não entra na pontuação hoje; vem no `select('*')` e é devolvida ao cliente" (`supabase/functions/recommend-trees/index.ts:54-55`). Em outras palavras, a captura de carbono projetada é hoje um atributo informativo e um critério de ordenação manual, não um fator de decisão automatizado. Essa é uma escolha de projeto com consequência direta para a discussão acadêmica: o ranking de recomendação otimiza adequação ao sítio, não desempenho climático.

## Estimativa de cobertura de copa

A segunda estimativa é geométrica e opera sobre um projeto de plantio, não sobre uma espécie isolada. A metodologia está escrita em `docs/estimativa-cobertura-copa.md`: aproxima-se a projeção da copa no solo por um círculo e aplica-se a área do círculo,

```
Área = π × raio², com raio = diametro_copa_adulto_max_m / 2
```

usando o diâmetro adulto máximo registrado no banco. O documento traz o exemplo do Resedá: 5 m de diâmetro produzem raio 2,5 m e área de 19,63 m², exibidos como 20 m² após arredondamento. O mesmo documento chama atenção para a não linearidade — 3 m de copa geram cerca de 7 m², 10 m geram cerca de 78 m² — e justifica a métrica pelo uso em licenciamentos municipais de compensação ambiental.

O cálculo aparece em dois lugares, com a mesma fórmula. No **dashboard do projeto**, `src/components/projects/ProjectStatsModal.tsx:39` acumula `Math.PI * Math.pow(raio, 2)` sobre todos os pontos e apresenta o total junto com a contagem de árvores, o número de espécies distintas, a divisão entre nativas e exóticas (com três vereditos textuais conforme o percentual) e a distribuição por porte. No **relatório em PDF**, `src/lib/pdf.ts:98` faz a mesma soma e a imprime no indicador "COBERTURA DE COPA", ao lado de "DIVERSIDADE" (número de espécies distintas) e "ORIGEM (NATIVAS)" (`src/lib/pdf.ts:120-144`).

O percentual de nativas é o quociente entre pontos cuja espécie tem `origem = 'Nativa BR'` e o total de pontos do projeto, arredondado. Para referência de escala: no catálogo completo, 129 das 167 espécies são nativas do Brasil (121 das 146 ativas), de modo que um projeto pode facilmente atingir percentuais altos se o usuário quiser.

Três limitações desta estimativa devem ser registradas. Primeiro, ela usa o **diâmetro adulto máximo**, isto é, descreve um cenário de maturidade plena, não o estado no horizonte de 10 anos — e portanto não é comparável nem combinável com a projeção descrita acima. Segundo, ela ignora sobreposição de copas: duas árvores plantadas a três metros uma da outra somam áreas que na prática se sobrepõem. Terceiro, pontos cuja espécie não resolve (por exemplo, após a exclusão de uma espécie do catálogo, que deixa `tree_id` nulo) simplesmente não entram na conta.
