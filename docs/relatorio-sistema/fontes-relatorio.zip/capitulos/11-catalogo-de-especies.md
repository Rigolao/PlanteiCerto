# Catálogo de espécies

O catálogo é a página inicial do PlanteiCerto (rota `/`) e concentra a consulta livre ao acervo de
espécies: apresentação, busca textual, ordenação, filtros avançados, favoritos, rolagem infinita e os
estados de carregamento e de resultado vazio. É uma página **pública** — qualquer visitante que tenha
passado pela tela de proteção intelectual vê todas as espécies; apenas os favoritos exigem conta.

Arquivos-fonte principais: `src/pages/TreesPage.tsx`, `src/components/trees/TreesToolbar.tsx`,
`src/components/trees/TreeGrid.tsx`, `src/components/trees/TreeCard.tsx`,
`src/components/ui/EmptyStateFilters.tsx`, `src/components/ui/Skeleton.tsx` e
`src/hooks/{useTrees,useFavorites}.ts`.

No banco de demonstração há **167 espécies cadastradas, das quais 146 estão ativas**; o catálogo
público exibe apenas as ativas — daí o número 146 repetido em todas as capturas. A paginação interna
é de **6 espécies por vez**.

---

## 1. Abertura da página

### Hero e chamada para a recomendação

![Topo da página: título grande "Encontre a árvore certa", subtítulo e botão verde](../shots/13-catalogo-hero.png)

**Rota:** `/` · **Quem acessa:** visitante ou usuário autenticado · **Viewport/tema:** desktop claro
(recorte dos 380 px superiores)

**Elementos visíveis:**

- Título em duas cores: **"Encontre a árvore "** em verde-escuro quase preto e **"certa"** em verde,
  em itálico da fonte de display.
- Subtítulo: "Descubra as melhores espécies para arborização urbana, com avaliações de impacto nas
  calçadas, limpeza e clima."
- Botão verde arredondado **"Encontrar Árvore Recomendada"** com um ícone de sol/brilho à esquerda.
- Logo abaixo, a barra de ferramentas: campo de busca com lupa e o texto de apoio "Buscar por nome ou
  espécie…", o seletor de ordenação exibindo **"Nome (A → Z)"** e o botão **"Filtros Avançados"**.
- Por fim, o contador **"Mostrando 6 de 146 árvores"** (os números em negrito).

**Ações possíveis / o que acontece:**

- "Encontrar Árvore Recomendada" → navega para `/recomendacao` (questionário guiado, documentado em
  outro capítulo).
- Digitar no campo de busca, trocar a ordenação ou abrir os filtros atualiza a grade imediatamente.

**Estados relacionados:** `13-catalogo-grid`, `13-catalogo-skeleton`

### Estado de carregamento (skeleton)

![Seis retângulos cinzentos no lugar dos cards, com a barra de ferramentas já visível](../shots/13-catalogo-skeleton.png)

**Rota:** `/` · **Quem acessa:** qualquer pessoa, nos primeiros instantes do carregamento
· **Viewport/tema:** desktop claro. Captura obtida atrasando artificialmente em 4 s a resposta da
consulta de espécies.

**Elementos visíveis:**

- Hero, botão de recomendação e barra de ferramentas já renderizados e funcionais.
- No lugar da grade, **6 blocos de espera** (`TreeCardSkeleton`) com a mesma proporção dos cards:
  uma área de imagem cinza-clara arredondada e, abaixo, três barrinhas cinza simulando título,
  nome científico e linhas de atributos.
- O contador "Mostrando … de … árvores" **não** aparece enquanto os dados não chegam.

**Ações possíveis / o que acontece:**

- Nenhuma ação sobre os blocos; assim que os dados chegam eles são substituídos pelos cards reais.

**Estados relacionados:** `13-catalogo-grid`

### Grade padrão

![Página inteira do catálogo com seis cards de espécies em quatro colunas](../shots/13-catalogo-grid.png)

**Rota:** `/` · **Quem acessa:** visitante · **Viewport/tema:** desktop claro, captura de página inteira

**Elementos visíveis:**

- Contador **"Mostrando 6 de 146 árvores"**.
- Grade responsiva (4 colunas em 1440 px; 5 colunas acima de 1536 px; 3, 2 ou 1 em telas menores) com
  as 6 primeiras espécies em ordem alfabética: **Açoita-cavalo** (*Luehea divaricata Mart.*),
  **Açoita-cavalo** (*Luehea divaricata*), **Aldrago** (*Pterocarpus violaceus Vogel*),
  **Aldrago miúdo** (*Pterocarpus rohrii Vahl*), **Aldrago miúdo** (*Pterocarpus rohrii*) e
  **Alecrim-de-campinas** (*Holocalyx balansae Micheli*).
- **Anatomia de cada card** (`TreeCard`): fotografia em proporção 4:3 no topo; sobre ela, no canto
  superior esquerdo, o chip escuro translúcido **"+ Comparar"** e, no canto superior direito, um botão
  circular com o ícone de coração (vazio). Abaixo da foto: nome popular em verde e negrito, uma
  pílula clara à direita indicando a origem (**"Nativa"** com ícone de casa, ou "Exótica" com ícone de
  globo), o nome científico em itálico cinza e três linhas de atributos — **Altura** (ex.:
  "25m (Grande)"), **Folhagem** (ex.: "Decídua", "Perenifólia", "Semidecídua") e **Espinhos**
  ("Sim"/"Não"). Espécies sem foto usam uma ilustração vetorial de árvore sobre fundo verde-claro.
- O card inteiro é clicável; ao passar o cursor ele sobe alguns pixels e ganha sombra.

**Ações possíveis / o que acontece:**

- Clicar no card → abre o modal de detalhe da espécie (capítulo seguinte).
- Clicar no chip "+ Comparar" → adiciona a espécie à comparação (não abre o detalhe).
- Clicar no coração → favorita (autenticado) ou dispara o convite de login (visitante).
- Rolar até o fim → carrega mais 6 espécies automaticamente.

**Estados relacionados:** `13-catalogo-grid-mobile-p1`, `13-catalogo-grid-dark`, `13-catalogo-scroll-infinito`

---

## 2. Busca, ordenação e filtros

### Busca textual

![Campo de busca com a palavra "ipê" e quatro cards de ipês amarelos](../shots/13-catalogo-busca.png)

**Rota:** `/` · **Quem acessa:** visitante · **Viewport/tema:** desktop claro

**Elementos visíveis:**

- Campo de busca preenchido com **"ipê"** e com borda verde (foco).
- Contador **"Mostrando 6 de 14 árvores"** — ou seja, 14 espécies do acervo correspondem ao termo.
- Os quatro primeiros resultados são todos chamados **"Ipê-amarelo"**, com nomes científicos
  diferentes: *Tabebuia chrysotricha* (10m, Médio, Decídua), *Tabebuia aurea* (14m, Médio,
  Perenifólia), *Tabebuia ochracea* (14m, Médio, Decídua) e *Tabebuia serratifolia* (20m, Grande,
  Decídua).

**Ações possíveis / o que acontece:**

- A busca é aplicada a cada tecla, sem botão de confirmar, e compara o termo com **nome popular e
  nome científico**.
- A comparação ignora acentos e diferenças de maiúsculas (buscar "ipe" devolve os mesmos resultados
  de "ipê").
- Alterar a busca reinicia a contagem visível para 6 itens.

**Estados relacionados:** `13-catalogo-vazio-filtros`

### Ordenação

O seletor de ordenação é um `<select>` nativo; o menu aberto pelo sistema operacional não aparece em
capturas de tela, por isso as opções estão listadas em texto. Foram lidas diretamente do componente
em execução, nesta ordem:

| Valor exibido | Efeito |
|---|---|
| Ordenar por... | opção vazia (nenhuma ordenação explícita) |
| Nome (A → Z) | ordem alfabética crescente pelo nome popular — **padrão ao abrir a página** |
| Nome (Z → A) | ordem alfabética decrescente |
| Maior porte primeiro | Grande → Médio → Pequeno |
| Menor porte primeiro | Pequeno → Médio → Grande |
| Mais sombra primeiro | maior `potencial_sombra` (escala 1–5) primeiro |
| Maior captura de CO₂ (10 anos) | maior CO₂e esperado por muda em 10 anos primeiro |
| Maior crescimento em altura (10 anos) | maior altura projetada em 10 anos primeiro |

Quando há ordenação selecionada, o seletor fica com borda e texto verdes.

#### Resultado da ordenação "Maior captura de CO₂ (10 anos)"

![Seletor exibindo "Maior captura de CO₂ (10 anos)" e cards de Jacarandá-da-Bahia, Jequitibá rosa, Jatobá e Sibipiruna](../shots/13-catalogo-ordem-co2.png)

**Rota:** `/` · **Quem acessa:** visitante · **Viewport/tema:** desktop claro

**Elementos visíveis:**

- O seletor mostra **"Maior captura de CO₂ (10 anos)"**; o contador continua "Mostrando 6 de 146 árvores".
- A grade passa a começar por **Jacarandá-da-Bahia** (*Dalbergia nigra*, 20m Grande, Semidecídua),
  **Jequitibá rosa** (*Cariniana legalis (Mart.) Kuntze*, 60m Grande, Decídua), **Jatobá**
  (*Hymenaea courbaril L.*, 20m Grande, Semidecídua) e **Sibipiruna**
  (*Caesalpinia peltophoroides*, 16m Grande, Semidecídua).

**Ações possíveis / o que acontece:**

- A ordenação é aplicada sobre o conjunto já filtrado e reinicia a contagem visível para 6 itens.
- Espécies sem projeção de 10 anos (palmeiras, por exemplo) são tratadas como valor zero e vão para o
  fim da lista.

**Estados relacionados:** `13-catalogo-ordem-porte`

#### Resultado da ordenação "Maior porte primeiro"

![Seletor exibindo "Maior porte primeiro" e quatro espécies de grande porte](../shots/13-catalogo-ordem-porte.png)

**Rota:** `/` · **Quem acessa:** visitante · **Viewport/tema:** desktop claro

**Elementos visíveis:**

- Seletor com **"Maior porte primeiro"**; contador "Mostrando 6 de 146 árvores".
- Todas as espécies visíveis têm a etiqueta de altura terminando em **(Grande)**: Açoita-cavalo
  (25m), Aldrago miúdo (20m), Alecrim-de-campinas (25m) e Amarelinho (18m). Dentro do mesmo porte a
  ordem alfabética original é preservada.

**Estados relacionados:** `13-catalogo-ordem-co2`

### Painel "Filtros Avançados" com dois critérios marcados

![Painel branco aberto abaixo da barra de ferramentas, com três seletores e quatro caixas de seleção, duas marcadas](../shots/13-catalogo-filtros-avancados.png)

**Rota:** `/` · **Quem acessa:** visitante · **Viewport/tema:** desktop claro

**Elementos visíveis:**

- O botão **"Filtros Avançados"** ficou verde-claro e ganhou um **contador circular com "2"**.
- Painel **"Critérios Específicos"** (cartão branco arredondado) com, à direita do título, o link
  sublinhado **"Limpar Todos (2)"**.
- Primeira linha, três seletores: **Porte da Árvore** ("Qualquer tamanho", "Grande (acima de 12m)",
  "Médio (6m a 12m)", "Pequeno (até 6m)"); **Tamanho da Copa** ("Qualquer copa", "Grande", "Média",
  "Pequena"); **Tipo de Folhagem** ("Todas", "Perenifólia (Não perde folha)", "Decídua (Perde
  folhas)", "Semidecídua (Perde parcialmente)").
- Quatro caixas de seleção, cada uma com título e explicação:
  **"Nativas do Brasil" / "Árvores de origem nacional"** (marcada, fundo verde-claro),
  **"Sem Espinhos" / "Totalmente livres de espinhos"** (marcada),
  **"Compatível p/ Fiação" / "Árvores que não encostam nos fios"** (desmarcada) e
  **"Calçadas Seguras" / "Baixo risco de destruição (Dano 1 ou 2)"** (desmarcada).
- Abaixo do painel, o contador passou a **"Mostrando 6 de 115 árvores"**.

**Ações possíveis / o que acontece:**

- Cada critério marcado incrementa o contador do botão; "Limpar Todos (N)" zera apenas os filtros
  avançados (a busca textual e o filtro de favoritos permanecem).
- "Compatível p/ Fiação" seleciona apenas espécies com compatibilidade total (código `C`);
  "Calçadas Seguras" mantém as espécies com potencial de dano à calçada 1 ou 2.
- Clicar de novo em "Filtros Avançados" recolhe o painel **sem** limpar os filtros — eles continuam
  ativos, sinalizados pelo contador.

**Estados relacionados:** `13-catalogo-vazio-filtros`

### Estado vazio com filtros ativos

![Ilustração de árvore com lupa e um "x", mensagem de nenhum resultado e dois chips removíveis](../shots/13-catalogo-vazio-filtros.png)

**Rota:** `/` · **Quem acessa:** visitante · **Viewport/tema:** desktop claro

**Elementos visíveis:**

- Busca preenchida com **"zzzz"** e o botão "Filtros Avançados" com o contador **"1"** (o filtro de
  porte "Grande" continua ativo mesmo com o painel recolhido).
- No lugar da grade, o componente `EmptyStateFilters`: ilustração cinza-clara de uma árvore com uma
  lupa contendo um "×"; título **"Nenhuma árvore encontrada"**; texto de apoio **"Tente remover um dos
  filtros ativos:"**.
- Dois chips verde-claros removíveis, cada um com um "×": **`Busca: "zzzz"`** e **`Porte: Grande`**.
- Abaixo, o link sublinhado **"Limpar todos os filtros"**.
- O contador "Mostrando … de …" desaparece quando não há resultados.

**Ações possíveis / o que acontece:**

- Clicar em um chip remove **apenas aquele** critério e refaz a busca (cada chip tem
  `aria-label="Remover filtro: …"`).
- "Limpar todos os filtros" zera busca, filtros avançados e o recorte de favoritos de uma vez,
  devolvendo as 146 espécies.
- Os chips cobrem todos os critérios possíveis: busca, porte, copa, folhagem, "Nativas do Brasil",
  "Sem Espinhos", "Compat. Fiação", "Calçadas Seguras" e "Apenas favoritos".

**Estados relacionados:** `13-catalogo-filtros-avancados`

---

## 3. Favoritos

### Visitante clica no coração

![Modal de login aberto e, no rodapé, um toast azul-claro pedindo login](../shots/13-catalogo-favorito-deslogado.png)

**Rota:** `/` · **Quem acessa:** visitante **não** autenticado · **Viewport/tema:** desktop claro

**Elementos visíveis:**

- Toast informativo (fundo azul-claro, ícone "i") na parte inferior central:
  **"Faça login para favoritar árvores."**
- Simultaneamente, o **AuthModal abre no modo "Entrar"**, sobre o catálogo desfocado.
- O coração do card permanece vazio — nada foi salvo.

**Ações possíveis / o que acontece:**

- Concluir o login no modal habilita os favoritos; fechar o modal mantém a navegação pública.
- O botão "Favoritos" da barra de ferramentas **não existe** para visitantes.

**Estados relacionados:** `12-auth-login`, `13-catalogo-favorito-ativo`

### Espécie favoritada por um usuário autenticado

![Primeiro card com coração vermelho preenchido e o botão Favoritos exibindo 4](../shots/13-catalogo-favorito-ativo.png)

**Rota:** `/` · **Quem acessa:** usuário autenticado · **Viewport/tema:** desktop claro (recorte da
barra de ferramentas e da primeira fileira de cards)

**Elementos visíveis:**

- Barra de ferramentas com o botão **"Favoritos"** acompanhado do contador **"4"** (a conta de
  demonstração tinha 3 favoritos e acabou de ganhar mais um).
- O primeiro card ("Açoita-cavalo", *Luehea divaricata Mart.*) está com o **coração preenchido em
  vermelho** dentro de um círculo vermelho; os demais cards continuam com o coração vazio.
- Contador da grade inalterado: "Mostrando 6 de 146 árvores".

**Ações possíveis / o que acontece:**

- O clique grava o favorito imediatamente (atualização otimista) e o contador do botão "Favoritos"
  sobe na hora.
- **Comportamento observado:** favoritar ou desfavoritar **não exibe nenhum toast** para o usuário
  autenticado — a única confirmação visual é o coração mudar de estado e o contador mudar. (O toast
  existe apenas no caso do visitante não autenticado.)
- Clicar de novo no mesmo coração remove o favorito.

**Estados relacionados:** `13-catalogo-favoritos-ativo`

### Filtro "Favoritos" ativo

![Botão Favoritos em vermelho com badge 4 e quatro cards, todos com coração vermelho](../shots/13-catalogo-favoritos-ativo.png)

**Rota:** `/?favoritos=true` · **Quem acessa:** usuário autenticado · **Viewport/tema:** desktop claro,
página inteira

**Elementos visíveis:**

- O botão **"Favoritos"** está destacado: fundo vermelho-claro, texto e coração preenchido em
  vermelho, contador **"4"** em círculo vermelho sólido.
- Contador da grade: **"Mostrando 4 de 4 árvores"**.
- Os quatro cards exibidos — **Açoita-cavalo** (*Luehea divaricata Mart.*), **Ipê-amarelo**
  (*Tabebuia chrysotricha*), **Ipê-roxo-de-bola** (*Handroanthus impetiginosus*) e **Oiti**
  (*Licania tomentosa*) — têm todos o coração vermelho preenchido.
- O endereço do navegador passa a conter o parâmetro `?favoritos=true`.

**Ações possíveis / o que acontece:**

- Clicar de novo em "Favoritos" remove o parâmetro da URL e devolve o acervo completo.
- O recorte de favoritos se combina com busca, ordenação e filtros avançados; quando zera resultados,
  aparece o chip **"Apenas favoritos"** no estado vazio.
- Como o filtro vive na URL, o endereço pode ser copiado e reaberto — mas só funciona para a própria
  conta autenticada.

**Estados relacionados:** `13-catalogo-favorito-ativo`, `13-catalogo-vazio-filtros`

## Fluxo passo a passo — favoritar uma espécie

1. Com a sessão iniciada, o usuário localiza a espécie na grade (ver `13-catalogo-grid`).
2. Clica no **ícone de coração** no canto superior direito da foto do card. O clique não abre o
   detalhe da espécie.
3. O coração passa a vermelho preenchido e o contador do botão "Favoritos" aumenta — sem mensagem de
   confirmação (ver `13-catalogo-favorito-ativo`).
4. Para rever apenas as espécies marcadas, o usuário clica em **"Favoritos"**: a URL ganha
   `?favoritos=true` e a grade passa a mostrar somente elas (ver `13-catalogo-favoritos-ativo`).
5. Um novo clique no coração (na grade ou no modal de detalhe) desfaz o favorito.
6. Um visitante que tente o passo 2 recebe o toast **"Faça login para favoritar árvores."** e o modal
   de login (ver `13-catalogo-favorito-deslogado`).

---

## 4. Rolagem infinita, mobile e tema escuro

### Rolagem infinita

![Contador mostrando "Mostrando 30 de 146 árvores" acima da primeira fileira de cards](../shots/13-catalogo-scroll-infinito.png)

**Rota:** `/` · **Quem acessa:** visitante · **Viewport/tema:** desktop claro (recorte da barra de
ferramentas e do contador, após rolar a página e voltar ao topo)

**Elementos visíveis:**

- Contador atualizado para **"Mostrando 30 de 146 árvores"** — depois de duas rolagens até o fim da
  página, cinco blocos de 6 espécies foram acrescentados aos 6 iniciais.
- A barra de ferramentas continua com busca vazia, ordenação "Nome (A → Z)" e "Filtros Avançados"
  sem contador.

**Ações possíveis / o que acontece:**

- Não existe botão "carregar mais" nem paginação numerada: um sentinela invisível no fim da lista
  aciona o carregamento quando chega a 200 px da área visível.
- Trocar busca, ordenação ou filtros **reinicia** a contagem para 6 itens.
- Os dados já vêm todos do servidor de uma vez; a rolagem apenas revela mais cards (não há nova
  requisição por página).

**Estados relacionados:** `13-catalogo-grid`

### Catálogo no mobile

![Catálogo em coluna única: header compacto com hambúrguer, hero, toolbar empilhada e cards um abaixo do outro](../shots/13-catalogo-grid-mobile-p1.png)

![Continuação da rolagem mobile, com mais cards de espécies](../shots/13-catalogo-grid-mobile-p2.png)

**Rota:** `/` · **Quem acessa:** visitante · **Viewport/tema:** mobile 390×844, claro (página inteira,
dividida em duas partes)

**Elementos visíveis:**

- Header reduzido: logotipo + "PlanteiCerto" à esquerda e o botão hambúrguer à direita; os logotipos
  institucionais e os links somem (ficam no drawer).
- Hero com o título quebrando em duas linhas ("Encontre a árvore" / "certa") e o botão
  "Encontrar Árvore Recomendada" ocupando boa parte da largura.
- Barra de ferramentas **empilhada**: busca, seletor de ordenação e botão "Filtros Avançados", cada
  um em uma linha de largura total.
- Contador "Mostrando 6 de 146 árvores" e a grade em **uma única coluna**, mantendo foto, chip
  "+ Comparar", coração, nome, origem e as três linhas de atributos.

**Ações possíveis / o que acontece:** as mesmas do desktop; os chips de comparação e o coração
continuam tocáveis sobre a foto.

**Estados relacionados:** `11-header-drawer-deslogado-mobile`

### Catálogo no tema escuro

![Catálogo inteiro em fundo preto com cards escuros e textos verde-claros](../shots/13-catalogo-grid-dark.png)

**Rota:** `/` · **Quem acessa:** visitante · **Viewport/tema:** desktop escuro, página inteira

**Elementos visíveis:**

- Fundo preto; cards em cinza muito escuro com borda sutil; nomes populares em verde-claro e nomes
  científicos em cinza-bege.
- As pílulas "Nativa", de altura ("25m (Grande)") e de folhagem ("Decídua", "Perenifólia",
  "Semidecídua") mantêm os fundos claros originais, criando contraste alto sobre o card escuro.
- O botão de tema no Header exibe o ícone de sol; o restante da estrutura é idêntico ao tema claro,
  inclusive o contador "Mostrando 6 de 146 árvores".

**Ações possíveis / o que acontece:** idênticas ao tema claro.

**Estados relacionados:** `11-header-tema-escuro`, `13-catalogo-grid`

---

## Observações sobre os dados do catálogo

- Existem **nomes populares repetidos** com nomes científicos distintos (dois "Açoita-cavalo", dois
  "Aldrago miúdo", vários "Ipê-amarelo"). A grade não sinaliza a diferença além do nome científico em
  itálico, o que pode confundir na hora de comparar ou favoritar.
- Algumas espécies têm campos vazios; nesses casos o card mostra um travessão ("—"), como em
  "Diâmetro da Copa — (Média)" no comparativo.
- O contador só aparece quando há pelo menos um resultado; com zero resultados ele é substituído pelo
  bloco de estado vazio.
