# Arquitetura Técnica

## Visão em camadas

O PlanteiCerto é uma aplicação de página única (SPA) que conversa com uma instalação do Supabase por HTTP. Não existe servidor de aplicação próprio: toda a lógica de apresentação roda no navegador e toda a lógica de dados roda ou no PostgreSQL (via PostgREST e políticas de segurança em nível de linha) ou numa função de borda escrita em Deno. O frontend é compilado por Vite e servido como arquivos estáticos pela Vercel.

A camada de cliente reúne React 19 com roteamento por `react-router-dom`, estilização por Tailwind CSS v4, estado de servidor gerenciado pelo TanStack Query, estado de sessão e tema em contextos React, mapas em Leaflet e geração de PDF no próprio navegador. A camada de serviço é o Supabase: o gateway Kong encaminha para PostgREST (dados), GoTrue (autenticação), Storage (arquivos, com MinIO por trás na produção auto-hospedada) e Edge Runtime (funções Deno). A camada de persistência é o PostgreSQL 17 (`supabase/config.toml:42`). Há ainda três serviços externos consumidos diretamente pelo navegador: os mosaicos de imagem de satélite e rótulos da Esri (`src/components/map/ProjectMap.tsx`), a geocodificação do Nominatim/OpenStreetMap e a consulta de CEP da BrasilAPI, ambas em `src/components/map/MapSearchBox.tsx:35` e `src/components/map/MapSearchBox.tsx:63`; e a telemetria da Vercel (`@vercel/analytics` e `@vercel/speed-insights`, montados em `src/App.tsx:66-67`).

```mermaid
flowchart LR
  subgraph Cliente["Navegador do usuário"]
    UI["React 19 e Vite 7"]
    RQ["TanStack Query v5"]
    CTX["AuthContext e ThemeContext"]
    LEAF["Leaflet e react-leaflet"]
    PDFL["jsPDF e html2canvas"]
    SW["Service Worker (PWA)"]
  end
  subgraph Borda["Vercel"]
    CDN["Hospedagem estática, rewrite SPA e CSP"]
    AN["Analytics e Speed Insights"]
  end
  subgraph Supa["Supabase (auto-hospedado)"]
    KONG["Kong (gateway de API)"]
    REST["PostgREST"]
    AUTH["GoTrue"]
    STO["Storage sobre MinIO"]
    EDGE["Edge Runtime (Deno)"]
    PG[("PostgreSQL 17")]
  end
  subgraph Ext["Serviços externos"]
    ESRI["Esri World Imagery"]
    NOM["Nominatim OpenStreetMap"]
    BAPI["BrasilAPI CEP v2"]
  end
  CDN --> UI
  UI --> RQ
  UI --> CTX
  UI --> LEAF
  UI --> PDFL
  UI --> AN
  SW -.-> UI
  RQ --> KONG
  CTX --> KONG
  KONG --> REST
  KONG --> AUTH
  KONG --> STO
  KONG --> EDGE
  REST --> PG
  AUTH --> PG
  EDGE --> PG
  LEAF --> ESRI
  LEAF --> NOM
  LEAF --> BAPI
```

## Fluxo de dados por funcionalidade

Todo acesso a dados passa por um hook em `src/hooks/`. A tabela abaixo consolida o mapeamento entre funcionalidade, hook, objeto de backend, chave de cache do React Query e tempo de frescor.

| Funcionalidade | Hook (arquivo) | Tabela ou função | Chave de cache | `staleTime` | Observação |
|---|---|---|---|---|---|
| Catálogo de espécies | `useTrees` (`src/hooks/useTrees.ts:6`) | `trees.select('*').order('id')` | `['trees']` | 15 min | Cai para 22 espécies estáticas se não configurado, em erro ou resultado vazio |
| Recomendação | `useRecommendation` (`src/hooks/useRecommendation.ts:5`) | Edge Function `recommend-trees` | mutação, sem cache | — | Lança erro se o Supabase não estiver configurado |
| Perfil e papel | `useProfile` (`src/hooks/useProfile.ts:6`) | `profiles` filtrado por `id` | `['profile', user?.id]` | 5 min | Retorna `null` em erro; expõe `isAdmin` |
| Favoritos | `useFavorites` (`src/hooks/useFavorites.ts:5`) | `user_favorites` | `['favorites', user?.id]` | 5 min | Alternância com atualização otimista e rollback |
| Lista de projetos | `useProjects` (`src/hooks/useProjects.ts:7`) | `projects` com agregação `points(count)` | `['projects', user?.id]` | padrão global (5 min) | Mutações de criar, editar, excluir e reposicionar mapa |
| Pontos de um projeto | `useProjectPoints` (`src/hooks/useProjectPoints.ts:6`) | `points` filtrado por `project_id` | não usa React Query | — | Estado local com `useState`/`useEffect` |
| Usuários (admin) | `useAdminUsers` (`src/hooks/useAdminUsers.ts:6`) | `profiles` ordenada por `created_at` | `['admin-users']` | 2 min | `useUpdateRole` invalida `['admin-users']` e `['profile']` |
| CRUD de espécies (admin) | `useAdminTrees` (`src/hooks/useAdminTrees.ts`) | `trees` e bucket `tree-images` | invalida `['trees']` | — | `useTreeUsageCount` usa `['tree-usage', treeId]`, 30 s |

O `QueryClient` global define `staleTime` de 5 minutos, `gcTime` de 10 minutos, uma única tentativa de repetição e `refetchOnWindowFocus: false` (`src/main.tsx:11-22`). Os hooks que precisam de política diferente a sobrescrevem individualmente.

## Gestão de estado

O estado divide-se em três domínios com responsabilidades claras. O **estado de servidor** é exclusivo do TanStack Query, que é a única fonte de verdade para catálogos, perfis, favoritos e projetos; invalidações explícitas após mutações mantêm as telas coerentes. O **estado de sessão** vive no `AuthContext` (`src/contexts/AuthContext.tsx`), que na montagem chama `supabase.auth.getSession()` e assina `onAuthStateChange`, mapeando a sessão do GoTrue para um `UserProfile` derivado dos metadados do usuário. O **estado de preferência visual** vive no `ThemeContext`, com valores `light`, `dark` ou `system`, padrão `system`, persistido em `localStorage` sob a chave `planteicerto-ui-theme` (`src/main.tsx:29`, `src/contexts/ThemeContext.tsx:24-31`). O restante — filtros, ordenação, seleção de comparação, passo do questionário — é estado local de componente, e alguns itens são promovidos a parâmetros de URL, como `?favoritos=true`.

A única exceção ao padrão é `useProjectPoints`, que administra os pontos do projeto com `useState` e mutações imperativas em vez de React Query. A consequência prática é que os pontos não participam do sistema de invalidação de cache e precisam de `refetch` manual.

## Roteamento e guardas

A árvore de rotas está inteiramente em `src/App.tsx`. Todas as páginas são carregadas sob demanda com `React.lazy` (`src/App.tsx:16-23`), e um `Suspense` com anel de carregamento cobre a transição (`src/App.tsx:25-32`). Dois guardas controlam o acesso: `ProtectedRoute` (`src/components/auth/ProtectedRoute.tsx`) redireciona visitantes para `/` preservando a origem em `location.state.from`; `AdminRoute` (`src/components/auth/AdminRoute.tsx`) combina sessão e papel, exibe "Verificando permissões..." enquanto resolve e dispara uma única vez o aviso "Acesso restrito a administradores." antes de redirecionar. As rotas públicas e protegidas compartilham o `Layout` com cabeçalho; as administrativas usam o `AdminLayout` com barra lateral própria.

```mermaid
flowchart TD
  ROOT["main.tsx: BrowserRouter, QueryClient, ThemeProvider, AuthProvider"]
  EB["ErrorBoundary"]
  GATE["IPProtectionGate"]
  SUS["Suspense com PageSkeleton"]
  LAY["Layout com Header"]
  PUB1["Rota / — TreesPage"]
  PUB2["Rota /quem-somos — AboutPage"]
  PUB3["Rota /recomendacao — RecommendationPage"]
  PROT["ProtectedRoute"]
  PR1["Rota /projetos — ProjectsPage"]
  PR2["Rota /perfil — ProfilePage"]
  PR3["Rota /reset-password — ResetPasswordPage"]
  ADMG["AdminRoute (exige role admin)"]
  ADML["AdminLayout com barra lateral"]
  AD1["Rota /admin/arvores — AdminTreesPage"]
  AD2["Rota /admin/equipe — AdminUsersPage"]
  NF["URL desconhecida — nenhuma rota corresponde"]
  ROOT --> EB
  EB --> GATE
  GATE --> SUS
  SUS --> LAY
  LAY --> PUB1
  LAY --> PUB2
  LAY --> PUB3
  LAY --> PROT
  PROT --> PR1
  PROT --> PR2
  PROT --> PR3
  SUS --> ADMG
  ADMG --> ADML
  ADML --> AD1
  ADML --> AD2
  SUS -.-> NF
```

O nó tracejado registra uma lacuna: não há rota curinga, de modo que um caminho inexistente renderiza uma página em branco. A divisão de pacotes acompanha essa estrutura — além dos `chunks` por rota gerados pelo `lazy`, o Vite recebe três grupos manuais: `vendor-map` (Leaflet), `vendor-pdf` (jsPDF e html2canvas) e `vendor-react` (React, React DOM e o roteador), em `vite.config.ts:10-14`.

## Autenticação: do cadastro ao papel administrativo

O diagrama abaixo descreve o caminho completo de um usuário que se cadastra por e-mail e senha e depois é reconhecido, ou não, como administrador. O ponto arquitetural relevante é que a linha em `public.profiles` não é criada pelo frontend: ela nasce de um gatilho no banco.

```mermaid
sequenceDiagram
    autonumber
    participant U as Usuário
    participant M as AuthModal
    participant C as AuthContext
    participant F as Edge check-email-exists
    participant G as GoTrue
    participant T as Trigger on_auth_user_created
    participant P as Tabela profiles
    participant H as useProfile
    U->>M: preenche nome, e-mail e senha
    M->>C: signUp com nome, e-mail e senha
    C->>F: POST com o e-mail digitado
    F-->>C: resposta exists falso
    C->>G: auth.signUp com metadado nome
    G->>G: INSERT em auth.users
    G->>T: AFTER INSERT dispara handle_new_user
    T->>P: INSERT de id, nome, e-mail e role user
    G-->>C: sessão ativa ou needsConfirmation
    C-->>M: retorno sem erro
    M-->>U: modal Confirme seu e-mail ou sessão iniciada
    U->>M: entra com e-mail e senha
    M->>C: signIn
    C->>G: auth.signInWithPassword
    G-->>C: sessão com JWT válido por uma hora
    C->>H: onAuthStateChange atualiza o usuário
    H->>P: SELECT do perfil onde id igual a auth.uid
    P-->>H: linha do perfil com o campo role
    H-->>U: isAdmin libera ou bloqueia as rotas admin
```

A chamada prévia a `check-email-exists` existe para transformar em mensagem clara o caso de e-mail já cadastrado, que o GoTrue devolve de forma ambígua; se essa verificação falhar, o erro é engolido e o cadastro segue (`src/contexts/AuthContext.tsx`). A duração do JWT é de 3600 segundos no ambiente local (`supabase/config.toml:170`) e o comprimento mínimo de senha é 6 (`supabase/config.toml:187`). O login federado com Google está habilitado (`supabase/config.toml:353-354`).

## Degradação sem backend

O cliente Supabase só é instanciado com credenciais reais quando `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY` estão ambas preenchidas; caso contrário, um cliente de fachada é criado contra `https://placeholder.supabase.co`, e a função `isSupabaseConfigured()` passa a retornar falso (`src/lib/supabase.ts:6-13`). Esse sinal é consultado pelos hooks para decidir o comportamento degradado: `useTrees` devolve as 22 espécies estáticas de `src/data/trees.ts`; `useProfile` e `useFavorites` ficam desabilitados; `useRecommendation` lança "Supabase não está configurado". O efeito é que o catálogo e a navegação continuam funcionando sem backend, enquanto autenticação, projetos e recomendação ficam indisponíveis. A mesma consulta de espécies também retorna o conjunto estático em caso de erro de rede ou resposta vazia (`src/hooks/useTrees.ts:15-17`), o que é conveniente para demonstração mas mascara falhas reais — ponto retomado no capítulo de limitações.

## Build, integração contínua e implantação

O build de produção é `tsc -b && vite build` (`package.json:9`), de modo que qualquer erro de tipagem interrompe a geração do pacote. O fluxo de integração contínua está em `.github/workflows/ci.yml`: em cada `push` ou `pull request` para `master`, com Node 20, executa-se `npm ci`, `npm audit --audit-level=high`, `npm run lint`, `npx tsc --noEmit`, `npm run test:ci` (Vitest, ambiente jsdom, dois arquivos de teste em `src/components/ui/Modal.test.tsx` e `src/components/trees/TreeCard.test.tsx`) e, por fim, `npm run build`. Localmente, um gancho de pré-commit do Husky roda `npm run build` antes de cada commit (`.husky/pre-commit`).

A implantação do frontend é feita na Vercel. O arquivo `vercel.json` cumpre duas funções: reescreve todas as rotas para `/index.html`, requisito de uma SPA com roteamento no cliente, e aplica um conjunto de cabeçalhos de segurança a todas as respostas — `X-Frame-Options: DENY`, `X-Content-Type-Options: nosniff`, `Referrer-Policy: strict-origin-when-cross-origin`, `Permissions-Policy` desativando câmera, microfone e geolocalização, `Strict-Transport-Security` com dois anos, e uma Content Security Policy que restringe `default-src` a `'self'`, autoriza `connect-src` para o domínio da API própria e para os domínios do Supabase e da telemetria da Vercel, admite imagens de qualquer origem HTTPS (necessário para os mosaicos da Esri e as fotos do Storage) e proíbe o enquadramento da página com `frame-ancestors 'none'`. Vale notar que a política atual de `Permissions-Policy` desabilita `geolocation`, enquanto a interface oferece o botão "Minha Localização" no editor de projeto — um conflito potencial que o relatório de telas deve confirmar empiricamente.
