# Projetos de arborização — lista e CRUD

A área **Meus Projetos** (`/projetos`) é o espaço privado onde cada pessoa autenticada organiza seus planos de arborização. Um "projeto" é apenas um contêiner com nome, descrição opcional e uma posição inicial de mapa; as árvores propriamente ditas são os *pontos* adicionados depois, dentro do editor (capítulo seguinte). A rota é protegida por `ProtectedRoute`: quem não está logado é redirecionado para `/` sem mensagem; enquanto a sessão é verificada aparece uma folha pulsando com o texto "Carregando...".

Arquivos-fonte: `src/pages/ProjectsPage.tsx` (decide entre esqueleto, lista e editor), `src/components/projects/ProjectList.tsx`, `ProjectRow.tsx`, `ProgressRing.tsx`, `ProjectModal.tsx`, `src/components/ui/ConfirmationModal.tsx` e o hook `src/hooks/useProjects.ts` (TanStack Query + Supabase).

Regras de dados observadas no código e confirmadas na prática:

| Comportamento | Detalhe |
|---|---|
| Ordenação da lista | `created_at` decrescente — o projeto mais recente aparece em primeiro lugar |
| Contagem de árvores | vem de `points(count)` na mesma consulta dos projetos |
| Anel de progresso | preenchimento = contagem ÷ `Math.max(10, maior contagem entre os projetos)` |
| Centro inicial de um projeto novo | `centro_lat = -21.1767`, `centro_lng = -47.8208`, `centro_zoom = 14` (Ribeirão Preto/SP) |
| Exclusão | remove o projeto e, em cascata, todos os pontos vinculados |

> Observação sobre as capturas: o botão redondo com um ícone de palmeira no canto inferior direito de todas as telas é o atalho do **React Query Devtools**, presente apenas no ambiente de desenvolvimento (`src/main.tsx`). Não faz parte do produto.

---

### Lista de projetos — esqueleto de carregamento

![Esqueleto de carregamento da lista de projetos](../shots/30-projetos-skeleton.png)

**Rota:** `/projetos` — estado exibido enquanto a consulta `projects` está em andamento (aqui forçado com atraso artificial na rede) · **Quem acessa:** usuário autenticado · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- No topo, duas barras cinza arredondadas simulando o título e o subtítulo da página.
- Abaixo, três cartões brancos (`ProjectRowSkeleton`), cada um com um quadrado cinza à esquerda (lugar do anel de progresso) e duas barras de larguras diferentes à direita (nome e contagem).
- Nenhum texto real e nenhum botão: a linha tracejada "Novo projeto" ainda não é renderizada.

**Ações possíveis / o que acontece:**
- Nenhuma; o esqueleto é substituído pela lista assim que a resposta chega.

**Estados relacionados:** `30-projetos-lista`, `30-projetos-vazio`

---

### Lista com os dois projetos de demonstração

![Lista de projetos com um projeto vazio e um projeto com seis árvores](../shots/30-projetos-lista.png)

**Rota:** `/projetos` — acessada pelo menu do avatar ("Meus Projetos") ou pelo menu móvel · **Quem acessa:** usuário autenticado · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Título "Meus Projetos" em serifa e, logo abaixo, o resumo "2 projetos · 6 árvores plantadas no total".
- Primeira linha — "Praça Sete de Setembro (em planejamento)": anel tracejado cinza com o número **0** no centro, nome em negrito e, abaixo, o texto em itálico "Nenhuma árvore adicionada". A linha inteira é exibida com opacidade reduzida (65%), indicando projeto ainda sem pontos.
- Segunda linha — "Arborização Rua Prudente de Moraes": anel verde preenchido em cerca de 60% com o número **6** no centro e a legenda "6 árvores".
- Cada linha termina com um chevron "›" cinza à direita.
- Terceira linha, com borda tracejada: círculo com "+", título "Novo projeto" e subtítulo "Comece um novo plano de arborização".

**Ações possíveis / o que acontece:**
- Clique (ou Enter/Espaço) em uma linha de projeto → abre o **editor de projeto** em tela cheia (ver capítulo "Editor de projeto").
- Clique na linha tracejada → abre o modal "Novo Projeto".
- Passar o mouse sobre uma linha → revela os botões Editar e Excluir e pinta a borda esquerda de verde.

**Estados relacionados:** `30-projetos-linha-hover`, `30-projetos-vazio`, `30-projetos-lista-mobile`, `30-projetos-lista-dark`

---

### Linha de projeto com as ações reveladas (hover)

![Linha do projeto com ícones de lápis e lixeira visíveis](../shots/30-projetos-linha-hover.png)

**Rota:** `/projetos` · **Quem acessa:** usuário autenticado · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- A linha "Arborização Rua Prudente de Moraes" está destacada (fundo branco, leve sombra) e exibe dois ícones à direita, antes do chevron: um **lápis** (`title="Editar projeto"`) e uma **lixeira** (`title="Excluir projeto"`).
- Nas demais linhas os ícones permanecem invisíveis (opacidade 0).

**Ações possíveis / o que acontece:**
- Lápis → abre o modal "Editar Projeto" já preenchido; o clique não abre o editor (o evento é interrompido com `stopPropagation`).
- Lixeira → abre o `ConfirmationModal` "Excluir projeto".

**Estados relacionados:** `31-projetos-modal-editar`, `31-projetos-excluir-confirm`

---

### Lista sem nenhum projeto

![Página Meus Projetos de uma usuária sem projetos](../shots/30-projetos-vazio.png)

**Rota:** `/projetos` (sessão da conta "Colega da Equipe", que não possui projetos) · **Quem acessa:** usuário autenticado · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Título "Meus Projetos" e o resumo "0 projetos · 0 árvores plantadas no total" (o texto usa plural mesmo com zero).
- Apenas a linha tracejada "Novo projeto / Comece um novo plano de arborização".
- Não há ilustração, mensagem de estado vazio dedicada nem chamada para ação adicional.

**Ações possíveis / o que acontece:**
- Clique na linha tracejada → modal "Novo Projeto".

**Estados relacionados:** `30-projetos-lista`, `31-projetos-modal-novo`

---

### Lista em tela pequena

![Lista de projetos em viewport móvel](../shots/30-projetos-lista-mobile.png)

**Rota:** `/projetos` · **Quem acessa:** usuário autenticado · **Viewport/tema:** mobile (390 × 844) claro

**Elementos visíveis:**
- Cabeçalho reduzido: logo "PlanteiCerto" à esquerda e botão hambúrguer à direita (o avatar, o nome e o botão de tema migram para o menu lateral).
- "Meus Projetos" e "2 projetos · 6 árvores plantadas no total" ocupam a largura total.
- Nas duas linhas os nomes são truncados com reticências ("Praça Sete de Set…", "Arborização Rua P…") e os **ícones de lápis e lixeira ficam sempre visíveis**, sem depender de hover.
- A legenda "Nenhuma árvore adicionada" quebra em duas linhas.

**Ações possíveis / o que acontece:**
- Idênticas ao desktop; o toque na linha abre o editor em layout móvel (mapa cheio + folha inferior).

**Estados relacionados:** `30-projetos-lista`, `36-editor-sheet-minimo-mobile`

---

### Lista no tema escuro

![Lista de projetos com tema escuro](../shots/30-projetos-lista-dark.png)

**Rota:** `/projetos` · **Quem acessa:** usuário autenticado · **Viewport/tema:** desktop escuro

**Elementos visíveis:**
- Fundo quase preto, cartões cinza-escuro, textos claros; o anel verde do projeto com 6 árvores e a pill verde mantêm o mesmo matiz do tema claro.
- No cabeçalho, o botão de tema mostra o ícone de **sol** (no tema claro mostra a lua).

**Ações possíveis / o que acontece:**
- Sem diferenças funcionais em relação ao tema claro.

**Estados relacionados:** `30-projetos-lista`

---

### Modal "Novo Projeto" vazio

![Modal Novo Projeto com campos em branco](../shots/31-projetos-modal-novo.png)

**Rota:** `/projetos` → clique em "Novo projeto" · **Quem acessa:** usuário autenticado · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Sobreposição escura com desfoque; cartão branco centralizado no topo, com "×" no canto superior direito.
- Título "Novo Projeto" e subtítulo "Defina um nome para seu plano de arborização".
- Campo **NOME** (rótulo em maiúsculas) com o placeholder "Nome do projeto (ex: Arborização da Rua das Flores)" e o contador "0/100" alinhado à direita.
- Campo **DESCRIÇÃO opcional** (textarea de 3 linhas) com o placeholder "Descrição (opcional)" e o contador "0/500".
- Botões "Cancelar" (contorno) e "Criar" (verde-escuro preenchido).

**Ações possíveis / o que acontece:**
- Digitar no nome atualiza o contador; o campo é `required` e limitado a 100 caracteres (descrição, 500).
- "Criar" com o nome vazio não faz nada (a submissão é bloqueada por `if (!nome.trim()) return`).
- "Cancelar", "×" ou clique fora fecham o modal sem salvar; `Esc` também fecha.

**Estados relacionados:** `31-projetos-modal-preenchido`, `31-projetos-salvando`

---

### Modal "Novo Projeto" preenchido

![Modal Novo Projeto com nome e descrição preenchidos](../shots/31-projetos-modal-preenchido.png)

**Rota:** `/projetos` · **Quem acessa:** usuário autenticado · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Campo NOME com "Projeto de Teste (captura)" e contador **26/100**.
- Campo DESCRIÇÃO com "Projeto criado apenas para ilustrar o fluxo de cadastro no relatório." e contador **69/500**; a borda do textarea fica verde por estar em foco.
- Botão "Criar" habilitado.

**Ações possíveis / o que acontece:**
- "Criar" → grava em `projects` (com `user_id` da sessão e o centro padrão de Ribeirão Preto), invalida o cache da lista e emite o toast de sucesso.

**Estados relacionados:** `31-projetos-salvando`, `31-projetos-toast-criado`

---

### Estado transitório "Salvando..."

![Modal com o botão em estado Salvando](../shots/31-projetos-salvando.png)

**Rota:** `/projetos` · **Quem acessa:** usuário autenticado · **Viewport/tema:** desktop claro (requisição atrasada artificialmente para a captura)

**Elementos visíveis:**
- O botão de submissão troca o rótulo "Criar" por "**Salvando...**", fica esmaecido (opacidade 50%) e desabilitado. O botão "Cancelar" continua ativo.
- Os campos permanecem preenchidos e editáveis.

**Ações possíveis / o que acontece:**
- Ao terminar, o modal fecha sozinho e a lista é recarregada.

**Estados relacionados:** `31-projetos-toast-criado`

---

### Toast "Projeto criado com sucesso!"

![Lista com três projetos e toast verde de criação](../shots/31-projetos-toast-criado.png)

**Rota:** `/projetos` · **Quem acessa:** usuário autenticado · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Toast verde-claro centralizado na base da tela, com ícone de check e o texto "Projeto criado com sucesso!" (sonner, `richColors`, ~4 s).
- O resumo do topo passou a "3 projetos · 6 árvores plantadas no total".
- "Projeto de Teste (captura)" aparece como **primeira** linha, com anel tracejado e "Nenhuma árvore adicionada".

**Ações possíveis / o que acontece:**
- O toast some sozinho; a lista já está atualizada.
- Em caso de falha o hook emite "Erro ao criar o projeto." (não capturado).

**Estados relacionados:** `30-projetos-lista`

---

### Modal "Editar Projeto" pré-preenchido

![Modal Editar Projeto com os dados atuais](../shots/31-projetos-modal-editar.png)

**Rota:** `/projetos` → hover na linha → ícone de lápis · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Mesmo cartão do cadastro, mas com o título "**Editar Projeto**" e **sem** o subtítulo explicativo.
- Nome e descrição já carregados ("Projeto de Teste (captura)", 26/100 e 69/500).
- Botão de submissão rotulado "**Salvar**" (em vez de "Criar").
- Ao fundo ainda se vê o toast da criação anterior, prestes a desaparecer.

**Ações possíveis / o que acontece:**
- "Salvar" atualiza apenas `nome` e `descricao` (o centro do mapa não é alterado aqui).

**Estados relacionados:** `31-projetos-toast-atualizado`

---

### Toast "Projeto atualizado com sucesso!"

![Toast de atualização com o modal ainda fechando](../shots/31-projetos-toast-atualizado.png)

**Rota:** `/projetos` · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Toast verde "Projeto atualizado com sucesso!" na base.
- O modal "Editar Projeto" ainda aparece na captura (o nome já está como "Projeto de Teste (captura) v2", 29/100): o toast é disparado pela mutação antes de a animação de fechamento do modal terminar (~300 ms).

**Ações possíveis / o que acontece:**
- Nada a fazer; o modal desaparece e a lista mostra o novo nome.

**Estados relacionados:** `31-projetos-modal-editar`

---

### Confirmação "Excluir projeto"

![Modal de confirmação de exclusão de projeto](../shots/31-projetos-excluir-confirm.png)

**Rota:** `/projetos` → hover na linha → ícone de lixeira · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Cartão pequeno centralizado com ícone de lixeira dentro de um círculo vermelho-claro.
- Título "Excluir projeto" e o texto "Tem certeza que deseja excluir este projeto? Todos os pontos mapeados e árvores vinculadas serão perdidos permanentemente."
- Botões "Cancelar" (cinza) e "**Sim, excluir projeto**" (vermelho, variante `danger`), além do "×" no canto.

**Ações possíveis / o que acontece:**
- "Sim, excluir projeto" → apaga o registro e fecha o diálogo (o `ConfirmationModal` sempre executa `onConfirm` e em seguida `onClose`).
- "Cancelar", "×", `Esc` ou clique fora → fecham sem excluir.

**Estados relacionados:** `31-projetos-toast-removido`

---

### Toast "Projeto removido com sucesso!"

![Lista de volta com dois projetos e toast de remoção](../shots/31-projetos-toast-removido.png)

**Rota:** `/projetos` · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Toast verde "Projeto removido com sucesso!".
- A lista voltou a "2 projetos · 6 árvores plantadas no total" com os dois projetos de demonstração.

**Ações possíveis / o que acontece:**
- Em caso de erro o hook emite "Erro ao remover o projeto." (não capturado).

**Estados relacionados:** `30-projetos-lista`

---

## Fluxo passo a passo — criar um projeto

1. Autenticado, o usuário abre `/projetos` pelo menu do avatar ("Meus Projetos"). Enquanto a consulta roda, vê o esqueleto (ver `30-projetos-skeleton`).
2. A lista carrega com o cabeçalho "Meus Projetos" e o resumo de projetos/árvores (ver `30-projetos-lista`).
3. Clica na linha tracejada "Novo projeto"; abre-se o modal com os campos vazios e os contadores em 0/100 e 0/500 (ver `31-projetos-modal-novo`).
4. Preenche nome e, opcionalmente, descrição — os contadores acompanham a digitação (ver `31-projetos-modal-preenchido`).
5. Clica em "Criar": o botão vira "Salvando..." e fica desabilitado (ver `31-projetos-salvando`).
6. O projeto é gravado com o centro padrão (-21,1767 / -47,8208, zoom 14); o modal fecha, a lista é invalidada e aparece o toast "Projeto criado com sucesso!". O novo projeto assume o topo da lista com anel tracejado e "Nenhuma árvore adicionada" (ver `31-projetos-toast-criado`).
7. A partir daí o projeto é aberto com um clique na linha, levando ao editor de mapa.

## Fluxo passo a passo — renomear e excluir um projeto

1. Na lista, o usuário passa o mouse sobre a linha desejada; surgem os ícones de lápis e lixeira (ver `30-projetos-linha-hover`). Em telas pequenas esses ícones já estão visíveis (ver `30-projetos-lista-mobile`).
2. Clicando no lápis, abre-se "Editar Projeto" com nome e descrição carregados e o botão "Salvar" (ver `31-projetos-modal-editar`).
3. Ao salvar, aparece "Projeto atualizado com sucesso!" enquanto o modal se fecha (ver `31-projetos-toast-atualizado`).
4. Clicando na lixeira, abre-se a confirmação "Excluir projeto", que avisa que os pontos mapeados serão perdidos permanentemente (ver `31-projetos-excluir-confirm`).
5. Confirmando em "Sim, excluir projeto", o registro é removido em cascata com seus pontos e aparece "Projeto removido com sucesso!" (ver `31-projetos-toast-removido`).
