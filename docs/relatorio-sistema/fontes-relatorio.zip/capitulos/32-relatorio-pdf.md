# Relatório PDF do projeto

O editor de projeto oferece um único formato de exportação: um **relatório em PDF** gerado inteiramente no navegador, sem passar por servidor. O botão "Relatório", na barra superior do editor, monta o documento com jsPDF e insere uma imagem do mapa capturada com html2canvas. O arquivo é baixado direto para a pasta de downloads do usuário — não fica armazenado no Supabase nem tem link compartilhável.

Arquivos-fonte: `src/lib/pdf.ts` (todo o desenho do documento) e `src/components/projects/ProjectEditor.tsx` (estado `generatingPdf`, atraso proposital de 1,6 s antes da captura e desligamento do agrupamento de marcadores durante a geração).

**Como o documento é montado** (A4 retrato, unidade em milímetros, margem de 16 mm):

| Bloco | Conteúdo |
|---|---|
| Cabeçalho | "PlanteiCerto" em 18 pt negrito, "Relatório de Arborização Urbana" em 8 pt e, à direita, "Doc: <data de hoje em pt-BR>"; linha divisória horizontal |
| Cartão do projeto | Retângulo arredondado verde-claro com o nome do projeto (14 pt, verde), a descrição quebrada em linhas e o rodapé "N árvores mapeadas \| Coordenadas: lat, lng" (4 casas decimais, usando o **centro salvo do projeto**, não a média dos pontos) |
| Estatísticas | Título "Estatísticas e Impacto Ambiental" e três caixas: DIVERSIDADE (nº de espécies distintas), COBERTURA DE COPA (soma de π·r² das copas adultas, arredondada) e ORIGEM (NATIVAS) (percentual de árvores com `origem = 'Nativa BR'`) |
| Mapa | Imagem JPEG (qualidade 0,85) do elemento do mapa, capturada com `scale: 2`, altura máxima de 90 mm, centralizada e com borda arredondada. São ignorados os controles do Leaflet e qualquer elemento com a classe `absolute` — por isso a caixa de busca, o botão de GPS e a dica "Clique no mapa…" **não** saem na imagem |
| Tabela | "Lista de Plantio e Coordenadas" com as colunas ESPÉCIE, ORIGEM, LAT(Y) / LNG(X), ALTURA MÁX e COPA MÁX; cada linha traz nome popular em negrito, nome científico em itálico, "Brasil" (verde, para nativas) ou "Exótica", coordenadas com 6 casas decimais e as medidas em metros (ou "—" quando o campo está vazio) |
| Rodapé | Em todas as páginas: "PlanteiCerto - Democratizando a arborização urbana", "Página N" ao centro e "www.planteicerto.com.br" à direita |

A observação escrita em cada ponto **não** é exportada: ela existe apenas no aplicativo (painel e tooltip). O nome do arquivo é montado a partir do nome do projeto, trocando espaços por sublinhados: no caso demonstrado, `Relatorio_Arborização_Rua_Prudente_de_Moraes.pdf`.

---

### Acionamento e estado "Gerando..."

![Botão Gerando e mapa com os seis marcadores desagrupados](../shots/35-relatorio-gerando.png)

**Rota:** `/projetos` → "Arborização Rua Prudente de Moraes" → botão "Relatório" · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- O botão verde-escuro à direita trocou o ícone de documento por um **spinner** e o rótulo por "**Gerando...**"; está esmaecido e desabilitado. O botão "Estatísticas" permanece habilitado.
- No mapa, o agrupamento foi desligado: em vez da bolha verde com "6", aparece uma pilha de pinos individuais sobrepostos no mesmo trecho da rua, com dois rótulos legíveis — "Resedá extremosa" e "Ipê-roxo-de-bola" — e os demais atrás.
- Painel, cabeçalho ("6 árvores · 6 espécies") e dica inferior continuam inalterados.

**Ações possíveis / o que acontece:**
- O estado dura cerca de 1,6 s de espera proposital mais o tempo do html2canvas; em seguida o navegador salva o arquivo e o botão volta a "Relatório".
- Se a geração lançar exceção, o app exibe o `alert` nativo "Erro ao gerar o relatório. Tente novamente." (não observado).

**Estados relacionados:** `35-relatorio-pos-download`, `34-editor-split`

---

### Editor logo após o download

![Editor de volta ao normal depois de gerar o PDF](../shots/35-relatorio-pos-download.png)

**Rota:** mesma tela, após o término da geração · **Quem acessa:** dono do projeto · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- O botão voltou a exibir o ícone de documento e o texto "Relatório".
- Os marcadores voltaram a ser agrupados (bolha verde "6" no centro do mapa).
- Não há toast, modal de confirmação nem link para o arquivo: o único sinal do sucesso é o download do navegador.

**Ações possíveis / o que acontece:**
- Gerar novamente produz um arquivo idêntico (exceto a data do cabeçalho) e o navegador acrescenta sufixo numérico ao nome, se já existir.

**Estados relacionados:** `35-relatorio-gerando`

---

## Conteúdo do PDF gerado

O arquivo baixado na execução documentada tem **2 páginas** e cerca de **789 KB** (o peso vem quase todo da imagem do mapa em alta resolução). Está salvo em `artefatos/Relatorio_projeto_demo.pdf`, com o texto extraído em `artefatos/Relatorio_projeto_demo.txt`.

As duas páginas do PDF gerado, rasterizadas a partir do arquivo baixado, aparecem a seguir:

![Relatório PDF gerado pelo app — página 1: cabeçalho, cartão do projeto, estatísticas, imagem do mapa e início da tabela de plantio](../shots/39-pdfgen-pagina-1.png)

![Relatório PDF gerado pelo app — página 2: continuação da tabela de plantio e rodapé](../shots/39-pdfgen-pagina-2.png)

### Transcrição da página 1

```
PlanteiCerto                                         Doc: 10/09/2026
Relatório de Arborização Urbana

Arborização Rua Prudente de Moraes
Plantio de 6 exemplares na calçada da Rua Prudente de Moraes (Ribeirão Preto/SP), priorizando espécies nativas e
compatíveis com a fiação existente.
6 árvores mapeadas | Coordenadas: -21.1767, -47.8214

Estatísticas e Impacto Ambiental
DIVERSIDADE          COBERTURA DE COPA          ORIGEM (NATIVAS)
6 Espécies           659 m²                     83% Nativas

[imagem do mapa de satélite com os seis marcadores]

Lista de Plantio e Coordenadas
ESPÉCIE                    ORIGEM    LAT(Y) / LNG(X)        ALTURA MÁX   COPA MÁX
Oiti                       Brasil    Lat: -21.176100        15m          10m
Licania tomentosa                    Lng: -47.821500
Dedaleira                  Brasil    Lat: -21.176560        18m          15m
Lafoensia pacari                     Lng: -47.821460
Resedá extremosa           Exótica   Lat: -21.176790         8m           5m
Lagerstroemia indica                 Lng: -47.821440

PlanteiCerto - Democratizando a arborização urbana    Página 1    www.planteicerto.com.br
```

### Transcrição da página 2

```
ESPÉCIE                    ORIGEM    LAT(Y) / LNG(X)        ALTURA MÁX   COPA MÁX
Jerivá                     Brasil    Lat: -21.177020        15m           8m
Syagrus romanzoffiana                Lng: -47.821420
Ipê-roxo-de-bola           Brasil    Lat: -21.177250        35m          20m
Handroanthus impetiginosus           Lng: -47.821400
Ipê-amarelo                Brasil    Lat: -21.176330        10m           5m
Tabebuia chrysotricha                Lng: -47.821480

PlanteiCerto - Democratizando a arborização urbana    Página 2    www.planteicerto.com.br
```

Observações sobre o documento gerado:

- A **quebra de página** acontece quando a próxima linha da tabela ultrapassaria 25 mm antes do fim da folha; o cabeçalho da tabela é redesenhado no topo da página seguinte, mas **o título "Lista de Plantio e Coordenadas" não se repete**.
- O mapa aparece **somente na página 1**; a página 2 contém apenas a continuação da tabela e o rodapé.
- As três estatísticas do PDF são as mesmas do "Dashboard do Projeto" (ver `34-editor-estatisticas`), com uma diferença: o PDF não mostra a distribuição por porte nem o total de árvores em caixa própria — o total aparece dentro do cartão do projeto ("6 árvores mapeadas").
- A cobertura de copa (659 m²) é a soma das áreas de copa adulta máxima das seis espécies: π·(10/2)² + π·(15/2)² + π·(5/2)² + π·(8/2)² + π·(20/2)² + π·(5/2)² ≈ 659 m². Trata-se de uma projeção do estágio adulto, não da situação no plantio.
- O percentual de nativas (83%) considera cinco árvores com `origem = 'Nativa BR'` contra uma exótica (Resedá extremosa).
- A data do cabeçalho é a do momento da geração, formatada em pt-BR.

---

## Fluxo passo a passo — gerar o relatório PDF

1. O usuário abre um projeto que já tenha pelo menos um ponto salvo (com zero pontos o botão fica desabilitado a 40% de opacidade — ver `32-editor-vazio`).
2. Opcionalmente ajusta o enquadramento do mapa, porque a imagem impressa é exatamente o que está visível na área do mapa no momento da geração.
3. Clica em "Relatório". O botão passa a "Gerando..." com spinner e o app desliga o agrupamento dos marcadores para que cada espécie apareça individualmente na imagem (ver `35-relatorio-gerando`).
4. Após ~1,6 s de espera proposital, o html2canvas fotografa o mapa (sem controles, sem caixa de busca e sem a dica inferior) e o jsPDF monta cabeçalho, cartão do projeto, três estatísticas, imagem e tabela de plantio.
5. O navegador baixa o arquivo `Relatorio_<Nome_do_Projeto>.pdf` — no exemplo, com 2 páginas e ~789 KB. O botão volta ao estado normal, sem toast de confirmação (ver `35-relatorio-pos-download`).
6. O conteúdo do arquivo é o transcrito acima: uma folha de rosto com resumo e mapa e uma tabela com espécie, origem, coordenadas (6 casas decimais), altura máxima e diâmetro de copa máximo de cada exemplar.
