# Infraestrutura e Operação

> **Nota de sanitização.** Este capítulo descreve a infraestrutura real do sistema, mas substitui deliberadamente todo identificador de acesso por um marcador: `<IP-DO-VPS>`, `<HOST>`, `<USUÁRIO>`, `<SEGREDO>`. Nenhuma chave, senha, token, endereço de IP, nome de host de SSH ou conteúdo de arquivo `.env` é reproduzido. Comandos que embutiriam credenciais são descritos em prosa em vez de transcritos.

## Ambientes

O sistema opera hoje em dois ambientes distintos, além do histórico mantido como plano de contingência.

**Produção.** O frontend permanece hospedado na Vercel, servindo o domínio `www.planteicerto.com.br`. O backend é uma instalação **auto-hospedada do Supabase** numa VPS (Hostinger KVM 2, região de São Paulo, Ubuntu 24.04), montada a partir do diretório `docker/` do repositório oficial `supabase/supabase`, com dois arquivos de sobreposição: `docker-compose.s3.yml`, que substitui o backend de armazenamento pelo **MinIO**, e `docker-compose.caddy.yml`, que acrescenta o **Caddy** como proxy reverso com emissão automática de certificados via Let's Encrypt. A API é publicada em `api.planteicerto.com.br`, com registro A apontando para `<IP-DO-VPS>` e DNS gerenciado no registro.br. Os contêineres relevantes são `supabase-db`, `supabase-auth`, `supabase-storage`, `supabase-edge-functions`, `supabase-kong`, `supabase-caddy` e `supabase-minio-1`. Toda a configuração sensível vive em um arquivo `.env` dentro da VPS, explicitamente nunca versionado.

**Contingência.** O projeto anterior no Supabase Cloud não foi cancelado e permanece ativo como rede de segurança. O procedimento de rollback é trivial por construção: reverter as variáveis `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY` na Vercel e redeployar. Essa reversibilidade é possível porque o frontend não conhece nada da topologia do backend além dessas duas variáveis.

**Desenvolvimento.** O ambiente local roda a pilha inteira em Docker por meio do CLI do Supabase, documentado em `DESENVOLVIMENTO.md`: `npx supabase start` sobe cerca de dez contêineres, expondo a API em `127.0.0.1:54321`, o **Studio** em `54323`, o **Mailpit** em `54324` e o Postgres em `54322`. Nenhum e-mail real é enviado em desenvolvimento — confirmações de cadastro e recuperação de senha caem todas no Mailpit, já com os modelos personalizados de `supabase/email_templates/`. As funções de borda são servidas com recarga automática por `npx supabase functions serve`. Há uma armadilha registrada no próprio documento: as variáveis precisam estar em `.env.development.local`, porque o Vite dá precedência a `.env.development` sobre `.env.local`.

| Aspecto | Produção | Desenvolvimento |
|---|---|---|
| Frontend | Vercel, domínio próprio | Vite em `localhost:5173` |
| Backend | Supabase auto-hospedado em VPS | Pilha Supabase local em Docker |
| Armazenamento | MinIO atrás do Storage | Storage local do CLI |
| E-mail | SMTP transacional (Brevo), domínio autenticado com SPF, DKIM e DMARC | Mailpit, sem envio externo |
| TLS | Caddy com Let's Encrypt | sem TLS |
| Painel | Studio publicado sob autenticação básica | Studio local sem autenticação |

## O cutover e suas lições

A migração do Supabase Cloud para a VPS foi concluída em **21 de julho de 2026**. O `INFRAESTRUTURA.md` registra o checklist executado: ressincronização final de banco e armazenamento com verificação de contagens (sem divergência), publicação na Vercel com as novas variáveis, e período de observação de 48 a 72 horas antes do cancelamento da assinatura anterior.

Duas falhas apareceram **somente depois do cutover**, com usuário real, e ambas têm a mesma causa raiz: o comando `supabase db dump` de esquema **não exporta objetos anexados a tabelas dos esquemas `auth` e `storage`**, ainda que a lógica seja inteiramente da aplicação.

1. **Gatilho `on_auth_user_created` ausente.** A função `handle_new_user()` foi restaurada normalmente, mas o `CREATE TRIGGER ... ON auth.users` não. O sintoma foi desconcertante: o login federado funcionava, mas toda consulta a `profiles` devolvia `406` com código `PGRST116` — zero linhas, porque o perfil nunca havia sido criado.
2. **`storage.objects` com RLS ativo e nenhuma política.** A combinação bloqueia qualquer escrita para todos os papéis autenticados, enquanto `service_role` continua funcionando por ignorar RLS. Como os testes de migração haviam usado scripts com chave de serviço, e não a interface real, a falha passou despercebida até que um upload de avatar ou de imagem de espécie fosse tentado pela interface.

Ambas as lacunas estão hoje cobertas pela migration `supabase/migrations/20260702000001_auth_storage_from_prod.sql`, que não foi usada no restore original. A lição foi convertida em um checklist pós-restore de duas consultas — contar gatilhos não internos em `auth.users` e contar políticas em `storage.objects` — cujo resultado esperado é **1 gatilho e 10 políticas**.

Uma terceira lição diz respeito à configuração do GoTrue: `SITE_URL` e `ADDITIONAL_REDIRECT_URLS` precisam apontar para o domínio real do frontend, sob pena de o serviço cair no padrão do template (`localhost:3000`) depois do login — o que efetivamente quebrou o login com Google logo após o cutover. Registra-se também que o `docker-compose.yml` oficial traz o redirecionamento do Google incompleto, faltando o segmento `/auth/v1` no caminho de retorno.

## Armazenamento e o incidente de 2026-09-09

O Storage self-hosted tem uma limitação conhecida e sem correção: o endpoint de protocolo S3 nativo devolve `SignatureDoesNotMatch` mesmo com credenciais corretas, comportamento que corresponde a *issues* abertas no projeto `supabase/storage`. A solução de contorno adotada é usar a API REST normal do Storage, com cabeçalho de sobrescrita, em vez do protocolo S3 para cargas em massa.

Em **9 de setembro de 2026** ocorreu um incidente de indisponibilidade documentado em `docs/runbook-storage-minio.md`: imagens, guias e critérios pararam de carregar, e a API do Storage passou a responder HTTP 500 com `InternalError`. O diagnóstico mostrou que o contêiner `supabase-minio-1` estava parado com código de saída 255, enquanto `supabase-storage` continuava saudável e apenas expirava ao tentar conectar-se ao endpoint interno do MinIO, com a mensagem "Socket timed out without establishing a connection within 5000 ms". Não houve corrupção de arquivos nem estouro de memória.

A recuperação consistiu em subir novamente o serviço `minio` pelo compose oficial, reutilizando o volume existente, e revalidar a resolução de nome e o endpoint de saúde a partir do contêiner de Storage. O runbook é enfático quanto ao que **não** fazer: não restaurar buckets nem o dump do banco antes de comparar contagem e SHA-256 dos arquivos, porque uma restauração precipitada criaria divergência entre a tabela `storage.objects` e o volume do MinIO. No incidente registrado, a verificação encontrou 153 arquivos de conteúdo e 233 objetos de metadados, nenhum vazio, com hashes coincidindo com o backup — prova de que o problema era de disponibilidade, não de integridade. A verificação final é uma tripla de requisições HTTP aos três buckets públicos, esperando código 200 em todos.

## Backup e restauração

O backup cobre os dois estados que importam: o banco, por `pg_dump -Fc`, e o volume do MinIO, por empacotamento `tar`. O script reside na VPS e é disparado de fora por SSH com uma chave dedicada, restrita em `authorized_keys` de modo a executar apenas esse script e nada mais — um detalhe de projeto relevante, porque reduz o alcance de uma eventual exposição da chave. O agendamento é diário, às três da manhã, por um agente `launchd` na máquina do desenvolvedor; os arquivos ficam localmente, um por dia, com **retenção de 14 dias**.

A restauração **foi testada** num contêiner Postgres descartável, recuperando corretamente as 167 árvores e os usuários existentes. Um requisito foi registrado: o restore deve usar a imagem `supabase/postgres` correspondente, e não uma imagem `postgres` genérica, sob pena de faltarem as extensões `pg_net` e `supabase_vault`.

## Endurecimento e riscos operacionais registrados

A VPS aplica um conjunto convencional de medidas: firewall `ufw` liberando apenas as portas de SSH, HTTP e HTTPS, com os demais serviços ligados somente à interface de loopback; autenticação SSH exclusivamente por chave, com senha desabilitada; `fail2ban` ativo; área de troca de 2 GB; e atualizações automáticas de segurança. O acesso administrativo ao Studio é protegido por autenticação básica, e o Postgres não é exposto para fora da máquina. Um endpoint de integração com ferramentas de IA foi mantido inacessível pela rede pública, disponível apenas por túnel SSH e com restrição de origem no gateway.

Há um risco operacional explicitamente assumido no documento de infraestrutura: **vários segredos trafegaram por sessões de chat durante a configuração inicial** e, até a última atualização daquele documento, **nenhum havia sido rotacionado**. Do ponto de vista de segurança, essa é a pendência mais relevante do ambiente de produção, e deve ser tratada antes de qualquer ampliação do acesso ao sistema.

## Cabeçalhos de segurança na borda e integração contínua

A camada da Vercel aplica os cabeçalhos definidos em `vercel.json` a todas as respostas: negação de enquadramento (`X-Frame-Options: DENY` e `frame-ancestors 'none'`), bloqueio de adivinhação de tipo (`nosniff`), política de referenciador restritiva, desativação de câmera, microfone e geolocalização via `Permissions-Policy`, HSTS de dois anos com subdomínios, e uma Content Security Policy que limita `default-src` a `'self'` e enumera em `connect-src` exatamente os destinos permitidos — o domínio próprio da API, os domínios do Supabase e os endpoints de telemetria da Vercel. Imagens são liberadas para qualquer origem HTTPS, o que é necessário para os mosaicos de satélite e as fotos servidas pelo Storage. A mesma configuração reescreve todas as rotas para `/index.html`, requisito de uma aplicação de página única.

A integração contínua (`.github/workflows/ci.yml`) roda em cada `push` e `pull request` para `master`, com Node 20, a sequência: instalação determinística, auditoria de dependências em nível alto, ESLint, verificação de tipos sem emissão, testes com Vitest e build de produção. Localmente, o gancho de pré-commit do Husky executa `npm run build`, de modo que um commit com erro de tipagem falha antes de chegar ao repositório remoto. Não há, no repositório, automação de implantação do backend: a aplicação de migrations e a publicação de funções de borda na VPS são procedimentos manuais descritos no runbook — copiar o arquivo SQL para o contêiner do banco e executá-lo com `psql`; copiar o diretório da função para o volume de funções e recriar o serviço correspondente, lembrando que reiniciar o contêiner não relê o arquivo de ambiente.
