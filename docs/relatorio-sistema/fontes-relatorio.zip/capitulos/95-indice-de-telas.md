# Índice de capturas de tela

Tabela de todas as capturas realizadas na aplicação em execução (222 imagens válidas, 0 tentativas registradas como não capturadas). O identificador é o nome do arquivo de imagem; "Capítulo" indica onde a figura é usada.

| Id | Título | Rota | Viewport / tema | Conta | Capítulo |
|---|---|---|---|---|---|
| `10-gate-desbloqueado` | Gate — após desbloqueio: catálogo liberado | `/` | desktop / light | none | 10-acesso-e-autenticacao |
| `10-gate-erro` | Gate — erro "Credenciais inválidas. Acesso negado." | `/` | desktop / light | none | 10-acesso-e-autenticacao |
| `10-gate-mobile` | Gate — layout mobile (390×844) | `/` | mobile / light | none | 10-acesso-e-autenticacao |
| `10-gate-ocioso` | Tela de proteção intelectual — estado ocioso | `/` | desktop / light | none | 10-acesso-e-autenticacao |
| `11-header-deslogado` | Header — visitante não autenticado (faixa superior) | `/` | desktop / light | none | 10-acesso-e-autenticacao |
| `11-header-deslogado-dark` | Header — visitante não autenticado, tema escuro | `/` | desktop / dark | none | 10-acesso-e-autenticacao |
| `11-header-drawer-admin-mobile` | MobileDrawer aberto — administrador | `/` | mobile / light | admin | 10-acesso-e-autenticacao |
| `11-header-drawer-deslogado-mobile` | MobileDrawer aberto — visitante | `/` | mobile / light | none | 10-acesso-e-autenticacao |
| `11-header-drawer-usuario-mobile` | MobileDrawer aberto — usuária autenticada | `/` | mobile / light | user | 10-acesso-e-autenticacao |
| `11-header-dropdown-admin` | Dropdown do administrador — inclui o item "Administração" | `/` | desktop / light | admin | 10-acesso-e-autenticacao |
| `11-header-dropdown-usuario` | Dropdown do usuário autenticado (sem privilégios de admin) | `/` | desktop / light | user | 10-acesso-e-autenticacao |
| `11-header-rota-inexistente` | Rota inexistente — página em branco, sem Header e sem 404 | `/rota-que-nao-existe` | desktop / light | none | 10-acesso-e-autenticacao |
| `11-header-tema-claro` | Catálogo no tema claro (antes de alternar o tema) | `/` | desktop / light | none | 10-acesso-e-autenticacao |
| `11-header-tema-escuro` | Mesma tela após clicar no botão "Alternar tema" (tema escuro) | `/` | desktop / light | none | 10-acesso-e-autenticacao |
| `12-auth-cadastro-confirme` | AuthModal — "Confirme seu e-mail" após o cadastro | `/` | desktop / light | none | 10-acesso-e-autenticacao |
| `12-auth-cadastro-logado` | Após abrir o link de confirmação: sessão iniciada (header com o nome do novo usuário) | `/` | desktop / light | none | 10-acesso-e-autenticacao |
| `12-auth-criar-conta` | AuthModal — modo "Criar Conta" | `/` | desktop / light | none | 10-acesso-e-autenticacao |
| `12-auth-login` | AuthModal — modo "Entrar" | `/` | desktop / light | none | 10-acesso-e-autenticacao |
| `12-auth-login-erro` | AuthModal — toast "E-mail ou senha incorretos." | `/` | desktop / light | none | 10-acesso-e-autenticacao |
| `12-auth-logout-modal` | ConfirmationModal "Sair da conta" (capturado e cancelado) | `/` | desktop / light | user | 10-acesso-e-autenticacao |
| `12-auth-mailpit` | Mailpit (caixa de e-mails local) exibindo a mensagem de confirmação de cadastro | `/view/<id> (Mailpit :54324)` | desktop / light | none | 10-acesso-e-autenticacao |
| `12-auth-recuperar-enviado` | AuthModal — confirmação "E-mail enviado" após pedir recuperação de senha | `/` | desktop / light | none | 10-acesso-e-autenticacao |
| `12-auth-recuperar-senha` | AuthModal — modo "Recuperar Senha" | `/` | desktop / light | none | 10-acesso-e-autenticacao |
| `13-catalogo-busca` | Busca por "ipê" — resultados filtrados | `/` | desktop / light | none | 11-catalogo-de-especies |
| `13-catalogo-favorito-ativo` | Card "Açoita-cavalo" com o coração preenchido (favoritado) e contador "Favoritos" em 4 | `/` | desktop / light | user | 11-catalogo-de-especies |
| `13-catalogo-favorito-deslogado` | Visitante clica no coração: toast "Faça login para favoritar árvores." + AuthModal | `/` | desktop / light | none | 11-catalogo-de-especies |
| `13-catalogo-favoritos-ativo` | Filtro "Favoritos" ativo (?favoritos=true) | `/?favoritos=true` | desktop / light | user | 11-catalogo-de-especies |
| `13-catalogo-filtros-avancados` | Painel "Critérios Específicos" com 2 filtros marcados | `/` | desktop / light | none | 11-catalogo-de-especies |
| `13-catalogo-grid` | Catálogo — grade padrão (página inteira) | `/` | desktop / light | none | 11-catalogo-de-especies |
| `13-catalogo-grid-dark` | Catálogo — tema escuro | `/` | desktop / dark | none | 11-catalogo-de-especies |
| `13-catalogo-grid-mobile-p1` | Catálogo — layout mobile (1 card por linha) | `/` | mobile / light | none | 11-catalogo-de-especies |
| `13-catalogo-grid-mobile-p2` | Catálogo — layout mobile (1 card por linha) | `/` | mobile / light | none | 11-catalogo-de-especies |
| `13-catalogo-hero` | Hero "Encontre a árvore certa" + CTA "Encontrar Árvore Recomendada" | `/` | desktop / light | none | 11-catalogo-de-especies |
| `13-catalogo-ordem-co2` | Ordenação "Maior captura de CO₂ (10 anos)" | `/` | desktop / light | none | 11-catalogo-de-especies |
| `13-catalogo-ordem-porte` | Ordenação "Maior porte primeiro" | `/` | desktop / light | none | 11-catalogo-de-especies |
| `13-catalogo-scroll-infinito` | Scroll infinito — contador aumenta conforme novas páginas de 6 cards entram | `/` | desktop / light | none | 11-catalogo-de-especies |
| `13-catalogo-skeleton` | Catálogo carregando — 6 TreeCardSkeleton | `/` | desktop / light | none | 11-catalogo-de-especies |
| `13-catalogo-vazio-filtros` | EmptyStateFilters — "Nenhuma árvore encontrada" com chips removíveis | `/` | desktop / light | none | 11-catalogo-de-especies |
| `14-especie-card-hover` | TreeCard sob o cursor (primeiro card elevado) ao lado de um card em repouso | `/` | desktop / light | none | 12-detalhe-e-comparacao |
| `14-especie-detalhe-dark` | TreeDetailModal no tema escuro (Oiti) — topo do modal | `/` | desktop / dark | none | 12-detalhe-e-comparacao |
| `14-especie-detalhe-p1` | TreeDetailModal do Ipê-roxo-de-bola (espécie com projeção de 10 anos) (parte 1 de 2) | `/` | desktop / light | none | 12-detalhe-e-comparacao |
| `14-especie-detalhe-p2` | TreeDetailModal do Ipê-roxo-de-bola (espécie com projeção de 10 anos) (parte 2 de 2) | `/` | desktop / light | none | 12-detalhe-e-comparacao |
| `14-especie-jeriva-p1` | TreeDetailModal do Jerivá (palmeira, sem seção de projeção) (parte 1 de 2) | `/` | desktop / light | none | 12-detalhe-e-comparacao |
| `14-especie-jeriva-p2` | TreeDetailModal do Jerivá (palmeira, sem seção de projeção) (parte 2 de 2) | `/` | desktop / light | none | 12-detalhe-e-comparacao |
| `15-comparar-barra-1` | TreesCompareBar com 1 espécie — botão mostra "Escolha +" (desabilitado) | `/` | desktop / light | none | 12-detalhe-e-comparacao |
| `15-comparar-barra-2` | TreesCompareBar com 2 espécies — botão "Comparar" habilitado | `/` | desktop / light | none | 12-detalhe-e-comparacao |
| `15-comparar-barra-3` | TreesCompareBar com 3 espécies (limite atingido) | `/` | desktop / light | none | 12-detalhe-e-comparacao |
| `15-comparar-chip-ativo` | Card selecionado: chip "+ Comparar" vira "Comparando" e o card ganha anel verde | `/` | desktop / light | none | 12-detalhe-e-comparacao |
| `15-comparar-modal-botanica-mobile` | CompareModal no mobile — aba "Botânica" (2 espécies) | `/` | mobile / light | none | 12-detalhe-e-comparacao |
| `15-comparar-modal-dimensoes-mobile` | CompareModal no mobile — aba "Dimensões" (2 espécies) | `/` | mobile / light | none | 12-detalhe-e-comparacao |
| `15-comparar-modal-p1` | CompareModal (desktop) — 3 espécies lado a lado (parte 1 de 2) | `/` | desktop / light | none | 12-detalhe-e-comparacao |
| `15-comparar-modal-p2` | CompareModal (desktop) — 3 espécies lado a lado (parte 2 de 2) | `/` | desktop / light | none | 12-detalhe-e-comparacao |
| `15-comparar-modal-tolerancias-mobile` | CompareModal no mobile — aba "Tolerâncias" (2 espécies) | `/` | mobile / light | none | 12-detalhe-e-comparacao |
| `15-comparar-modal-urbano-mobile` | CompareModal no mobile — aba "Uso Urbano" (2 espécies) | `/` | mobile / light | none | 12-detalhe-e-comparacao |
| `15-comparar-toast-limite` | Toast "Você pode comparar no máximo 3 árvores por vez." ao tentar a 4ª espécie | `/` | desktop / light | none | 12-detalhe-e-comparacao |
| `16-sobre-guias` | Seção "Guias de Arborização" — grade com os 10 guias | `/quem-somos` | desktop / light | none | 13-quem-somos-e-documentos |
| `16-sobre-metodologia` | Seção "Metodologia e Critérios de Avaliação" — 3 cartões de escalas | `/quem-somos` | desktop / light | none | 13-quem-somos-e-documentos |
| `16-sobre-mobile-p1` | "Quem Somos" no mobile (coluna única) | `/quem-somos` | mobile / light | none | 13-quem-somos-e-documentos |
| `16-sobre-mobile-p2` | "Quem Somos" no mobile (coluna única) | `/quem-somos` | mobile / light | none | 13-quem-somos-e-documentos |
| `16-sobre-parametrizacao` | Bloco "Documentos de Parametrização" — 2 botões de PDF | `/quem-somos` | desktop / light | none | 13-quem-somos-e-documentos |
| `16-sobre-pdf-carregando` | PdfViewer — estado "Carregando..." (requisição do PDF retardada) | `/quem-somos` | desktop / light | none | 13-quem-somos-e-documentos |
| `16-sobre-pdf-erro` | PdfViewer — erro "Não foi possível carregar o PDF." (arquivo indisponível) | `/quem-somos` | desktop / light | none | 13-quem-somos-e-documentos |
| `16-sobre-pdf-pagina` | PdfViewer — guia 3 renderizado no canvas, com barra de paginação "1 / 7" | `/quem-somos` | desktop / light | none | 13-quem-somos-e-documentos |
| `16-sobre-pdf-paginacao` | PdfViewer — após avançar para a página 2 de 7 | `/quem-somos` | desktop / light | none | 13-quem-somos-e-documentos |
| `16-sobre-topo` | Página "Quem Somos" completa | `/quem-somos` | desktop / light | none | 13-quem-somos-e-documentos |
| `20-rec-dialogo-finalizar` | Diálogo "Finalizar questionário?" | `/recomendacao` | desktop / light | user | 20-recomendacao-questionario |
| `20-rec-dialogo-reaberto` | Diálogo reaberto após revisão, antes de confirmar | `/recomendacao` | desktop / light | user | 20-recomendacao-questionario |
| `20-rec-passo1-respondido` | Questionário — passo 1 respondido ("Calçada em frente a lote/residência") | `/recomendacao` | desktop / light | user | 20-recomendacao-questionario |
| `20-rec-passo1-vazio` | Questionário — passo 1 sem resposta ("Próximo" desabilitado) | `/recomendacao` | desktop / light | user | 20-recomendacao-questionario |
| `20-rec-q1-2-multiselect` | Multi-select q1_2 — 2 objetivos marcados, demais desabilitados | `/recomendacao` | desktop / light | user | 20-recomendacao-questionario |
| `20-rec-q2-2-helptext` | Grupo 2 — pergunta eliminatória com texto de ajuda (faixa de serviço) | `/recomendacao` | desktop / light | user | 20-recomendacao-questionario |
| `20-rec-q2-5-antes` | Fiação aérea — antes de responder (total ainda 24 passos) | `/recomendacao` | desktop / light | user | 20-recomendacao-questionario |
| `20-rec-q2-5-fiacao` | Fiação convencional selecionada — total salta para 25 passos | `/recomendacao` | desktop / light | user | 20-recomendacao-questionario |
| `20-rec-q2-6-condicional` | Pergunta condicional q2_6 — distância até a fiação aérea | `/recomendacao` | desktop / light | user | 20-recomendacao-questionario |
| `20-rec-q2-8a-esquina` | Distâncias de segurança — esquina (mín. 6 m) | `/recomendacao` | desktop / light | user | 20-recomendacao-questionario |
| `20-rec-q2-8b-poste` | Distâncias de segurança — poste de iluminação (mín. 4 m) | `/recomendacao` | desktop / light | user | 20-recomendacao-questionario |
| `20-rec-q2-8c-guia` | Distâncias de segurança — guia rebaixada (mín. 1,5 m) | `/recomendacao` | desktop / light | user | 20-recomendacao-questionario |
| `20-rec-q2-8d-bocalobo` | Distâncias de segurança — boca-de-lobo (mín. 1,5 m) | `/recomendacao` | desktop / light | user | 20-recomendacao-questionario |
| `20-rec-q3-1-insolacao` | Grupo 3 — insolação (pergunta mista: eliminatória + classificatória) | `/recomendacao` | desktop / light | user | 20-recomendacao-questionario |
| `20-rec-q4-2-espinhos` | Grupo 4 — espinhos/substâncias irritantes | `/recomendacao` | desktop / light | user | 20-recomendacao-questionario |
| `20-rec-q5-1-nativas` | Grupo 5 — preferência por espécies nativas | `/recomendacao` | desktop / light | user | 20-recomendacao-questionario |
| `20-rec-revisar-respostas` | Após "Revisar respostas" — volta ao último passo respondido | `/recomendacao` | desktop / light | user | 20-recomendacao-questionario |
| `20-rec-stepper-zoom` | Stepper no meio do percurso — respondidos, ativo e bloqueados | `/recomendacao` | desktop / light | user | 20-recomendacao-questionario |
| `20-rec-ultimo-passo` | Último passo — botão "Ver Resultados" | `/recomendacao` | desktop / light | user | 20-recomendacao-questionario |
| `20-rec-voltar` | Botão "Voltar" — retorno ao passo anterior com a resposta preservada | `/recomendacao` | desktop / light | user | 20-recomendacao-questionario |
| `21-rec-card-zoom` | Card de resultado em detalhe — score, pills e "Destaques da árvore" | `/recomendacao` | desktop / light | user | 21-recomendacao-resultados |
| `21-rec-criterios-expandido` | Critérios expandidos — chips eliminatórios (vermelhos) e classificatórios (verdes) | `/recomendacao` | desktop / light | user | 21-recomendacao-resultados |
| `21-rec-criterios-recolhido` | Cartão "Como as espécies foram avaliadas" recolhido | `/recomendacao` | desktop / light | user | 21-recomendacao-resultados |
| `21-rec-detalhe-modal` | TreeDetailModal aberto a partir de um resultado | `/recomendacao` | desktop / light | user | 21-recomendacao-resultados |
| `21-rec-editar-passo1` | Passo 1 com a resposta preservada após "Editar Respostas" | `/recomendacao` | desktop / light | user | 21-recomendacao-resultados |
| `21-rec-editar-volta` | "Editar Respostas" — volta ao questionário no passo em que estava | `/recomendacao` | desktop / light | user | 21-recomendacao-resultados |
| `21-rec-fiacao-topo` | Resultados do cenário com fiação convencional (topo) | `/recomendacao` | desktop / light | user | 21-recomendacao-resultados |
| `21-rec-grade-p1` | Grade completa de espécies recomendadas | `/recomendacao` | desktop / light | user | 21-recomendacao-resultados |
| `21-rec-grade-p2` | Grade completa de espécies recomendadas | `/recomendacao` | desktop / light | user | 21-recomendacao-resultados |
| `21-rec-grade-p3` | Grade completa de espécies recomendadas | `/recomendacao` | desktop / light | user | 21-recomendacao-resultados |
| `21-rec-limpar-refazer` | Após "Limpar e Refazer" — questionário zerado no passo 1 | `/recomendacao` | desktop / light | user | 21-recomendacao-resultados |
| `21-rec-loading` | Fase de carregamento — "Analisando espécies..." | `/recomendacao` | desktop / light | user | 21-recomendacao-resultados |
| `21-rec-questionario-dark` | Questionário em tema escuro | `/recomendacao` | desktop / dark | user | 21-recomendacao-resultados |
| `21-rec-questionario-mobile` | Questionário em tela estreita (390 px) | `/recomendacao` | mobile / light | user | 21-recomendacao-resultados |
| `21-rec-topo` | ResultScreen — cabeçalho, contagem e ações | `/recomendacao` | desktop / light | user | 21-recomendacao-resultados |
| `21-rec-topo-dark` | Resultados em tema escuro (critérios expandidos) | `/recomendacao` | desktop / dark | user | 21-recomendacao-resultados |
| `21-rec-topo-mobile` | Resultados em tela estreita — topo | `/recomendacao` | mobile / light | user | 21-recomendacao-resultados |
| `21-rec-zero-chips` | Cartão "Filtros eliminatórios aplicados" no estado vazio | `/recomendacao` | desktop / light | user | 21-recomendacao-resultados |
| `21-rec-zero-resultados` | Nenhuma espécie compatível encontrada (com chips eliminatórios) | `/recomendacao` | desktop / light | user | 21-recomendacao-resultados |
| `30-projetos-linha-hover` | Linha de projeto com as ações Editar/Excluir reveladas no hover | `/projetos` | desktop / light | projetista | 30-projetos |
| `30-projetos-lista` | Lista de projetos — projeto com pontos e projeto vazio | `/projetos` | desktop / light | projetista | 30-projetos |
| `30-projetos-lista-dark` | Lista de projetos — tema escuro | `/projetos` | desktop / dark | projetista | 30-projetos |
| `30-projetos-lista-mobile` | Lista de projetos — mobile (390×844) | `/projetos` | mobile / light | projetista | 30-projetos |
| `30-projetos-skeleton` | Lista de projetos — esqueleto de carregamento | `/projetos` | desktop / light | projetista | 30-projetos |
| `30-projetos-vazio` | Lista de projetos sem nenhum projeto (usuária sem projetos) | `/projetos` | desktop / light | colega | 30-projetos |
| `31-projetos-excluir-confirm` | ConfirmationModal "Excluir projeto" | `/projetos` | desktop / light | projetista | 30-projetos |
| `31-projetos-modal-editar` | Modal "Editar Projeto" pré-preenchido | `/projetos` | desktop / light | projetista | 30-projetos |
| `31-projetos-modal-novo` | Modal "Novo Projeto" vazio (contadores 0/100 e 0/500) | `/projetos` | desktop / light | projetista | 30-projetos |
| `31-projetos-modal-preenchido` | Modal "Novo Projeto" preenchido com nome e descrição | `/projetos` | desktop / light | projetista | 30-projetos |
| `31-projetos-salvando` | Botão do modal em estado "Salvando..." | `/projetos` | desktop / light | projetista | 30-projetos |
| `31-projetos-toast-atualizado` | Toast "Projeto atualizado com sucesso!" | `/projetos` | desktop / light | projetista | 30-projetos |
| `31-projetos-toast-criado` | Toast "Projeto criado com sucesso!" | `/projetos` | desktop / light | projetista | 30-projetos |
| `31-projetos-toast-removido` | Toast "Projeto removido com sucesso!" | `/projetos` | desktop / light | projetista | 30-projetos |
| `32-editor-ponto-pendente` | Ponto pendente âmbar no mapa e seção "Aguardando vinculação" no painel | `/projetos` | desktop / light | projetista | 31-editor-de-projeto |
| `32-editor-vazio` | Editor de projeto sem pontos — mapa, painel vazio e botões desabilitados | `/projetos` | desktop / light | projetista | 31-editor-de-projeto |
| `33-editor-busca-vazia` | TreeSelectionDialog — busca sem resultados | `/projetos` | desktop / light | projetista | 31-editor-de-projeto |
| `33-editor-dialogo-edicao` | TreeSelectionDialog em modo edição (espécie e observação pré-preenchidas) | `/projetos` | desktop / light | projetista | 31-editor-de-projeto |
| `33-editor-dialogo-fechado` | TreeSelectionDialog — combobox fechado | `/projetos` | desktop / light | projetista | 31-editor-de-projeto |
| `33-editor-dropdown` | TreeSelectionDialog — dropdown aberto com miniaturas | `/projetos` | desktop / light | projetista | 31-editor-de-projeto |
| `33-editor-especie-selecionada` | TreeSelectionDialog — espécie escolhida, prévia e observação preenchida | `/projetos` | desktop / light | projetista | 31-editor-de-projeto |
| `33-editor-menu-ponto` | PointActionsMenu aberto ("Editar espécie" / "Remover") | `/projetos` | desktop / light | projetista | 31-editor-de-projeto |
| `33-editor-painel-1ponto` | Editor com um ponto vinculado — pin nomeado e linha no painel | `/projetos` | desktop / light | projetista | 31-editor-de-projeto |
| `33-editor-remover-confirm` | ConfirmationModal "Remover árvore" | `/projetos` | desktop / light | projetista | 31-editor-de-projeto |
| `33-editor-toast-adicionada` | Toast "Árvore adicionada com sucesso!" | `/projetos` | desktop / light | projetista | 31-editor-de-projeto |
| `33-editor-toast-atualizada` | Toast "Dados da árvore atualizados!" | `/projetos` | desktop / light | projetista | 31-editor-de-projeto |
| `33-editor-toast-removida` | Toast "Árvore removida do mapa." | `/projetos` | desktop / light | projetista | 31-editor-de-projeto |
| `34-editor-busca-erro` | MapSearchBox — erro de busca por CEP inexistente | `/projetos` | desktop / light | projetista | 31-editor-de-projeto |
| `34-editor-busca-preenchida` | MapSearchBox com "Ribeirão Preto" digitado | `/projetos` | desktop / light | projetista | 31-editor-de-projeto |
| `34-editor-busca-resultado` | Mapa após a busca por "Ribeirão Preto" | `/projetos` | desktop / light | projetista | 31-editor-de-projeto |
| `34-editor-cluster-aberto` | Agrupamento aberto — marcadores individuais com o nome da espécie | `/projetos` | desktop / light | projetista | 31-editor-de-projeto |
| `34-editor-estatisticas` | ProjectStatsModal populado — "Dashboard do Projeto" | `/projetos` | desktop / light | projetista | 31-editor-de-projeto |
| `34-editor-minha-localizacao` | Toast "Localização encontrada!" após usar o GPS | `/projetos` | desktop / light | projetista | 31-editor-de-projeto |
| `34-editor-ponto-selecionado` | Ponto selecionado — marcador azul e linha destacada no painel | `/projetos` | desktop / light | projetista | 31-editor-de-projeto |
| `34-editor-split` | Editor desktop — mapa satélite (marcadores agrupados) e painel com os 6 pontos | `/projetos` | desktop / light | projetista | 31-editor-de-projeto |
| `34-editor-tooltip-pin` | Tooltip de um marcador (nome popular — observação) | `/projetos` | desktop / light | projetista | 31-editor-de-projeto |
| `34-editor-zoom-maximo` | Mapa no zoom máximo — pins nomeados e agrupamentos remanescentes | `/projetos` | desktop / light | projetista | 31-editor-de-projeto |
| `35-relatorio-gerando` | Botão "Gerando..." e mapa com os marcadores desagrupados durante a captura | `/projetos` | desktop / light | projetista | 32-relatorio-pdf |
| `35-relatorio-pos-download` | Editor logo após a geração — botão volta a "Relatório" | `/projetos` | desktop / light | projetista | 32-relatorio-pdf |
| `36-editor-sheet-alto-mobile` | Editor mobile — BottomSheet no snap máximo (90%) | `/projetos` | mobile / light | projetista | 31-editor-de-projeto |
| `36-editor-sheet-meio-mobile` | Editor mobile — BottomSheet no snap intermediário (50%) | `/projetos` | mobile / light | projetista | 31-editor-de-projeto |
| `36-editor-sheet-minimo-mobile` | Editor mobile — mapa cheio e BottomSheet no snap mínimo (150 px) | `/projetos` | mobile / light | projetista | 31-editor-de-projeto |
| `36-editor-split-dark` | Editor de projeto — tema escuro | `/projetos` | desktop / dark | projetista | 31-editor-de-projeto |
| `37-perfil-avatar-erro-tamanho` | Mensagem "Arquivo muito grande. Máximo: 5MB." | `/perfil` | desktop / light | projetista | 33-perfil-e-seguranca |
| `37-perfil-avatar-hover` | Avatar em hover exibindo a sobreposição "Alterar Foto" | `/perfil` | desktop / light | projetista | 33-perfil-e-seguranca |
| `37-perfil-avatar-inicial` | Cartão "Informações Públicas" com avatar em placeholder (inicial do nome) | `/perfil` | desktop / light | projetista | 33-perfil-e-seguranca |
| `37-perfil-avatar-previa` | Prévia da nova foto de perfil antes de salvar | `/perfil` | desktop / light | projetista | 33-perfil-e-seguranca |
| `37-perfil-com-foto` | Perfil já com a foto salva e pill "E-mail" em Método de Login | `/perfil` | desktop / light | projetista | 33-perfil-e-seguranca |
| `37-perfil-salvando` | Botão "Salvando..." durante o envio do perfil | `/perfil` | desktop / light | projetista | 33-perfil-e-seguranca |
| `37-perfil-toast-salvo` | Toast "Perfil atualizado com sucesso!" | `/perfil` | desktop / light | projetista | 33-perfil-e-seguranca |
| `37-perfil-topo` | Página "Meu Perfil" completa | `/perfil` | desktop / light | projetista | 33-perfil-e-seguranca |
| `38-perfil-dark` | Página de perfil — tema escuro | `/perfil` | desktop / dark | projetista | 33-perfil-e-seguranca |
| `38-perfil-mobile` | Página de perfil — mobile | `/perfil` | mobile / light | projetista | 33-perfil-e-seguranca |
| `38-perfil-seguranca` | Seção "Segurança" com o formulário de troca de senha | `/perfil` | desktop / light | projetista | 33-perfil-e-seguranca |
| `38-perfil-toast-senha-curta` | Toast "A senha deve ter no mínimo 6 caracteres." | `/perfil` | desktop / light | projetista | 33-perfil-e-seguranca |
| `38-perfil-toast-senhas-diferentes` | Toast "As senhas não coincidem." | `/perfil` | desktop / light | projetista | 33-perfil-e-seguranca |
| `38-reset-email-enviado` | AuthModal — confirmação "E-mail enviado" | `/` | desktop / light | none | 33-perfil-e-seguranca |
| `38-reset-erro-curta` | Validação — senha com menos de 6 caracteres | `/reset-password` | desktop / light | none | 33-perfil-e-seguranca |
| `38-reset-erro-diferentes` | Validação — senhas não coincidem | `/reset-password` | desktop / light | none | 33-perfil-e-seguranca |
| `38-reset-form` | Página /reset-password — formulário "Nova Senha" | `/reset-password` | desktop / light | none | 33-perfil-e-seguranca |
| `38-reset-solicitar` | AuthModal — "Recuperar Senha" com e-mail preenchido | `/` | desktop / light | none | 33-perfil-e-seguranca |
| `39-pdfgen-pagina-1` | Relatório PDF gerado pelo app — página 1 | `(arquivo PDF gerado pelo app)` | pdf / light | projetista | 32-relatorio-pdf |
| `39-pdfgen-pagina-2` | Relatório PDF gerado pelo app — página 2 | `(arquivo PDF gerado pelo app)` | pdf / light | projetista | 32-relatorio-pdf |
| `39-reset-alterando` | Botão em estado "Alterando..." | `/reset-password` | desktop / light | none | 33-perfil-e-seguranca |
| `39-reset-redirecionado` | Catálogo após o redirecionamento automático (usuária já autenticada) | `/` | desktop / light | none | 33-perfil-e-seguranca |
| `39-reset-sucesso` | Painel de sucesso "Senha atualizada!" | `/reset-password` | desktop / light | none | 33-perfil-e-seguranca |
| `40-admin-acesso-negado` | Usuária comum em /admin/arvores — redirecionada com toast | `/` | desktop / light | user | 40-administracao-de-especies |
| `40-admin-arvores-dark` | Painel de espécies no tema escuro | `/admin/arvores` | desktop / dark | admin | 40-administracao-de-especies |
| `40-admin-arvores-lista` | Painel admin — Gerenciar Árvores | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `40-admin-arvores-mobile` | Painel de espécies no mobile | `/admin/arvores` | mobile / light | admin | 40-administracao-de-especies |
| `40-admin-guard-verificando` | AdminRoute — "Verificando permissões..." | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `40-admin-loading-tabela` | Carregando árvores... | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `40-admin-sidebar` | AdminLayout — barra lateral | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `40-admin-sidebar-mobile` | Folha lateral do admin (mobile) | `/admin/arvores` | mobile / light | admin | 40-administracao-de-especies |
| `41-admin-busca-ipe` | Busca por "ipê" | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `41-admin-busca-sem-resultado` | Busca sem resultados | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `41-admin-ordenacao-asc` | Ordenação por Nome Popular (crescente) | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `41-admin-ordenacao-asc-zoom` | Zoom: cabeçalho com seta ↑ | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `41-admin-ordenacao-desc` | Ordenação por Nome Popular (decrescente) | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `41-admin-ordenacao-desc-zoom` | Zoom: cabeçalho com seta ↓ | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `41-admin-paginacao-15` | Paginação com 15 itens por página | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `41-admin-paginacao-pagina2` | Segunda página (15 por página) | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `41-admin-paginacao-rodape` | Rodapé de paginação | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `41-admin-sem-foto` | Coluna Foto: miniaturas × ícone de pinheiro (espécie sem foto) | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `42-admin-excluir-em-uso` | Exclusão de espécie usada em projetos | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `42-admin-excluir-verificando` | Exclusão — "Verificando uso nos projetos..." | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `43-admin-form-dados-basicos` | Formulário de cadastro — seção "Dados Básicos" | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `43-admin-form-fenologia` | Formulário — seção "Fenologia" | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `43-admin-form-morfologia` | Formulário — seção "Morfologia" | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `43-admin-form-projecao` | Formulário — seção "Projeção de Crescimento (10 anos)" | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `43-admin-form-projecao-p2` | Formulário — seção "Projeção de Crescimento (10 anos)" (continuação, rolagem interna) | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `43-admin-form-tolerancias` | Formulário — seção "Tolerâncias Ecológicas" | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `43-admin-form-urbanismo` | Formulário — seção "Urbanismo & Riscos" | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `44-admin-rating-valor` | RatingInput com nota 4 selecionada e botão "Limpar" | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `44-admin-upload-dragover` | ImageUpload — estado "arrastando sobre a área" | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `44-admin-upload-erro-tamanho` | ImageUpload — erro "Arquivo muito grande. Máximo: 5MB." | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `44-admin-upload-previa` | ImageUpload — prévia da imagem com botão ✕ de remoção | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `44-admin-upload-vazio` | ImageUpload — área de arrastar/soltar vazia | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `45-admin-form-preenchido` | Formulário preenchido antes de salvar | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `45-admin-form-salvando` | Botão em estado "Salvando..." | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `45-admin-form-validacao` | Validação: "Nome popular é obrigatório" / "Nome científico é obrigatório" | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `45-admin-status-desmarcado` | Checkbox "Status" desmarcado → toast "Árvore atualizada com sucesso!" | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `45-admin-tabela-zz` | Nova espécie listada na tabela administrativa | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `45-admin-toast-cadastrada` | Toast "Árvore cadastrada com sucesso!" e a nova linha na tabela | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `46-admin-excluir-sem-uso` | Diálogo de exclusão de espécie sem uso | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `46-admin-form-editar` | Modal de edição pré-preenchido | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `46-admin-toast-atualizada` | Toast "Árvore atualizada com sucesso!" após editar | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `46-admin-toast-excluida` | Toast "Árvore excluída com sucesso!" | `/admin/arvores` | desktop / light | admin | 40-administracao-de-especies |
| `47-equipe-propria-linha` | Linha do próprio administrador — botão desabilitado | `/admin/equipe` | desktop / light | admin | 41-administracao-de-equipe |
| `47-equipe-tabela` | Painel admin — Gerenciar Equipe | `/admin/equipe` | desktop / light | admin | 41-administracao-de-equipe |
| `48-equipe-promover-dialogo` | ConfirmDialog de promoção a administrador | `/admin/equipe` | desktop / light | admin | 41-administracao-de-equipe |
| `48-equipe-tabela-colega-admin` | Tabela com a colega já marcada como Admin | `/admin/equipe` | desktop / light | admin | 41-administracao-de-equipe |
| `48-equipe-toast-promovido` | Toast "Usuário promovido a administrador!" | `/admin/equipe` | desktop / light | admin | 41-administracao-de-equipe |
| `49-equipe-rebaixar-dialogo` | ConfirmDialog de remoção de privilégios | `/admin/equipe` | desktop / light | admin | 41-administracao-de-equipe |
| `49-equipe-tabela-dark` | Gerenciar Equipe no tema escuro | `/admin/equipe` | desktop / dark | admin | 41-administracao-de-equipe |
| `49-equipe-tabela-final` | Estado final: colega novamente com papel "Usuário" | `/admin/equipe` | desktop / light | admin | 41-administracao-de-equipe |
| `49-equipe-tabela-mobile` | Gerenciar Equipe no mobile | `/admin/equipe` | mobile / light | admin | 41-administracao-de-equipe |
| `49-equipe-toast-rebaixado` | Toast "Privilégios de admin removidos." | `/admin/equipe` | desktop / light | admin | 41-administracao-de-equipe |
