# Recomendação de espécies — questionário

A página `/recomendacao` é o assistente (*wizard*) que traduz as condições físicas e as preferências de um
ponto de plantio em uma lista ordenada de espécies adequadas. Ela é **pública** — qualquer visitante pode
percorrê-la sem login — mas todas as capturas deste capítulo foram feitas com a conta de usuária comum
(`Usuária Demonstração`) para que o cabeçalho autenticado apareça nas imagens. A tela é implementada por
`src/pages/RecommendationPage.tsx` (máquina de três fases: `questions → loading → results`), o cartão de
cada pergunta por `src/components/recommendation/QuestionCard.tsx` e o conteúdo do questionário por
`src/data/questionnaire.ts`. As respostas são enviadas para a *edge function* `recommend-trees`
(`supabase/functions/recommend-trees/index.ts`) pelo hook `src/hooks/useRecommendation.ts`. Este capítulo
cobre a fase `questions`; a fase de carregamento e a tela de resultados estão no capítulo seguinte
("Recomendação de espécies — resultados").

> **Observação sobre as imagens:** o pequeno ícone circular com palmeiras no canto inferior direito de
> todas as capturas é o botão do **React Query Devtools**, montado apenas no ambiente de desenvolvimento
> (`src/main.tsx`). Ele **não faz parte da interface do produto** e não aparece em produção.

---

## Estrutura do questionário

O arquivo `src/data/questionnaire.ts` declara **5 grupos temáticos** e 20 perguntas-folha. A função
`flattenQuestions()` substitui a pergunta-contêiner `q2_8` ("Distâncias de segurança", que não tem opções
próprias) pelas suas 4 sub-perguntas `q2_8a`–`q2_8d`, produzindo **25 passos lineares**. Desses 25, apenas
24 são exibidos por padrão: `q2_6` só entra na lista quando há fiação aérea (ver "Pergunta condicional"
adiante).

> **Divergência documental:** o `CLAUDE.md` do repositório descreve o questionário como tendo "6 grupos".
> O código implementado — e a interface observada — têm **5 grupos**. Os rótulos de grupo efetivamente
> exibidos nos cartões são, em maiúsculas: "CONTEXTO E OBJETIVOS", "ESPAÇO E INTERFERÊNCIAS",
> "CONDIÇÕES ECOLÓGICAS E AMBIENTAIS", "PREFERÊNCIAS E MANUTENÇÃO" e "PREFERÊNCIAS BOTÂNICAS".

### Tabela completa dos 25 passos

| # | id | Grupo | Tipo | Pergunta (texto literal) | Opções (valor → rótulo) |
|---|---|---|---|---|---|
| 1 | `q1_1` | 1 · Contexto e Objetivos | classificatório | Qual o tipo de local de plantio? | `calcada` → "Calçada em frente a lote/residência" · `canteiro_central` → "Canteiro central de avenida" · `praca_parque` → "Praça ou parque (área interna)" · `rotatorio` → "Rotatória ou trevo viário" |
| 2 | `q1_2` | 1 · Contexto e Objetivos | classificatório (**multi, até 2**) | Qual o principal objetivo com a árvore? (escolha até 2) — ajuda: "Selecione até 2 opções." | `sombra` → "Sombra e conforto térmico" · `embelezamento` → "Embelezamento e floração" · `fauna` → "Atração de fauna (aves/polinizadores)" · `baixa_manutencao` → "Baixa manutenção / pouca sujeira" · `qualidade_ar` → "Melhorar qualidade do ar e biodiversidade" · `nativas` → "Valorizar espécies nativas da região" |
| 3 | `q2_1` | 2 · Espaço e Interferências | eliminatório | Qual a largura total da calçada (m)? | `lt_1` → "Menos de 1 m" · `1_2` → "1 a 2 m" · `2_3` → "2 a 3 m" · `3_4` → "3 a 4 m" · `gt_4` → "Mais de 4 m" |
| 4 | `q2_2` | 2 · Espaço e Interferências | eliminatório | Qual a largura efetiva da faixa de serviço (m)? — ajuda: "Faixa onde a árvore será plantada, entre o meio-fio e a faixa livre." | as mesmas 5 opções de `q2_1` |
| 5 | `q2_3` | 2 · Espaço e Interferências | eliminatório | É necessário manter faixa livre acessível de 1,20 m (ABNT NBR 9050)? — ajuda: "Calçadas com fluxo de pedestres precisam de faixa livre mínima de 1,20 m." | `sim` → "Sim" · `nao` → "Não" |
| 6 | `q2_4` | 2 · Espaço e Interferências | eliminatório | Qual a dimensão disponível para o berço/cova (m²)? | `lt_1` → "Menos de 1 m²" · `1_2` → "1 a 2 m²" · `gt_2` → "Mais de 2 m²" |
| 7 | `q2_5` | 2 · Espaço e Interferências | eliminatório | Existe fiação aérea no local? | `nao` → "Não há fiação" · `sim_convencional` → "Sim, convencional" · `sim_protegida` → "Sim, isolada/protegida" |
| 8 | `q2_6` | 2 · Espaço e Interferências | eliminatório · **condicional** | Qual a distância até a fiação aérea (m)? | `lt_4` → "Menos de 4 m" · `gt_4` → "4 m ou mais" |
| 9 | `q2_7` | 2 · Espaço e Interferências | eliminatório | Qual o recuo da edificação em relação à calçada? | `nenhum` → "Sem recuo (construção na divisa)" · `lt_2` → "Menos de 2 m" · `gt_2` → "2 m ou mais" |
| 10 | `q2_8a` | 2 · Espaço e Interferências | eliminatório | Qual a distância até a esquina mais próxima (m)? — ajuda: "Mínimo recomendado: 6 m (Cartilha de Arborização, p.16)." | `lt_6` → "Menos de 6 m" · `gt_6` → "6 m ou mais" |
| 11 | `q2_8b` | 2 · Espaço e Interferências | eliminatório | Qual a distância até o poste de iluminação mais próximo (m)? — ajuda: "Mínimo recomendado: 4 m (Cartilha de Arborização, p.16)." | `lt_4` → "Menos de 4 m" · `gt_4` → "4 m ou mais" |
| 12 | `q2_8c` | 2 · Espaço e Interferências | eliminatório | Qual a distância até a guia rebaixada (rampa de acessibilidade) mais próxima (m)? — ajuda: "Mínimo recomendado: 1,5 m (Cartilha de Arborização, p.16)." | `lt_1_5` → "Menos de 1,5 m" · `gt_1_5` → "1,5 m ou mais" |
| 13 | `q2_8d` | 2 · Espaço e Interferências | eliminatório | Qual a distância até a boca-de-lobo ou caixa de inspeção mais próxima (m)? — ajuda: "Mínimo recomendado: 1,5 m (Cartilha de Arborização, p.16)." | `lt_1_5` → "Menos de 1,5 m" · `gt_1_5` → "1,5 m ou mais" |
| 14 | `q3_1` | 3 · Condições Ecológicas e Ambientais | **misto** | Qual a condição de insolação do local? | `sol_pleno` → "Sol pleno (mais de 6h de sol direto)" · `meia_sombra` → "Meia sombra (3 a 6h de sol)" · `sombra` → "Sombra (menos de 3h de sol)" |
| 15 | `q3_2` | 3 · Condições Ecológicas e Ambientais | **misto** | Como é a umidade do solo no local? | `seco` → "Seco (bem drenado)" · `umido` → "Úmido (moderado)" · `encharcado` → "Encharcado (alagável)" |
| 16 | `q3_3` | 3 · Condições Ecológicas e Ambientais | **misto** | Qual a qualidade do solo? | `bom` → "Bom (solo natural, permeável)" · `ruim` → "Ruim (compactado, entulho, aterro)" |
| 17 | `q3_4` | 3 · Condições Ecológicas e Ambientais | **misto** | Haverá irrigação regular no primeiro ano? | `sim` → "Sim" · `nao` → "Não" |
| 18 | `q3_5` | 3 · Condições Ecológicas e Ambientais | classificatório | O local é muito exposto a ventos fortes? | `sim` → "Sim, local ventoso" · `nao` → "Não, local abrigado" |
| 19 | `q3_6` | 3 · Condições Ecológicas e Ambientais | classificatório | O local sofre com ilha de calor (necessidade de sombra extra)? | `sim` → "Sim, priorizar espécies com alto potencial de sombra" · `nao` → "Não" |
| 20 | `q4_1` | 4 · Preferências e Manutenção | **misto** | A queda de folhas, flores ou frutos é um problema no local? | `sim` → "Sim, quero minimizar sujeira" · `nao` → "Não, sem restrição" |
| 21 | `q4_2` | 4 · Preferências e Manutenção | **misto** | A presença de espinhos ou substâncias irritantes é um problema? | `sim` → "Sim, quero evitar" · `nao` → "Não, sem restrição" |
| 22 | `q4_3` | 4 · Preferências e Manutenção | **misto** | É necessário evitar atração de abelhas ou insetos? | `sim` → "Sim, quero minimizar" · `nao` → "Não, sem restrição" |
| 23 | `q4_4` | 4 · Preferências e Manutenção | classificatório | Haverá poda profissional periódica? | `sim` → "Sim, haverá manutenção profissional" · `nao` → "Não, manutenção mínima" |
| 24 | `q5_1` | 5 · Preferências Botânicas | classificatório | Há preferência por espécies nativas do Brasil? | `sim` → "Sim, priorizar nativas" · `nao` → "Não é uma prioridade" |
| 25 | `q5_2` | 5 · Preferências Botânicas | classificatório | Há preferência por espécies que atraiam fauna (aves, polinizadores)? | `sim` → "Sim, priorizar" · `nao` → "Não é uma prioridade" |

### Eliminatório × classificatório

Cada cartão exibe, no canto superior direito, uma ou duas *pills* que indicam como aquela resposta será
usada pelo motor de recomendação:

| Pill | Cor observada | Significado (atributo `title` do elemento) | Efeito na *edge function* |
|---|---|---|---|
| "ELIMINATÓRIO" | texto vermelho sobre fundo rosa-claro, borda vermelha | "Pode eliminar espécies da lista de recomendação" | a resposta entra em `passesEliminatoryRules()`: a espécie que não satisfaz a condição é **descartada** e nem chega a ser pontuada |
| "CLASSIFICATÓRIO" | texto verde-escuro sobre fundo verde-claro, borda verde | "Influencia a pontuação das espécies recomendadas" | a resposta entra em `calculateScore()` e soma pontos num total máximo de 190, normalizado depois para 0–100 |

Perguntas do tipo `misto` (todas as de insolação/solo/irrigação do grupo 3 e as três primeiras do grupo 4)
exibem **as duas pills ao mesmo tempo**: elas primeiro eliminam quem não atende ao mínimo e depois
pontuam quem sobreviveu. Isso é visível em `20-rec-q3-1-insolacao` e `20-rec-q4-2-espinhos`.

Contagem por tipo nos 25 passos: **11 eliminatórios puros** (todo o grupo 2), **7 mistos** (`q3_1`–`q3_4`,
`q4_1`–`q4_3`) e **7 classificatórios puros** (`q1_1`, `q1_2`, `q3_5`, `q3_6`, `q4_4`, `q5_1`, `q5_2`).

### Navegação, stepper e regras de interação

- **Cabeçalho de progresso:** à esquerda, "Pergunta N de M" em negrito; à direita, a porcentagem
  arredondada `((N)/M)×100`. Como M muda quando `q2_6` entra na lista, a porcentagem pode **recuar** —
  observado: 29 % no passo 7 de 24 → 28 % no mesmo passo 7, agora de 25.
- **Stepper de bolinhas:** uma bolinha numerada por passo visível, em faixa horizontal rolável (a barra de
  rolagem é ocultada por CSS) que se auto-centraliza na bolinha ativa. Cada botão tem
  `aria-label="Ir para pergunta N"` e um `title` com o texto integral da pergunta. Quatro estados visuais:
  **ativa** (verde-escuro sólido, ampliada, com anel claro ao redor), **respondida** (verde sólido, sem
  anel), **clicável mas não respondida** (fundo branco, borda cinza, número escuro) e **bloqueada**
  (esmaecida a 40 %, cursor "não permitido"). A regra de desbloqueio é: só se pode saltar até a **primeira
  pergunta ainda não respondida** — perguntas além dela ficam inacessíveis.
- **Botões de navegação:** "Voltar" (cinza) só aparece a partir do passo 2; "Próximo" (verde) fica
  **desabilitado** enquanto a pergunta atual não tiver resposta; no último passo visível o rótulo muda
  para "Ver Resultados".
- **Seleção única:** clicar em uma opção a marca imediatamente (fundo verde-claro, borda verde-acinzentada,
  texto escuro) e desmarca a anterior; **não** avança sozinho — é preciso clicar em "Próximo".
- **Multi-select (`q1_2`):** cada opção ganha uma *checkbox* quadrada à esquerda. Ao atingir 2 marcações,
  as demais **ficam desabilitadas** (esmaecidas a 40 %). Clicar de novo numa marcada a desmarca e
  reabilita as outras. Internamente as escolhas são serializadas como uma string separada por vírgulas.
- **Pergunta condicional (`q2_6`):** declarada com `showIf: { questionId: 'q2_5', values: ['sim_convencional','sim_protegida'] }`.
  A lista de passos visíveis é recalculada a cada resposta, então escolher "Sim, convencional" ou
  "Sim, isolada/protegida" faz o total saltar de 24 para 25 **na mesma tela**, antes de avançar.
- **Link permanente "Voltar ao catálogo"** no topo esquerdo da área de conteúdo, abaixo do cabeçalho do
  site, em todas as fases (perguntas, carregamento e resultados). Ele navega para `/` (`navigate('/')`).
- **Não há validação de coerência entre respostas** nem campo de texto livre: todas as perguntas são de
  escolha entre botões.

---

## Telas e estados

### Passo 1 sem resposta (entrada na página)

![Primeira pergunta do questionário, ainda sem resposta, com o botão Próximo apagado](../shots/20-rec-passo1-vazio.png)

**Rota:** `/recomendacao` — chega-se por link direto, pelo CTA "Encontrar Árvore Recomendada" da página
inicial ou pelo menu do cabeçalho · **Quem acessa:** visitante ou usuário autenticado (aqui, autenticado)
· **Viewport/tema:** desktop 1440×900, tema claro

**Elementos visíveis:**
- Cabeçalho do site (fixo em todas as telas): logotipo "PlanteiCerto" com ícone de árvore, os selos
  institucionais da Unaerp e do "Mestrado e Doutorado em Tecnologia Ambiental", os links "Árvores" e
  "Quem Somos", o chip da conta ("U · Usuária Demon…" com seta de menu) e o botão de alternância de tema
  (ícone de lua).
- Link "Voltar ao catálogo" com seta para a esquerda, logo abaixo do cabeçalho.
- Linha de progresso: "Pergunta 1 de 24" à esquerda e "4%" à direita.
- Stepper com 13 bolinhas visíveis (1 a 13) na largura da tela: a bolinha **1** está verde-escura, ampliada
  e com anel; as bolinhas 2 a 13 estão esmaecidas (bloqueadas). Uma linha horizontal fina liga os pontos.
- Cartão branco de pergunta com: badge de grupo "CONTEXTO E OBJETIVOS" (ícone de alvo, verde, caixa alta),
  pill "CLASSIFICATÓRIO" à direita, o título "Qual o tipo de local de plantio?" e as 4 opções como botões
  retangulares de largura total, todas não selecionadas.
- Botão "Próximo" centralizado, **desabilitado** (verde translúcido, sem reação ao clique). O botão
  "Voltar" **não existe** neste passo.

**Ações possíveis / o que acontece:**
- Clicar numa das 4 opções → a opção fica marcada e "Próximo" é habilitado (ver `20-rec-passo1-respondido`).
- Clicar em "Voltar ao catálogo" → navega para `/` (catálogo de espécies).
- Clicar numa bolinha esmaecida → nada acontece (botão desabilitado).

**Estados relacionados:** `20-rec-passo1-respondido`, `21-rec-limpar-refazer` (mesma tela após "Limpar e Refazer").

---

### Passo 1 respondido

![Primeira pergunta com a opção Calçada marcada e o botão Próximo ativo](../shots/20-rec-passo1-respondido.png)

**Rota:** `/recomendacao` · **Quem acessa:** visitante ou usuário autenticado · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- A opção "Calçada em frente a lote/residência" agora tem fundo verde-claro, borda verde-acinzentada e
  texto em peso médio; as outras três seguem neutras.
- No stepper, a bolinha **2** mudou de esmaecida para branca com borda e número escuro — sinalizando que
  agora é clicável (é a primeira pergunta não respondida).
- "Pergunta 1 de 24" e "4%" inalterados (o contador só muda ao avançar).
- Botão "Próximo" em verde sólido, habilitado.

**Ações possíveis / o que acontece:**
- "Próximo" → avança para a pergunta 2 (`q1_2`).
- Clicar em outra opção → troca a marcação (seleção única).
- Clicar na bolinha 2 → salta direto para a pergunta 2.

**Estados relacionados:** `20-rec-passo1-vazio`, `20-rec-q1-2-multiselect`.

---

### Pergunta de múltipla escolha com limite de 2 (`q1_2`)

![Pergunta de objetivos com duas opções marcadas e quatro esmaecidas](../shots/20-rec-q1-2-multiselect.png)

**Rota:** `/recomendacao`, passo 2 de 24 · **Quem acessa:** visitante ou usuário autenticado ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- "Pergunta 2 de 24" · "8%". Stepper: bolinhas 1 e 2 verdes (1 respondida, 2 ativa com anel), 3 branca
  clicável, 4 a 13 esmaecidas.
- Badge "CONTEXTO E OBJETIVOS", pill "CLASSIFICATÓRIO".
- Título "Qual o principal objetivo com a árvore? (escolha até 2)" e, abaixo dele, o texto de ajuda em
  cinza: "Selecione até 2 opções."
- Seis opções com *checkbox* quadrada à esquerda. **Marcadas** (checkbox verde com ✓ branco, fundo
  verde-claro): "Sombra e conforto térmico" e "Valorizar espécies nativas da região". **Desabilitadas**
  (texto e checkbox a 40 % de opacidade): "Embelezamento e floração", "Atração de fauna
  (aves/polinizadores)", "Baixa manutenção / pouca sujeira" e "Melhorar qualidade do ar e biodiversidade".
- Botões "Voltar" (cinza) e "Próximo" (verde) lado a lado.

**Ações possíveis / o que acontece:**
- Clicar numa opção desabilitada → nada acontece (o limite de 2 é imposto pelo próprio atributo `disabled`).
- Clicar numa das duas marcadas → desmarca e as outras quatro voltam a ficar habilitadas.
- "Voltar" → retorna ao passo 1 mantendo a resposta anterior.

**Estados relacionados:** `20-rec-passo1-respondido`.

---

### Pergunta eliminatória com texto de ajuda (`q2_2`)

![Pergunta sobre a largura da faixa de serviço, com pill vermelha Eliminatório](../shots/20-rec-q2-2-helptext.png)

**Rota:** `/recomendacao`, passo 4 de 24 · **Quem acessa:** visitante ou usuário autenticado ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- "Pergunta 4 de 24" · "17%". Stepper: 1–4 verdes (4 ativa), 5 branca clicável, 6–13 esmaecidas.
- Badge de grupo "ESPAÇO E INTERFERÊNCIAS" com ícone de régua, em verde.
- Pill única **"ELIMINATÓRIO"** em vermelho — todo o grupo 2 é eliminatório puro.
- Título "Qual a largura efetiva da faixa de serviço (m)?" e texto de ajuda em cinza: "Faixa onde a árvore
  será plantada, entre o meio-fio e a faixa livre."
- Cinco opções: "Menos de 1 m", "**1 a 2 m**" (marcada), "2 a 3 m", "3 a 4 m", "Mais de 4 m".
- Botões "Voltar" e "Próximo".

**Ações possíveis / o que acontece:**
- Escolher a faixa → a *edge function* descarta toda espécie cujo campo `faixa_serv_min_m_recomendada`
  ultrapasse o limite superior da faixa escolhida (2,0 m no caso de "1 a 2 m").
- O mesmo valor também alimenta a regra da NBR 9050 quando `q2_3` for "Sim".

**Estados relacionados:** `20-rec-q2-5-antes`, `20-rec-q2-8a-esquina`.

---

### Fiação aérea — antes de responder (`q2_5`, total = 24)

![Pergunta sobre fiação aérea sem resposta, mostrando Pergunta 7 de 24](../shots/20-rec-q2-5-antes.png)

**Rota:** `/recomendacao`, passo 7 · **Quem acessa:** visitante ou usuário autenticado ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- "**Pergunta 7 de 24**" · "**29%**" — o total ainda é 24 porque `q2_6` está fora da lista.
- Stepper: 1–6 verdes, 7 ativa, 8–13 esmaecidas.
- Badge "ESPAÇO E INTERFERÊNCIAS", pill "ELIMINATÓRIO".
- Título "Existe fiação aérea no local?" com três opções sem marcação: "Não há fiação",
  "Sim, convencional", "Sim, isolada/protegida".
- "Próximo" desabilitado (verde translúcido); "Voltar" habilitado.

**Ações possíveis / o que acontece:**
- Escolher "Não há fiação" → o questionário continua com 24 passos e nenhuma regra de fiação é aplicada.
- Escolher qualquer uma das duas opções "Sim…" → a pergunta `q2_6` é inserida logo depois (ver captura seguinte).

**Estados relacionados:** `20-rec-q2-5-fiacao`, `20-rec-q2-6-condicional`.

---

### Fiação convencional selecionada — o total salta para 25

![Mesma pergunta, agora com Sim convencional marcada e Pergunta 7 de 25](../shots/20-rec-q2-5-fiacao.png)

**Rota:** `/recomendacao`, passo 7 · **Quem acessa:** visitante ou usuário autenticado ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- "**Pergunta 7 de 25**" · "**28%**". Comparando com a captura anterior: **o denominador mudou de 24 para
  25 e a porcentagem recuou de 29 % para 28 %**, tudo sem sair da mesma pergunta. Essa é a evidência
  visual da pergunta condicional entrando na lista.
- No stepper, a bolinha **8** passou de esmaecida a branca com borda (agora é a próxima pergunta não
  respondida e, portanto, clicável). A faixa continua mostrando 13 bolinhas por limitação de largura,
  mas o total de bolinhas existentes subiu de 24 para 25 — é o que o denominador do cabeçalho informa.
- "Sim, convencional" marcada em verde-claro.
- "Próximo" habilitado.

**Ações possíveis / o que acontece:**
- "Próximo" → vai para `q2_6` ("Qual a distância até a fiação aérea (m)?").
- Voltar aqui depois e trocar para "Não há fiação" remove `q2_6` da lista de passos visíveis (a resposta
  já dada a `q2_6` continua no estado, mas deixa de ser exibida e, como não é apagada, continua sendo
  enviada à *edge function* — comportamento não testado explicitamente nesta captura).

**Estados relacionados:** `20-rec-q2-5-antes`, `20-rec-q2-6-condicional`.

---

### Pergunta condicional `q2_6` — distância até a fiação

![Pergunta condicional sobre distância até a fiação, Pergunta 8 de 25](../shots/20-rec-q2-6-condicional.png)

**Rota:** `/recomendacao`, passo 8 de 25 · **Quem acessa:** visitante ou usuário autenticado ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- "Pergunta 8 de 25" · "32%". O stepper já rolou: mostra de 2 a 14, com 8 ativa.
- Badge "ESPAÇO E INTERFERÊNCIAS", pill "ELIMINATÓRIO".
- Título "Qual a distância até a fiação aérea (m)?" com duas opções: "**Menos de 4 m**" (marcada) e
  "4 m ou mais".
- Botões "Voltar" e "Próximo".

**Ações possíveis / o que acontece:**
- "Menos de 4 m" com fiação convencional → a regra mais dura: toda espécie com `compat_fiacao = 'N'`
  (incompatível) é eliminada, independentemente do porte.
- "4 m ou mais" (ou fiação isolada/protegida) → regra mais branda: só elimina espécies que sejam
  **simultaneamente** `compat_fiacao = 'N'` **e** de porte "Grande".

**Estados relacionados:** `20-rec-q2-5-fiacao`, `21-rec-fiacao-topo` (resultado deste cenário).

---

### Distâncias de segurança — esquina (`q2_8a`)

![Pergunta sobre distância até a esquina com a nota da Cartilha de Arborização](../shots/20-rec-q2-8a-esquina.png)

**Rota:** `/recomendacao`, passo 10 de 25 · **Quem acessa:** visitante ou usuário autenticado ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- "Pergunta 10 de 25" · "40%". Stepper mostrando 4–16, com 10 ativa.
- Badge "ESPAÇO E INTERFERÊNCIAS", pill "ELIMINATÓRIO".
- Título "Qual a distância até a esquina mais próxima (m)?" e ajuda em cinza:
  "Mínimo recomendado: 6 m (Cartilha de Arborização, p.16)."
- Opções "Menos de 6 m" e "**6 m ou mais**" (marcada).

**Ações possíveis / o que acontece:**
- "Menos de 6 m" → elimina todas as espécies de porte "Grande".
- "6 m ou mais" → nenhuma eliminação por este critério.

**Estados relacionados:** `20-rec-q2-8b-poste`, `20-rec-q2-8c-guia`, `20-rec-q2-8d-bocalobo`.

---

### Distâncias de segurança — poste de iluminação (`q2_8b`)

![Pergunta sobre distância até o poste, mínimo de 4 m](../shots/20-rec-q2-8b-poste.png)

**Rota:** `/recomendacao`, passo 11 de 25 · **Quem acessa:** visitante ou usuário autenticado ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- "Pergunta 11 de 25" · "44%". Stepper 5–17, com 11 ativa.
- Título "Qual a distância até o poste de iluminação mais próximo (m)?"; ajuda:
  "Mínimo recomendado: 4 m (Cartilha de Arborização, p.16)."
- Opções "Menos de 4 m" e "**4 m ou mais**" (marcada). Pill "ELIMINATÓRIO".

**Ações possíveis / o que acontece:**
- "Menos de 4 m" → elimina espécies com `copa_classe = 'Grande'`.

**Estados relacionados:** `20-rec-q2-8a-esquina`, `20-rec-q2-8c-guia`.

---

### Distâncias de segurança — guia rebaixada (`q2_8c`)

![Pergunta sobre distância até a guia rebaixada, mínimo de 1,5 m](../shots/20-rec-q2-8c-guia.png)

**Rota:** `/recomendacao`, passo 12 de 25 · **Quem acessa:** visitante ou usuário autenticado ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- "Pergunta 12 de 25" · "48%". Stepper 6–18, com 12 ativa.
- Título em duas linhas: "Qual a distância até a guia rebaixada (rampa de acessibilidade) mais próxima (m)?";
  ajuda: "Mínimo recomendado: 1,5 m (Cartilha de Arborização, p.16)."
- Opções "Menos de 1,5 m" e "**1,5 m ou mais**" (marcada). Pill "ELIMINATÓRIO".

**Ações possíveis / o que acontece:**
- **Atenção — esta é a resposta mais destrutiva do questionário:** escolher "Menos de 1,5 m" faz a
  *edge function* devolver **zero espécies**, porque a regra correspondente em
  `supabase/functions/recommend-trees/index.ts` retorna `false` incondicionalmente para qualquer árvore
  (justificativa embutida no código: NBR 9050 — não se planta ao lado de uma rampa de acessibilidade).
  Esse é o cenário documentado em `21-rec-zero-resultados`.

**Estados relacionados:** `21-rec-zero-resultados`, `21-rec-zero-chips`.

---

### Distâncias de segurança — boca-de-lobo (`q2_8d`)

![Pergunta sobre distância até a boca-de-lobo, mínimo de 1,5 m](../shots/20-rec-q2-8d-bocalobo.png)

**Rota:** `/recomendacao`, passo 13 de 25 · **Quem acessa:** visitante ou usuário autenticado ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- "Pergunta 13 de 25" · "52%". Stepper 7–19, com 13 ativa.
- Título "Qual a distância até a boca-de-lobo ou caixa de inspeção mais próxima (m)?"; ajuda:
  "Mínimo recomendado: 1,5 m (Cartilha de Arborização, p.16)."
- Opções "Menos de 1,5 m" e "**1,5 m ou mais**" (marcada). Pill "ELIMINATÓRIO".

**Ações possíveis / o que acontece:**
- "Menos de 1,5 m" → elimina espécies com `potencial_dano_calcada_1a5 ≥ 4` (raízes agressivas).

**Estados relacionados:** `20-rec-q2-8c-guia`.

---

### Grupo 3 — pergunta mista (insolação)

![Pergunta sobre insolação exibindo as duas pills, Eliminatório e Classificatório](../shots/20-rec-q3-1-insolacao.png)

**Rota:** `/recomendacao`, passo 14 de 25 · **Quem acessa:** visitante ou usuário autenticado ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- "Pergunta 14 de 25" · "56%". Stepper 8–20, com 14 ativa.
- Badge de grupo "CONDIÇÕES ECOLÓGICAS E AMBIENTAIS" com ícone de folha.
- **Duas pills lado a lado**: "ELIMINATÓRIO" (vermelha) e "CLASSIFICATÓRIO" (verde) — é o tipo `misto`.
- Título "Qual a condição de insolação do local?" com três opções: "**Sol pleno (mais de 6h de sol
  direto)**" (marcada), "Meia sombra (3 a 6h de sol)", "Sombra (menos de 3h de sol)".

**Ações possíveis / o que acontece:**
- "Sol pleno" → elimina toda espécie cujo campo `tolerancia_sol_pleno` seja explicitamente falso e, em
  seguida, concede 20 pontos (de 20) a quem o tem verdadeiro, 10 a quem o tem nulo.

**Estados relacionados:** `20-rec-stepper-zoom` (mesmo momento do percurso), `20-rec-q4-2-espinhos`.

> **Detalhe de implementação observado:** o mapa `groupIcons` em `QuestionCard.tsx` tem as chaves
> "Condições Ecológicas" e "Preferências", mas os rótulos reais dos grupos são "Condições Ecológicas e
> Ambientais" e "Preferências e Manutenção". Como a busca é por igualdade exata, esses dois grupos caem no
> ícone padrão (folha) em vez dos ícones previstos. Na prática, os grupos 3 e 4 exibem **o mesmo ícone**
> (comparar esta captura com `20-rec-q4-2-espinhos`).

---

### Stepper em detalhe (meio do percurso)

![Recorte ampliado da faixa de bolinhas do stepper mostrando os quatro estados](../shots/20-rec-stepper-zoom.png)

**Rota:** `/recomendacao`, passo 14 de 25 (recorte da faixa superior) · **Quem acessa:** visitante ou
usuário autenticado · **Viewport/tema:** desktop claro, recorte ampliado

**Elementos visíveis:**
- Linha "Pergunta 14 de 25" à esquerda e "56%" à direita.
- Bolinhas, da esquerda para a direita: **8, 9, 10, 11, 12, 13** em verde-escuro sólido com número branco
  (respondidas); **14** em verde-escuro, maior que as demais e com um anel claro em volta (ativa);
  **15** branca com borda cinza e número escuro (clicável — é a próxima não respondida); **16, 17, 18, 19,
  20** esmaecidas em cinza-claro (bloqueadas).
- Uma linha horizontal fina de cor cinza atravessa os pontos, ligando-os.
- As bolinhas 1 a 7 ficaram fora do recorte porque a faixa rola horizontalmente e se centraliza na ativa.

**Ações possíveis / o que acontece:**
- Clicar numa bolinha verde ou branca → salta para aquela pergunta (as respostas já dadas são mantidas).
- Clicar numa esmaecida → nada (desabilitada).

**Estados relacionados:** `20-rec-q3-1-insolacao`, `20-rec-voltar`.

---

### Botão "Voltar"

![Questionário de volta ao passo 14 depois de o passo 15 já ter sido respondido](../shots/20-rec-voltar.png)

**Rota:** `/recomendacao`, passo 14 de 25 (após responder o 15 e clicar em "Voltar") · **Quem acessa:**
visitante ou usuário autenticado · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- "Pergunta 14 de 25" · "56%" — voltamos um passo.
- No stepper, **as bolinhas 8 a 15 estão todas verdes** (15 também já foi respondida) e a **14** é a ativa,
  com anel; a 16 é a primeira branca/clicável.
- O cartão mostra novamente "Qual a condição de insolação do local?" com "Sol pleno (mais de 6h de sol
  direto)" **ainda marcada** — as respostas não se perdem ao voltar.
- "Próximo" habilitado (a pergunta já tem resposta).

**Ações possíveis / o que acontece:**
- "Próximo" → volta ao passo 15 (verificado: o cabeçalho retorna a "Pergunta 15 de 25").
- Trocar a resposta aqui → a nova escolha substitui a anterior; as respostas posteriores permanecem.

**Estados relacionados:** `20-rec-stepper-zoom`, `20-rec-q3-1-insolacao`.

---

### Grupo 4 — espinhos e substâncias irritantes

![Pergunta sobre espinhos com as duas pills e duas opções](../shots/20-rec-q4-2-espinhos.png)

**Rota:** `/recomendacao`, passo 21 de 25 · **Quem acessa:** visitante ou usuário autenticado ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- "Pergunta 21 de 25" · "84%". Stepper 13–25, com 21 ativa, 22 branca e 23–25 esmaecidas.
- Badge "PREFERÊNCIAS E MANUTENÇÃO" (mesmo ícone de folha do grupo 3 — ver nota acima).
- Pills "ELIMINATÓRIO" e "CLASSIFICATÓRIO" (tipo `misto`).
- Título "A presença de espinhos ou substâncias irritantes é um problema?" com "**Sim, quero evitar**"
  (marcada) e "Não, sem restrição".

**Ações possíveis / o que acontece:**
- "Sim, quero evitar" → elimina qualquer espécie com `presenca_espinhos = true` **ou**
  `presenca_subst_irritantes = true`; entre as sobreviventes, dá 15 pontos (de 15) a quem não tem nenhum
  dos dois, 7 a quem tem só um registro ausente e 0 a quem tem ambos.

**Estados relacionados:** `20-rec-q3-1-insolacao`, `21-rec-criterios-expandido`.

---

### Grupo 5 — preferências botânicas

![Pergunta sobre preferência por nativas, com pill Classificatório apenas](../shots/20-rec-q5-1-nativas.png)

**Rota:** `/recomendacao`, passo 24 de 25 · **Quem acessa:** visitante ou usuário autenticado ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- "Pergunta 24 de 25" · "96%". Stepper 13–25, com 24 ativa e 25 branca (última, ainda não respondida).
- Badge "PREFERÊNCIAS BOTÂNICAS" com ícone de flor.
- Pill única "CLASSIFICATÓRIO" (todo o grupo 5 é classificatório puro — nunca elimina).
- Título "Há preferência por espécies nativas do Brasil?" com "**Sim, priorizar nativas**" (marcada) e
  "Não é uma prioridade".

**Ações possíveis / o que acontece:**
- "Sim, priorizar nativas" → 10 pontos (de 10) para espécies com `origem = 'Nativa BR'`, 0 para exóticas.
  Esse é o critério que empurra as nativas para o topo da lista de resultados.

**Estados relacionados:** `20-rec-ultimo-passo`.

---

### Último passo — botão "Ver Resultados"

![Última pergunta do questionário com o botão Ver Resultados e 100% de progresso](../shots/20-rec-ultimo-passo.png)

**Rota:** `/recomendacao`, passo 25 de 25 · **Quem acessa:** visitante ou usuário autenticado ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- "Pergunta 25 de 25" · "**100%**". No stepper, **todas** as bolinhas visíveis (13 a 25) estão verdes e a
  25 é a ativa, com anel.
- Badge "PREFERÊNCIAS BOTÂNICAS", pill "CLASSIFICATÓRIO".
- Título "Há preferência por espécies que atraiam fauna (aves, polinizadores)?" com "**Sim, priorizar**"
  marcada e "Não é uma prioridade".
- O botão verde da direita mudou de rótulo: agora lê "**Ver Resultados**" em vez de "Próximo".
  "Voltar" continua à esquerda.

**Ações possíveis / o que acontece:**
- "Ver Resultados" → **não envia nada ainda**: abre o diálogo de confirmação "Finalizar questionário?".

**Estados relacionados:** `20-rec-dialogo-finalizar`.

---

### Diálogo "Finalizar questionário?"

![Modal central de confirmação sobre o questionário desfocado](../shots/20-rec-dialogo-finalizar.png)

**Rota:** `/recomendacao` (sobreposição modal sobre a fase de perguntas) · **Quem acessa:** visitante ou
usuário autenticado · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Fundo da página coberto por uma camada translúcida com desfoque (*backdrop blur*) — o questionário
  continua visível, borrado, atrás.
- Cartão branco centralizado, de cantos arredondados, com:
  - Título "**Finalizar questionário?**"
  - Texto "Você respondeu a todas as perguntas obrigatórias. Deseja ver as árvores recomendadas para o
    seu local agora?"
  - Dois botões alinhados à direita: "**Revisar respostas**" (cinza) e "**Ver Recomendações**" (verde).
- O cabeçalho do site permanece nítido no topo (o modal cobre apenas a área de conteúdo).

**Ações possíveis / o que acontece:**
- "Revisar respostas" → fecha o diálogo e devolve ao questionário, no mesmo passo 25 (ver
  `20-rec-revisar-respostas`). Nada é enviado.
- "Ver Recomendações" → fecha o diálogo, muda a fase para `loading` e chama a *edge function*
  `recommend-trees` com todas as respostas (ver capítulo de resultados, `21-rec-loading`).
- Clicar fora do cartão **não** fecha o diálogo (não há manipulador de clique no fundo, diferentemente do
  `Modal` genérico usado em outras telas).

**Estados relacionados:** `20-rec-revisar-respostas`, `20-rec-dialogo-reaberto`, `21-rec-loading`.

---

### Após "Revisar respostas"

![Questionário de volta ao passo 25 com o diálogo fechado](../shots/20-rec-revisar-respostas.png)

**Rota:** `/recomendacao`, passo 25 de 25 · **Quem acessa:** visitante ou usuário autenticado ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- Tela idêntica a `20-rec-ultimo-passo`: "Pergunta 25 de 25", "100%", stepper todo verde, a última
  pergunta com "Sim, priorizar" marcada e o botão "Ver Resultados".
- O modal desapareceu; nenhuma mensagem de confirmação ou aviso é exibida.

**Ações possíveis / o que acontece:**
- Navegar livremente pelo stepper ou pelos botões "Voltar"/"Próximo" para conferir/alterar respostas.
- Clicar em "Ver Resultados" de novo → reabre o mesmo diálogo (`20-rec-dialogo-reaberto`).

**Estados relacionados:** `20-rec-ultimo-passo`, `20-rec-dialogo-reaberto`.

---

### Diálogo reaberto, antes de confirmar

![O mesmo modal de confirmação reaberto após a revisão](../shots/20-rec-dialogo-reaberto.png)

**Rota:** `/recomendacao` (modal) · **Quem acessa:** visitante ou usuário autenticado ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- Exatamente o mesmo diálogo "Finalizar questionário?" com os mesmos textos e os botões "Revisar
  respostas" e "Ver Recomendações". Não há indicação de que é a segunda vez — o diálogo não tem memória
  nem contador.

**Ações possíveis / o que acontece:**
- "Ver Recomendações" → envio efetivo. Nesta execução (cenário com fiação), o resultado foi
  **19 espécies compatíveis de 146 analisadas · 127 eliminadas** (ver `21-rec-fiacao-topo` no próximo
  capítulo).

**Estados relacionados:** `20-rec-dialogo-finalizar`, `21-rec-fiacao-topo`.

---

## Fluxo passo a passo — Percurso do questionário (cenário com fiação aérea)

Este é o roteiro exato reproduzido na captura, com a conta `usuario.demo@planteicerto.local`
(nome exibido "Usuária Demonstração"), em desktop 1440×900, tema claro.

1. Abrir `/recomendacao`. A página entra na fase `questions` com "Pergunta 1 de 24" e o botão "Próximo"
   desabilitado (ver `20-rec-passo1-vazio`).
2. Responder `q1_1` = "Calçada em frente a lote/residência". "Próximo" habilita e a bolinha 2 do stepper
   fica clicável (ver `20-rec-passo1-respondido`). Clicar em "Próximo".
3. Em `q1_2`, marcar "Sombra e conforto térmico" e "Valorizar espécies nativas da região". As outras
   quatro opções ficam desabilitadas (ver `20-rec-q1-2-multiselect`). "Próximo".
4. `q2_1` = "2 a 3 m"; "Próximo".
5. `q2_2` = "1 a 2 m" — primeira pergunta com pill "ELIMINATÓRIO" e texto de ajuda
   (ver `20-rec-q2-2-helptext`); "Próximo".
6. `q2_3` = "Sim" (faixa livre de 1,20 m obrigatória); "Próximo".
7. `q2_4` = "1 a 2 m²"; "Próximo".
8. No passo 7, antes de responder, o cabeçalho lê "Pergunta 7 de **24**" (ver `20-rec-q2-5-antes`).
   Responder `q2_5` = "Sim, convencional": o cabeçalho passa imediatamente a "Pergunta 7 de **25**"
   (ver `20-rec-q2-5-fiacao`). "Próximo".
9. `q2_6` (pergunta que só existe agora) = "Menos de 4 m" (ver `20-rec-q2-6-condicional`); "Próximo".
10. `q2_7` = "2 m ou mais"; "Próximo".
11. Quatro sub-perguntas de distância, todas com a citação "(Cartilha de Arborização, p.16)":
    `q2_8a` = "6 m ou mais" (`20-rec-q2-8a-esquina`), `q2_8b` = "4 m ou mais" (`20-rec-q2-8b-poste`),
    `q2_8c` = "1,5 m ou mais" (`20-rec-q2-8c-guia`), `q2_8d` = "1,5 m ou mais"
    (`20-rec-q2-8d-bocalobo`).
12. `q3_1` = "Sol pleno (mais de 6h de sol direto)" — primeira pergunta com as duas pills
    (ver `20-rec-q3-1-insolacao` e o recorte `20-rec-stepper-zoom`); "Próximo".
13. `q3_2` = "Úmido (moderado)". Para demonstrar a navegação, clicar em "Voltar": a tela retorna ao passo
    14 com a resposta preservada e o passo 15 já marcado como respondido no stepper
    (ver `20-rec-voltar`). Clicar em "Próximo" para retomar.
14. `q3_3` = "Bom (solo natural, permeável)"; `q3_4` = "Sim"; `q3_5` = "Não, local abrigado";
    `q3_6` = "Sim, priorizar espécies com alto potencial de sombra".
15. `q4_1` = "Não, sem restrição"; `q4_2` = "Sim, quero evitar" (ver `20-rec-q4-2-espinhos`);
    `q4_3` = "Não, sem restrição"; `q4_4` = "Não, manutenção mínima".
16. `q5_1` = "Sim, priorizar nativas" (ver `20-rec-q5-1-nativas`); "Próximo".
17. `q5_2` = "Sim, priorizar". O progresso chega a 100 % e o botão passa a "Ver Resultados"
    (ver `20-rec-ultimo-passo`). Clicar nele.
18. O diálogo "Finalizar questionário?" aparece (ver `20-rec-dialogo-finalizar`). Clicar em
    "Revisar respostas" devolve ao passo 25 sem enviar nada (ver `20-rec-revisar-respostas`).
19. Clicar em "Ver Resultados" novamente reabre o diálogo (ver `20-rec-dialogo-reaberto`) e, em
    "Ver Recomendações", a consulta é enviada. Resultado deste cenário: **19 espécies compatíveis de 146
    analisadas, 127 eliminadas** (ver `21-rec-fiacao-topo`).

A tabela completa de respostas deste cenário, e a dos outros dois cenários documentados, está no capítulo
de resultados, na seção "Tabelas de respostas dos três cenários".
