# Painel administrativo — gestão da equipe

A segunda tela da área restrita responde por uma única pergunta: **quem é administrador do
PlanteiCerto**. Ela lista todas as contas registradas no sistema e permite promover alguém a
administrador ou retirar esse privilégio. Não há criação nem exclusão de contas por aqui — quem
entra na lista é quem se cadastra pelo site (um gatilho do banco cria automaticamente a linha em
`profiles` a cada novo usuário do Supabase Auth).

A tela é a `AdminUsersPage` (`src/pages/AdminUsersPage.tsx`), servida na rota `/admin/equipe` sob a
mesma guarda `AdminRoute` e a mesma moldura `AdminLayout` descritas no capítulo anterior. A leitura
e a gravação ficam em `src/hooks/useAdminUsers.ts`, e a confirmação usa o componente genérico
`ConfirmDialog` (`src/components/ui/ConfirmDialog.tsx`).

No ambiente documentado havia **quatro contas**: três com papel `user` e uma com papel `admin` (a
conta usada nas capturas). A promoção e o rebaixamento demonstrados foram feitos na conta
"Colega da Equipe", que voltou ao papel `user` ao fim do processo.

---

## Tela "Gerenciar Equipe"

### Lista de usuários

![Painel administrativo com barra lateral e tabela de quatro usuários com papéis e botões de ação](../shots/47-equipe-tabela.png)

**Rota:** `/admin/equipe` — item "Equipe" na barra lateral do painel · **Quem acessa:** administrador ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- Barra lateral do painel à esquerda, agora com **"Equipe"** destacado em verde e "Árvores" em cinza.
- Cabeçalho: ícone de duas pessoas + título **"Gerenciar Equipe"**; abaixo, em cinza,
  **"4 usuários registrados"** (no singular seria "1 usuário registrados" — ver Observações).
- Tabela mais estreita que a de espécies (largura máxima de 896 px), com quatro colunas:
  **Nome, Email, Role, Ações**.
- Linhas, na ordem de criação das contas:
  1. "Usuária Demonstração" · usuario.demo@planteicerto.local · *pill* cinza-azulado
     **"Usuário"** · botão verde **"Promover"** com ícone de escudo com "check";
  2. "Projetista Demonstração" · projetista.demo@planteicerto.local · "Usuário" · "Promover";
  3. **"Administrador Demo" seguido de "(você)"** em letra menor · admin.demo@planteicerto.local ·
     *pill* verde **"Admin"** · botão **"Remover Admin"** visivelmente apagado;
  4. "Colega da Equipe" · colega.demo@planteicerto.local · "Usuário" · "Promover".
- Os e-mails aparecem em cinza claro; o *pill* de papel é verde para "Admin" e cinza para "Usuário".
- Não há busca, paginação, ordenação nem contagem por papel: a lista é sempre integral, ordenada
  pela data de criação da conta (crescente).

**Ações possíveis / o que acontece:**
- "Promover" → abre o diálogo de confirmação de promoção.
- "Remover Admin" → abre o diálogo de confirmação de rebaixamento.
- O botão da própria linha está desabilitado (ver a captura seguinte).

**Estados relacionados:** 47-equipe-propria-linha, 48-equipe-promover-dialogo, 49-equipe-tabela-final

### A própria linha do administrador está protegida

![Recorte da linha Administrador Demo com a marca você e o botão Remover Admin esmaecido](../shots/47-equipe-propria-linha.png)

**Rota:** `/admin/equipe` (recorte da terceira linha) · **Quem acessa:** administrador ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- Nome em negrito **"Administrador Demo"** seguido do marcador **"(você)"** em cinza pequeno.
- E-mail admin.demo@planteicerto.local, *pill* verde "Admin".
- À direita, o botão **"Remover Admin"** com ícone de escudo cortado, renderizado com 30 % de
  opacidade, sem fundo colorido e com cursor de bloqueio. O atributo `disabled` está de fato
  aplicado (verificado na página).

**Ações possíveis / o que acontece:**
- Clicar não faz nada. O botão carrega a dica nativa do navegador
  **"Não é possível alterar seu próprio role"** — como toda dica nativa (`title`), ela não é
  desenhada pelo navegador em capturas de tela, então o texto está registrado aqui, mas não aparece
  na imagem.
- A comparação é feita entre o `id` da linha e o `id` da sessão; assim, um administrador nunca se
  auto-rebaixa e não fica sem ninguém no comando por engano.

### Diálogo de promoção

![Diálogo com o título Promover Colega da Equipe a Admin e dois botões](../shots/48-equipe-promover-dialogo.png)

**Rota:** `/admin/equipe` → "Promover" na linha da colega · **Quem acessa:** administrador ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- Cartão branco estreito, centralizado sobre um fundo escurecido e desfocado.
- Título em negrito: **`Promover "Colega da Equipe" a Admin?`**.
- Texto: **"Este usuário terá acesso ao painel administrativo e poderá gerenciar árvores e outros
  usuários."**
- Rodapé com **"Cancelar"** (contorno cinza) e um botão vermelho rotulado **"Excluir"**.
- Um "×" cinza no canto superior direito, que se sobrepõe ao fim do título.

**Ações possíveis / o que acontece:**
- "Cancelar", "×", Esc ou clique fora fecham sem alterar nada.
- O botão vermelho é o **botão de confirmação** — ele aplica a promoção apesar do rótulo "Excluir".
  Trata-se do `ConfirmDialog` genérico, cujo botão de ação é fixo (ver Observações).

### Usuário promovido

![Tabela com a colega já marcada como Admin e toast verde Usuário promovido a administrador](../shots/48-equipe-toast-promovido.png)

![Recorte da tabela mostrando duas linhas Admin, a do próprio usuário e a da colega](../shots/48-equipe-tabela-colega-admin.png)

**Rota:** `/admin/equipe` logo após confirmar · **Quem acessa:** administrador ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- Toast verde na base da tela: **"Usuário promovido a administrador!"**.
- A quarta linha muda em três pontos ao mesmo tempo: o *pill* passa de "Usuário" cinza para
  **"Admin" verde**, o botão troca de "Promover" (verde) para **"Remover Admin"** (vermelho, com
  ícone de escudo cortado) e a linha passa a ser equivalente à do próprio administrador, exceto pelo
  marcador "(você)" e pelo botão continuar habilitado.
- O contador do cabeçalho segue em "4 usuários registrados" — a promoção não cria contas.

**Ações possíveis / o que acontece:**
- A gravação é um `update` em `profiles.role`; ao dar certo, o hook invalida os caches
  `admin-users` e `profile`, de modo que a tabela e o próprio menu do site refletem a mudança sem
  recarregar a página.
- A partir desse momento a colega passa pela guarda `AdminRoute` e enxerga `/admin/arvores` e
  `/admin/equipe`; no site público ela ganha o item "Administração" no menu do usuário.
- Em caso de falha o toast seria vermelho: "Erro ao alterar permissão: …".

### Diálogo de rebaixamento

![Diálogo com o título Remover admin de Colega da Equipe e dois botões](../shots/49-equipe-rebaixar-dialogo.png)

**Rota:** `/admin/equipe` → "Remover Admin" na linha da colega · **Quem acessa:** administrador ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- Título **`Remover admin de "Colega da Equipe"?`** — nesta captura o "?" final fica parcialmente
  encoberto pelo botão "×" do canto.
- Texto: **"Este usuário perderá o acesso ao painel administrativo."**
- Mesmos botões "Cancelar" e "Excluir" (vermelho) do diálogo anterior.

**Ações possíveis / o que acontece:**
- O botão vermelho confirma o rebaixamento.

### Privilégios removidos

![Tabela de volta ao estado inicial com toast verde Privilégios de admin removidos](../shots/49-equipe-toast-rebaixado.png)

**Elementos visíveis:**
- Toast verde na base: **"Privilégios de admin removidos."** (com ponto final, diferente do toast de
  promoção, que termina em exclamação).
- A linha da colega volta ao *pill* cinza "Usuário" e ao botão verde "Promover".

### Estado final da equipe

![Tabela com três usuários comuns e apenas o administrador atual como Admin](../shots/49-equipe-tabela-final.png)

**Rota:** `/admin/equipe` · **Quem acessa:** administrador · **Viewport/tema:** desktop claro

**Elementos visíveis:** exatamente o mesmo conteúdo de 47-equipe-tabela — três contas "Usuário"
(Usuária Demonstração, Projetista Demonstração, Colega da Equipe) e uma "Admin"
(Administrador Demo, com "(você)" e botão desabilitado). Confirma que o par promover/rebaixar é
reversível e não deixa resíduo.

### Gerenciar Equipe no mobile

![Tela estreita com barra superior Admin e tabela com as colunas Nome e Role](../shots/49-equipe-tabela-mobile.png)

**Rota:** `/admin/equipe` · **Quem acessa:** administrador · **Viewport/tema:** mobile 390×844, claro

**Elementos visíveis:**
- Barra superior do painel com logotipo, "Admin" e botão hambúrguer.
- Título "Gerenciar Equipe" e "4 usuários registrados".
- A tabela mostra apenas **Nome** e **Role**: a coluna "Email" desaparece abaixo do ponto de quebra
  `sm` e o endereço passa a ser exibido **em uma segunda linha, sob o nome**, em cinza pequeno.
- A coluna "Ações" fica fora da área visível — vê-se apenas uma tira verde na borda direita, indício
  dos botões "Promover"; o contêiner rola horizontalmente.
- O marcador "(você)" continua ao lado de "Administrador Demo".

**Ações possíveis / o que acontece:**
- É preciso arrastar a tabela para a esquerda para alcançar os botões de promover/rebaixar.

### Gerenciar Equipe no tema escuro

![Mesma tabela em fundo preto com pills e botões em tons escuros](../shots/49-equipe-tabela-dark.png)

**Rota:** `/admin/equipe` · **Quem acessa:** administrador · **Viewport/tema:** desktop escuro

**Elementos visíveis:**
- Fundo quase preto; tabela delimitada por bordas discretas e cabeçalho em cinza escuro.
- *Pills* "Usuário" em cinza-azulado escuro e "Admin" em verde translúcido com texto verde-claro.
- Botões "Promover" ganham fundo verde escuro translúcido; o botão da própria linha continua
  apagado.

---

## Fluxo passo a passo — promover um usuário a administrador

1. Entrar com uma conta administradora e clicar em **"Equipe"** na barra lateral do painel (ou ir
   direto a `/admin/equipe`).
2. Localizar a pessoa na lista — a tabela traz todas as contas, sem filtro nem paginação
   *(ver 47-equipe-tabela)*.
3. Clicar no botão verde **"Promover"** da linha correspondente.
4. Ler o diálogo `Promover "<nome>" a Admin?`, que explica que a pessoa "terá acesso ao painel
   administrativo e poderá gerenciar árvores e outros usuários" *(ver 48-equipe-promover-dialogo)*.
5. Confirmar no **botão vermelho** do diálogo (rotulado "Excluir", mas é o de confirmação) ou
   desistir em "Cancelar".
6. Aparece o toast **"Usuário promovido a administrador!"** e a linha passa a exibir o *pill*
   "Admin" e o botão "Remover Admin" *(ver 48-equipe-toast-promovido e
   48-equipe-tabela-colega-admin)*.

## Fluxo passo a passo — remover privilégios de administrador

1. Na mesma tela, clicar no botão vermelho **"Remover Admin"** da linha da pessoa.
2. Ler o diálogo `Remover admin de "<nome>"?`, que avisa que a pessoa "perderá o acesso ao painel
   administrativo" *(ver 49-equipe-rebaixar-dialogo)*.
3. Confirmar. Surge o toast **"Privilégios de admin removidos."** e a linha volta a "Usuário" /
   "Promover" *(ver 49-equipe-toast-rebaixado e 49-equipe-tabela-final)*.
4. Não é possível fazer isso com a própria conta: o botão da linha marcada com "(você)" está
   desabilitado *(ver 47-equipe-propria-linha)*.

---

## Observações técnicas e divergências observadas

- **A trava da própria linha é dupla.** Além do botão desabilitado na interface, o banco tem o
  gatilho `enforce_role_protection`, que executa a função `prevent_role_self_escalation()` antes de
  cada `UPDATE` em `profiles`: se o valor de `role` mudar e quem está gravando não for
  administrador, a transação é abortada com o erro "Alteração de role não permitida". Ou seja, um
  usuário comum não consegue se promover nem editando a requisição diretamente — a política de RLS
  "Users can update own profile" permite que ele altere o próprio perfil (nome, por exemplo), mas o
  gatilho barra especificamente a mudança de papel.
- **A leitura da lista também é protegida por RLS:** a política "Admins can read all profiles" só
  devolve a tabela inteira para quem tem `role = 'admin'`; um usuário comum enxerga apenas a própria
  linha. A política "Admins can update any profile" é o que autoriza a promoção/rebaixamento.
- **O botão de confirmação diz "Excluir" nos dois diálogos.** O `ConfirmDialog` é um componente
  genérico com rótulo e cor fixos ("Excluir", vermelho), pensado para exclusões e reaproveitado sem
  ajuste na promoção e no rebaixamento. É a divergência de interface mais visível desta tela: o
  texto do botão contradiz a ação descrita no título e na mensagem.
- **O "×" do modal encobre o fim de títulos longos** — visível em
  `Remover admin de "Colega da Equipe"?`.
- **Erro de concordância no contador:** o código alterna apenas a palavra "usuário"/"usuários" e
  mantém "registrados" fixo, de modo que com uma única conta o texto ficaria
  "1 usuário registrados".
- **A coluna se chama "Role", em inglês**, no meio de uma interface toda em português; os valores
  exibidos, porém, são traduzidos ("Admin" e "Usuário").
- **A tela não cria, não convida nem exclui contas** e não mostra data de cadastro, último acesso ou
  qualquer outro dado do perfil — apenas nome, e-mail e papel. Também não há busca nem paginação, o
  que deve pesar se a base de usuários crescer.
- **O cache da lista dura 2 minutos** (`staleTime`), mas é invalidado explicitamente a cada mudança
  de papel, então a tabela nunca fica desatualizada depois de uma ação feita na própria tela.
