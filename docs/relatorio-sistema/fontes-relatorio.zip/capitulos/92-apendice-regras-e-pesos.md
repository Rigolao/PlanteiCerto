# Apêndice C — Regras Eliminatórias, Pesos e Rótulos

Transcrição integral da lógica implementada em `supabase/functions/recommend-trees/index.ts` (572 linhas). Os números de linha referem-se a esse arquivo.

## C.1 Interpretação das faixas de medida

Função `rangeUpperBound` (linhas 77 a 87). Adota sempre o **limite superior** da faixa declarada pelo usuário, o que torna o filtro conservador.

| Valor da resposta | Limite adotado |
|---|---|
| `lt_1` | 1,0 |
| `1_2` | 2,0 |
| `2_3` | 3,0 |
| `3_4` | 4,0 |
| `gt_4` | 99 |
| `gt_2` | 99 |
| qualquer outro | 99 |

## C.2 Regras eliminatórias

Função `passesEliminatoryRules(tree, answers)`, linhas 91 a 161. A avaliação é sequencial e a primeira regra violada descarta a espécie. Nenhum valor nulo elimina: as comparações numéricas são protegidas por `!= null` e as booleanas usam igualdade estrita.

| # | Condição na resposta | Coluna avaliada | Espécie é eliminada quando | Linhas |
|---|---|---|---|---|
| 1 | `q2_2` respondida | `faixa_serv_min_m_recomendada` | valor `>` `rangeUpperBound(q2_2)` | 94–97 |
| 2 | `q2_3 = 'sim'` e `q2_1` respondida | `faixa_serv_min_m_recomendada` | valor `>` `rangeUpperBound(q2_1) − 1,20` | 98–101 |
| 3 | `q2_4` respondida | `berco_area_min_m2_recomendada` | valor `>` `rangeUpperBound(q2_4)` | 102–105 |
| 4 | `q2_5 = 'sim_convencional'` e `q2_6 = 'lt_4'` | `compat_fiacao` | valor `= 'N'` | 107–108 |
| 5 | `q2_5 = 'sim_protegida'` ou `q2_6 = 'gt_4'`, dentro do bloco em que `q2_5 <> 'nao'` | `compat_fiacao` e `porte_altura_classe` | `compat_fiacao = 'N'` **e** `porte_altura_classe = 'Grande'` | 109–110 |
| 6 | `q2_7 = 'nenhum'` ou `q2_7 = 'lt_2'` | `copa_classe` | valor `= 'Grande'` | 113–115 |
| 7 | `q2_8a = 'lt_6'` | `porte_altura_classe` | valor `= 'Grande'` | 116–118 |
| 8 | `q2_8b = 'lt_4'` | `copa_classe` | valor `= 'Grande'` | 119–121 |
| 9 | `q2_8c = 'lt_1_5'` | nenhuma | **sempre** — retorno incondicional `false`, justificado no código pela NBR 9050 | 123 |
| 10 | `q2_8d = 'lt_1_5'` | `potencial_dano_calcada_1a5` | `(valor ?? 0) >= 4` | 125–127 |
| 11 | `q3_1 = 'sol_pleno'` | `tolerancia_sol_pleno` | valor `= false` | 131 |
| 12 | `q3_1 = 'meia_sombra'` | `tolerancia_meia_sombra` | valor `= false` | 132 |
| 13 | `q3_1 = 'sombra'` | `tolerancia_sombra` | valor `= false` | 133 |
| 14 | `q3_2 = 'seco'` | `tolerancia_seca_1a5` | valor `<= 2` | 135–137 |
| 15 | `q3_2 = 'encharcado'` | `tolerancia_encharcamento_1a5` | valor `<= 3` | 138–140 |
| 16 | `q3_3 = 'ruim'` | `tolerancia_compactacao_solo_1a5` | valor `<= 3` | 141–143 |
| 17 | `q3_4 = 'nao'` | `tolerancia_seca_1a5` | valor `<= 2` | 144–146 |
| 18 | `q4_1 = 'sim'` | `potencial_sujeira_1a5` | valor `>= 3` | 150–152 |
| 19 | `q4_2 = 'sim'` | `presenca_espinhos` e `presenca_subst_irritantes` | qualquer um `= true` | 153–155 |
| 20 | `q4_3 = 'sim'` | `atracao_fauna_1a5` | valor `>= 4` | 156–158 |

## C.3 Pesos classificatórios

Função `calculateScore(tree, answers)`, linhas 174 a 426. `MAX_SCORE = 190` (linha 166); nota final `Math.round((raw / 190) × 100)` (linha 425). A coluna "Rótulo" reproduz literalmente o campo `label` de cada entrada do `scoreBreakdown`, na forma em que chega ao cliente e é exibida na tela de resultados. A ordem das linhas é a ordem em que o código empilha o `breakdown`.

| Ordem | Pergunta e resposta | `maxPoints` | Pontuação | Rótulo (`label`) | Linhas |
|---|---|---|---|---|---|
| 1 | `q3_1 = sol_pleno` | 20 | `tolerancia_sol_pleno` verdadeiro → 20; falso → 0; nulo → 10 | Insolação (sol pleno) | 184–186 |
| 1 | `q3_1 = meia_sombra` | 20 | `tolerancia_meia_sombra` verdadeiro → 20; falso → 0; nulo → 10 | Insolação (meia sombra) | 187–189 |
| 1 | `q3_1 = sombra` | 20 | `tolerancia_sombra` verdadeiro → 20; falso → 0; nulo → 10 | Insolação (sombra) | 190–192 |
| 2 | `q3_2 = seco` | 20 | `(tolerancia_seca_1a5 ?? 3) × 4` | Tolerância à seca | 202–204 |
| 2 | `q3_2 = umido` | 20 | 15 fixos | Umidade do solo | 205–207 |
| 2 | `q3_2 = encharcado` | 20 | `(tolerancia_encharcamento_1a5 ?? 3) × 4` | Tolerância a encharcamento | 208–210 |
| 3 | `q3_3 = ruim` | 20 | `(tolerancia_compactacao_solo_1a5 ?? 3) × 4` | Solo compactado/aterro | 220–222 |
| 3 | `q3_3` qualquer outra | 20 | 20 fixos | Qualidade do solo | 223–226 |
| 4 | `q3_4 = nao` | 10 | `(tolerancia_seca_1a5 ?? 3) × 2` | Sem irrigação disponível | 235–237 |
| 4 | `q3_4` qualquer outra | 10 | 10 fixos | Irrigação disponível | 238–241 |
| 5 | `q4_1 = sim` | 15 | `(6 − (potencial_sujeira_1a5 ?? 3)) × 3` | Potencial de sujeira | 252–254 |
| 5 | `q4_1` qualquer outra | 15 | 15 fixos | Queda de folhas/frutos | 255–258 |
| 6 | `q4_2 = sim`, sem espinhos e sem irritantes | 15 | 15 | Sem espinhos/irritantes | 270–271 |
| 6 | `q4_2 = sim`, apenas um dos dois ausente | 15 | 7 | Espinhos/irritantes (parcial) | 272–273 |
| 6 | `q4_2 = sim`, ambos presentes | 15 | 0 | Presença de espinhos/irritantes | 274–276 |
| 6 | `q4_2` qualquer outra | 15 | 15 fixos | Espinhos/irritantes | 277–279 |
| 7 | `q4_3 = sim` | 10 | `(6 − (atracao_fauna_1a5 ?? 3)) × 2` | Atração de insetos/abelhas | 288–290 |
| 7 | `q4_3` qualquer outra | 10 | 10 fixos | Atração de fauna | 291–293 |
| 8 | `q4_4 = nao` | 10 | `(tolerancia_poda_1a5 ?? 3) × 2` | Tolerância a poda mínima | 302–304 |
| 8 | `q4_4` qualquer outra | 10 | 10 fixos | Manutenção profissional | 305–307 |
| 9 | `q1_1 = calcada` | 10 | `(6 − (potencial_dano_calcada_1a5 ?? 3)) × 2` | Adequação à calçada | 318–320 |
| 9 | `q1_1 = canteiro_central` | 10 | `(tolerancia_poluicao_atmosferica_1a5 ?? 3) × 2` | Tolerância à poluição (canteiro) | 321–323 |
| 9 | `q1_1 = praca_parque` | 10 | `(atracao_fauna_1a5 ?? 3) × 2` | Contribuição ecológica (praça) | 324–326 |
| 9 | `q1_1 = rotatorio` | 10 | `(tolerancia_ventos_fortes_1a5 ?? 3) × 2` | Tolerância a ventos (rotatória) | 327–329 |
| 10 | `q1_2` (múltipla escolha) | 20 | soma das contribuições por objetivo, `quota = 20 / n`, com `Math.round` no total | Objetivo(s) de plantio | 336–365 |
| 11 | `q5_1 = sim` | 10 | `origem = 'Nativa BR'` → 10; senão 0 | Espécie nativa | 373–375 |
| 11 | `q5_1 = nao` | 10 | 10 fixos | Origem da espécie | 376–378 |
| 12 | `q5_2 = sim` | 10 | `(atracao_fauna_1a5 ?? 3) × 2` | Atração de fauna (preferência) | 387–389 |
| 12 | `q5_2 = nao` | 10 | 10 fixos | Atração de fauna | 390–392 |
| 13 | `q3_5 = sim` | 10 | `(tolerancia_ventos_fortes_1a5 ?? 3) × 2` | Tolerância a ventos fortes | 401–403 |
| 13 | `q3_5 = nao` | 10 | 10 fixos | Exposição ao vento | 404–406 |
| 14 | `q3_6 = sim` | 10 | `(potencial_sombra_1a5 ?? 3) × 2` | Potencial de sombra (ilha de calor) | 415–417 |
| 14 | `q3_6 = nao` | 10 | 10 fixos | Potencial de sombra | 418–420 |

Soma dos máximos das quatorze perguntas pontuadas: 20 + 20 + 20 + 10 + 15 + 15 + 10 + 10 + 10 + 20 + 10 + 10 + 10 + 10 = **190**. As onze perguntas do grupo 2 não pontuam.

### Contribuição de cada objetivo em `q1_2`

Linhas 341 a 360; `quota = 20 / número de objetivos selecionados`; a interface limita a seleção a dois.

| Objetivo | Rótulo na interface | Contribuição |
|---|---|---|
| `sombra` | Sombra e conforto térmico | `((potencial_sombra_1a5 ?? 3) / 5) × quota` |
| `embelezamento` | Embelezamento e floração | `((atracao_fauna_1a5 ?? 3) / 5) × quota` — usa atração de fauna como *proxy*, conforme comentário no código |
| `fauna` | Atração de fauna (aves/polinizadores) | `((atracao_fauna_1a5 ?? 3) / 5) × quota` |
| `baixa_manutencao` | Baixa manutenção / pouca sujeira | `decidua_perenifolia = 'Perenifólia'` → cota integral; senão `((6 − (potencial_sujeira_1a5 ?? 3)) / 5) × quota` |
| `qualidade_ar` | Melhorar qualidade do ar e biodiversidade | `((contribuicao_biodiversidade_1a5 ?? 3) / 5) × quota` |
| `nativas` | Valorizar espécies nativas da região | `origem = 'Nativa BR'` → cota integral; senão 0 |

## C.4 Rótulos de `criteriaSummary`

Função `buildCriteriaSummary(answers)`, linhas 430 a 497. Os dois vetores são construídos apenas a partir das respostas, sem consultar espécie alguma, e alimentam o cartão "Como as espécies foram avaliadas" na tela de resultados.

### Vetor `eliminatory`, na ordem de inserção

| Condição | Texto inserido |
|---|---|
| `q2_2` respondida | `Faixa de serviço: X`, com X em `< 1m`, `1–2m`, `2–3m`, `3–4m` ou `> 4m` |
| `q2_3 = 'sim'` | `Faixa acessível de 1,20m obrigatória` |
| `q2_4` respondida | `Berço disponível: X`, com X em `< 1m²`, `1–2m²` ou `> 2m²` |
| `q2_5 = 'sim_convencional'` | `Fiação convencional` |
| `q2_5 = 'sim_protegida'` | `Fiação isolada/protegida` |
| `q2_6 = 'lt_4'` | `Fiação a < 4m` |
| `q2_7 = 'nenhum'` | `Sem recuo da edificação` |
| `q2_7 = 'lt_2'` | `Recuo < 2m` |
| `q2_8a = 'lt_6'` | `Esquina a < 6m` |
| `q2_8b = 'lt_4'` | `Poste a < 4m` |
| `q2_8c = 'lt_1_5'` | `Guia rebaixada a < 1,5m` |
| `q2_8d = 'lt_1_5'` | `Boca-de-lobo a < 1,5m` |
| `q3_1 = 'sol_pleno'` | `Insolação: sol pleno (tolerância obrigatória)` |
| `q3_1 = 'meia_sombra'` | `Insolação: meia sombra (tolerância obrigatória)` |
| `q3_1 = 'sombra'` | `Insolação: sombra (tolerância obrigatória)` |
| `q3_2 = 'seco'` | `Solo seco (tolerância_seca ≥ 3 exigida)` |
| `q3_2 = 'encharcado'` | `Solo encharcado (tolerância_encharcamento ≥ 4 exigida)` |
| `q3_3 = 'ruim'` | `Solo compactado (tolerância_compactação ≥ 4 exigida)` |
| `q3_4 = 'nao'` | `Sem irrigação no 1º ano (tolerância_seca ≥ 3 exigida)` |
| `q4_1 = 'sim'` | `Queda de resíduos: elimina potencial_sujeira ≥ 3` |
| `q4_2 = 'sim'` | `Espinhos/irritantes: elimina espécies com presença` |
| `q4_3 = 'sim'` | `Atração de insetos: elimina atracao_fauna ≥ 4` |

### Vetor `classificatory`, na ordem de inserção

| Condição | Texto inserido |
|---|---|
| `q3_1` respondida | `Insolação: X`, com X em `Sol pleno (> 6h)`, `Meia sombra (3–6h)` ou `Sombra (< 3h)` |
| `q3_2` respondida | `Umidade: X`, com X em `Solo seco`, `Solo úmido` ou `Solo encharcado` |
| `q3_3 = 'ruim'` | `Solo compactado/aterro` |
| `q3_4 = 'nao'` | `Sem irrigação no 1º ano` |
| `q4_1 = 'sim'` | `Queda de resíduos é problema` |
| `q4_2 = 'sim'` | `Espinhos/irritantes são problema` |
| `q4_3 = 'sim'` | `Evitar atração de insetos` |
| `q4_4 = 'nao'` | `Sem poda profissional` |
| `q1_1` respondida | `Local: X`, com X em `Calçada`, `Canteiro central`, `Praça/parque` ou `Rotatória` |
| `q1_2` respondida | `Objetivo(s): X`, com os rótulos `Sombra`, `Embelezamento`, `Atração de fauna`, `Baixa manutenção`, `Qualidade do ar` e `Espécies nativas` unidos por vírgula |
| `q5_1 = 'sim'` | `Preferência por nativas` |
| `q5_2 = 'sim'` | `Preferência por espécies atrativas à fauna` |
| `q3_5 = 'sim'` | `Local exposto a ventos fortes` |
| `q3_6 = 'sim'` | `Necessidade de sombra (ilha de calor)` |

Note-se a assimetria deliberada: o vetor eliminatório descreve restrições do sítio com o limiar numérico explícito, enquanto o classificatório descreve preferências. Alguns textos aparecem apenas quando a resposta é afirmativa, de modo que o cartão fica mais curto quanto menos restritivo for o cenário informado.
