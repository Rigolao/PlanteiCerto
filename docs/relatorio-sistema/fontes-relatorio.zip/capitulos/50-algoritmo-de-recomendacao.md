# O Algoritmo de Recomendação

## O questionário

O instrumento de entrada está declarado em `src/data/questionnaire.ts`, como um vetor tipado `Question[]`. A estrutura de cada pergunta prevê identificador, grupo (`1 | 2 | 3 | 4 | 5`), rótulo do grupo, tipo (`eliminatorio`, `classificatorio` ou `misto`), enunciado, texto de ajuda opcional, opções de resposta, marcação de múltipla escolha, condição de exibição e subperguntas (`src/data/questionnaire.ts:8-19`).

O vetor contém **22 entradas**. Uma delas, `q2_8` ("Distâncias de segurança", `src/data/questionnaire.ts:145`), é apenas um contêiner: tem `options: []` e quatro subperguntas. A função `flattenQuestions()` percorre o vetor e substitui toda pergunta que tenha subperguntas pelas suas filhas (`src/data/questionnaire.ts:344-354`), produzindo a lista linear efetivamente apresentada ao usuário: **25 passos**. Desses, 24 são sempre exibidos e um é condicional — `q2_6`, sobre a distância até a fiação aérea, só aparece quando `q2_5` responde `sim_convencional` ou `sim_protegida` (`src/data/questionnaire.ts:121-131`). Uma única pergunta admite resposta múltipla: `q1_2`, limitada a duas escolhas pela interface e serializada como uma cadeia de valores separados por vírgula.

Os cinco grupos são: 1 — Contexto e Objetivos (2 perguntas, classificatórias); 2 — Espaço e Interferências (11 passos, todos eliminatórios); 3 — Condições Ecológicas e Ambientais (6 perguntas, quatro mistas e duas classificatórias); 4 — Preferências e Manutenção (4 perguntas, três mistas e uma classificatória); 5 — Preferências Botânicas (2 perguntas, classificatórias). O apêndice do questionário traz os 25 passos com enunciado, opções e rótulos exatos.

## O pipeline

```mermaid
flowchart TD
  A["Usuário responde o questionário, até 25 passos"]
  B["RecommendationPage monta answers como Record de string para string"]
  C["useRecommendation chama functions.invoke recommend-trees"]
  D{"Campo answers presente e é objeto?"}
  E["HTTP 400 com Campo answers é obrigatório"]
  F["Cliente service_role lê todas as colunas de trees onde ativa é verdadeiro"]
  G{"Erro na consulta?"}
  H["HTTP 500 com Erro ao buscar espécies"]
  I["totalCount recebe o número de espécies ativas"]
  J["Fase 1: passesEliminatoryRules aplicada a cada espécie"]
  K["Conjunto de sobreviventes"]
  L["Fase 2: calculateScore em cada sobrevivente"]
  M["score igual a round de raw dividido por 190 vezes 100, mais scoreBreakdown"]
  N["Ordenação decrescente por score, sem critério de desempate"]
  O["buildCriteriaSummary derivado apenas das respostas"]
  P["HTTP 200 com trees, eliminated_count e criteriaSummary"]
  Q["ResultScreen exibe o ranking e o resumo de critérios"]
  A --> B
  B --> C
  C --> D
  D -->|"não"| E
  D -->|"sim"| F
  F --> G
  G -->|"sim"| H
  G -->|"não"| I
  I --> J
  J --> K
  K --> L
  L --> M
  M --> N
  N --> O
  O --> P
  P --> Q
```

A função de borda é `supabase/functions/recommend-trees/index.ts`, com 572 linhas de Deno. Ela recebe `POST` com corpo `{ answers }`, trata `OPTIONS` para CORS e responde em JSON. A consulta ao banco usa a chave de serviço lida de `SUPABASE_SERVICE_ROLE_KEY` e filtra explicitamente por `ativa = true` (`supabase/functions/recommend-trees/index.ts:526`), de modo que a recomendação nunca considera espécies desativadas, independentemente de quem chama. A ordenação final é `scored.sort((a, b) => b.score - a.score)` (linha 548): decrescente por pontuação, sem desempate secundário — como `Array.prototype.sort` é estável no V8, espécies com a mesma nota preservam a ordem em que o banco as devolveu.

## Fase 1 — Regras eliminatórias

A função `passesEliminatoryRules(tree, answers)` (linhas 91 a 161) devolve `false` na primeira regra violada; basta uma para descartar a espécie. Faixas de medida são interpretadas pelo **limite superior** por meio de `rangeUpperBound` (linhas 77 a 87): `lt_1` vale 1,0; `1_2` vale 2,0; `2_3` vale 3,0; `3_4` vale 4,0; `gt_4` e `gt_2` valem 99; qualquer outro valor também vale 99. Trata-se de uma escolha conservadora explícita: adota-se o teto do intervalo declarado pelo usuário, admitindo menos espécies em troca de maior segurança de que caberão no espaço.

| # | Condição na resposta | Coluna testada | Elimina quando | Linha |
|---|---|---|---|---|
| 1 | `q2_2` com qualquer valor | `faixa_serv_min_m_recomendada` | valor `>` limite superior de `q2_2` | 94–97 |
| 2 | `q2_3 = 'sim'` **e** `q2_1` respondida | `faixa_serv_min_m_recomendada` | valor `>` limite superior de `q2_1` menos 1,20 m | 98–101 |
| 3 | `q2_4` com qualquer valor | `berco_area_min_m2_recomendada` | valor `>` limite superior de `q2_4` | 102–105 |
| 4 | `q2_5 = 'sim_convencional'` **e** `q2_6 = 'lt_4'` | `compat_fiacao` | igual a `'N'` | 107–108 |
| 5 | `q2_5 = 'sim_protegida'` **ou** `q2_6 = 'gt_4'`, desde que `q2_5` não seja `'nao'` | `compat_fiacao` e `porte_altura_classe` | `compat_fiacao = 'N'` **e** porte `'Grande'` | 109–110 |
| 6 | `q2_7 ∈ {'nenhum', 'lt_2'}` | `copa_classe` | igual a `'Grande'` | 113–115 |
| 7 | `q2_8a = 'lt_6'` | `porte_altura_classe` | igual a `'Grande'` | 116–118 |
| 8 | `q2_8b = 'lt_4'` | `copa_classe` | igual a `'Grande'` | 119–121 |
| 9 | `q2_8c = 'lt_1_5'` | nenhuma | **todas as espécies**, incondicionalmente | 123 |
| 10 | `q2_8d = 'lt_1_5'` | `potencial_dano_calcada_1a5` | valor, com nulo tratado como 0, `>= 4` | 125–127 |
| 11 | `q3_1 = 'sol_pleno'` | `tolerancia_sol_pleno` | exatamente `false` | 131 |
| 12 | `q3_1 = 'meia_sombra'` | `tolerancia_meia_sombra` | exatamente `false` | 132 |
| 13 | `q3_1 = 'sombra'` | `tolerancia_sombra` | exatamente `false` | 133 |
| 14 | `q3_2 = 'seco'` | `tolerancia_seca_1a5` | `<= 2` | 135–137 |
| 15 | `q3_2 = 'encharcado'` | `tolerancia_encharcamento_1a5` | `<= 3` | 138–140 |
| 16 | `q3_3 = 'ruim'` | `tolerancia_compactacao_solo_1a5` | `<= 3` | 141–143 |
| 17 | `q3_4 = 'nao'` | `tolerancia_seca_1a5` | `<= 2` | 144–146 |
| 18 | `q4_1 = 'sim'` | `potencial_sujeira_1a5` | `>= 3` | 150–152 |
| 19 | `q4_2 = 'sim'` | `presenca_espinhos` e `presenca_subst_irritantes` | qualquer uma exatamente `true` | 153–155 |
| 20 | `q4_3 = 'sim'` | `atracao_fauna_1a5` | `>= 4` | 156–158 |

A regra 9 merece leitura atenta: quando o usuário informa que há guia rebaixada (rampa de acessibilidade) a menos de 1,5 m, a função retorna `false` para **toda e qualquer espécie**, sem consultar nenhuma coluna. O comentário no código justifica: "guia rebaixada < 1,5m — elimina qualquer árvore (NBR 9050)". O resultado prático é uma tela de zero recomendações — comportamento correto do ponto de vista normativo (não se planta ali), mas que, do ponto de vista da experiência, chega ao usuário como uma lista vazia sem explicação específica dessa causa.

Nulos nunca eliminam. Todas as comparações numéricas estão protegidas por `!= null`, e os testes booleanos usam igualdade estrita com `false` ou com `true`. Uma espécie sem dado na coluna testada sempre sobrevive à fase eliminatória. A regra 10 é a única exceção parcial à convenção: ela aplica `?? 0` ao potencial de dano à calçada, o que continua favorecendo a espécie sem dado (0 nunca é maior ou igual a 4).

## Fase 2 — Pontuação classificatória

A constante `MAX_SCORE = 190` está na linha 166, precedida do comentário que a decompõe. A pontuação final é `Math.round((raw / MAX_SCORE) * 100)` (linha 425), resultando numa escala de 0 a 100. Cada pergunta respondida empurra uma entrada `{ label, points, maxPoints }` para o vetor `breakdown`, que é devolvido ao cliente como `scoreBreakdown` e alimenta a seção "Destaques da árvore" na tela de resultados.

| Pergunta e resposta | `maxPoints` | Fórmula ou valor | Rótulo no `scoreBreakdown` |
|---|---|---|---|
| `q3_1 = sol_pleno` | 20 | `true` → 20; `false` → 0; nulo → 10 | Insolação (sol pleno) |
| `q3_1 = meia_sombra` | 20 | idem sobre `tolerancia_meia_sombra` | Insolação (meia sombra) |
| `q3_1 = sombra` | 20 | idem sobre `tolerancia_sombra` | Insolação (sombra) |
| `q3_2 = seco` | 20 | `(tolerancia_seca_1a5 ?? 3) × 4` | Tolerância à seca |
| `q3_2 = umido` | 20 | 15 fixos | Umidade do solo |
| `q3_2 = encharcado` | 20 | `(tolerancia_encharcamento_1a5 ?? 3) × 4` | Tolerância a encharcamento |
| `q3_3 = ruim` | 20 | `(tolerancia_compactacao_solo_1a5 ?? 3) × 4` | Solo compactado/aterro |
| `q3_3` demais | 20 | 20 fixos | Qualidade do solo |
| `q3_4 = nao` | 10 | `(tolerancia_seca_1a5 ?? 3) × 2` | Sem irrigação disponível |
| `q3_4` demais | 10 | 10 fixos | Irrigação disponível |
| `q4_1 = sim` | 15 | `(6 − (potencial_sujeira_1a5 ?? 3)) × 3` | Potencial de sujeira |
| `q4_1` demais | 15 | 15 fixos | Queda de folhas/frutos |
| `q4_2 = sim` | 15 | sem espinhos **e** sem irritantes → 15; apenas um ausente → 7; ambos presentes → 0 | Sem espinhos/irritantes · Espinhos/irritantes (parcial) · Presença de espinhos/irritantes |
| `q4_2` demais | 15 | 15 fixos | Espinhos/irritantes |
| `q4_3 = sim` | 10 | `(6 − (atracao_fauna_1a5 ?? 3)) × 2` | Atração de insetos/abelhas |
| `q4_3` demais | 10 | 10 fixos | Atração de fauna |
| `q4_4 = nao` | 10 | `(tolerancia_poda_1a5 ?? 3) × 2` | Tolerância a poda mínima |
| `q4_4` demais | 10 | 10 fixos | Manutenção profissional |
| `q1_1 = calcada` | 10 | `(6 − (potencial_dano_calcada_1a5 ?? 3)) × 2` | Adequação à calçada |
| `q1_1 = canteiro_central` | 10 | `(tolerancia_poluicao_atmosferica_1a5 ?? 3) × 2` | Tolerância à poluição (canteiro) |
| `q1_1 = praca_parque` | 10 | `(atracao_fauna_1a5 ?? 3) × 2` | Contribuição ecológica (praça) |
| `q1_1 = rotatorio` | 10 | `(tolerancia_ventos_fortes_1a5 ?? 3) × 2` | Tolerância a ventos (rotatória) |
| `q1_2` (múltipla) | 20 | soma das cotas, `quota = 20 / n`, arredondada ao final | Objetivo(s) de plantio |
| `q5_1 = sim` | 10 | `origem = 'Nativa BR'` → 10; senão 0 | Espécie nativa |
| `q5_1 = nao` | 10 | 10 fixos | Origem da espécie |
| `q5_2 = sim` | 10 | `(atracao_fauna_1a5 ?? 3) × 2` | Atração de fauna (preferência) |
| `q5_2 = nao` | 10 | 10 fixos | Atração de fauna |
| `q3_5 = sim` | 10 | `(tolerancia_ventos_fortes_1a5 ?? 3) × 2` | Tolerância a ventos fortes |
| `q3_5 = nao` | 10 | 10 fixos | Exposição ao vento |
| `q3_6 = sim` | 10 | `(potencial_sombra_1a5 ?? 3) × 2` | Potencial de sombra (ilha de calor) |
| `q3_6 = nao` | 10 | 10 fixos | Potencial de sombra |

A contribuição de cada objetivo selecionado em `q1_2` (linhas 341 a 360), sempre sobre a cota:

| Objetivo | Cálculo |
|---|---|
| `sombra` | `((potencial_sombra_1a5 ?? 3) / 5) × quota` |
| `embelezamento` | `((atracao_fauna_1a5 ?? 3) / 5) × quota` — o código anota que se trata de um *proxy*, por não existir campo de floração no banco |
| `fauna` | `((atracao_fauna_1a5 ?? 3) / 5) × quota` |
| `baixa_manutencao` | `decidua_perenifolia = 'Perenifólia'` → cota integral; caso contrário `((6 − (potencial_sujeira_1a5 ?? 3)) / 5) × quota` |
| `qualidade_ar` | `((contribuicao_biodiversidade_1a5 ?? 3) / 5) × quota` |
| `nativas` | `origem = 'Nativa BR'` → cota integral; caso contrário 0 |

Somando os `maxPoints` das quatorze perguntas pontuadas — 20 + 20 + 20 + 10 + 15 + 15 + 10 + 10 + 10 + 20 + 10 + 10 + 10 + 10 — chega-se exatamente a 190. Ou seja, a constante é consistente **para um questionário integralmente respondido**. Como o vetor `breakdown` só recebe entradas das perguntas que foram respondidas, mas o divisor permanece 190, qualquer preenchimento parcial rebaixa a nota de todas as espécies proporcionalmente e torna a nota 100 matematicamente inalcançável. Note-se que as onze perguntas do grupo 2 não pontuam: elas são puramente eliminatórias.

O tratamento de ausência de dado segue duas convenções: escala numérica nula assume o valor **3** (mediano), pelo operador `??`; booleano nulo na pergunta de insolação vale **10 pontos**, metade do máximo, o que é neutro por construção.

## Exemplo numérico completo

Considere uma espécie hipotética com `origem = 'Nativa BR'`, `decidua_perenifolia = 'Semidecídua'`, `tolerancia_sol_pleno = true`, `tolerancia_seca_1a5 = 4`, `tolerancia_compactacao_solo_1a5 = 4`, `potencial_sujeira_1a5 = 2`, `presenca_espinhos = false`, `presenca_subst_irritantes = false`, `atracao_fauna_1a5 = 3`, `tolerancia_poda_1a5 = 4`, `potencial_dano_calcada_1a5 = 2`, `tolerancia_poluicao_atmosferica_1a5 = 4`, `tolerancia_ventos_fortes_1a5 = 3`, `potencial_sombra_1a5 = 4`, `contribuicao_biodiversidade_1a5 = 4`, `faixa_serv_min_m_recomendada = 2,0`, `berco_area_min_m2_recomendada = 1,0`, `compat_fiacao = 'C'`, `porte_altura_classe = 'Médio'` e `copa_classe = 'Média'`.

E um questionário respondido assim: `q1_1 = calcada`; `q1_2 = sombra,nativas`; `q2_1 = 3_4`; `q2_2 = 2_3`; `q2_3 = sim`; `q2_4 = 1_2`; `q2_5 = nao` (com o que `q2_6` não é exibida); `q2_7 = gt_2`; `q2_8a = gt_6`; `q2_8b = gt_4`; `q2_8c = gt_1_5`; `q2_8d = gt_1_5`; `q3_1 = sol_pleno`; `q3_2 = seco`; `q3_3 = bom`; `q3_4 = nao`; `q3_5 = nao`; `q3_6 = sim`; `q4_1 = sim`; `q4_2 = sim`; `q4_3 = nao`; `q4_4 = nao`; `q5_1 = sim`; `q5_2 = nao`.

**Fase eliminatória.** A faixa de serviço declarada `2_3` vira teto de 3,0 m, e 2,0 ≤ 3,0. A exigência de faixa acessível reduz a calçada `3_4` (teto 4,0 m) para 2,80 m úteis, e 2,0 ≤ 2,80. O berço `1_2` vira 2,0 m², e 1,0 ≤ 2,0. Não há fiação, o recuo é maior que 2 m e as quatro distâncias de segurança estão acima dos mínimos. A espécie tolera sol pleno, tem tolerância à seca 4 (maior que 2, portanto sobrevive tanto à regra do solo seco quanto à da ausência de irrigação), potencial de sujeira 2 (menor que 3) e não tem espinhos nem irritantes. A espécie sobrevive.

**Fase classificatória**, na ordem em que o código empilha o `breakdown`:

| Critério | Cálculo | Pontos | Máximo |
|---|---|---|---|
| Insolação (sol pleno) | booleano verdadeiro | 20 | 20 |
| Tolerância à seca | 4 × 4 | 16 | 20 |
| Qualidade do solo | valor fixo (resposta `bom`) | 20 | 20 |
| Sem irrigação disponível | 4 × 2 | 8 | 10 |
| Potencial de sujeira | (6 − 2) × 3 | 12 | 15 |
| Sem espinhos/irritantes | ausência de ambos | 15 | 15 |
| Atração de fauna | valor fixo (resposta `nao`) | 10 | 10 |
| Tolerância a poda mínima | 4 × 2 | 8 | 10 |
| Adequação à calçada | (6 − 2) × 2 | 8 | 10 |
| Objetivo(s) de plantio | cota 20/2 = 10; sombra (4/5)×10 = 8; nativas = 10; soma 18 | 18 | 20 |
| Espécie nativa | origem `Nativa BR` | 10 | 10 |
| Atração de fauna | valor fixo (resposta `nao`) | 10 | 10 |
| Exposição ao vento | valor fixo (resposta `nao`) | 10 | 10 |
| Potencial de sombra (ilha de calor) | 4 × 2 | 8 | 10 |
| **Soma bruta** | | **173** | **190** |

Nota final: `round((173 / 190) × 100) = round(91,05) = 91`. A espécie apareceria na lista com o selo verde de 91 %. Na seção "Destaques da árvore", a tela de resultados filtra os critérios com pontuação maior que zero, ordena por pontos decrescentes com desempate por `maxPoints` e mostra os três primeiros (`src/components/recommendation/ResultScreen.tsx:300-303`): neste exemplo, "Insolação (sol pleno)" 20 de 20, "Qualidade do solo" 20 de 20 e "Objetivo(s) de plantio" 18 de 20, seguidos da linha "+11 outros critérios pontuados".

## Resumo de critérios, formato da resposta e observabilidade

A função `buildCriteriaSummary(answers)` (linhas 430 a 497) constrói dois vetores de rótulos legíveis em português — `eliminatory` e `classificatory` — **exclusivamente a partir das respostas**, sem consultar nenhuma espécie. É o material que a tela de resultados exibe no cartão "Como as espécies foram avaliadas". Os rótulos exatos estão reproduzidos no apêndice de regras e pesos.

A resposta bem-sucedida tem a forma:

```json
{
  "trees": [ { "id": 1, "nome_popular": "...", "score": 91, "scoreBreakdown": [ { "label": "Insolação (sol pleno)", "points": 20, "maxPoints": 20 } ] } ],
  "eliminated_count": 37,
  "criteriaSummary": { "eliminatory": ["..."], "classificatory": ["..."] }
}
```

Cada elemento de `trees` é a linha completa da tabela (inclusive as colunas de projeção de 10 anos, que não participam da pontuação) acrescida de `score` e `scoreBreakdown`. Os erros previstos são HTTP 400 com `{"error":"Campo \"answers\" é obrigatório"}`, HTTP 500 com `{"error":"Erro ao buscar espécies","details":...}` e HTTP 500 com `{"error":"Erro interno","details":...}`.

O CORS é controlado por uma lista de origens autorizadas lida da variável de ambiente `ALLOWED_ORIGINS`, separada por vírgulas, com o par `http://localhost:5173` e `http://localhost:4173` como padrão de desenvolvimento; a origem recebida só é refletida se constar da lista, e o cabeçalho `Vary: Origin` acompanha a resposta (linhas 3 a 15). Ambas as funções de borda são publicadas sem verificação de JWT (`verify_jwt = false`, `supabase/config.toml:441` e `supabase/config.toml:444`), o que permite que visitantes não autenticados usem a recomendação.

A observabilidade é feita por registros estruturados em JSON no `stdout`: `recommendation_request` com a contagem de respostas (linha 520), `recommendation_success` com total de espécies, eliminadas e retornadas (linhas 550 a 555), e `recommendation_error` com o motivo (`invalid_input`, `db_query_failed` ou `unhandled_exception`).

## Divergência em relação ao documento de referência

O documento `docs/recomendacao-classificacao.md`, datado de 2026-03-22, descreve a mesma lógica com **numeração diferente e seis grupos**, enquanto `questionnaire.ts` declara cinco. Os pesos, fórmulas e limiares conferem integralmente; o que mudou foram os identificadores e o agrupamento. A correspondência é a seguinte:

| Documento (2026-03-22) | Código atual | Observação |
|---|---|---|
| G1 — Espaço e Interferências (`q1_1`…`q1_8d`) | Grupo 2 (`q2_1`…`q2_8d`) | Mesmo conteúdo, prefixo alterado |
| G2 — Condições Ecológicas (`q2_1`…`q2_4`) | Grupo 3 (`q3_1`…`q3_4`) | |
| G3 — Preferências do Usuário (`q3_1`…`q3_4`) | Grupo 4 (`q4_1`…`q4_4`) | |
| G4 — Contexto e Objetivos (`q4_1`, `q4_2`) | Grupo 1 (`q1_1`, `q1_2`) | Moveu-se para o início do questionário |
| G5 — Preferências Botânicas (`q5_1`, `q5_2`) | Grupo 5 (`q5_1`, `q5_2`) | Únicos identificadores que coincidem |
| G6 — Outros Fatores (`q6_1`, `q6_2`) | Absorvido no Grupo 3 como `q3_5` e `q3_6` | O sexto grupo deixou de existir |

O risco dessa divergência é específico e real: identificadores como `q2_1` e `q3_1` existem nos dois esquemas com significados diferentes, de modo que uma leitura cruzada descuidada entre documento e código produz afirmações erradas. Note-se ainda que o comentário que decompõe `MAX_SCORE` na linha 165 do código usa a numeração antiga ("Q4.1", "Q6.1", "Q6.2"), reforçando que o documento é a origem histórica. Outros dois pontos do mesmo arquivo estão desatualizados: a afirmação "Com apenas 4 espécies no banco" (`docs/recomendacao-classificacao.md:296`), quando o catálogo tem hoje 167 linhas, e a referência à planilha `src/assets/Aplicativo - draft - oficial.xlsx`, num diretório que atualmente está vazio.
