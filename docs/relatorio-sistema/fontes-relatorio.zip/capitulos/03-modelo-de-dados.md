# Modelo de Dados

## Visão geral do esquema

O banco é um PostgreSQL 17 com cinco tabelas no esquema `public` — `trees`, `profiles`, `projects`, `points` e `user_favorites` — mais a tabela `auth.users`, mantida pelo GoTrue, que é a âncora de identidade de todas as demais. Não há visões (`views`) declaradas em nenhuma migration. Segurança em nível de linha (RLS) está habilitada nas cinco tabelas públicas, e as permissões amplas concedidas a `anon`, `authenticated` e `service_role` só não expõem os dados porque as políticas de RLS são o verdadeiro portão.

```mermaid
erDiagram
    AUTH_USERS ||--|| PROFILES : "cria via trigger"
    AUTH_USERS ||--o{ PROJECTS : "possui"
    AUTH_USERS ||--o{ USER_FAVORITES : "marca"
    PROJECTS ||--o{ POINTS : "contém"
    TREES |o--o{ POINTS : "é plantada em"
    TREES ||--o{ USER_FAVORITES : "é favoritada em"
    AUTH_USERS {
        uuid id PK
        text email
        jsonb raw_user_meta_data
    }
    PROFILES {
        uuid id PK "FK auth.users ON DELETE CASCADE"
        text nome
        text email
        text role "default user"
        timestamptz created_at
    }
    PROJECTS {
        uuid id PK
        uuid user_id FK
        text nome
        text descricao
        float8 centro_lat
        float8 centro_lng
        int2 centro_zoom
        timestamptz created_at
    }
    POINTS {
        uuid id PK
        uuid project_id FK "ON DELETE CASCADE"
        int tree_id FK "ON DELETE SET NULL"
        float8 lat
        float8 lng
        text observacao
        timestamptz created_at
    }
    TREES {
        int id PK
        text nome_popular
        text nome_cientifico
        text origem
        bool ativa
        numeric outras_46_colunas
    }
    USER_FAVORITES {
        uuid id PK
        uuid user_id FK
        int tree_id FK
        timestamptz created_at
    }
```

## A tabela `trees`

É a tabela central do sistema: **51 colunas**, esquema plano e em `snake_case`, sem aninhamento. A lista integral, com tipos, nulidade e comentários, está no apêndice de esquema. Em termos conceituais, as colunas se agrupam em sete blocos:

1. **Identificação e mídia** — `id` (inteiro, `serial` via `trees_id_seq`), `nome_popular` e `nome_cientifico` (ambos obrigatórios), `foto` (URL, anulável).
2. **Botânica e fenologia** — `origem`, `decidua_perenifolia`, `epoca_floracao`, `epoca_frutificacao`.
3. **Morfologia** — `altura_adulta_max_m`, `porte_altura_classe`, `diametro_copa_adulto_max_m`, `copa_classe`, `dap_adulto_max_cm`, `altura_primeira_bifurcacao_m`, `forma_copa`.
4. **Requisitos de espaço urbano** — `faixa_serv_min_m_recomendada`, `berco_area_min_m2_recomendada`, `volume_solo_min_m3_recomendado`, `compat_fiacao`, `potencial_dano_calcada_1a5`.
5. **Tolerâncias e potenciais em escala 1 a 5** — seca, encharcamento, poluição atmosférica, compactação do solo, ventos fortes, sujeira, atração de fauna, poda, sombra e contribuição à biodiversidade.
6. **Atributos booleanos** — tolerância a sol pleno, meia sombra e sombra; presença de espinhos; presença de substâncias irritantes.
7. **Projeção de crescimento em 10 anos** — 15 colunas acrescentadas posteriormente (DAP, altura, biomassa, carbono, CO₂ equivalente, sobrevivência e a classificação de emissão de BVOC), tratadas no capítulo de estimativas ambientais.

A coluna `ativa` é `NOT NULL DEFAULT true` e funciona como interruptor de visibilidade pública.

### Restrições de integridade

O banco impõe dezenove restrições `CHECK` sobre `trees`. Onze delas garantem que as escalas fiquem no intervalo de 1 a 5 (`atracao_fauna_1a5`, `contribuicao_biodiversidade_1a5`, `potencial_dano_calcada_1a5`, `potencial_sombra_1a5`, `potencial_sujeira_1a5`, `tolerancia_compactacao_solo_1a5`, `tolerancia_encharcamento_1a5`, `tolerancia_poda_1a5`, `tolerancia_poluicao_atmosferica_1a5`, `tolerancia_seca_1a5`, `tolerancia_ventos_fortes_1a5`). Cinco restringem enumerações textuais: `origem` a `Nativa BR` ou `Exótica`; `decidua_perenifolia` a `Perenifólia`, `Decídua` ou `Semidecídua`; `porte_altura_classe` a `Grande`, `Médio` ou `Pequeno`; `copa_classe` a `Grande`, `Média` ou `Pequena`; `compat_fiacao` a `N`, `A` ou `C` — respectivamente incompatível, compatível com cuidados e compatível. As três últimas vieram com a projeção: `sobrevivencia_10a_pct` entre 0 e 100, `classe_bvoc` em `baixo`, `moderado`, `alto`, `desconhecido` ou `indeterminado`, e `confianca_bvoc` em `baixa`, `baixa-média`, `média` ou `média-alta`.

Um efeito colateral prático dessas restrições é que qualquer formulário que envie uma cadeia vazia em vez de `NULL` para um campo enumerado provoca violação de `CHECK` — problema que o formulário administrativo já enfrentou e corrigiu.

## As demais tabelas

`public.profiles` espelha `auth.users` com quatro colunas além da chave: `nome`, `email`, `role` (`NOT NULL DEFAULT 'user'`) e `created_at`. A chave primária `id` é também chave estrangeira para `auth.users(id)` com `ON DELETE CASCADE`, e o comentário da tabela a descreve como "Perfis de usuário com controle de role (user/admin)".

`public.projects` guarda o plano de arborização: `nome`, `descricao` (`NOT NULL DEFAULT ''`), o centro do mapa em `centro_lat`, `centro_lng` e `centro_zoom`, e `user_id` obrigatório apontando para `auth.users` em cascata. Os padrões de latitude e longitude, `-21.1767` e `-47.8208`, correspondem a Ribeirão Preto, São Paulo, e são repetidos literalmente no cliente ao criar um projeto (`src/hooks/useProjects.ts:36-38`).

`public.points` é a tabela de plantios: `project_id` obrigatório com `ON DELETE CASCADE` e `tree_id` anulável com `ON DELETE SET NULL`. Essa assimetria é deliberada e tem consequência visível: excluir um projeto apaga seus pontos, mas excluir uma espécie do catálogo deixa os pontos órfãos com `tree_id` nulo; o gerador de PDF simplesmente ignora pontos cuja espécie não resolve (`src/lib/pdf.ts`).

`public.user_favorites` associa usuário e espécie com restrição `UNIQUE (user_id, tree_id)`, o que torna a operação de favoritar idempotente no banco.

Sete índices B-tree acompanham o esquema: `idx_points_project_id`, `idx_points_tree_id`, `idx_projects_user_id`, `idx_trees_nome_popular`, `idx_trees_origem`, `idx_user_favorites_tree_id` e `idx_user_favorites_user_id`.

## Funções e gatilhos

Quatro funções vivem no esquema `public`, todas com `SECURITY DEFINER`:

| Função | Retorno | Linguagem | Papel |
|---|---|---|---|
| `get_my_role()` | `text` | SQL, `STABLE` | Devolve o `role` do chamador, lendo `profiles` por `auth.uid()`; é o predicado usado nas políticas de administrador |
| `handle_new_user()` | gatilho | PL/pgSQL | Cria a linha em `public.profiles` no cadastro, derivando o nome de `raw_user_meta_data->>'nome'`, depois `'full_name'`, e por fim da parte local do e-mail |
| `prevent_role_self_escalation()` | gatilho | PL/pgSQL | Levanta a exceção "Alteração de role não permitida" quando `OLD.role` difere de `NEW.role` e o chamador não é administrador |
| `email_exists(p_email text)` | `boolean` | SQL, `STABLE`, `search_path = ''` | Verifica existência de e-mail em `auth.users`, com execução revogada de `public`, `anon` e `authenticated` e concedida apenas a `service_role` |

Dois gatilhos os acionam: `on_auth_user_created`, `AFTER INSERT ON auth.users`, que executa `handle_new_user()`; e `enforce_role_protection`, `BEFORE UPDATE ON public.profiles`, que executa `prevent_role_self_escalation()`. O primeiro é o elo que faz o cadastro produzir um perfil; o segundo impede que um usuário comum se promova a administrador escrevendo diretamente na própria linha, que a política "Users can update own profile" permitiria atualizar.

## Segurança em nível de linha

| Tabela | Quem lê | Quem escreve |
|---|---|---|
| `trees` | Qualquer um, mas só linhas com `ativa = true`; administradores veem todas | Apenas administradores (INSERT, UPDATE e DELETE, cada um com política própria verificando `profiles.role = 'admin'`) |
| `profiles` | O próprio usuário (`auth.uid() = id`) e administradores (`get_my_role() = 'admin'`) | O próprio usuário e administradores; o gatilho `enforce_role_protection` bloqueia a mudança de `role` por não administradores |
| `projects` | O dono (`auth.uid() = user_id`) | O dono, com políticas separadas de INSERT, UPDATE e DELETE |
| `points` | O dono do projeto, por subconsulta em `projects`; administradores leem todos | O dono do projeto, pela política `ALL` "Users can manage own project points" |
| `user_favorites` | O dono | O dono (INSERT e DELETE; não há política de UPDATE, o que é coerente com uma tabela de associação) |

A política de leitura de `trees` merece destaque porque é o mecanismo que sustenta o campo `ativa` como interruptor editorial: `((ativa = true) OR (EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')))`.

## Armazenamento de arquivos

Há quatro buckets, todos públicos para leitura: `avatars`, `criterios`, `guias` e `tree-images`. Dez políticas governam `storage.objects`:

| Bucket | Política | Operação | Quem |
|---|---|---|---|
| `tree-images` | `Public read tree images` | SELECT | Qualquer um |
| `tree-images` | `Admin upload tree images` | INSERT | Administradores |
| `tree-images` | `Admin update tree images` | UPDATE | Administradores |
| `tree-images` | `Admin delete tree images` | DELETE | Administradores |
| `avatars` | `public_avatars` | SELECT | Qualquer um |
| `avatars` | `insert_avatars` | INSERT | Papel `authenticated` |
| `avatars` | `update_avatars` | UPDATE | Papel `authenticated` |
| `avatars` | `delete_avatars` | DELETE | Papel `authenticated` |
| `guias` | `Public Read Guias` | SELECT | Qualquer um |
| `guias` | `Temp Public Insert Guias` | INSERT | **Qualquer um, inclusive anônimo** |

A última linha é uma permissividade conhecida: a política autoriza inserção sem autenticação no bucket `guias`, e a própria migration a documenta como reprodução de paridade com a produção, pendente de restrição. O bucket `criterios`, que hospeda os dois PDFs de parametrização, é público mas não tem política de escrita, de modo que só o papel `service_role` (que ignora RLS) consegue gravar nele.

## Histórico de migrations e carga inicial

As cinco migrations em `supabase/migrations/` são aplicadas em ordem de nome:

| Arquivo | Data | Conteúdo |
|---|---|---|
| `20260702000000_baseline_from_prod.sql` | 2026-07-02 | Linha de base extraída da produção: extensões, as cinco tabelas, índices, as três primeiras funções, o gatilho `enforce_role_protection`, RLS e todas as políticas das tabelas públicas |
| `20260702000001_auth_storage_from_prod.sql` | 2026-07-02 | O que o `supabase db dump` não exporta: o gatilho `on_auth_user_created`, os quatro buckets e as dez políticas de `storage.objects` |
| `20260702000002_email_exists_rpc.sql` | 2026-07-02 | A função `email_exists`, com concessão restrita a `service_role`, substituindo a listagem paginada de usuários que falhava além da primeira página |
| `20260802000000_add_projecao_10a_to_trees.sql` | 2026-08-02 | As 15 colunas de projeção, três novas restrições `CHECK`, comentários com as fórmulas e a carga idempotente de **149 linhas** por `trees.id` |
| `20260908000000_apply_lorenzi_v1_validated_structure.sql` | 2026-09-08 | Correção editorial a partir de Lorenzi, *Árvores Brasileiras*, volume 1 (1992): 23 alturas com o respectivo porte e 13 hábitos foliares, cada atualização guardada por comparação com o valor esperado |

A última migration é defensiva de um jeito incomum e digno de nota metodológica: cada correção declara o valor que espera encontrar (`AND tree.altura_adulta_max_m = correction.expected_height_m`) e, ao final, o bloco confere as contagens e levanta "Migration Lorenzi V1 interrompida: esperava atualizar 23 alturas, atualizou %." se divergirem. Isso impede que a migration sobrescreva dados já alterados por outra via; em contrapartida, torna a migration dependente do estado prévio do banco — efeito discutido no capítulo de limitações.

A carga inicial está em `supabase/seed.sql`: um único `INSERT INTO public.trees` com 51 colunas e **167 linhas**, seguido de `setval('trees_id_seq', 198, true)`. O valor 198 acima do número de linhas indica que houve exclusões ao longo da curadoria e que os identificadores não são contíguos. O seed é regenerado pelo script de projeção quando novas colunas são preenchidas, justamente porque o `supabase db reset` executa as migrations antes do seed e, num banco zerado, a carga da migration não encontraria linhas para atualizar.
