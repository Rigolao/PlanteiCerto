# Recomendação de espécies — resultados

Depois de o usuário confirmar o questionário descrito no capítulo anterior, a `RecommendationPage`
(`src/pages/RecommendationPage.tsx`) passa da fase `questions` para `loading`, envia as respostas à
*edge function* `recommend-trees` (`supabase/functions/recommend-trees/index.ts`) pelo hook
`src/hooks/useRecommendation.ts` e, com a resposta em mãos, entra na fase `results`, renderizada por
`src/components/recommendation/ResultScreen.tsx`. A função devolve três coisas: a lista de espécies
sobreviventes já pontuadas e ordenadas (`trees`), quantas foram descartadas pelos filtros
(`eliminated_count`) e um resumo textual dos critérios aplicados (`criteriaSummary`). Este capítulo
documenta essa fase, as três variações de cenário testadas, as versões mobile e escura, e uma falha
silenciosa de tratamento de erro.

> Como no capítulo anterior, o ícone circular com palmeiras no canto inferior direito das capturas é o
> botão do React Query Devtools (ferramenta de desenvolvimento), não um elemento do produto.

---

## Como a pontuação funciona (resumo para leitura das telas)

- A *edge function* carrega todas as espécies ativas (`trees` com `ativa = true`; no ambiente
  documentado, **146 espécies**), aplica as regras **eliminatórias** e só então pontua as sobreviventes.
- A pontuação bruta tem teto de **190 pontos** (`MAX_SCORE`), distribuídos entre os critérios
  classificatórios respondidos; o número exibido no distintivo circular do card é
  `Math.round(bruto / 190 × 100)`, ou seja, uma nota de 0 a 100.
- Como perguntas não respondidas simplesmente não somam pontos (mas o divisor continua 190), um
  questionário incompleto nunca chega a 100.
- A ordenação é **apenas por pontuação decrescente**, sem critério de desempate; empates preservam a
  ordem de leitura do banco (ordenação estável).
- Cores observadas: distintivo de nota **verde** para ≥ 70, amarelo para ≥ 40 e vermelho abaixo disso.
  Nos três cenários documentados **todas** as espécies devolvidas ficaram acima de 70, então só o
  distintivo verde foi efetivamente fotografado. As barras de "Destaques da árvore" usam a mesma lógica
  sobre o percentual do critério: verde ≥ 75 %, amarela ≥ 40 %, vermelha abaixo.

---

## Telas e estados

### Fase de carregamento — "Analisando espécies..."

![Tela quase vazia com um círculo de carregamento e a mensagem Analisando espécies](../shots/21-rec-loading.png)

**Rota:** `/recomendacao` (fase `loading`) — aparece ao clicar em "Ver Recomendações" no diálogo de
confirmação · **Quem acessa:** visitante ou usuário autenticado · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- O cabeçalho do site e o link "Voltar ao catálogo" permanecem; todo o resto da tela é substituído.
- Bloco centralizado horizontalmente, a cerca de um terço da altura: um anel circular de carregamento
  (animação de rotação, congelada na captura), o texto em destaque "**Analisando espécies...**" e, logo
  abaixo, em cinza menor, "Aplicando critérios do local".
- Não há barra de progresso, porcentagem, botão de cancelar nem tempo estimado.

**Ações possíveis / o que acontece:**
- Nenhuma ação é oferecida; a fase termina sozinha. Em sucesso vai para `results`; em erro volta
  silenciosamente para `questions` (ver "Falha silenciosa" no fim do capítulo).
- **Duração real observada:** a chamada à *edge function* no ambiente local respondeu em torno de
  10–50 ms, de modo que esta tela é praticamente um piscar. A captura foi obtida esperando o seletor de
  texto "Analisando" **antes** de acionar o botão; nenhum atraso artificial foi necessário.

**Estados relacionados:** `20-rec-dialogo-finalizar`, `21-rec-topo`.

---

### ResultScreen — topo (cenário padrão)

![Cabeçalho dos resultados com título, contagens, três botões e os três primeiros cards](../shots/21-rec-topo.png)

**Rota:** `/recomendacao` (fase `results`) · **Quem acessa:** visitante ou usuário autenticado ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- Link "Voltar ao catálogo" no topo (o mesmo das outras fases).
- Título grande "**Árvores Recomendadas**".
- Linha de contagem, com destaques coloridos: "**22** espécies compatíveis de 146 analisadas ·
  **124 eliminadas pelos filtros do local**". O "22" aparece em verde e a parte final, em vermelho.
  O total "146" é calculado no cliente como `trees.length + eliminated_count`.
- Três botões alinhados à direita, na mesma altura do título: "**Editar Respostas**" (verde, preenchido),
  "**Limpar e Refazer**" (cinza) e "**Voltar ao Catálogo**" (branco com borda).
- Abaixo, o cartão recolhido "COMO AS ESPÉCIES FORAM AVALIADAS" com um distintivo cinza "14" e uma seta
  para baixo à direita.
- Em seguida começa a grade de resultados, 3 colunas no desktop. Os três primeiros cards visíveis são
  "Uvaia" (93 pts), "Sabão-de-soldado" (92 pts) e "Guaçatonga" (91 pts).
- **Não há** botão de exportar PDF, ordenar, filtrar ou salvar a recomendação em um projeto.

**Ações possíveis / o que acontece:**
- "Editar Respostas" → volta à fase `questions` mantendo todas as respostas (ver `21-rec-editar-volta`).
- "Limpar e Refazer" → zera tudo e volta ao passo 1 em branco (ver `21-rec-limpar-refazer`).
- "Voltar ao Catálogo" → navega para `/`.
- Clicar no cabeçalho do cartão de critérios → expande/recolhe (ver as duas capturas seguintes).
- Clicar em qualquer card → abre o `TreeDetailModal` da espécie (ver `21-rec-detalhe-modal`).
- Clicar no coração no canto superior esquerdo da foto de um card → adiciona/remove dos favoritos
  (usuário logado) ou exibe o aviso "Faça login para favoritar árvores." (visitante).

**Estados relacionados:** `21-rec-fiacao-topo`, `21-rec-topo-mobile`, `21-rec-topo-dark`,
`21-rec-zero-resultados`.

---

### Cartão de critérios recolhido

![Faixa branca fina com o texto Como as espécies foram avaliadas e o número 14](../shots/21-rec-criterios-recolhido.png)

**Rota:** `/recomendacao` (fase `results`, recorte do cartão) · **Quem acessa:** visitante ou usuário
autenticado · **Viewport/tema:** desktop claro, recorte

**Elementos visíveis:**
- Cartão branco de largura total e cantos arredondados, com o rótulo "COMO AS ESPÉCIES FORAM AVALIADAS"
  em caixa alta e cinza-escuro, seguido de um distintivo arredondado cinza com o número "**14**" — soma
  de `criteriaSummary.eliminatory.length + criteriaSummary.classificatory.length`.
- Seta em forma de "v" na extremidade direita (gira 180° quando expandido).
- Estado inicial é **sempre recolhido** (`isCriteriaOpen` começa em `false`); o estado não é memorizado
  entre consultas.

**Ações possíveis / o que acontece:**
- Clicar em qualquer ponto da faixa → expande com animação de altura (~300 ms).

**Estados relacionados:** `21-rec-criterios-expandido`.

---

### Cartão de critérios expandido

![Cartão aberto com uma faixa de chips vermelhos e outra de chips verdes](../shots/21-rec-criterios-expandido.png)

**Rota:** `/recomendacao` (fase `results`, recorte do cartão) · **Quem acessa:** visitante ou usuário
autenticado · **Viewport/tema:** desktop claro, recorte

**Elementos visíveis:**
- Cabeçalho igual ao do estado recolhido, com a seta apontando para cima.
- Primeira seção, com o subtítulo vermelho "**Filtros eliminatórios (condições do local)**" e 5 chips
  vermelhos (fundo rosa-claro, borda e texto vermelhos):
  "Faixa de serviço: 1–2m" · "Faixa acessível de 1,20m obrigatória" · "Berço disponível: 1–2m²" ·
  "Insolação: sol pleno (tolerância obrigatória)" · "Espinhos/irritantes: elimina espécies com presença".
- Segunda seção, com o subtítulo verde "**Critérios de pontuação (preferências e ecologia)**" e 9 chips
  verdes: "Insolação: Sol pleno (> 6h)" · "Umidade: Solo úmido" · "Espinhos/irritantes são problema" ·
  "Sem poda profissional" · "Local: Calçada" · "Objetivo(s): Sombra, Espécies nativas" ·
  "Preferência por nativas" · "Preferência por espécies atrativas à fauna" ·
  "Necessidade de sombra (ilha de calor)".
- 5 + 9 = 14, conferindo com o distintivo.

**Ações possíveis / o que acontece:**
- Clicar no cabeçalho de novo → recolhe.
- Os chips são **apenas informativos**: não são clicáveis nem removíveis (diferentemente dos chips de
  filtro do catálogo).

**Observação sobre o conteúdo:** a lista é montada por `buildCriteriaSummary(answers)` **a partir das
respostas**, não das espécies. Respostas "neutras" não geram chip: por isso não aparecem entradas para
"esquina", "poste", "boca-de-lobo" ou "recuo" — todas foram respondidas com o valor seguro. Note também
que apenas 14 dos 24 passos geraram texto: as demais perguntas ou não produzem rótulo (ex.: `q2_1`
isolada) ou foram respondidas com o valor que não aciona regra.

**Estados relacionados:** `21-rec-criterios-recolhido`, `21-rec-zero-chips`, `21-rec-topo-dark`.

---

### Grade completa de resultados

![Primeira parte da grade, com doze cards em quatro linhas de três](../shots/21-rec-grade-p1.png)

![Segunda parte da grade, da quarta à oitava linha de cards](../shots/21-rec-grade-p2.png)

![Terceira parte: rodapé do último card e área vazia](../shots/21-rec-grade-p3.png)

**Rota:** `/recomendacao` (fase `results`, página inteira) · **Quem acessa:** visitante ou usuário
autenticado · **Viewport/tema:** desktop claro. A página tem **5250 px de altura**, por isso foi
fatiada em três imagens (`-p1`, `-p2`, `-p3`).

**Elementos visíveis:**
- Grade de **22 cards** em 3 colunas (8 linhas: sete completas e uma com um único card).
- Ordem e notas, de cima para baixo e da esquerda para a direita: Uvaia 93 · Sabão-de-soldado 92 ·
  Guaçatonga 91 · Ipê-amarelo (*Tabebuia ochracea*) 90 · Pau-rei 90 · Cambuci 90 · Ingá do brejo 90 ·
  Ipê-amarelo (*Tabebuia aurea*) 90 · Ipê-roxo-anão 90 · Pau-pereira 89 · Pau-ripa 89 ·
  Algodão-do-brejo 89 · Ipê-amarelo (*Tabebuia chrysotricha*) 89 · Aleluia, pau-fava 88 · Cambuí 88 ·
  Folha-de-castanha 86 · Resedá extremosa 81 · Calistemon (*Callistemon viminalis*) 79 ·
  Calistemon (*Callistemon imperialis*) 79 · Falsa murta 79 · Calicarpa 78 · Quereltéria 76.
- **Todos os 16 primeiros colocados são nativos** ("Nativa BR"); as exóticas só aparecem a partir da
  17.ª posição (Resedá extremosa, 81 pts). É o efeito direto de `q5_1 = "Sim, priorizar nativas"`
  (10 pontos exclusivos) somado ao objetivo "Valorizar espécies nativas da região" de `q1_2`.
- Na segunda fatia, o card "Ipê-amarelo" (*Tabebuia chrysotricha*, 89 pts) aparece com o **coração
  preenchido em vermelho**: é uma das espécies favoritadas pela conta de demonstração, provando que o
  estado de favoritos é compartilhado entre o catálogo e a tela de recomendação.
- A terceira fatia contém apenas o rodapé do último card e espaço em branco — a tela **não tem paginação,
  rolagem infinita, rodapé nem botão de exportação**.

**Ações possíveis / o que acontece:**
- Rolar a página para percorrer os 22 resultados.
- Clicar num card → abre o modal de detalhe da espécie.
- Clicar num coração → alterna o favorito.

**Estados relacionados:** `21-rec-topo`, `21-rec-card-zoom`, `21-rec-detalhe-modal`.

---

### Card de resultado em detalhe

![Card ampliado da Uvaia com foto, nota 93, pills e três barras de critérios](../shots/21-rec-card-zoom.png)

**Rota:** `/recomendacao` (fase `results`, recorte do primeiro card) · **Quem acessa:** visitante ou
usuário autenticado · **Viewport/tema:** desktop claro, recorte do elemento

**Elementos visíveis (de cima para baixo):**
- **Foto** da espécie ocupando o topo do card, proporção 4:3, recortada para preencher. Espécies sem foto
  recebem um ícone vetorial de árvore sobre fundo verde-claro.
- **Coração** no canto superior esquerdo, sobre um círculo escuro translúcido — vazio (não favoritada).
  O atributo `title` alterna entre "Adicionar aos favoritos" e "Remover dos favoritos".
- **Distintivo de nota** no canto superior direito: círculo verde com "**93**" em cima e "**pts**"
  embaixo, em letra menor.
- **Nome popular** "Uvaia" em verde-escuro e negrito; **nome científico** "*Eugenia pyriformis Cambess.*"
  em itálico cinza logo abaixo.
- Três **pills** cinza-esverdeadas em linha: "Porte Médio", "Nativa BR" e "13m" (altura adulta máxima).
- Bloco separado por uma linha fina, com o rótulo "**DESTAQUES DA ÁRVORE**" em caixa alta e três barras
  de critério, cada uma com o rótulo à esquerda, os pontos à direita no formato `x/y` e uma barra de
  progresso colorida abaixo:
  - "Insolação (sol pleno)" — **20/20** (barra verde cheia)
  - "Qualidade do solo" — **20/20** (barra verde cheia)
  - "Objetivo(s) de plantio" — **18/20** (barra verde quase cheia)
- Rodapé do bloco: "**+11 outros critérios pontuados**".

**Como a lista de destaques é escolhida:** `ResultScreen.tsx` filtra os critérios com `points > 0`,
ordena por pontos decrescentes (desempate por `maxPoints`) e mostra os **três primeiros**; o contador
final é `total_pontuados − 3`.

**Detalhamento completo da Uvaia neste cenário** (os 14 critérios que o card resume em três):

| Critério (`label`) | Pontos | Máximo |
|---|---|---|
| Insolação (sol pleno) | 20 | 20 |
| Umidade do solo | 15 | 20 |
| Qualidade do solo | 20 | 20 |
| Irrigação disponível | 10 | 10 |
| Queda de folhas/frutos | 15 | 15 |
| Sem espinhos/irritantes | 15 | 15 |
| Atração de fauna | 10 | 10 |
| Tolerância a poda mínima | 8 | 10 |
| Adequação à calçada | 8 | 10 |
| Objetivo(s) de plantio | 18 | 20 |
| Espécie nativa | 10 | 10 |
| Atração de fauna (preferência) | 10 | 10 |
| Exposição ao vento | 10 | 10 |
| Potencial de sombra (ilha de calor) | 8 | 10 |
| **Soma bruta** | **177** | (teto fixo 190) |

`round(177 / 190 × 100) = 93` — exatamente o número impresso no distintivo. A coluna "Máximo" soma
precisamente **190**, o teto `MAX_SCORE` da função: como o questionário foi respondido por inteiro, todos
os critérios classificatórios previstos geraram entrada no detalhamento. Se alguma pergunta ficasse sem
resposta, a entrada correspondente desapareceria da tabela mas o divisor continuaria 190, derrubando a
nota final.

**Por que as primeiras colocadas pontuaram tanto:** as respostas do cenário premiam justamente o perfil
das espécies do topo. "Sol pleno" vale 20 pontos cheios para quem tem `tolerancia_sol_pleno` verdadeiro;
"Bom (solo natural, permeável)" vale 20 fixos para todo mundo; "Sim, priorizar nativas" dá 10 pontos só
às `Nativa BR`; e o par de objetivos "Sombra" + "Valorizar espécies nativas" reparte 20 pontos, dos quais
a metade vai integralmente para qualquer nativa e a outra metade é proporcional ao
`potencial_sombra_1a5`. As diferenças entre o 1.º e o 9.º lugar (93 → 90) vêm quase só de
`potencial_sombra_1a5`, `potencial_dano_calcada_1a5` e `tolerancia_poda_1a5`, que aparecem nas linhas
"Objetivo(s) de plantio", "Adequação à calçada" e "Tolerância a poda mínima". Todas as fórmulas estão em
`calculateScore()` em `supabase/functions/recommend-trees/index.ts`.

**Estados relacionados:** `21-rec-grade-p1`, `21-rec-detalhe-modal`.

---

### Modal de detalhe aberto a partir de um resultado

![Modal escurecendo a grade, com foto grande da Uvaia e seções de morfologia e tolerâncias](../shots/21-rec-detalhe-modal.png)

**Rota:** `/recomendacao` (fase `results`, sobreposição modal) · **Quem acessa:** visitante ou usuário
autenticado · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Fundo escurecido e desfocado; a grade de resultados continua parcialmente visível atrás.
- Cartão modal centralizado (o mesmo componente `TreeDetailModal` usado no catálogo):
  - Foto da espécie no topo, em faixa larga, com o botão de favorito (coração) e o botão de fechar "×"
    sobrepostos no canto superior direito.
  - "Uvaia" em verde-escuro e "*Eugenia pyriformis Cambess.*" em itálico.
  - Seção "**MORFOLOGIA**" com seis campos em caixas: "Altura adulta 13m", "Copa 7m (Média)",
    "Porte Médio", "Forma da Copa Arredondada", "DAP (Diâmetro) 50cm", "1ª Bifurcação 1,8–2,2".
  - Seção "**TOLERÂNCIAS ECOLÓGICAS**" com três linhas booleanas — "Sol Pleno: Sim", "Meia Sombra: Sim",
    "Sombra: Sim" — e onze linhas com escala de 1 a 5 representada por cinco quadradinhos preenchidos em
    verde: Seca, Encharcamento, Poluição Atmosférica, Compactação do Solo, Ventos Fortes, Potencial
    Sujeira, Potencial Dano Calçada, Atração de Fauna, Potencial Sombra, Contribuição Biodiversidade e
    Tolerância à Poda.
  - O modal rola internamente; abaixo do recorte visível continuam as seções de fenologia, urbanismo e
    projeção em 10 anos (documentadas no capítulo do catálogo).
- **O modal não mostra a nota nem o detalhamento da recomendação** — é o mesmo componente do catálogo,
  sem qualquer informação específica da consulta.

**Ações possíveis / o que acontece:**
- "×" ou tecla `Esc` → fecha o modal e volta à grade (verificado).
- Coração → alterna favorito; sem login exibe "Faça login para favoritar árvores.".

**Estados relacionados:** `21-rec-card-zoom`, `21-rec-grade-p1`.

---

### "Editar Respostas" — para onde volta

![Questionário reaberto na pergunta 24 de 24, a última, com a resposta marcada](../shots/21-rec-editar-volta.png)

**Rota:** `/recomendacao` (volta à fase `questions`) · **Quem acessa:** visitante ou usuário autenticado
· **Viewport/tema:** desktop claro

**Elementos visíveis:**
- "Pergunta **24 de 24**" · "100%" — ou seja, o botão devolve o usuário **ao passo em que ele estava
  quando confirmou**, que é sempre o último, e **não** ao passo 1.
- Todas as bolinhas visíveis (12 a 24) estão verdes; a 24 é a ativa.
- O cartão exibe "Há preferência por espécies que atraiam fauna (aves, polinizadores)?" com
  "Sim, priorizar" ainda marcada.
- Botões "Voltar" e "Ver Resultados".

**Ações possíveis / o que acontece:**
- Usar o stepper ou "Voltar" para chegar à pergunta que se quer alterar.
- "Ver Resultados" → reabre o diálogo "Finalizar questionário?" e refaz a consulta com as respostas
  atualizadas.

**Observação de usabilidade:** `handleEdit()` altera apenas a fase, sem mexer em `currentIndex`. Como o
enunciado da última pergunta é o primeiro que o usuário vê ao voltar, pode não ficar evidente que todas
as respostas continuam disponíveis para revisão.

**Estados relacionados:** `21-rec-editar-passo1`, `21-rec-topo`.

---

### Respostas preservadas no passo 1

![Passo 1 do questionário com todas as bolinhas verdes e a opção Calçada ainda marcada](../shots/21-rec-editar-passo1.png)

**Rota:** `/recomendacao` (fase `questions`, após clicar na bolinha 1 do stepper) · **Quem acessa:**
visitante ou usuário autenticado · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- "Pergunta 1 de 24" · "4%".
- **Todas as 13 bolinhas visíveis estão verdes** (todas as perguntas já foram respondidas); a 1 é a ativa,
  com anel.
- A opção "Calçada em frente a lote/residência" continua marcada em verde-claro.
- O botão "Voltar" não aparece (estamos no primeiro passo) e "Próximo" está habilitado.

**Ações possíveis / o que acontece:**
- Trocar a resposta aqui e reenviar produz uma nova consulta; os resultados anteriores são substituídos.

**Estados relacionados:** `21-rec-editar-volta`, `20-rec-passo1-respondido`.

---

### Resultados do cenário com fiação convencional

![Topo dos resultados mostrando 19 espécies compatíveis e 127 eliminadas](../shots/21-rec-fiacao-topo.png)

**Rota:** `/recomendacao` (fase `results`) · **Quem acessa:** visitante ou usuário autenticado ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- Mesmo layout de `21-rec-topo`, com a linha de contagem alterada: "**19** espécies compatíveis de 146
  analisadas · **127 eliminadas pelos filtros do local**".
- O distintivo do cartão de critérios agora marca "**16**" (dois chips a mais: "Fiação convencional" e
  "Fiação a < 4m").
- Os três primeiros cards são os mesmos do cenário padrão: Uvaia 93, Sabão-de-soldado 92,
  Guaçatonga 91 — as notas **não mudam**, porque a fiação só participa das regras eliminatórias.

**Ações possíveis / o que acontece:** idênticas às de `21-rec-topo`.

**Diferença efetiva entre os dois cenários:** exatamente **3 espécies** desapareceram ao informar fiação
convencional a menos de 4 m, todas de porte "Grande" e com `compat_fiacao = 'N'`:

| Espécie | Nome científico | id | Nota no cenário padrão | Porte | `compat_fiacao` |
|---|---|---|---|---|---|
| Pau-rei | *Pterygota brasiliensis* | 188 | 90 | Grande | N |
| Pau-pereira | *Platycyamus regnellii* | 187 | 89 | Grande | N |
| Pau-ripa | *Luetzelburgia auriculata* | 189 | 89 | Grande | N |

**Estados relacionados:** `20-rec-q2-6-condicional`, `21-rec-topo`.

---

### Nenhuma espécie compatível encontrada

![Tela com chips vermelhos no topo, ícone de pinheiro e mensagem de nenhuma espécie](../shots/21-rec-zero-resultados.png)

**Rota:** `/recomendacao` (fase `results` com `trees = []`) · **Quem acessa:** visitante ou usuário
autenticado · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Link "Voltar ao catálogo" no topo.
- Cartão branco de largura total com o título em negrito "**Filtros eliminatórios aplicados**" e seis
  chips vermelhos: "Faixa de serviço: 1–2m" · "Faixa acessível de 1,20m obrigatória" ·
  "Berço disponível: 1–2m²" · "**Guia rebaixada a < 1,5m**" · "Insolação: sol pleno (tolerância
  obrigatória)" · "Espinhos/irritantes: elimina espécies com presença".
- Bloco central, muito espaçado: ícone linear de pinheiro em cinza, título
  "**Nenhuma espécie compatível encontrada**" e o texto "As condições do local são muito restritivas.
  Tente ajustar os critérios eliminatórios."
- Três botões em linha, centralizados: "**Editar Respostas**" (verde), "**Limpar e Refazer**" (cinza) e
  "**Voltar ao Catálogo**" (branco com borda).
- **O cartão recolhível "Como as espécies foram avaliadas" não existe neste estado** (verificado: zero
  ocorrências na página). No lugar dele entra o cartão fixo de filtros eliminatórios, e os critérios
  **classificatórios não são mostrados** — o que faz sentido, já que nenhuma espécie chegou a ser
  pontuada.
- Também não há sugestão automática de qual critério relaxar, nem link para a pergunta responsável.

**Ações possíveis / o que acontece:**
- "Editar Respostas" → volta ao questionário no último passo, com tudo preservado.
- "Limpar e Refazer" → zera tudo (ver `21-rec-limpar-refazer`).
- "Voltar ao Catálogo" → navega para `/`.

**Estados relacionados:** `21-rec-zero-chips`, `21-rec-limpar-refazer`, `20-rec-q2-8c-guia`.

---

### Chips eliminatórios no estado vazio (recorte)

![Recorte do cartão de filtros eliminatórios com seis chips vermelhos](../shots/21-rec-zero-chips.png)

**Rota:** `/recomendacao` (fase `results` vazia, recorte do cartão) · **Quem acessa:** visitante ou
usuário autenticado · **Viewport/tema:** desktop claro, recorte

**Elementos visíveis:**
- Título "Filtros eliminatórios aplicados" e os seis chips arredondados vermelhos listados acima, em
  uma única linha.
- O chip "**Guia rebaixada a < 1,5m**" é o responsável por zerar a lista: a regra correspondente na
  *edge function* descarta **todas** as espécies sem sequer olhar seus atributos, por incompatibilidade
  com a faixa de acessibilidade (NBR 9050).

**Ações possíveis / o que acontece:** os chips são estáticos, não removíveis.

**Estados relacionados:** `21-rec-zero-resultados`, `21-rec-criterios-expandido`.

---

### Após "Limpar e Refazer"

![Questionário totalmente zerado no passo 1 com o botão Próximo desabilitado](../shots/21-rec-limpar-refazer.png)

**Rota:** `/recomendacao` (fase `questions`, estado inicial) · **Quem acessa:** visitante ou usuário
autenticado · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- "Pergunta 1 de **24**" · "4%" — note que o total voltou para 24: como `q2_5` foi apagada, a pergunta
  condicional `q2_6` saiu da lista.
- Stepper: apenas a bolinha 1 verde/ativa; **todas as demais esmaecidas** (bloqueadas), exatamente como
  na primeira visita.
- Cartão "Qual o tipo de local de plantio?" com as quatro opções **sem nenhuma marcação** (verificado:
  zero opções selecionadas).
- "Próximo" **desabilitado**; não há botão "Voltar".
- Não há confirmação antes de limpar, nem aviso de que os resultados serão descartados.

**Ações possíveis / o que acontece:**
- Responder de novo a partir do zero.

**Estados relacionados:** `20-rec-passo1-vazio` (tela idêntica na primeira visita),
`21-rec-zero-resultados`.

---

### Questionário em tela estreita (mobile)

![Questionário em celular com pills empilhadas e botões grandes](../shots/21-rec-questionario-mobile.png)

**Rota:** `/recomendacao` · **Quem acessa:** visitante ou usuário autenticado ·
**Viewport/tema:** mobile 390×844, tema claro

**Elementos visíveis e diferenças em relação ao desktop:**
- Cabeçalho reduzido: só o logotipo "PlanteiCerto" e um botão de menu sanduíche (três linhas);
  os selos institucionais, os links e o chip da conta somem para dentro do menu.
- "Pergunta 13 de 24" e "54%" em fonte proporcionalmente maior.
- O stepper mostra apenas ~7 bolinhas por vez (10 a 16), com a ativa centralizada; continua rolável.
- No cartão, o badge de grupo ("CONDIÇÕES ECOLÓGICAS E AMBIENTAIS") ocupa uma linha inteira e as pills
  "ELIMINATÓRIO"/"CLASSIFICATÓRIO" **descem para a linha seguinte**, à esquerda (no desktop ficam à
  direita, na mesma linha do badge).
- O enunciado quebra em duas linhas; as opções ocupam a largura total com bastante altura de toque.
- "Voltar" e "Próximo" continuam lado a lado, mas ocupam metade da largura cada.

**Ações possíveis / o que acontece:** idênticas às do desktop.

**Estados relacionados:** `20-rec-q3-1-insolacao` (mesma pergunta no desktop), `21-rec-topo-mobile`.

---

### Resultados em tela estreita (mobile)

![Resultados em celular com botões empilhados e um card por linha](../shots/21-rec-topo-mobile.png)

**Rota:** `/recomendacao` (fase `results`) · **Quem acessa:** visitante ou usuário autenticado ·
**Viewport/tema:** mobile 390×844, tema claro

**Elementos visíveis e diferenças em relação ao desktop:**
- Título "Árvores Recomendadas" em duas linhas de fonte grande.
- A contagem **quebra em duas linhas e o separador "·" desaparece**: "22 espécies compatíveis de 146
  analisadas" numa linha e "124 eliminadas pelos filtros do local" (em vermelho) na seguinte — o ponto
  separador tem a classe `hidden sm:inline`.
- Os três botões de ação passam a ocupar **a largura inteira, empilhados** na ordem "Editar Respostas"
  (verde), "Limpar e Refazer" (cinza), "Voltar ao Catálogo" (com borda).
- O cartão "COMO AS ESPÉCIES FORAM AVALIADAS" quebra o título em duas linhas, mantendo o distintivo "14"
  e a seta à direita.
- A grade passa a **uma coluna**: cada card ocupa a largura da tela, com a foto bem maior e o distintivo
  de nota proporcionalmente maior ("93 pts").

**Ações possíveis / o que acontece:** idênticas às do desktop.

**Estados relacionados:** `21-rec-topo`, `21-rec-questionario-mobile`.

---

### Questionário em tema escuro

![Mesma pergunta de insolação em fundo escuro](../shots/21-rec-questionario-dark.png)

**Rota:** `/recomendacao` · **Quem acessa:** visitante ou usuário autenticado ·
**Viewport/tema:** desktop 1440×900, **tema escuro**

**Elementos visíveis:**
- Fundo quase preto, cartão cinza-escuro, textos claros; o botão de tema no cabeçalho troca a lua por
  um sol.
- Bolinhas respondidas em verde médio sobre fundo escuro; as bloqueadas quase somem (cinza sobre preto).
- Pills "ELIMINATÓRIO" (vermelha) e "CLASSIFICATÓRIO" (verde) mantêm as cores, com fundos translúcidos
  mais escuros.
- **Detalhe notável:** a opção selecionada ("Sol pleno (mais de 6h de sol direto)") continua com **fundo
  claro e texto escuro**, destoando do restante da interface escura. Isso acontece porque
  `QuestionCard.tsx` aplica cores fixas ao estado selecionado (`bg-[#e8ede9]`, `text-[#1c2e1e]`,
  `border-[#a8c5a9]`) em vez de usar as variáveis de tema. As opções não selecionadas seguem o tema
  corretamente.

**Ações possíveis / o que acontece:** idênticas às do tema claro.

**Estados relacionados:** `20-rec-q3-1-insolacao` (mesma pergunta no tema claro).

---

### Resultados em tema escuro (critérios expandidos)

![Resultados em fundo escuro com o cartão de critérios aberto](../shots/21-rec-topo-dark.png)

**Rota:** `/recomendacao` (fase `results`) · **Quem acessa:** visitante ou usuário autenticado ·
**Viewport/tema:** desktop 1440×900, **tema escuro**

**Elementos visíveis:**
- "Árvores Recomendadas" em branco; a contagem "22 espécies compatíveis de 146 analisadas · 124
  eliminadas pelos filtros do local" com o "22" em verde-claro e a parte final em vermelho escurecido
  (contraste visivelmente mais fraco que no tema claro).
- Os três botões de ação mantêm a hierarquia (verde preenchido / cinza / contornado).
- O cartão de critérios aparece **expandido** nesta captura: subtítulo vermelho "Filtros eliminatórios
  (condições do local)" com os 5 chips e subtítulo verde "Critérios de pontuação (preferências e
  ecologia)" com os 9 chips, todos com fundo translúcido escuro.
- Os cards mantêm as fotos em cores normais; o distintivo verde de nota continua bem legível.

**Ações possíveis / o que acontece:** idênticas às do tema claro.

**Estados relacionados:** `21-rec-topo`, `21-rec-criterios-expandido`.

---

## Tabelas de respostas dos três cenários

Todos os cenários foram executados na mesma base local: **146 espécies ativas** (de 167 cadastradas; 21
estão inativas e invisíveis para não-administradores). Reproduzindo exatamente as respostas abaixo,
obtêm-se os mesmos números.

### Cenário A — "Padrão" (calçada residencial, sem fiação) — 24 passos

| # | id | Valor enviado | Rótulo escolhido na tela |
|---|---|---|---|
| 1 | `q1_1` | `calcada` | Calçada em frente a lote/residência |
| 2 | `q1_2` | `sombra,nativas` | Sombra e conforto térmico + Valorizar espécies nativas da região |
| 3 | `q2_1` | `2_3` | 2 a 3 m |
| 4 | `q2_2` | `1_2` | 1 a 2 m |
| 5 | `q2_3` | `sim` | Sim |
| 6 | `q2_4` | `1_2` | 1 a 2 m² |
| 7 | `q2_5` | `nao` | Não há fiação |
| — | `q2_6` | (não exibida) | — |
| 8 | `q2_7` | `gt_2` | 2 m ou mais |
| 9 | `q2_8a` | `gt_6` | 6 m ou mais |
| 10 | `q2_8b` | `gt_4` | 4 m ou mais |
| 11 | `q2_8c` | `gt_1_5` | 1,5 m ou mais |
| 12 | `q2_8d` | `gt_1_5` | 1,5 m ou mais |
| 13 | `q3_1` | `sol_pleno` | Sol pleno (mais de 6h de sol direto) |
| 14 | `q3_2` | `umido` | Úmido (moderado) |
| 15 | `q3_3` | `bom` | Bom (solo natural, permeável) |
| 16 | `q3_4` | `sim` | Sim |
| 17 | `q3_5` | `nao` | Não, local abrigado |
| 18 | `q3_6` | `sim` | Sim, priorizar espécies com alto potencial de sombra |
| 19 | `q4_1` | `nao` | Não, sem restrição |
| 20 | `q4_2` | `sim` | Sim, quero evitar |
| 21 | `q4_3` | `nao` | Não, sem restrição |
| 22 | `q4_4` | `nao` | Não, manutenção mínima |
| 23 | `q5_1` | `sim` | Sim, priorizar nativas |
| 24 | `q5_2` | `sim` | Sim, priorizar |

**Resultado:** **22 espécies compatíveis · 124 eliminadas · 146 analisadas.**
Cinco primeiras: Uvaia (*Eugenia pyriformis* Cambess.) **93**; Sabão-de-soldado (*Sapindus saponaria*)
**92**; Guaçatonga (*Casearia sylvestris* Sw.) **91**; Ipê-amarelo (*Tabebuia ochracea*) **90**;
Pau-rei (*Pterygota brasiliensis*) **90**. Lista completa das 22 na descrição de `21-rec-grade-p1`/`-p2`.
Capturas: `21-rec-loading`, `21-rec-topo`, `21-rec-criterios-recolhido`, `21-rec-criterios-expandido`,
`21-rec-grade-p1`…`-p3`, `21-rec-card-zoom`, `21-rec-detalhe-modal`, `21-rec-editar-volta`,
`21-rec-editar-passo1`, `21-rec-questionario-mobile`, `21-rec-topo-mobile`, `21-rec-questionario-dark`,
`21-rec-topo-dark`.

### Cenário B — "Fiação" (igual ao A, mas com fiação convencional a menos de 4 m) — 25 passos

Idêntico ao cenário A, com duas mudanças:

| # | id | Valor enviado | Rótulo escolhido na tela |
|---|---|---|---|
| 7 | `q2_5` | `sim_convencional` | Sim, convencional |
| 8 | `q2_6` | `lt_4` | Menos de 4 m |

**Resultado:** **19 espécies compatíveis · 127 eliminadas · 146 analisadas.**
Cinco primeiras: Uvaia **93**; Sabão-de-soldado **92**; Guaçatonga **91**; Ipê-amarelo
(*Tabebuia ochracea*) **90**; Cambuci (*Campomanesia phaea*) **90**. As três espécies perdidas em
relação ao cenário A estão na tabela da seção "Resultados do cenário com fiação convencional".
Capturas: todo o capítulo 20 mais `21-rec-fiacao-topo`.

### Cenário C — "Zero" (igual ao A, mas com guia rebaixada a menos de 1,5 m) — 24 passos

Idêntico ao cenário A, com uma mudança:

| # | id | Valor enviado | Rótulo escolhido na tela |
|---|---|---|---|
| 11 | `q2_8c` | `lt_1_5` | Menos de 1,5 m |

**Resultado:** **0 espécies compatíveis · 146 eliminadas · 146 analisadas.**
A regra de `q2_8c = 'lt_1_5'` descarta todas as espécies incondicionalmente, então não há nenhuma
pontuação a relatar. Capturas: `21-rec-zero-resultados`, `21-rec-zero-chips`, `21-rec-limpar-refazer`.

---

## Falha silenciosa da consulta (lacuna conhecida)

Em `RecommendationPage.tsx`, a confirmação do questionário é tratada assim:

```ts
const data = await recommendation.mutateAsync(answers);
...
} catch {
  setPhase('questions');
}
```

O bloco `catch` é **vazio**: em caso de erro, a aplicação simplesmente volta da tela de carregamento para
o questionário, no mesmo passo em que estava, **sem toast, sem mensagem de erro e sem registro visível
para o usuário**. Do ponto de vista de quem usa, o clique em "Ver Recomendações" apenas "não faz nada".
Os erros possíveis incluem: Supabase não configurado (o hook lança `'Supabase não está configurado'`),
origem bloqueada pelo CORS da *edge function*, falha de rede, e as respostas de erro da própria função
(`400 Campo "answers" é obrigatório`, `500 Erro ao buscar espécies`, `500 Erro interno`). Como a camada
de mutação do React Query está configurada com `retry: 1` (`src/main.tsx`), uma falha transitória é
tentada duas vezes antes de cair no `catch`, o que apenas prolonga a tela de carregamento.

Este comportamento **não foi reproduzido** nas capturas (o ambiente respondeu corretamente em todas as
execuções); está documentado a partir da leitura do código e é uma lacuna de tratamento de erro digna de
menção na dissertação.

---

## Fluxo passo a passo — Recomendação completa

1. Abrir `/recomendacao` (link direto, CTA da página inicial ou menu). A página entra na fase de
   perguntas com "Pergunta 1 de 24" e "Próximo" desabilitado (ver `20-rec-passo1-vazio`).
2. Responder as 24 perguntas visíveis do cenário A na ordem, usando "Próximo" a cada passo; escolher duas
   opções em `q1_2` (ver `20-rec-q1-2-multiselect`). Se `q2_5` for respondida com fiação, o total muda
   para 25 e `q2_6` é inserida (ver `20-rec-q2-5-antes` → `20-rec-q2-5-fiacao` → `20-rec-q2-6-condicional`).
3. No último passo, o botão passa a "Ver Resultados" e o progresso chega a 100 % (ver
   `20-rec-ultimo-passo`). Clicar nele.
4. Confirmar no diálogo "Finalizar questionário?" clicando em "Ver Recomendações"
   (ver `20-rec-dialogo-finalizar`). "Revisar respostas" cancela sem enviar
   (ver `20-rec-revisar-respostas`).
5. A tela de carregamento "Analisando espécies... / Aplicando critérios do local" aparece por frações de
   segundo (ver `21-rec-loading`) enquanto a *edge function* filtra e pontua as 146 espécies ativas.
6. A tela de resultados abre no topo: título "Árvores Recomendadas" e a contagem "22 espécies
   compatíveis de 146 analisadas · 124 eliminadas pelos filtros do local" (ver `21-rec-topo`).
7. Opcionalmente, expandir "COMO AS ESPÉCIES FORAM AVALIADAS" para ver os 14 critérios aplicados,
   separados em chips vermelhos (eliminatórios) e verdes (classificatórios)
   (ver `21-rec-criterios-recolhido` → `21-rec-criterios-expandido`).
8. Rolar a grade de 22 cards, ordenada por nota decrescente (ver `21-rec-grade-p1`, `-p2`, `-p3`). Cada
   card mostra foto, coração de favorito, distintivo de nota, nome popular e científico, pills de porte,
   origem e altura, e os três critérios que mais pontuaram sob o rótulo "DESTAQUES DA ÁRVORE"
   (ver `21-rec-card-zoom`).
9. Clicar num card abre a ficha completa da espécie no `TreeDetailModal`; fechar com "×" ou `Esc`
   (ver `21-rec-detalhe-modal`).
10. Para ajustar o cenário, clicar em "Editar Respostas": o questionário reabre no **último** passo, com
    todas as respostas preservadas (ver `21-rec-editar-volta`); navegando pelo stepper até a bolinha 1 vê-se
    a primeira resposta intacta (ver `21-rec-editar-passo1`). Reenviar repete o ciclo a partir do passo 3.
11. Para recomeçar do zero, clicar em "Limpar e Refazer" (ver `21-rec-limpar-refazer`); para sair, clicar
    em "Voltar ao Catálogo" ou no link "Voltar ao catálogo" do topo, ambos indo para `/`.

## Fluxo passo a passo — Cenário sem resultados

1. Percorrer o questionário exatamente como no cenário A, mas respondendo `q2_8c`
   ("Qual a distância até a guia rebaixada (rampa de acessibilidade) mais próxima (m)?") com
   "**Menos de 1,5 m**" (ver `20-rec-q2-8c-guia`, que mostra a mesma pergunta com a resposta oposta).
2. Concluir o questionário e confirmar em "Ver Recomendações".
3. A tela de resultados abre no estado vazio: cartão "Filtros eliminatórios aplicados" com seis chips
   vermelhos no topo — entre eles "Guia rebaixada a < 1,5m" —, ícone de pinheiro, título "Nenhuma espécie
   compatível encontrada" e o texto "As condições do local são muito restritivas. Tente ajustar os
   critérios eliminatórios." (ver `21-rec-zero-resultados` e o recorte `21-rec-zero-chips`).
   Contagem registrada: **0 compatíveis, 146 eliminadas de 146 analisadas**.
4. O cartão recolhível de critérios e a lista de critérios classificatórios **não aparecem** neste estado;
   também não há indicação automática de qual resposta relaxar.
5. Clicar em "Limpar e Refazer" devolve ao questionário totalmente zerado: "Pergunta 1 de 24", nenhuma
   opção marcada, "Próximo" desabilitado e todas as bolinhas seguintes bloqueadas
   (ver `21-rec-limpar-refazer`).
6. Alternativamente, "Editar Respostas" volta ao último passo com tudo preservado, permitindo corrigir
   somente `q2_8c` e reenviar — o caminho mais curto para sair do estado vazio.
