# Limitações Conhecidas e Divergências

Este capítulo reúne as inconsistências entre documentação e código, as lacunas funcionais e os pontos de fragilidade observados durante o levantamento. Cada item traz o arquivo de origem e o impacto prático. Nenhum deles impede o uso do sistema; todos são material legítimo para a seção de limitações da dissertação.

### 1. O documento de referência do algoritmo usa numeração obsoleta

`docs/recomendacao-classificacao.md` declara **seis grupos** e identificadores de `q1_*` a `q6_*`, enquanto `src/data/questionnaire.ts:9` tipa o campo `group` como `1 | 2 | 3 | 4 | 5` e o questionário implementa **cinco grupos**. A correspondência completa está no capítulo do algoritmo. O agravante é que os prefixos foram remanejados sem ficarem livres: `q2_1` e `q3_1` existem nos dois esquemas com significados diferentes. **Impacto:** qualquer citação cruzada entre documento e código corre risco de erro factual; o próprio comentário de `MAX_SCORE` (`supabase/functions/recommend-trees/index.ts:165`) ainda fala em "Q6.1" e "Q6.2". Os pesos e fórmulas, esses, conferem integralmente.

### 2. Afirmação de catálogo desatualizada no mesmo documento

`docs/recomendacao-classificacao.md:296` afirma "Com apenas 4 espécies no banco", em nota sobre o risco de resultados vazios. O banco tem hoje 167 espécies, 146 ativas. **Impacto:** a nota subestima em duas ordens de grandeza a base sobre a qual o algoritmo opera e, se citada, distorceria a avaliação de cobertura do sistema. O mesmo arquivo referencia a planilha `src/assets/Aplicativo - draft - oficial.xlsx`, num diretório que hoje está vazio.

### 3. Quatro artefatos de código morto

Nenhum dos quatro arquivos abaixo é importado em qualquer ponto de `src/` — verificação por busca textual em toda a árvore:

- `src/hooks/useTreeFilters.ts` — implementação legada de busca e filtro por `FiltroAtributo`, referenciada apenas pela própria definição na linha 4.
- `src/components/layout/Drawer.tsx` — gaveta com filtros; o `Header.tsx:9` importa `MobileDrawer`, não este.
- `src/components/ui/ProgressBar.tsx` — barra de progresso 1 a 5.
- `src/components/trees/OdsBadge.tsx` — selo de Objetivos de Desenvolvimento Sustentável; o único uso de `OdsBadge` está dentro do próprio arquivo, no componente `SubParameter`, também sem importadores.

**Impacto:** dois conjuntos de filtros coexistem no repositório (o morto, com `FiltroAtributo` de escolha única, e o vivo, `AdvancedFilters` em `src/components/trees/TreesToolbar.tsx`), o que induz a erro quem lê o código pela primeira vez. O selo de ODS sugere uma funcionalidade planejada e não entregue.

### 4. Política de armazenamento permite inserção anônima

A política `Temp Public Insert Guias` (`supabase/migrations/20260702000001_auth_storage_from_prod.sql:71-72`) autoriza `INSERT` em `storage.objects` para o bucket `guias` **sem qualquer verificação de autenticação**. O comentário imediatamente acima, nas linhas 68 a 70, reconhece o problema e o marca como pendência de segurança da migração. **Impacto:** qualquer pessoa com a URL da API e a chave anônima — que é pública por definição, pois viaja no pacote do frontend — pode gravar arquivos no bucket dos guias.

### 5. `MAX_SCORE` fixo em 190

A normalização é `Math.round((raw / 190) * 100)` (`supabase/functions/recommend-trees/index.ts:425`), com o divisor constante (linha 166). A soma dos `maxPoints` das quatorze perguntas pontuadas é exatamente 190 **quando todas são respondidas**, mas o vetor `breakdown` só recebe as respondidas. **Impacto duplo:** um questionário parcial rebaixa proporcionalmente todas as espécies e torna a nota 100 inalcançável, sem que nada na interface avise; e qualquer alteração futura de peso quebra silenciosamente a normalização, porque nada no código deriva o divisor da soma real dos máximos.

### 6. O acervo estático de 22 espécies também responde a erros

`src/hooks/useTrees.ts:15-17` devolve `staticTrees` quando a consulta retorna erro, dado nulo **ou** lista vazia — o mesmo caminho usado quando o Supabase não está configurado. **Impacto:** uma queda do backend se apresenta ao usuário como um catálogo de 22 espécies aparentemente normal, sem aviso de falha. É também o sintoma que o guia de desenvolvimento ensina a reconhecer ("App mostra só 22 árvores"), o que confirma que a ambiguidade já se manifestou na prática.

### 7. Não existe rota de erro 404

A árvore de rotas de `src/App.tsx:41-62` não declara nenhum caminho curinga. **Impacto:** uma URL inexistente não corresponde a nenhuma rota e a aplicação renderiza uma página em branco, sem cabeçalho e sem caminho de retorno. Como a Vercel reescreve tudo para `index.html`, o servidor responde 200, de modo que nem o usuário nem um rastreador percebem que o endereço é inválido.

### 8. Falha da recomendação retorna ao questionário sem mensagem

Em `src/pages/RecommendationPage.tsx:72-73`, o bloco `catch` apenas executa `setPhase('questions')`. **Impacto:** se a função de borda estiver indisponível, se o CORS recusar a origem ou se houver erro de rede, o usuário que clicou em "Ver Recomendações" volta à última pergunta sem explicação alguma, como se o clique não tivesse acontecido. As respostas são preservadas, mas não há indicação de que houve falha nem sugestão de tentar novamente.

### 9. `npx supabase db reset` falha na migration de correções editoriais

A migration `supabase/migrations/20260908000000_apply_lorenzi_v1_validated_structure.sql` exige que exatamente 23 alturas e 13 hábitos sejam atualizados e levanta exceção caso contrário (linhas 56 e 88, "Migration Lorenzi V1 interrompida"). Como o `db reset` aplica **todas as migrations antes** do `supabase/seed.sql`, num banco recém-criado a tabela `trees` está vazia e a contagem é zero. A falha foi reproduzida hoje, ao preparar este relatório; o contorno adotado foi aplicar o seed primeiro e a migration em seguida, manualmente. **Impacto:** a reconstrução automática do ambiente local está quebrada, o que contradiz o procedimento documentado em `DESENVOLVIMENTO.md`. A causa estrutural é a mesma que levou o script de projeção a regenerar o `seed.sql`: migrations de correção de dados não convivem bem com a ordem "migrations antes do seed".

### 10. O portão de proteção intelectual não é um controle de segurança

`src/components/auth/IPProtectionGate.tsx:19-21` compara usuário e senha no cliente e grava `localStorage['ip_unlocked'] = 'true'`. A senha vem de `import.meta.env.VITE_GATE_PASSWORD` e, por ser uma variável `VITE_`, é **embutida no pacote JavaScript** entregue ao navegador. **Impacto:** o portão dissuade o visitante casual, mas não resiste a inspeção do pacote nem à simples gravação manual da chave no `localStorage`. Ele deve ser descrito na dissertação como barreira de divulgação, nunca como mecanismo de controle de acesso — o controle real são as políticas de RLS no banco.

### 11. Diálogos nativos do navegador no editor de projeto

`src/components/projects/ProjectEditor.tsx` usa `alert()` nas linhas 43, 75 e 81 e `window.confirm()` na linha 51. **Impacto:** essas caixas escapam ao sistema de design (o restante do aplicativo usa `ConfirmationModal` e avisos do `sonner`), não respeitam o tema claro ou escuro, não são estilizáveis e, em telas de captura de documentação, aparecem como elementos do navegador e não da aplicação. Funcionalmente, os três `alert()` cobrem justamente os caminhos de erro mais importantes do editor: falha na geração do relatório e falha ao vincular ou editar uma espécie.

### 12. Marcadores do mapa não podem ser arrastados

Nenhum marcador é criado com a propriedade `draggable` — a busca por esse termo em `src/components/map/` não retorna ocorrência. **Impacto:** corrigir a posição de um plantio exige removê-lo e recriá-lo, com nova seleção de espécie e nova digitação da observação. Em projetos com muitos pontos, é a operação de edição mais cara da interface.

### 13. O README instrui a copiar um arquivo que o repositório não distribui

`README.md:33-42` manda copiar `.env.example` para `.env.local` e afirma que ele "já inclui a URL e Chave Pública padrão". Contudo, `.gitignore` exclui `.env` e `.env.*`, e a verificação por `git ls-files` confirma que **nenhum arquivo `.env*` está versionado**. **Impacto:** quem clona o repositório não encontra o arquivo descrito e não tem como configurar o ambiente seguindo o README; o procedimento correto é o de `DESENVOLVIMENTO.md`, que orienta criar `.env.development.local` com os valores impressos por `npx supabase start`.

### 14. Conflito potencial entre a política de permissões e o botão de localização

`vercel.json:10` envia `Permissions-Policy: camera=(), microphone=(), geolocation=()`, o que desabilita a API de geolocalização para o documento. O editor de projeto oferece o botão "Minha Localização", que chama `navigator.geolocation.getCurrentPosition` (`src/components/map/MyLocationButton.tsx:19` e `:25`). **Impacto:** em produção, a chamada tende a ser recusada pelo navegador antes mesmo de o usuário ver o pedido de permissão, caindo na mensagem de erro genérica do componente. Este relatório não verificou o comportamento empiricamente em produção — a confirmação depende de teste no domínio real.

### 15. Propriedades discutíveis da função de pontuação

Três comportamentos do algoritmo não são erros, mas merecem registro metodológico. Primeiro, responder "Úmido (moderado)" em `q3_2` atribui **15 pontos fixos** a toda espécie sobrevivente (`supabase/functions/recommend-trees/index.ts:205-207`): o critério de umidade deixa de discriminar. Segundo, `q1_2` divide 20 pontos entre os objetivos escolhidos, de modo que **selecionar dois objetivos pode reduzir a nota** de uma espécie excelente em apenas um deles. Terceiro, `tolerancia_seca_1a5` é consultada duas vezes na pontuação — em `q3_2 = 'seco'` e em `q3_4 = 'nao'` — somando até 30 dos 190 pontos, uma ênfase deliberada, documentada, mas que concentra peso num único atributo. Some-se que `q2_1` (largura total da calçada) só influencia o resultado quando `q2_3 = 'sim'`: em qualquer outra combinação, a resposta é coletada e ignorada.

### 16. Pontos de projeto órfãos e operações silenciosas

A chave estrangeira `points.tree_id` usa `ON DELETE SET NULL`, de modo que excluir uma espécie do catálogo deixa pontos sem espécie; o gerador de PDF (`src/lib/pdf.ts`) simplesmente pula esses pontos, e a contagem de cobertura de copa também os ignora, sem qualquer aviso de que o relatório está incompleto. Na mesma linha, `src/hooks/useProjects.ts:118-123` engole silenciosamente as falhas de `updateMapCenter`, mutação que não tem tratamento de erro: se a persistência do centro do mapa falhar, o usuário só descobre ao reabrir o projeto e encontrá-lo enquadrado em outro lugar.

### 17. Permissão administrativa sem interface correspondente

A política `Admins can read all points` concede a administradores a leitura de todos os pontos de todos os projetos, mas o painel administrativo cobre apenas espécies (`/admin/arvores`) e equipe (`/admin/equipe`). **Impacto:** há uma permissão concedida e não exercida. Do ponto de vista de privacidade, convém registrar na dissertação que administradores podem, por consulta direta à API, ler os projetos de qualquer usuário — ainda que a interface não ofereça esse caminho.

### 18. Limitação de taxa da verificação de e-mail é volátil

A função `check-email-exists` implementa limite de dez requisições por minuto por IP em memória do processo (`supabase/functions/check-email-exists/index.ts`), estado que se perde a cada reinício a frio do runtime e não é compartilhado entre instâncias. **Impacto:** o limite atenua abuso casual, mas não constitui proteção robusta contra enumeração de endereços de e-mail cadastrados.
