# Quem Somos e documentos de apoio

A rota `/quem-somos` reúne a apresentação do projeto, a explicação da metodologia de avaliação das
espécies e a biblioteca de materiais em PDF: dois documentos de parametrização (um simplificado e um
técnico) e dez guias de arborização. Todos os arquivos são abertos dentro da própria aplicação, em
um visualizador de PDF embutido.

A página é **pública** (não exige conta) e usa o mesmo Header do catálogo. Arquivos-fonte:
`src/pages/AboutPage.tsx` e `src/components/ui/PdfViewer.tsx`. Os PDFs ficam no armazenamento do
Supabase, em dois "baldes" públicos: `criterios/` (parametrização) e `guias/` (guias numerados
`guia1.pdf` … `guia10.pdf`).

---

## 1. A página completa

### "Quem Somos" — página inteira

![Página completa: título Quem Somos, cartão Sobre o PlanteiCerto, três cartões de escalas, bloco de parametrização e grade com dez guias](../shots/16-sobre-topo.png)

**Rota:** `/quem-somos` — acessível pelo link "Quem Somos" no Header ou pelo drawer no mobile
· **Quem acessa:** qualquer pessoa · **Viewport/tema:** desktop claro, página inteira (1 872 px de
altura, capturada em uma única imagem)

**Elementos visíveis (de cima para baixo):**

1. Título **"Quem Somos"** em serifada, precedido por um ícone circular de informação em verde. No
   Header, o link "Quem Somos" está destacado em verde, indicando a rota ativa.
2. Cartão branco **"Sobre o PlanteiCerto"** com dois parágrafos: o primeiro define a plataforma como
   dedicada "a auxiliar cidadãos, profissionais e gestores públicos na escolha adequada de espécies
   arbóreas para o plantio urbano e rural", com o objetivo de "promover a arborização consciente,
   garantindo que a árvore certa seja plantada no lugar certo"; o segundo trata de evitar problemas
   futuros com infraestrutura, fiação elétrica e calçadas.
3. Seção **"Metodologia e Critérios de Avaliação"** (ícone de medalha) com um parágrafo introdutório
   e três cartões explicativos.
4. Bloco **"Documentos de Parametrização"** com dois botões-cartão.
5. Seção **"Guias de Arborização"** (ícone de livro aberto) com a frase "Acesse nossos materiais
   educativos para aprender mais sobre planejamento, plantio e manutenção de árvores." e a grade de
   dez guias em três colunas.

**Ações possíveis / o que acontece:**

- Qualquer um dos 12 botões (2 documentos + 10 guias) abre o visualizador de PDF em modal.
- A página não tem estado de carregamento próprio: o conteúdo é estático e aparece imediatamente.

**Estados relacionados:** `16-sobre-metodologia`, `16-sobre-guias`, `16-sobre-mobile-p1`

---

## 2. Metodologia e documentos de parametrização

### Os três cartões de escalas

![Seção Metodologia com três cartões: Escalas de 1 a 5, Escalas de 0 a 1 e Escalas Numéricas](../shots/16-sobre-metodologia.png)

**Rota:** `/quem-somos` · **Quem acessa:** qualquer pessoa · **Viewport/tema:** desktop claro

**Elementos visíveis:**

- Título **"Metodologia e Critérios de Avaliação"** e o parágrafo: "A classificação e pontuação das
  espécies no **PlanteiCerto** baseiam-se em critérios metodológicos que analisam a compatibilidade
  urbana e ecológica. Os dados são estruturados em três tipos de escalas para refletir as diferentes
  características de cada árvore:".
- **Cartão 1 — "Escalas de 1 a 5"** (ícone de balança): "Mensuram graus qualitativos e de tolerância.
  Utilizada para classificar o nível de resistência a estresses ambientais e potenciais ecológicos ou
  de impactos urbanos."; rodapé em fonte monoespaçada verde: **"1 = Muito Baixo | 5 = Muito Alto"**.
- **Cartão 2 — "Escalas de 0 a 1"** (ícone binário): "Escala binária de presença ou ausência. Define
  de forma objetiva se a espécie apresenta espinhos, substâncias irritantes ou características
  específicas de insolação."; rodapé: **"0 = Não / Ausente | 1 = Sim / Presente"**.
- **Cartão 3 — "Escalas Numéricas"** (ícone de cerquilha): "Valores quantitativos e dimensionais
  físicos. Indicam medidas técnicas necessárias como largura mínima da calçada, área de berço e
  recuos para fiação elétrica."; rodapé: **"Unidades métricas (m, m²) e absolutas"**.
- Cada cartão reage ao cursor com borda esverdeada e sombra.

**Ações possíveis / o que acontece:**

- Os cartões são apenas informativos (não são clicáveis).
- São a chave de leitura das fichas de espécie: os indicadores de cinco quadradinhos do
  `TreeDetailModal` correspondem à escala de 1 a 5 descrita aqui.

**Estados relacionados:** `14-especie-detalhe-p1` (uso prático das escalas)

### Documentos de parametrização

![Bloco cinza-claro com dois botões-cartão: Parametrização Simplificada e Parametrização Técnica](../shots/16-sobre-parametrizacao.png)

**Rota:** `/quem-somos` · **Quem acessa:** qualquer pessoa · **Viewport/tema:** desktop claro

**Elementos visíveis:**

- Bloco com fundo levemente acinzentado e o título **"Documentos de Parametrização"**.
- Dois botões-cartão lado a lado, cada um com um ícone de documento em quadrado verde-claro:
  - **"Para o cidadão comum" / "Parametrização Simplificada"** — "Uma explicação em linguagem simples
    e acessível sobre o funcionamento das escalas de avaliação e critérios das espécies."
  - **"Detalhamento Avançado" / "Parametrização Técnica"** — "Detalhamento explícito sobre as regras,
    pontuações e parâmetros científicos que definem a avaliação de cada critério."
- Logo abaixo começa a seção "Guias de Arborização".

**Ações possíveis / o que acontece:**

- Clicar em um dos botões abre o visualizador de PDF em modal, com o título do documento no
  cabeçalho — o comportamento é idêntico ao dos guias (ver `16-sobre-pdf-pagina`).
- Os arquivos correspondentes são `parametrizacao_simples.pdf` e `parametrizacao_tecnica.pdf`,
  servidos do balde público `criterios/`; ambos responderam normalmente na verificação do ambiente.
- **NÃO CAPTURADO:** a abertura específica desses dois documentos no visualizador — as capturas do
  `PdfViewer` foram feitas com os guias, que exercitam exatamente a mesma tela.

**Estados relacionados:** `16-sobre-pdf-pagina`

---

## 3. Guias de arborização

### Grade com os dez guias

![Seção Guias de Arborização com dez cartões numerados em três colunas](../shots/16-sobre-guias.png)

**Rota:** `/quem-somos` · **Quem acessa:** qualquer pessoa · **Viewport/tema:** desktop claro

**Elementos visíveis:**

- Título **"Guias de Arborização"** com ícone de livro aberto e a linha de apoio "Acesse nossos
  materiais educativos para aprender mais sobre planejamento, plantio e manutenção de árvores."
- Grade de três colunas com dez cartões brancos; cada um traz um ícone circular de livro em
  verde-claro e o título do guia:

| # | Título do cartão | Arquivo | Páginas |
|---|---|---|---|
| 1 | 1 - Porque as árvores da cidade | `guia1.pdf` | 2 |
| 2 | 2 - Onde estão e quantas são as árvores da cidade? | `guia2.pdf` | 2 |
| 3 | 3 - Planejando o plantio - o quê e onde plantar | `guia3.pdf` | 7 |
| 4 | 4 - Áreas verdes públicas e de preservação | `guia4.pdf` | 3 |
| 5 | 5 - Plantando | `guia5.pdf` | 4 |
| 6 | 6 - Depois do plantio - mantendo a muda | `guia6.pdf` | 2 |
| 7 | 7 - Poda | `guia7.pdf` | 6 |
| 8 | 8 - Pragas e doenças em árvores. O que fazer? | `guia8.pdf` | 2 |
| 9 | 9 - Extração de árvores urbanas | `guia9.pdf` | 2 |
| 10 | 10 - Os resíduos do manejo da arborização urbana | `guia10.pdf` | 2 |

  (A contagem de páginas foi obtida diretamente dos arquivos no armazenamento local; ela determina se
  a barra de paginação aparece no visualizador.)

- O décimo cartão fica sozinho na quarta linha, à esquerda.

**Ações possíveis / o que acontece:**

- Clicar em um cartão abre o `PdfViewer` em modal, sem sair da página nem baixar o arquivo.
- Os cartões destacam o título em verde quando recebem o cursor e o ícone cresce ligeiramente.

**Estados relacionados:** `16-sobre-pdf-carregando`, `16-sobre-pdf-pagina`, `16-sobre-pdf-erro`

---

## 4. Visualizador de PDF (`PdfViewer`)

### Estado "Carregando..."

![Modal do visualizador vazio, com o texto Carregando... centralizado](../shots/16-sobre-pdf-carregando.png)

**Rota:** sobreposto a `/quem-somos` · **Quem acessa:** qualquer pessoa · **Viewport/tema:** desktop
claro. Captura obtida atrasando artificialmente a resposta do arquivo `guia3.pdf`.

**Elementos visíveis:**

- Modal grande (largura máxima de ~1 024 px, altura de 85 % da janela), com fundo escurecido e
  desfocado atrás.
- Barra de título do modal: à esquerda, o nome do documento — **"3 - Planejando o plantio - o quê e
  onde plantar"**; à direita, o link discreto **"Abrir em nova aba"** e um botão "×".
- Corpo do modal vazio, com o texto cinza **"Carregando..."** centralizado vertical e horizontalmente.
- Ainda não existe barra de paginação (o número de páginas é desconhecido nesse momento).

**Ações possíveis / o que acontece:**

- "Abrir em nova aba" já funciona nesse estado e abre o arquivo diretamente no navegador.
- O "×" (ou um clique no fundo escurecido) cancela o carregamento e fecha o modal.

**Estados relacionados:** `16-sobre-pdf-pagina`, `16-sobre-pdf-erro`

### Página renderizada e barra de paginação

![Modal com a primeira página do guia 3 desenhada e, no rodapé, a barra "1 / 7"](../shots/16-sobre-pdf-pagina.png)

**Rota:** sobreposto a `/quem-somos` · **Quem acessa:** qualquer pessoa · **Viewport/tema:** desktop claro

**Elementos visíveis:**

- Mesma barra de título ("3 - Planejando o plantio - o quê e onde plantar", "Abrir em nova aba", "×").
- Área central com fundo cinza-claro exibindo a **página 1 do guia desenhada em um `canvas`**,
  ajustada para caber na altura disponível. Na captura é possível ler o cabeçalho verde
  "Planejando o plantio: o quê e onde plantar — Diversidade de espécies, porte e formato de copa",
  a subseção "Por que variar as espécies?", uma caixa de destaque e a subseção "Atenção ao porte da
  árvore e ao formato da copa" com uma infografia comparando árvores de porte pequeno, médio e grande.
- **Barra de paginação** no rodapé do modal, centralizada: seta **"←"** (desabilitada, 40 % de
  opacidade, por estar na primeira página), o indicador **"1 / 7"** e a seta **"→"**.

**Ações possíveis / o que acontece:**

- As setas avançam e retrocedem uma página por clique; a renderização é refeita no `canvas`.
- Não há zoom, busca no texto, miniaturas nem download direto — apenas a navegação página a página e
  o link "Abrir em nova aba".
- **A barra de paginação só existe quando o documento tem mais de uma página**; em PDFs de página
  única o rodapé não é renderizado.

**Estados relacionados:** `16-sobre-pdf-paginacao`

### Navegação entre páginas

![Mesmo modal exibindo a página 2 do guia 3; o indicador mostra "2 / 7"](../shots/16-sobre-pdf-paginacao.png)

**Rota:** sobreposto a `/quem-somos` · **Quem acessa:** qualquer pessoa · **Viewport/tema:** desktop claro

**Elementos visíveis:**

- Conteúdo da **página 2** do guia 3: legenda "Figura 3 — Classificação das árvores urbanas por porte:
  pequeno (até 6 m), médio (até 12 m) e grande (mais de 12 m)", um trecho sobre o formato da copa,
  a infografia "Copa piramidal / Copa arredondada / Copa pendente" e um quadro
  **"VOCABULÁRIO TÉCNICO"** com as definições de "Diâmetro de copa" e "Gema apical".
- Barra de paginação agora com **"2 / 7"**; ambas as setas habilitadas (a seta "→" aparece em
  destaque por ter acabado de ser clicada). A leitura textual da barra confirmou o conteúdo
  `← 2 / 7 →`.

**Ações possíveis / o que acontece:**

- Ao chegar à última página, a seta "→" fica desabilitada; na primeira, a "←".
- Fechar e reabrir o documento reinicia a leitura na página 1.

**Estados relacionados:** `16-sobre-pdf-pagina`

### Erro ao carregar o PDF

![Modal com a mensagem "Não foi possível carregar o PDF." e o link Abrir em nova aba](../shots/16-sobre-pdf-erro.png)

**Rota:** sobreposto a `/quem-somos` · **Quem acessa:** qualquer pessoa · **Viewport/tema:** desktop
claro. Estado provocado interceptando a requisição de `guia9.pdf` e devolvendo "404 não encontrado".

**Elementos visíveis:**

- Barra de título normal, com o nome **"9 - Extração de árvores urbanas"**, o link "Abrir em nova
  aba" e o "×".
- Corpo do modal vazio, com dois elementos centralizados verticalmente: a frase em cinza
  **"Não foi possível carregar o PDF."** e, logo abaixo, o link verde sublinhado
  **"Abrir em nova aba"**.
- Não há barra de paginação, botão de "tentar novamente" nem detalhe do erro; o motivo da falha só
  aparece no console do navegador.

**Ações possíveis / o que acontece:**

- O link "Abrir em nova aba" tenta abrir o mesmo endereço fora da aplicação — se o arquivo realmente
  não existir, o navegador mostrará o erro do servidor.
- "×" ou clique no fundo fecham o modal e devolvem a página "Quem Somos" intacta.
- É o único tratamento de erro do visualizador: qualquer falha (arquivo ausente, rede indisponível,
  PDF corrompido) recai nesta mesma tela.

**Estados relacionados:** `16-sobre-pdf-carregando`

## Fluxo passo a passo — abrir um guia em PDF

1. Na rota `/quem-somos`, o usuário rola até a seção **"Guias de Arborização"** (ver `16-sobre-guias`).
2. Clica no cartão do guia desejado — por exemplo **"3 - Planejando o plantio - o quê e onde plantar"**.
3. O modal abre imediatamente com o título do guia e o texto **"Carregando..."** enquanto o arquivo é
   baixado e interpretado (ver `16-sobre-pdf-carregando`).
4. Terminado o carregamento, a primeira página é desenhada e surge a barra **"1 / 7"** no rodapé
   (ver `16-sobre-pdf-pagina`).
5. As setas "←" e "→" percorrem as páginas; o indicador acompanha, por exemplo **"2 / 7"**
   (ver `16-sobre-pdf-paginacao`).
6. Se o arquivo não puder ser obtido, o modal mostra **"Não foi possível carregar o PDF."** com a
   alternativa "Abrir em nova aba" (ver `16-sobre-pdf-erro`).
7. O "×", a área escurecida ao redor do modal ou a tecla de fechar devolvem a página "Quem Somos".

---

## 5. Versão móvel

### "Quem Somos" no mobile

![Página Quem Somos em coluna única: cartão de apresentação e os três cartões de escalas empilhados](../shots/16-sobre-mobile-p1.png)

![Continuação: seção Guias de Arborização com os dez cartões empilhados um abaixo do outro](../shots/16-sobre-mobile-p2.png)

**Rota:** `/quem-somos` · **Quem acessa:** qualquer pessoa · **Viewport/tema:** mobile 390×844, claro,
página inteira dividida em duas partes

**Elementos visíveis:**

- Header compacto com logotipo e botão hambúrguer.
- Título "Quem Somos" e o cartão "Sobre o PlanteiCerto" em largura total, com o texto reflowado.
- Os três cartões de escalas deixam de ser colunas e ficam **empilhados**, na ordem "Escalas de 1 a 5",
  "Escalas de 0 a 1" e "Escalas Numéricas", preservando os rodapés monoespaçados.
- O bloco "Documentos de Parametrização" também empilha os dois botões; as descrições ficam
  truncadas em duas linhas com reticências ("Uma explicação em linguagem simples e…").
- Na segunda parte, os dez guias aparecem em **coluna única**, cada um em seu cartão, do guia 1 ao
  guia 10.

**Ações possíveis / o que acontece:**

- O visualizador de PDF abre em modal também no celular, ocupando praticamente toda a tela; a
  renderização se ajusta à largura disponível.

**Estados relacionados:** `16-sobre-topo`, `16-sobre-pdf-pagina`

---

## Observações

- Os títulos dos guias vêm **fixos no código** (`src/pages/AboutPage.tsx`), não do banco de dados:
  incluir ou renomear um guia exige alterar o código-fonte, mesmo que o arquivo já esteja no
  armazenamento.
- Os endereços dos PDFs são montados a partir da variável de ambiente do Supabase
  (`<url>/storage/v1/object/public/guias/<arquivo>`); em uma instalação sem essa variável os botões
  apontariam para um endereço inválido e sempre cairiam na tela de erro.
- A página não possui índice interno nem âncoras: a navegação entre as três seções é feita apenas
  pela rolagem.
