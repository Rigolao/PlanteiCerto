# Detalhe da espécie e comparação lado a lado

A partir do catálogo, o usuário pode aprofundar a consulta de duas maneiras: abrir a **ficha completa
de uma espécie** (`TreeDetailModal`) ou selecionar até **três espécies e compará-las lado a lado**
(`CompareModal`). Ambas as funções são públicas — não exigem conta — e acontecem em modais sobre o
catálogo, sem mudar de rota.

Arquivos-fonte principais: `src/components/trees/TreeCard.tsx`,
`src/components/trees/TreeDetailModal.tsx`, `src/components/trees/CompareModal.tsx`,
`src/components/trees/TreesCompareBar.tsx` e `src/components/ui/Modal.tsx`.

---

## 1. Interação no card

### Card sob o cursor

![Dois cards lado a lado; o da esquerda está ligeiramente elevado com sombra](../shots/14-especie-card-hover.png)

**Rota:** `/` · **Quem acessa:** qualquer pessoa · **Viewport/tema:** desktop claro (recorte de dois
cards da primeira fileira)

**Elementos visíveis:**

- O card da esquerda ("Açoita-cavalo", *Luehea divaricata Mart.*) está **alguns pixels acima** da
  linha de base e com sombra mais forte — é o card sob o cursor; o card à direita ("Açoita-cavalo",
  *Luehea divaricata*) permanece na posição normal.
- Em ambos: chip escuro **"+ Comparar"** no canto superior esquerdo da foto e botão circular com
  coração vazio no canto superior direito.
- Conteúdo textual: nome popular em verde, pílula **"Nativa"**, nome científico em itálico e as
  linhas "Altura 25m (Grande)", "Folhagem Decídua" e "Espinhos Não".

**Ações possíveis / o que acontece:**

- Clicar em qualquer área do card (menos no chip e no coração) abre o modal de detalhe.
- A foto também aplica um leve zoom ao receber o cursor.

**Estados relacionados:** `15-comparar-chip-ativo`, `14-especie-detalhe-p1`

---

## 2. Seleção para comparação

### Card selecionado — chip "Comparando"

![O card da esquerda agora tem um chip verde "Comparando" e um anel verde ao redor](../shots/15-comparar-chip-ativo.png)

**Rota:** `/` · **Quem acessa:** qualquer pessoa · **Viewport/tema:** desktop claro

**Elementos visíveis:**

- No card selecionado, o chip mudou de **"+ Comparar"** (fundo preto translúcido, ícone "+") para
  **"Comparando"** (fundo verde sólido, ícone de "visto").
- O card ganhou um **anel/borda verde** e sombra, distinguindo-o do card vizinho, que continua com o
  chip "+ Comparar".

**Ações possíveis / o que acontece:**

- Clicar de novo no chip remove a espécie da comparação (o `title` do botão alterna entre
  "Adicionar à comparação" e "Remover da comparação").
- A seleção é temporária: vive apenas na memória da página e se perde ao recarregar.

**Estados relacionados:** `15-comparar-barra-1`

### Barra flutuante de comparação — 1, 2 e 3 espécies

![Barra branca flutuante com "1 de 3 árvores selecionadas", Limpar e o botão cinza "Escolha +"](../shots/15-comparar-barra-1.png)

![Mesma barra com "2 de 3 árvores selecionadas" e o botão verde "Comparar"](../shots/15-comparar-barra-2.png)

![Mesma barra com "3 de 3 árvores selecionadas"](../shots/15-comparar-barra-3.png)

**Rota:** `/` · **Quem acessa:** qualquer pessoa · **Viewport/tema:** desktop claro (recortes da
parte inferior central da tela)

**Elementos visíveis:**

- Assim que a primeira espécie é marcada, surge uma barra flutuante arredondada, branca e com sombra,
  centralizada na parte inferior da janela (`TreesCompareBar`).
- À esquerda, em duas linhas: o contador em negrito — **"1 de 3 árvores"**, depois **"2 de 3 árvores"**
  e **"3 de 3 árvores"** — e, abaixo, a palavra **"selecionadas"**.
- À direita: o botão de texto **"Limpar"** e o botão principal. Com **1** espécie, o botão principal
  está **desabilitado**, em cinza, com o rótulo **"Escolha +"**; a partir de **2** ele fica verde,
  habilitado, com um "visto" e o rótulo **"Comparar"**.

**Ações possíveis / o que acontece:**

- "Limpar" desmarca todas as espécies e a barra desaparece.
- "Comparar" (ativo com 2 ou 3 espécies) abre o `CompareModal`.
- A barra fica sempre visível enquanto houver seleção, mesmo rolando a página.

**Estados relacionados:** `15-comparar-toast-limite`, `15-comparar-modal-p1`

### Limite de três espécies

![Três cards com chip "Comparando", o quarto ainda com "+ Comparar", e um toast vermelho no rodapé](../shots/15-comparar-toast-limite.png)

**Rota:** `/` · **Quem acessa:** qualquer pessoa · **Viewport/tema:** desktop claro

**Elementos visíveis:**

- Os três primeiros cards estão com o chip verde **"Comparando"**; o quarto ("Aldrago miúdo")
  continua com **"+ Comparar"**.
- Toast vermelho na parte inferior central: **"Você pode comparar no máximo 3 árvores por vez."**

**Ações possíveis / o que acontece:**

- A quarta seleção é **recusada**: nada é adicionado e o card não muda de estado.
- Para trocar de espécie é preciso desmarcar uma das três (clicando no chip "Comparando") ou usar
  "Limpar".

**Estados relacionados:** `15-comparar-barra-3`

---

## 3. CompareModal (desktop)

### Comparação lado a lado — parte 1

![Modal largo com três colunas de fotos e nomes, seguidas das seções Porte e Dimensões e Características Botânicas](../shots/15-comparar-modal-p1.png)

### Comparação lado a lado — parte 2

![Continuação do mesmo modal: Tolerâncias Climáticas, Uso Urbano e o botão Fechar](../shots/15-comparar-modal-p2.png)

**Rota:** sobreposto a `/` · **Quem acessa:** qualquer pessoa · **Viewport/tema:** desktop claro. O
modal é mais alto que a janela; as duas capturas correspondem à rolagem do início e do fim.

**Elementos visíveis:**

- Cabeçalho com ícone de seta dupla e o título **"Comparação Lado a Lado"**, seguido da linha
  **"Comparando 3 espécies."**; botão "×" no canto superior direito.
- **Cabeçalhos das colunas:** foto em proporção 16:9, nome popular em negrito e nome científico em
  itálico. Nas capturas: "Açoita-cavalo / *Luehea divaricata Mart.*", "Aldrago / *Pterocarpus
  violaceus Vogel*" e "Açoita-cavalo / *Luehea divaricata*". Espécies sem foto exibem uma ilustração
  e o texto "Sem foto".
- **Seção "PORTE E DIMENSÕES"** (ícone de régua), um cartão por espécie com: *Altura Máxima*
  ("25m (Grande)", "14m (Médio)", "25m (Grande)"), *Diâmetro da Copa* ("8m (Grande)", "— (Média)",
  "10m (Grande)") e *Raízes / Dano à Calçada* ("3/5 Risco", "3/5 Risco", "4/5 Risco") com uma barra
  de cinco segmentos preenchidos proporcionalmente.
- **Seção "CARACTERÍSTICAS BOTÂNICAS"** (ícone de folha), em formato de tabela com quatro linhas por
  espécie: *Origem* ("Nativa" com ícone de casa, ou "Exótica"), *Folhagem* ("Decídua",
  "Perenifólia"), *Floração* ("Dez-Fev", "Out-Dez", "Dez-Abr") e *Espinhos* ("Não").
- **Seção "TOLERÂNCIAS CLIMÁTICAS"** (ícone de sol): *Sol Pleno* com "visto" verde (ou "×" vermelho
  quando falso), *Tolerância a Seca (1-5)* com o número e a barra (4, 4 e 3 nas capturas) e
  *Ventos Fortes (1-5)* (3, 3 e 3).
- **Seção "USO URBANO"** (ícone de prédio): *Compatibilidade com Fiação* como pílula colorida —
  vermelha **"Incompatível"**, amarela **"Apenas Alta Tensão"** ou verde "Total"; *Potencial de
  Sombra (1-5)* (5, 3 e 4) e *Berço Mínimo (m²)* (3, 4 e 2).
- No rodapé, o botão cinza **"Fechar"**.

**Ações possíveis / o que acontece:**

- "Fechar", o "×", a tecla `Esc` ou um clique fora do cartão encerram o modal; a seleção das três
  espécies **permanece** ativa na barra flutuante.
- Comparar apenas 2 espécies produz o mesmo modal com duas colunas e a frase "Comparando 2 espécies.".
- A comparação é uma visão resumida: mostra 13 atributos, contra as cinco seções completas da ficha
  individual.

**Estados relacionados:** `15-comparar-modal-dimensoes-mobile`

---

## 4. CompareModal no mobile — quatro abas

No mobile o layout em colunas é substituído por **abas**, e as espécies aparecem empilhadas dentro da
aba escolhida. As capturas abaixo usam **duas** espécies para que cada aba caiba em uma tela.

### Aba "Dimensões"

![Modal móvel com abas no topo; a aba Dimensões está selecionada e há dois blocos de espécies](../shots/15-comparar-modal-dimensoes-mobile.png)

**Rota:** sobreposto a `/` · **Quem acessa:** qualquer pessoa · **Viewport/tema:** mobile 390×844, claro

**Elementos visíveis:**

- Cabeçalho "Comparação Lado a Lado" + "Comparando 2 espécies." e o "×".
- Fila de abas roláveis horizontalmente: **"Dimensões"** (ativa, verde sólido), "Botânica",
  "Tolerâncias" e "Uso Urbano" (esta última fora da área visível, indicada pelo corte na borda direita).
- Para cada espécie: miniatura quadrada, nome popular em negrito e nome científico em itálico;
  abaixo, um cartão com barra verde na lateral esquerda contendo *Altura Máxima* ("25m (Grande)"),
  *Diâmetro da Copa* ("8m (Grande)" e "10m (Grande)") e *Raízes / Dano à Calçada* ("3/5 Risco" e
  "4/5 Risco") com as barras de cinco segmentos.
- Botão **"Fechar"** no rodapé do modal.

### Aba "Botânica"

![Mesma estrutura, aba Botânica ativa, mostrando Origem, Folhagem, Floração e Espinhos](../shots/15-comparar-modal-botanica-mobile.png)

**Elementos visíveis:** para cada espécie, as linhas *Origem* ("Nativa"), *Folhagem* ("Decídua"),
*Floração* ("Dez-Fev" e "Dez-Abr") e *Espinhos* ("Não").

### Aba "Tolerâncias"

![Aba Tolerâncias ativa, com Sol Pleno marcado e as escalas de seca e ventos](../shots/15-comparar-modal-tolerancias-mobile.png)

**Elementos visíveis:** **"✓ Sol Pleno"** em verde; *Tolerância a Seca (1-5)* com o valor (4 e 3) e a
barra; *Ventos Fortes (1-5)* (3 e 3).

### Aba "Uso Urbano"

![Aba Uso Urbano ativa; a fila de abas rolou e "Dimensões" saiu de vista](../shots/15-comparar-modal-urbano-mobile.png)

**Elementos visíveis:** *Compatibilidade com Fiação* com a pílula vermelha **"Incompatível"** nas
duas espécies; *Potencial de Sombra (1-5)* (5 e 4); *Berço Mínimo (m²)* (3 e 2). Note que a fila de
abas rolou para a esquerda e "Dimensões" deixou de aparecer — a navegação entre abas no mobile exige
arrastar essa fila.

**Ações possíveis / o que acontece (nas quatro abas):**

- Tocar em uma aba troca o conteúdo de **todas** as espécies simultaneamente; a rolagem volta ao topo.
- "Fechar" encerra o modal mantendo a seleção.

**Estados relacionados:** `15-comparar-modal-p1`

## Fluxo passo a passo — comparar três espécies

1. No catálogo, o usuário clica no chip **"+ Comparar"** sobre a foto do primeiro card; ele vira
   **"Comparando"** e o card ganha anel verde (ver `15-comparar-chip-ativo`).
2. Surge a barra flutuante **"1 de 3 árvores selecionadas"**, ainda com o botão desabilitado
   "Escolha +" (ver `15-comparar-barra-1`).
3. Com a segunda espécie marcada, o botão vira **"Comparar"** em verde (ver `15-comparar-barra-2`);
   com a terceira, a barra mostra "3 de 3 árvores selecionadas" (ver `15-comparar-barra-3`).
4. Tentar marcar uma quarta espécie é recusado com o toast **"Você pode comparar no máximo 3 árvores
   por vez."** (ver `15-comparar-toast-limite`).
5. Clicar em **"Comparar"** abre o `CompareModal`, com as três espécies em colunas e as quatro seções
   — Porte e Dimensões, Características Botânicas, Tolerâncias Climáticas e Uso Urbano
   (ver `15-comparar-modal-p1` e `15-comparar-modal-p2`); no celular, as mesmas seções viram abas
   (ver `15-comparar-modal-dimensoes-mobile` a `15-comparar-modal-urbano-mobile`).
6. **"Fechar"** encerra a comparação sem perder a seleção; **"Limpar"**, na barra flutuante, desmarca
   tudo.

---

## 5. TreeDetailModal — ficha completa da espécie

A ficha é aberta clicando em qualquer card. O conteúdo é dividido em cinco blocos, sempre na mesma
ordem: Morfologia, Tolerâncias Ecológicas, Fenologia, Urbanismo & Manutenção e — **quando a espécie
tem projeção** — Projeção em 10 anos.

### Espécie com projeção — parte 1 (foto, morfologia e tolerâncias)

![Modal com foto de ipê roxo florido no topo, nome da espécie e as seções Morfologia e Tolerâncias Ecológicas](../shots/14-especie-detalhe-p1.png)

**Rota:** sobreposto a `/` (busca por "Ipê-roxo-de-bola") · **Quem acessa:** qualquer pessoa
· **Viewport/tema:** desktop claro

**Elementos visíveis:**

- **Topo:** fotografia em faixa de 256 px de altura (ipê roxo florido) ocupando toda a largura do
  modal, com cantos superiores arredondados. Sobre ela, no canto direito, um botão circular com
  **coração vazio** e, ao lado, o "×" de fechar.
- **Identificação:** nome popular **"Ipê-roxo-de-bola"** em verde e negrito; logo abaixo, o nome
  científico em itálico cinza: *Handroanthus impetiginosus (Mart. ex DC.) Mattos*. (Há três espécies
  com esse mesmo nome popular no acervo; esta é a que aparece primeiro na ordem alfabética.)
- **Seção "MORFOLOGIA"** (rótulo em versalete verde, ícone de broto): seis caixas cinza-claras em
  duas colunas — *Altura adulta* **18m**; *Copa* **8m (Grande)**; *Porte* **Grande**;
  *Forma da Copa* **Globosa**; *DAP (Diâmetro)* **80cm**; *1ª Bifurcação* **2,5-3,5**.
- **Seção "TOLERÂNCIAS ECOLÓGICAS"** (ícone de escudo): primeiro três linhas com pílulas de
  "Sim"/"Não" — *Sol Pleno* **Sim**, *Meia Sombra* **Sim**, *Sombra* **Não**; depois onze linhas com
  **indicadores de cinco quadradinhos** preenchidos conforme a nota de 1 a 5: *Seca* 4,
  *Encharcamento* 2, *Poluição Atmosférica* 3, *Compactação do Solo* 3, *Ventos Fortes* 3,
  *Potencial Sujeira* 4, *Potencial Dano Calçada* 2, *Atração de Fauna* 4, *Potencial Sombra* 4,
  *Contribuição Biodiversidade* 4 e *Tolerância à Poda* 3.
- Ao fundo, o catálogo desfocado e escurecido.

**Ações possíveis / o que acontece:**

- O coração favorita/desfavorita a espécie (para visitantes, dispara o mesmo toast de login do card).
- "×", `Esc` ou clique fora fecham o modal e devolvem o catálogo.
- Atributos nulos simplesmente não são exibidos (as linhas de escala só aparecem quando há valor).

**Estados relacionados:** `14-especie-detalhe-p2`, `14-especie-jeriva-p1`

### Espécie com projeção — parte 2 (fenologia, urbanismo e projeção de 10 anos)

![Continuação do modal, com Fenologia em pílulas, Urbanismo & Manutenção e o bloco Projeção em 10 anos](../shots/14-especie-detalhe-p2.png)

**Rota:** sobreposto a `/` · **Quem acessa:** qualquer pessoa · **Viewport/tema:** desktop claro
(rolagem até o fim do modal)

**Elementos visíveis:**

- **Seção "FENOLOGIA"** (ícone de calendário): três pílulas verde-claras — **"Decídua"**,
  **"Floração: Mai-Ago"** e **"Frutificação: Set-Out"**.
- **Seção "URBANISMO & MANUTENÇÃO"** (ícone de prédio): pílulas com
  **"Fiação: Incompatível"**, **"Faixa Serviço Mín: 2.5m"**, **"Berço Mín: 6m²"**,
  **"Vol. Solo Mín: 12m³"**, **"Espinhos: Não"** e **"Subst. Irritantes: Não"**.
  A compatibilidade com a fiação é traduzida para texto: `N` → "Incompatível", `A` →
  "Compatível c/ Alta Tensão", `C` → "Compatível".
- **Seção "PROJEÇÃO EM 10 ANOS"** (ícone de tendência de alta) com seis caixas em duas colunas:
  - *DAP* **9 cm** — "entre 7,2 e 10,8 cm";
  - *Altura* **5,5 m** — "entre 4,5 e 6,5 m";
  - *CO₂e capturado* **34,6 kg**;
  - *CO₂e esperado por muda* **28,4 kg** — "já descontada a mortalidade";
  - *Sobrevivência* **85%**;
  - *Biomassa aérea* **20,1 kg** — "9,4 kg de carbono".
- Abaixo das caixas, a pílula **"Emissão de BVOC: Baixa"**.
- Aviso com ícone de informação: **"Classificação de BVOC com evidência limitada (fator de gênero
  i-Tree) — confiança baixa."**
- Última linha, em cinza pequeno: **"Muda de DAP 3 cm e altura 1,5 m, plantada em boas condições."** —
  o cenário de referência da projeção, idêntico para todas as espécies.

**Ações possíveis / o que acontece:**

- Os valores da projeção são de leitura apenas; o mesmo conjunto alimenta as ordenações
  "Maior captura de CO₂ (10 anos)" e "Maior crescimento em altura (10 anos)" do catálogo.
- A pílula de BVOC muda de rótulo conforme a classe registrada ("Baixa", "Moderada", "Alta",
  "Desconhecida", "Indeterminada"); o aviso de evidência limitada só aparece quando a espécie está
  marcada para exibi-lo.

**Estados relacionados:** `14-especie-jeriva-p2`

### Espécie sem projeção — Jerivá (palmeira)

![Modal do Jerivá com foto da palmeira e as seções Morfologia e Tolerâncias](../shots/14-especie-jeriva-p1.png)

![Fim do modal do Jerivá: depois de Urbanismo & Manutenção o modal termina, sem bloco de projeção](../shots/14-especie-jeriva-p2.png)

**Rota:** sobreposto a `/` (busca por "Jerivá") · **Quem acessa:** qualquer pessoa
· **Viewport/tema:** desktop claro, duas partes

**Elementos visíveis:**

- Foto de uma palmeira jerivá em frente a uma casa; nome **"Jerivá"** e, em itálico,
  *Syagrus romanzoffiana*.
- **Morfologia:** *Altura adulta* **15m**; *Copa* **8m (Média)**; *Porte* **Médio**;
  *Forma da Copa* **Colunar**; *DAP (Diâmetro)* **40cm**; *1ª Bifurcação* **0** (palmeiras não
  bifurcam).
- **Tolerâncias Ecológicas:** *Sol Pleno* **Sim**, *Meia Sombra* **Sim**, *Sombra* **Não**; escalas:
  *Seca* 3, *Encharcamento* 2, *Poluição Atmosférica* 3, *Compactação do Solo* 2, *Ventos Fortes* 4,
  *Potencial Sujeira* 4, *Potencial Dano Calçada* 1, *Atração de Fauna* 5, *Potencial Sombra* 2,
  *Contribuição Biodiversidade* 5, *Tolerância à Poda* 2.
- **Fenologia:** "Perenifólia", "Floração: Nov-Mar", "Frutificação: Mar-Nov".
- **Urbanismo & Manutenção:** "Fiação: Compatível c/ Alta Tensão", "Faixa Serviço Mín: 1.5m",
  "Berço Mín: 2.25m²", "Vol. Solo Mín: 3m³", "Espinhos: Não", "Subst. Irritantes: Não".
- **Ponto central desta captura:** logo depois da seção de urbanismo o **modal termina** — não há a
  faixa "PROJEÇÃO EM 10 ANOS", nem tabela de DAP/CO₂, nem a frase do cenário da muda. A borda
  inferior do cartão aparece imediatamente abaixo das pílulas de urbanismo.

**Ações possíveis / o que acontece:**

- A ausência é intencional e está documentada no próprio código: a projeção só é renderizada quando a
  espécie tem DAP projetado para 10 anos, e **palmeiras não seguem a alometria de DAP** usada no
  modelo. Confirmado em execução: a consulta pelo texto "Projeção em 10 anos" encontrou 0 ocorrências
  nesta ficha e 1 na ficha do Ipê-roxo-de-bola.
- Consequência para o catálogo: nas ordenações por CO₂ e por crescimento, espécies sem projeção são
  tratadas como valor zero e ficam no fim da lista.

**Estados relacionados:** `14-especie-detalhe-p2`

### Ficha no tema escuro

![Modal do Oiti em tema escuro: foto no topo, textos claros sobre fundo preto](../shots/14-especie-detalhe-dark.png)

**Rota:** sobreposto a `/` (busca por "Oiti") · **Quem acessa:** qualquer pessoa
· **Viewport/tema:** desktop escuro (topo do modal)

**Elementos visíveis:**

- Cartão preto; nome **"Oiti"** em verde-claro e *Licania tomentosa* em cinza.
- **Morfologia:** *Altura adulta* **15m**; *Copa* **10m (Grande)**; *Porte* **Médio**;
  *Forma da Copa* **Arredondada**; *DAP (Diâmetro)* **50cm**; *1ª Bifurcação* **2,0 - 3,0**.
- **Tolerâncias Ecológicas** com as pílulas "Sim/Sim/Não" e os indicadores de cinco quadradinhos, em
  verde-claro sobre cinza-escuro.
- Os rótulos de seção continuam em versalete verde; a legibilidade se mantém.

**Ações possíveis / o que acontece:** idênticas ao tema claro.

**Estados relacionados:** `14-especie-detalhe-p1`, `13-catalogo-grid-dark`

---

## Observações sobre o comportamento observado

- O modal de detalhe **não rola internamente**: quem rola é a camada que o contém, de modo que a
  ficha inteira desliza sob o cabeçalho da página. Por isso as fichas mais longas exigiram duas
  capturas.
- O botão de favorito aparece na ficha na mesma posição do "×" (ligeiramente à esquerda dele), o que
  exige atenção para não fechar o modal por engano.
- A comparação e o detalhe não alteram a URL: não é possível compartilhar o link de uma ficha ou de
  uma comparação específica.
