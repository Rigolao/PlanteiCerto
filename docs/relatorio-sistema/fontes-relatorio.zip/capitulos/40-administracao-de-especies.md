# Painel administrativo — gestão de espécies

O PlanteiCerto tem uma área restrita, separada do site público, onde a equipe do projeto mantém o
catálogo de espécies arbóreas que alimenta o buscador, a recomendação e os projetos de arborização.
Essa área vive sob o prefixo `/admin`, é protegida pela guarda `AdminRoute`
(`src/components/auth/AdminRoute.tsx`) e usa uma moldura própria, o `AdminLayout`
(`src/components/layout/AdminLayout.tsx`), sem o cabeçalho do site. A tela principal é a
`AdminTreesPage` (`src/pages/AdminTreesPage.tsx`), composta por uma tabela de dados
(`src/components/admin/TreeDataTable.tsx`) e por um formulário em modal
(`src/components/admin/TreeFormModal.tsx`), que por sua vez reúne os componentes auxiliares
`FormSection`, `RatingInput` e `ImageUpload`. Todas as gravações passam pelos hooks de
`src/hooks/useAdminTrees.ts`, que falam diretamente com a tabela `trees` do Supabase e com o bucket
de imagens `tree-images`.

No ambiente documentado o banco tinha **167 espécies cadastradas** (146 delas com o campo `ativa`
ligado, ou seja, visíveis para o público). Todas as capturas foram feitas com a conta
`admin.demo@planteicerto.local` (papel `admin`), em desktop 1440×900 e tema claro, salvo indicação
em contrário. A espécie "Zz Espécie de Teste" que aparece em algumas telas foi criada apenas para a
documentação, mantida fora do catálogo público (`ativa = false`) e excluída ao final.

---

## Acesso e guarda de rota

### AdminRoute — verificação de permissões

![Tela de carregamento com folha verde e a frase Verificando permissões](../shots/40-admin-guard-verificando.png)

**Rota:** `/admin/arvores` (e `/admin/equipe`) — estado exibido logo após a navegação, enquanto o
perfil do usuário é lido no banco · **Quem acessa:** qualquer pessoa autenticada que tente entrar na
área administrativa · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Tela inteira vazia, fundo creme, conteúdo centralizado vertical e horizontalmente.
- Ícone de folha verde (SVG estilo "leaf") em animação de pulsação, com cerca de 48 px.
- Abaixo do ícone, o texto "Verificando permissões..." em cinza médio, também pulsando.
- Nenhum menu, cabeçalho ou botão: a moldura administrativa só é montada depois da verificação.

**Ações possíveis / o que acontece:**
- Nenhuma ação do usuário. O estado dura o tempo de duas consultas: a sessão do `AuthContext` e a
  linha correspondente em `profiles` (hook `useProfile`). Em ambiente local isso leva frações de
  segundo; a captura foi obtida atrasando artificialmente a resposta de `profiles`.
- Ao terminar: se não houver sessão, redireciona para `/`; se houver sessão sem `role = 'admin'`,
  redireciona para `/` e dispara o toast de acesso restrito; se for admin, o `AdminLayout` é montado.

**Estados relacionados:** 40-admin-acesso-negado, 40-admin-loading-tabela

### Acesso negado a usuário comum

![Catálogo público aberto com um toast vermelho de acesso restrito na parte inferior](../shots/40-admin-acesso-negado.png)

**Rota:** digitou-se `/admin/arvores` e o sistema devolveu `/` — **Quem acessa:** usuário autenticado
sem papel de administrador (conta `usuario.demo@planteicerto.local`) · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- A tela mostrada é o **catálogo público** (`/`), não a área administrativa: cabeçalho com o logo
  "PlanteiCerto", logos da UNAERP e do Mestrado, links "Árvores" e "Quem Somos", avatar
  "Usuária Demon…" e botão redondo de tema.
- Título "Encontre a árvore certa", subtítulo sobre arborização urbana, botão verde
  "Encontrar Árvore Recomendada", barra de busca, ordenador "Nome (A → Z)", botão "Favoritos 3" e
  "Filtros Avançados"; contador "Mostrando 6 de 146 árvores" e a grade de cartões.
- Na parte inferior central, um toast vermelho-claro com ícone de alerta e o texto literal
  **"Acesso restrito a administradores."**.

**Ações possíveis / o que acontece:**
- O redirecionamento é automático (`<Navigate to="/" replace />`): a URL `/admin/arvores` some do
  histórico e o usuário fica no catálogo. O toast desaparece sozinho em cerca de 4 segundos.
- O `AdminRoute` usa um `useRef` para garantir que o aviso apareça uma única vez por montagem.

**Estados relacionados:** 40-admin-guard-verificando

---

## AdminLayout — a moldura do painel

### Barra lateral (desktop)

![Barra lateral branca com logo, título Admin, itens Árvores e Equipe e rodapé Voltar ao site](../shots/40-admin-sidebar.png)

**Rota:** presente em todas as rotas `/admin/*` · **Quem acessa:** administrador · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Coluna fixa de 264 px (classe `w-64`), fundo de cartão, separada do conteúdo por uma borda fina.
- No topo, faixa de 64 px com o logotipo circular do PlanteiCerto (árvore com "check") e a palavra
  **"Admin"** em negrito.
- Navegação com dois itens, cada um com ícone à esquerda: **"Árvores"** (ícone de duas árvores) e
  **"Equipe"** (ícone de duas pessoas). O item ativo — "Árvores" na captura — recebe fundo verde
  bem claro e texto verde; o inativo fica em cinza.
- No rodapé, separado por uma borda, o botão **"Voltar ao site"** com ícone de seta para a esquerda.
- Não há alternador de tema nesta barra: o painel segue o tema já salvo em `localStorage`.

**Ações possíveis / o que acontece:**
- "Árvores" → navega para `/admin/arvores`; "Equipe" → `/admin/equipe`; "Voltar ao site" → `/`.

**Estados relacionados:** 40-admin-sidebar-mobile, 47-equipe-tabela

### Painel de espécies no mobile

![Tela estreita com barra superior Admin e hambúrguer, título Gerenciar Árvores e tabela reduzida](../shots/40-admin-arvores-mobile.png)

**Rota:** `/admin/arvores` · **Quem acessa:** administrador · **Viewport/tema:** mobile 390×844, claro

**Elementos visíveis:**
- Barra superior fixa de 56 px com o logotipo e a palavra "Admin" centralizados e um botão
  hambúrguer (três traços) à direita. A barra lateral fixa desaparece abaixo de `md`.
- Conteúdo em coluna única: "Gerenciar Árvores", "167 árvores cadastradas", botão verde de largura
  total "Cadastrar Nova Árvore", campo de busca e a tabela.
- A tabela mostra apenas as colunas **ID, Foto, Nome Popular e Status**; "Nome Científico" some
  abaixo de `md` e "Porte"/"Origem" abaixo de `lg`. A coluna "Ações" existe, mas fica fora da área
  visível — o contêiner da tabela rola horizontalmente (`overflow-x-auto`).
- Rodapé com "Mostrando 1–5 de 167", "Por página: 5" e a paginação "1 / 34" em duas linhas.

**Ações possíveis / o que acontece:**
- Hambúrguer → abre a folha lateral (ver captura seguinte). Arrastar a tabela para a esquerda revela
  os botões de editar e excluir.

**Estados relacionados:** 40-admin-sidebar-mobile

### Folha lateral de navegação (mobile)

![Folha branca deslizando da direita com Admin, X, Árvores, Equipe e Voltar ao site](../shots/40-admin-sidebar-mobile.png)

**Rota:** `/admin/arvores` com o menu aberto · **Quem acessa:** administrador · **Viewport/tema:** mobile claro

**Elementos visíveis:**
- Painel de 280 px encostado na borda direita, cobrindo cerca de 70 % da largura; o restante da tela
  fica escurecido e desfocado (fundo preto a 40 % com `backdrop-blur`).
- Cabeçalho da folha: logotipo + "Admin" à esquerda e botão "✕" à direita.
- Os mesmos dois itens de navegação ("Árvores" destacado em verde, "Equipe" em cinza) e, no rodapé,
  "Voltar ao site".

**Ações possíveis / o que acontece:**
- "✕" ou clique na área escurecida → fecha a folha. Escolher um item navega e fecha automaticamente
  (o `AdminLayout` fecha a folha a cada mudança de rota). Enquanto aberta, o `body` fica com
  rolagem travada.

---

## Tela "Gerenciar Árvores"

### Lista completa

![Painel administrativo com barra lateral, título Gerenciar Árvores, busca e tabela de cinco espécies](../shots/40-admin-arvores-lista.png)

**Rota:** `/admin/arvores` — acessível pela barra lateral, pelo item "Administração" do menu do
usuário no site ou por URL direta · **Quem acessa:** administrador · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Barra lateral descrita acima, à esquerda.
- Cabeçalho da página: ícone de pinheiro verde + título **"Gerenciar Árvores"**; logo abaixo, em
  cinza, o contador **"167 árvores cadastradas"** (o texto muda para "1 árvore cadastrada" no
  singular). À direita, o botão verde-escuro **"Cadastrar Nova Árvore"** com um "+".
- Campo de busca de largura limitada com o placeholder
  **"Buscar por nome popular ou científico..."**.
- Tabela com as colunas, da esquerda para a direita: **ID, Foto, Nome Popular, Nome Científico,
  Porte, Origem, Status, Ações**. O cabeçalho tem fundo cinza-claro; as colunas ordenáveis exibem um
  pequeno ícone de setas.
- As cinco primeiras linhas, na ordem padrão (ID crescente): #1 Oiti / *Licania tomentosa* / Médio /
  Nativa BR; #2 Resedá extremosa / *Lagerstroemia indica* / Médio / Exótica; #3 Pata-de-vaca /
  *Bauhinia forficata*; #4 Sabão-de-soldado / *Sapindus saponaria*; #5 Uvaia /
  *Eugenia pyriformis Cambess.*
- Coluna ID em fonte monoespaçada com "#" (ex.: "#1"); coluna Foto com miniatura quadrada de 40 px
  e cantos arredondados; Nome Científico em itálico; Origem como *pill* — verde para "Nativa BR",
  azul para "Exótica"; Status como caixa de seleção marcada; Ações com dois ícones (lápis e lixeira).
- Rodapé: **"Mostrando 1–5 de 167"** à esquerda; à direita "Por página:" com um seletor em "5",
  setas "‹" (desabilitada) e "›" e o indicador **"1 / 34"**.

**Ações possíveis / o que acontece:**
- "Cadastrar Nova Árvore" → abre o modal de cadastro (ver 43-admin-form-dados-basicos).
- Lápis (`title="Editar"`) → abre o modal já preenchido; lixeira (`title="Excluir"`) → abre o
  diálogo de confirmação com verificação de uso.
- Caixa de seleção da coluna Status → liga/desliga o campo `ativa` da espécie imediatamente.
- Clicar nos cabeçalhos ordenáveis reordena a lista; digitar na busca filtra; o seletor muda o
  tamanho da página.

**Estados relacionados:** 40-admin-loading-tabela, 40-admin-arvores-dark, 41-admin-*

### Carregando árvores

![Painel com a barra lateral já montada e apenas o texto Carregando árvores no centro](../shots/40-admin-loading-tabela.png)

**Rota:** `/admin/arvores` durante a consulta à tabela `trees` · **Quem acessa:** administrador ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- A barra lateral já está montada (a guarda de permissão passou), mas a área de conteúdo traz apenas
  a frase **"Carregando árvores..."** em cinza, centralizada horizontalmente e a cerca de 80 px do
  topo, com animação de pulsação. Não há título, botão nem tabela.

**Ações possíveis / o que acontece:**
- Nenhuma. Quando a consulta do hook `useTrees` responde (cache de 15 minutos), a página completa
  substitui esse bloco. A captura foi obtida atrasando a resposta de `/rest/v1/trees`.

### Tema escuro

![Mesmo painel em fundo preto, com textos claros e pills coloridos preservados](../shots/40-admin-arvores-dark.png)

**Rota:** `/admin/arvores` · **Quem acessa:** administrador · **Viewport/tema:** desktop escuro

**Elementos visíveis:**
- Fundo geral quase preto; barra lateral em cinza muito escuro, item ativo "Árvores" com um verde
  esmaecido de fundo e texto verde-claro.
- Título "Gerenciar Árvores" em branco; o botão "Cadastrar Nova Árvore" fica verde mais vivo.
- Cabeçalho da tabela em cinza escuro; linhas separadas por bordas discretas; os *pills* "Nativa BR"
  e "Exótica" ganham versões escuras (verde e azul translúcidos) com texto claro.
- As mesmas cinco espécies e o mesmo rodapé de paginação da versão clara.

**Ações possíveis / o que acontece:**
- Idênticas à versão clara. O painel não tem botão de tema próprio: ele herda a preferência salva
  pelo `ThemeContext` no site público.

---

## A tabela de espécies (`TreeDataTable`)

### Ordenação por "Nome Popular" (crescente)

![Tabela ordenada alfabeticamente começando em Abacateiro](../shots/41-admin-ordenacao-asc.png)

![Zoom no cabeçalho mostrando a seta para cima ao lado de Nome Popular](../shots/41-admin-ordenacao-asc-zoom.png)

**Rota:** `/admin/arvores` após um clique no cabeçalho "Nome Popular" · **Quem acessa:** administrador ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- O cabeçalho "Nome Popular" fica em cor de texto forte e exibe uma **seta para cima (↑) verde**; os
  demais cabeçalhos ordenáveis mantêm o ícone neutro de setas duplas (⇅) esmaecido. O cabeçalho
  "ID", que estava com ↑, volta ao ícone neutro.
- As cinco primeiras linhas passam a ser: #28 Abacateiro; Abacate / *Persea americana* / Grande /
  Exótica / Status desmarcado; #36 Acerola / *Malpighia emarginata* / Pequeno / Exótica /
  desmarcado; #26 "Acerola; Aceroleira; Cereja-das-antilhas; Cerejeira-do-Pará" /
  *Malpighia glabra L.* / Pequeno / Exótica / desmarcado; #8 Açoita-cavalo /
  *Luehea divaricata Mart.* / Grande / Nativa BR / marcado; #108 Açoita-cavalo /
  *Luehea divaricata* / Grande / Nativa BR / marcado.
- O rodapé continua "Mostrando 1–5 de 167 · 1 / 34": ordenar não altera o total nem a página.

**Ações possíveis / o que acontece:**
- A ordenação é feita no cliente, com `localeCompare` em pt-BR para textos, portanto respeita
  acentos e cedilha. Nulos vão para o fim na ordem crescente.
- Um novo clique no mesmo cabeçalho inverte o sentido; clicar em outro cabeçalho reinicia em
  crescente.

**Estados relacionados:** 41-admin-ordenacao-desc

### Ordenação por "Nome Popular" (decrescente)

![Tabela ordenada de Z para A começando em Uvaia](../shots/41-admin-ordenacao-desc.png)

![Zoom no cabeçalho mostrando a seta para baixo ao lado de Nome Popular](../shots/41-admin-ordenacao-desc-zoom.png)

**Rota:** `/admin/arvores` após o segundo clique no mesmo cabeçalho · **Quem acessa:** administrador ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- O ícone ao lado de "Nome Popular" passa a ser uma **seta para baixo (↓) verde**.
- Linhas: #5 Uvaia / *Eugenia pyriformis Cambess.*; #44 Tuia / *Thuja occidentalis* / Exótica —
  com a caixa **Status desmarcada**, ou seja, uma espécie oculta do catálogo público; #74
  Tarumã-do-cerrado / *Vitex polygama*; #73 Suinã / *Erythrina speciosa* / Pequeno; #72 Sombreiro /
  *Clitoria fairchildiana*.

**Ações possíveis / o que acontece:**
- Terceiro clique volta ao sentido crescente. A comparação é sempre sobre o valor exibido na coluna.

### Paginação

![Rodapé com Mostrando 1 a 5 de 167, seletor Por página em 5 e indicador 1 de 34](../shots/41-admin-paginacao-rodape.png)

**Rota:** `/admin/arvores` (recorte do rodapé) · **Quem acessa:** administrador · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- À esquerda, **"Mostrando 1–5 de 167"** (o intervalo é calculado sobre a lista já filtrada e
  ordenada). À direita, o rótulo "Por página:" e um `<select>` nativo exibindo "5"; em seguida a
  seta "‹" esmaecida (desabilitada na primeira página), o contador **"1 / 34"** e a seta "›".
- As opções do seletor são **5, 10 e 15** — em captura de tela um `<select>` aberto não é
  renderizado, por isso as opções estão descritas aqui em texto e o efeito da escolha aparece na
  captura seguinte.
- O bloco de setas só é renderizado quando há mais de uma página.

**Ações possíveis / o que acontece:**
- Trocar o valor do seletor recalcula as páginas e volta para a primeira.
- "›"/"‹" avançam e retrocedem uma página. Se a página atual deixar de existir após um filtro, o
  componente volta sozinho para a primeira.

### 15 itens por página

![Tabela com quinze linhas e rodapé Mostrando 1 a 15 de 167, 1 de 12](../shots/41-admin-paginacao-15.png)

**Rota:** `/admin/arvores` com "Por página" em 15 · **Quem acessa:** administrador · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Quinze linhas visíveis (IDs #1 a #15 na ordem padrão) e a página total da tela cresce para
  aproximadamente 1154 px de altura.
- Rodapé: **"Mostrando 1–15 de 167"**, seletor em "15", contador **"1 / 12"**.

**Ações possíveis / o que acontece:**
- A mudança é instantânea e não recarrega dados: a paginação é feita no cliente sobre a lista já
  baixada.

### Segunda página

![Tabela com quinze linhas a partir do ID 16 e rodapé Mostrando 16 a 30 de 167](../shots/41-admin-paginacao-pagina2.png)

**Rota:** `/admin/arvores`, página 2 · **Quem acessa:** administrador · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Rodapé **"Mostrando 16–30 de 167"**, seletor "15", contador **"2 / 12"**, agora com as duas setas
  habilitadas.
- Linhas de #16 Amarelinho (*Helietta apiculata*) a #31 Primavera (*Bougainvillea glabra Choisy*).
  Os identificadores **não são contínuos** — não existe espécie com ID 24 —, o que evidencia que o
  "#" é a chave real da tabela `trees` e não uma posição na lista.
- Metade das linhas desta página está com a caixa de Status desmarcada (#26 a #31), ou seja,
  espécies cadastradas mas ainda fora do catálogo público.
- Duas linhas (#19 Araçarana e #30 Cajá-manga) aparecem com a célula "Foto" vazia: têm URL de foto
  gravada, mas a imagem não carregou.
- Nesta largura os *pills* "Nativa BR" quebram em duas linhas dentro da célula.

**Ações possíveis / o que acontece:**
- "‹" volta para a página 1.

### Busca por texto

![Tabela filtrada pelo termo ipê mostrando cinco espécies de ipê](../shots/41-admin-busca-ipe.png)

**Rota:** `/admin/arvores` com "ipê" digitado na busca · **Quem acessa:** administrador ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- O campo de busca mostra o texto "ipê" e ganha borda verde de foco.
- Resultados: #23 Ipê-roxo-de-bola / *Handroanthus impetiginosus (Mart. ex DC.) Mattos* / Grande /
  Nativa BR / ativo; #32 Ipê-branco / *Handroanthus albus* / Grande / Nativa BR / **inativo**;
  #43 Ipê-amarelo-de-jardim / *Tecoma stans* / Pequeno / Exótica / **inativo**; #91 Ipê-roxo-da-mata /
  *Tabebuia avellanedae* / Grande / Nativa BR / ativo; #99 Ipê-roxo-de-bola /
  *Handroanthus impetiginosus* / Grande / Nativa BR / ativo.
- Rodapé: **"Mostrando 1–5 de 16"** e contador **"1 / 4"** — o filtro reduz o universo de 167 para
  16 espécies.

**Ações possíveis / o que acontece:**
- O filtro é imediato (sem *debounce*), roda no cliente e compara o termo em minúsculas contra
  `nome_popular` **e** `nome_cientifico`. Não há normalização de acentos: buscar "ipe" sem acento
  encontra menos registros do que "ipê".

### Busca sem resultados

![Painel com o termo xyzabc na busca e a frase Nenhuma árvore encontrada para esta busca](../shots/41-admin-busca-sem-resultado.png)

**Rota:** `/admin/arvores` com termo inexistente · **Quem acessa:** administrador · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Campo de busca com "xyzabc". No lugar da tabela, a frase centralizada em cinza
  **"Nenhuma árvore encontrada para esta busca."**.
- O contador do cabeçalho continua "167 árvores cadastradas" (ele conta o total, não o filtro) e
  **o rodapé de paginação desaparece por completo** nesse estado.
- Quando não há busca digitada e a base está vazia, o mesmo espaço exibiria
  "Nenhuma árvore cadastrada." (mensagem não observada neste ambiente, que sempre teve dados).

**Ações possíveis / o que acontece:**
- Apagar o termo restaura a tabela e a paginação.

### Coluna "Foto": miniatura × marcador de espécie sem imagem

![Recorte da tabela com a primeira linha exibindo um ícone de pinheiro e as demais miniaturas fotográficas](../shots/41-admin-sem-foto.png)

**Rota:** `/admin/arvores`, ordenado por Nome Popular decrescente · **Quem acessa:** administrador ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- Primeira linha: **#200 "Zz Espécie de Teste" / *Zz Especimen demonstrativo***, criada sem foto —
  a célula mostra um quadrado cinza-claro de 40 px com um **ícone de pinheiro** no centro; as
  colunas Porte exibem "—" e Status está desmarcado (espécie inativa).
- Linhas seguintes (#5 Uvaia, #44 Tuia, #74 Tarumã-do-cerrado, #73 Suinã) exibem miniaturas
  fotográficas reais, recortadas em quadrado (`object-cover`).

**Ações possíveis / o que acontece:**
- O marcador de pinheiro só aparece quando o campo `foto` é **nulo**. Se a URL existir mas a imagem
  falhar ao carregar (caso das linhas #19 e #30 vistas em 41-admin-paginacao-pagina2), a célula fica
  simplesmente vazia — não há tratamento de erro de carregamento.
- Nenhuma das 167 espécies reais do banco tinha `foto` nula; a linha de exemplo foi inserida só para
  esta captura e removida em seguida.

### Coluna "Status" — ativar e desativar a espécie

![Tabela filtrada pela espécie de teste com a caixa Status desmarcada e toast de árvore atualizada](../shots/45-admin-status-desmarcado.png)

**Rota:** `/admin/arvores` com a busca "Zz" · **Quem acessa:** administrador · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Uma única linha: **#202 "Zz Espécie de Teste"**, com a caixa da coluna Status agora **desmarcada**.
- Toast verde na base da tela: **"Árvore atualizada com sucesso!"**.
- Contador do cabeçalho em "168 árvores cadastradas" (167 reais + a espécie de demonstração).

**Ações possíveis / o que acontece:**
- Clicar na caixa chama `useUpdateTree` com `{ ativa: !ativa }` e dispara o toast acima; em caso de
  erro apareceria "Erro ao atualizar árvore: …".
- O `title` da caixa alterna entre "Desativar visualização" (quando marcada) e
  "Ativar visualização" (quando desmarcada).
- Efeito prático: com `ativa = false` a espécie continua visível para administradores, mas some do
  catálogo público, da recomendação e da seleção de árvores dos projetos — a política de leitura da
  tabela `trees` libera para o público apenas as linhas com `ativa = true`.

---

## O formulário de espécie (`TreeFormModal`)

O modal é o mesmo para cadastro e edição. Tem largura máxima de 896 px (`max-w-4xl`), título no
topo, **seis seções recolhíveis** (`FormSection`) numa área que rola internamente (altura máxima de
70 % da janela) e, fixa no rodapé, a dupla de botões "Cancelar" e "Salvar". Um "×" no canto superior
direito também fecha o modal, assim como a tecla Esc ou um clique no fundo escurecido. Ao abrir,
apenas a primeira seção vem expandida; as outras mostram só o título e uma seta para baixo, que gira
180° quando a seção abre.

### Seção 1 — Dados Básicos

![Modal Cadastrar Nova Árvore com a seção Dados Básicos aberta e as demais recolhidas](../shots/43-admin-form-dados-basicos.png)

**Rota:** `/admin/arvores` → botão "Cadastrar Nova Árvore" · **Quem acessa:** administrador ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- Título **"Cadastrar Nova Árvore"** em negrito no topo do cartão branco.
- Seção **"Dados Básicos"** aberta, em grade de duas colunas, com:
  - **"Nome Popular *"** — campo de texto vazio, limite de 150 caracteres;
  - **"Nome Científico *"** — campo de texto vazio, limite de 150 caracteres;
  - **"Origem"** — lista suspensa em "Nativa BR" (outra opção: "Exótica");
  - **"Folhagem"** — lista suspensa em "Perenifólia" (outras: "Decídua", "Semidecídua");
  - caixa de seleção **"Disponibilizar árvore no catálogo (Ativa)"**, marcada por padrão;
  - campo **"Foto"** ocupando as duas colunas, com a área tracejada de upload.
- Abaixo, as seções recolhidas "Morfologia", "Tolerâncias Ecológicas", "Fenologia" e
  "Urbanismo & Riscos" — a sexta ("Projeção de Crescimento (10 anos)") fica logo abaixo da dobra da
  área rolável.
- Rodapé fixo com "Cancelar" (contorno) e **"Salvar"** (verde, com ícone de disquete).

**Ações possíveis / o que acontece:**
- Clicar no título de qualquer seção expande ou recolhe aquele bloco; várias podem ficar abertas ao
  mesmo tempo.
- "Cancelar", "×", Esc ou clique fora fecham o modal descartando o que foi digitado.

**Estados relacionados:** 45-admin-form-validacao, 45-admin-form-preenchido, 46-admin-form-editar

### Seção 2 — Morfologia

![Modal com a seção Morfologia aberta, sete campos de medidas e classes](../shots/43-admin-form-morfologia.png)

**Elementos visíveis:** sete campos em duas colunas —
**"Altura Máxima (m)"** (numérico), **"Porte"** (lista: —, Pequeno, Médio, Grande),
**"Diâmetro Copa (m)"** (numérico), **"Classe Copa"** (lista: —, Pequena, Média, Grande),
**"DAP Máximo (cm)"** (numérico), **"Alt. 1ª Bifurcação"** (texto livre) e
**"Forma da Copa"** (texto, até 100 caracteres). As listas começam na opção "—", que grava nulo.

**Ações possíveis:** todos os campos são opcionais; campos numéricos vazios são gravados como nulo
(não como zero).

### Seção 3 — Tolerâncias Ecológicas

![Modal com a seção Tolerâncias Ecológicas aberta, três caixas de luminosidade e nove escalas de 1 a 5](../shots/43-admin-form-tolerancias.png)

**Elementos visíveis:**
- Subtítulo **"Luminosidade"** com três caixas de seleção lado a lado: **"Sol Pleno"**,
  **"Meia Sombra"** e **"Sombra"**.
- Nove escalas de 1 a 5 (`RatingInput`), em duas colunas, cada uma com um rótulo e cinco botões
  circulares numerados: **"Tolerância à Seca"**, **"Tolerância ao Encharcamento"**,
  **"Tolerância à Poluição"**, **"Tolerância à Compactação"**, **"Tolerância a Ventos Fortes"**,
  **"Tolerância à Poda"**, **"Atração da Fauna"**, **"Potencial de Sombra"** e
  **"Contribuição à Biodiversidade"**.
- Esta é a seção mais alta do formulário: com ela aberta a área interna passa a rolar, e o título da
  seção anterior fica parcialmente cortado no topo da captura.

### Seção 4 — Fenologia

![Modal com a seção Fenologia aberta e dois campos de época](../shots/43-admin-form-fenologia.png)

**Elementos visíveis:** apenas dois campos de texto, **"Época de Floração"** (placeholder
"Ex: Set-Nov") e **"Época de Frutificação"** (placeholder "Ex: Jan-Mar"), ambos com limite de 100
caracteres. Com só essa seção aberta, as seis faixas de título cabem na tela sem rolagem.

### Seção 5 — Urbanismo & Riscos

![Modal com a seção Urbanismo e Riscos aberta, listas, escalas, medidas mínimas e caixas de risco](../shots/43-admin-form-urbanismo.png)

**Elementos visíveis:**
- **"Compatibilidade Fiação"** — lista com "—", "Compatível" (grava `C`),
  "Compatível com cuidados" (`A`) e "Incompatível" (`N`).
- Duas escalas de 1 a 5: **"Potencial Dano à Calçada"** e **"Potencial de Sujeira"**.
- Três campos numéricos: **"Faixa de Serviço Mín. (m)"**, **"Área Berço Mín. (m²)"** e
  **"Volume Solo Mín. (m³)"**.
- Subtítulo **"Riscos"** com duas caixas: **"Presença de Espinhos"** e **"Substâncias Irritantes"**.

### Seção 6 — Projeção de Crescimento (10 anos)

![Modal com a seção de projeção aberta, nota de cenário e onze campos numéricos](../shots/43-admin-form-projecao.png)

![Continuação da mesma seção mostrando os campos BVOC e a caixa de ressalva](../shots/43-admin-form-projecao-p2.png)

**Elementos visíveis:**
- Logo abaixo do título, uma nota fixa em cinza:
  **"Cenário: boas condições · muda inicial DAP 3 cm / altura 1,5 m · horizonte de 10 anos"** — é
  texto de contexto da planilha de projeção, igual para todas as espécies, e não um campo do banco.
- Onze campos numéricos em duas colunas: **"DAP aos 10 anos (cm)"**, **"Altura aos 10 anos (m)"**,
  **"DAP mínimo (cm)"**, **"Altura mínima (m)"**, **"DAP máximo (cm)"**, **"Altura máxima (m)"**,
  **"Biomassa aérea (kg)"**, **"Carbono armazenado (kg C)"**, **"CO₂e (kg)"**,
  **"CO₂e esperado por muda (kg)"** e **"Sobrevivência (%)"**.
- **"Classe BVOC"** — lista com "—", "Baixo", "Moderado", "Alto", "Desconhecido", "Indeterminado".
- **"Confiança da Classe BVOC"** — lista com "—", "Baixa", "Baixa-média", "Média", "Média-alta".
- **"Evidência da Classe BVOC"** — campo de texto de largura total, placeholder
  "Ex: fator de gênero i-Tree", até 200 caracteres.
- Caixa de seleção **"Exibir ressalva sobre a classificação BVOC"**, visível apenas na segunda
  captura, depois de rolar a área interna do modal.

**Ações possíveis / o que acontece:**
- Esta seção é a única que não cabe inteira na altura útil do modal: é preciso rolar dentro dele
  para chegar aos campos BVOC. As duas capturas mostram o início e o fim da mesma seção.

### `RatingInput` — escala de 1 a 5 com botão "Limpar"

![Escala Tolerância à Seca com os círculos de 1 a 4 verdes, o 5 apagado e o link Limpar](../shots/44-admin-rating-valor.png)

**Rota:** dentro do modal, seção "Tolerâncias Ecológicas" · **Quem acessa:** administrador ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- Rótulo pequeno **"Tolerância à Seca"** e, abaixo, cinco botões circulares numerados de 1 a 5.
- Com a nota 4 escolhida, os círculos **1, 2, 3 e 4 ficam verde-escuros com número branco** (barra
  cumulativa) e o 5 permanece cinza-claro.
- À direita dos círculos aparece o botão de texto **"Limpar"**, que só existe quando há valor.

**Ações possíveis / o que acontece:**
- Clicar num número define a nota; clicar de novo no **mesmo** número zera o campo (volta a nulo).
- "Limpar" também devolve o campo a nulo e some em seguida.
- O mesmo componente é usado doze vezes no formulário (nove em Tolerâncias Ecológicas e duas em
  Urbanismo & Riscos, além de "Potencial Dano à Calçada").

### `ImageUpload` — área vazia

![Retângulo tracejado com ícone de upload e a frase Arraste uma imagem ou clique para selecionar](../shots/44-admin-upload-vazio.png)

**Elementos visíveis:** rótulo "Foto"; retângulo de 128 px de altura e largura total, borda
tracejada cinza, ícone de seta para cima no centro e os textos
**"Arraste uma imagem ou clique para selecionar"** e, menor, **"Máx. 5MB"**. O campo de arquivo real
fica oculto dentro do rótulo e aceita `image/*`.

### `ImageUpload` — arrastando um arquivo sobre a área

![Mesma área com borda e ícone verdes e fundo verde bem claro](../shots/44-admin-upload-dragover.png)

**Elementos visíveis:** ao arrastar um arquivo sobre a zona, a borda tracejada e o ícone ficam
**verdes** e o interior ganha um fundo verde translúcido; o ícone muda de "seta para cima" para um
símbolo de **imagem**. Os textos permanecem os mesmos.

**Ações possíveis / o que acontece:** soltar o arquivo aciona a mesma validação do clique; sair da
área com o cursor devolve o estado neutro. Só arquivos cujo tipo comece por `image/` são aceitos no
soltar.

### `ImageUpload` — arquivo acima do limite

![Área de upload neutra com a mensagem vermelha Arquivo muito grande. Máximo: 5MB.](../shots/44-admin-upload-erro-tamanho.png)

**Elementos visíveis:** a zona tracejada volta ao estado neutro e, logo abaixo dela, surge em
vermelho a mensagem **"Arquivo muito grande. Máximo: 5MB."**. Nenhuma prévia é gerada.

**Ações possíveis / o que acontece:** o arquivo é descartado no cliente, antes de qualquer envio ao
Supabase. Escolher um arquivo válido limpa a mensagem.

### `ImageUpload` — prévia da imagem escolhida

![Miniatura quadrada da imagem escolhida com um botão vermelho de X no canto superior direito](../shots/44-admin-upload-previa.png)

**Elementos visíveis:** a área tracejada é substituída por uma miniatura de 128×128 px com cantos
arredondados e recorte `object-cover`, e um **botão circular vermelho com "✕"** sobreposto ao canto
superior direito. (A imagem usada na demonstração é uma captura do próprio catálogo, escolhida
apenas como arquivo de teste.)

**Ações possíveis / o que acontece:**
- "✕" remove a escolha e devolve a zona tracejada; em modo de edição, isso também zera o campo
  `foto` da espécie.
- O envio ao bucket `tree-images` só acontece no momento de salvar: o arquivo é gravado com um nome
  aleatório (UUID + extensão original) e o formulário guarda a URL pública devolvida pelo Storage.

### Validação dos campos obrigatórios

![Modal com bordas e mensagens vermelhas sob Nome Popular e Nome Científico](../shots/45-admin-form-validacao.png)

**Rota:** modal de cadastro, botão "Salvar" pressionado com os nomes em branco ·
**Quem acessa:** administrador · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Sob o campo "Nome Popular *", em vermelho: **"Nome popular é obrigatório"**; sob "Nome Científico *":
  **"Nome científico é obrigatório"**.
- O primeiro campo inválido recebe o foco (contorno verde na captura).
- A foto já escolhida continua na prévia e as demais seções permanecem recolhidas — a validação não
  reabre seções nem limpa nada.

**Ações possíveis / o que acontece:**
- Nada é enviado ao servidor enquanto houver erro. As duas mensagens somem assim que os campos são
  preenchidos.
- Há uma terceira regra, de limite: passar de 150 caracteres em qualquer um dos nomes produziria
  **"Máximo de 150 caracteres"**; na prática o próprio `maxLength` do campo impede a digitação, e a
  mensagem não foi observada.

### Formulário preenchido, pronto para salvar

![Modal com Nome Popular e Nome Científico preenchidos, Folhagem Semidecídua e prévia da foto](../shots/45-admin-form-preenchido.png)

**Elementos visíveis:** "Nome Popular *" com "Zz Espécie de Teste", "Nome Científico *" com
"Zz Especimen demonstrativo", "Origem" em "Nativa BR", "Folhagem" em "Semidecídua", a caixa
"Disponibilizar árvore no catálogo (Ativa)" marcada e a prévia da foto. As demais seções aparecem
recolhidas, mas já tinham sido preenchidas (morfologia, nove notas de tolerância, épocas de floração
e frutificação, dados urbanos e projeção de 10 anos).

### Estado "Salvando..."

![Botão do rodapé em verde apagado com um ícone giratório e o texto Salvando](../shots/45-admin-form-salvando.png)

**Elementos visíveis:** o botão verde do rodapé passa a exibir um **círculo em rotação** no lugar do
disquete e o texto muda de "Salvar" para **"Salvando..."**, com opacidade reduzida e cursor de
bloqueio; o botão "Cancelar" continua ativo.

**Ações possíveis / o que acontece:**
- O estado cobre as duas etapas da gravação: primeiro o envio da imagem ao bucket, depois o `insert`
  (ou `update`) na tabela `trees`. Enquanto durar, o botão fica desabilitado, evitando envio duplo.

### Espécie cadastrada

![Painel com uma única linha na tabela e toast verde Árvore cadastrada com sucesso](../shots/45-admin-toast-cadastrada.png)

![Recorte da tabela mostrando a linha 202 com miniatura, nomes, Porte Médio e Status marcado](../shots/45-admin-tabela-zz.png)

**Elementos visíveis:**
- O modal fechou sozinho. Toast verde na base: **"Árvore cadastrada com sucesso!"**.
- O contador do cabeçalho subiu para "168 árvores cadastradas" e a busca "Zz" deixa visível só a
  linha nova: **#202 · miniatura · "Zz Espécie de Teste" · *Zz Especimen demonstrativo* · Médio ·
  Nativa BR · Status marcado · lápis e lixeira**. Rodapé: "Mostrando 1–1 de 1".
- O ID é atribuído pelo banco; a espécie entra no fim da sequência.

**Ações possíveis / o que acontece:**
- O cache da consulta `trees` é invalidado, então a linha aparece sem recarregar a página.
- Em caso de falha o toast seria vermelho, com "Erro ao cadastrar árvore: …" e o modal permaneceria
  aberto.

### Modal de edição

![Modal intitulado Editar: Zz Espécie de Teste com os campos já preenchidos](../shots/46-admin-form-editar.png)

**Rota:** `/admin/arvores` → ícone de lápis na linha · **Quem acessa:** administrador ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- Título **"Editar: Zz Espécie de Teste"** (o modal usa o nome popular da espécie).
- Todos os campos vêm carregados do banco: nomes preenchidos, "Origem" em "Nativa BR", "Folhagem" em
  "Semidecídua", a caixa "Disponibilizar árvore no catálogo (Ativa)" **desmarcada** (a espécie havia
  sido desativada pela coluna Status) e a foto atual exibida na prévia com o "✕".
- A estrutura de seções é idêntica à do cadastro, sempre reabrindo em "Dados Básicos".

**Ações possíveis / o que acontece:**
- Salvar chama `useUpdateTree` com o registro inteiro; o formulário é recarregado a cada abertura
  (`reset`), de modo que cancelar não deixa resíduo de uma edição anterior.

### Espécie atualizada

![Painel com toast verde Árvore atualizada com sucesso](../shots/46-admin-toast-atualizada.png)

**Elementos visíveis:** modal fechado e toast verde **"Árvore atualizada com sucesso!"** na base da
tela; a linha permanece na tabela com o Status desmarcado. Na demonstração o campo alterado foi
"Altura Máxima (m)", de 12 para 14 — confirmado no banco depois da gravação.

---

## Exclusão de espécie

A lixeira abre um `ConfirmDialog` que, antes de perguntar qualquer coisa, **conta quantos pontos de
projetos de usuários apontam para aquela espécie** (hook `useTreeUsageCount`, que faz uma contagem
exata na tabela `points`). O texto do diálogo muda conforme o resultado.

### Verificando o uso nos projetos

![Diálogo pequeno com o título Excluir Oiti e a frase Verificando uso nos projetos](../shots/42-admin-excluir-verificando.png)

**Elementos visíveis:** cartão branco e estreito, título **`Excluir "Oiti"?`**, mensagem
**"Verificando uso nos projetos..."** em cinza e, no rodapé, os botões "Cancelar" (contorno) e
**"Excluir"** (vermelho). O "×" de fechar aparece no canto superior direito.

**Ações possíveis / o que acontece:**
- É um estado transitório (no ambiente local dura poucos milissegundos; a captura exigiu atrasar a
  resposta do banco). **O botão vermelho "Excluir" já fica habilitado durante a verificação** — nada
  impede confirmar antes de saber se a espécie está em uso.

### Espécie em uso em projetos

![Diálogo Excluir Oiti com aviso de que a árvore está em uso em um ponto de projeto](../shots/42-admin-excluir-em-uso.png)

**Rota:** `/admin/arvores` → lixeira da linha #1 (Oiti) · **Quem acessa:** administrador ·
**Viewport/tema:** desktop claro

**Elementos visíveis:**
- Título **`Excluir "Oiti"?`** e o texto completo:
  **"Atenção: Esta árvore está sendo usada em 1 ponto de projeto de usuários. Ao excluir, esses
  pontos ficarão sem árvore associada. Esta ação não pode ser desfeita."**
- Com mais de um ponto a frase usa o plural "pontos de projetos".
- Botões "Cancelar" e "Excluir" (vermelho).

**Ações possíveis / o que acontece:**
- Nesta documentação clicou-se em **"Cancelar"**: o diálogo fecha e nada é alterado.
- Confirmar apagaria a linha de `trees`; os pontos de projeto que a referenciam ficariam sem espécie
  associada (a chave estrangeira em `points.tree_id` é anulada, não bloqueia a exclusão).

### Espécie sem uso

![Diálogo Excluir Zz Espécie de Teste informando que a árvore não está em nenhum projeto](../shots/46-admin-excluir-sem-uso.png)

**Elementos visíveis:** título **`Excluir "Zz Espécie de Teste"?`** e a mensagem
**"Esta árvore não está sendo usada em nenhum projeto. A exclusão é permanente."**, seguida dos
botões "Cancelar" e "Excluir".

### Espécie excluída

![Painel com a busca Zz sem resultados e toast verde Árvore excluída com sucesso](../shots/46-admin-toast-excluida.png)

**Elementos visíveis:** toast verde **"Árvore excluída com sucesso!"**; o contador volta a
"167 árvores cadastradas" e, como a busca "Zz" continua ativa, a área da tabela mostra
"Nenhuma árvore encontrada para esta busca.".

**Ações possíveis / o que acontece:**
- A exclusão é imediata e definitiva; não há lixeira nem desfazer. O arquivo de imagem enviado
  continua no bucket `tree-images` — a exclusão da espécie **não** apaga a foto (ver "Observações").

---

## Fluxo passo a passo — cadastrar uma espécie com imagem

1. Entrar com uma conta de administrador e ir a `/admin/arvores`. Durante a checagem de papel a tela
   mostra "Verificando permissões..." *(ver 40-admin-guard-verificando)*; enquanto as espécies são
   buscadas, "Carregando árvores..." *(ver 40-admin-loading-tabela)*.
2. Clicar em **"Cadastrar Nova Árvore"**. O modal abre com a seção "Dados Básicos" expandida
   *(ver 43-admin-form-dados-basicos)*.
3. Preencher "Nome Popular *" e "Nome Científico *" (obrigatórios) e ajustar "Origem" e "Folhagem".
   Deixar marcada a caixa "Disponibilizar árvore no catálogo (Ativa)" se a espécie já puder aparecer
   para o público.
4. No campo "Foto", arrastar um arquivo de imagem — a área fica verde durante o arraste
   *(ver 44-admin-upload-dragover)* — ou clicar para escolher no disco. Arquivos acima de 5 MB são
   recusados na hora *(ver 44-admin-upload-erro-tamanho)*; os válidos viram uma prévia com "✕"
   *(ver 44-admin-upload-previa)*.
5. Abrir as demais seções e preencher o que houver: medidas em "Morfologia"
   *(ver 43-admin-form-morfologia)*, luminosidade e as nove notas de 1 a 5 em "Tolerâncias
   Ecológicas" *(ver 43-admin-form-tolerancias e 44-admin-rating-valor)*, épocas em "Fenologia"
   *(ver 43-admin-form-fenologia)*, compatibilidade com fiação, riscos e dimensões mínimas do
   canteiro em "Urbanismo & Riscos" *(ver 43-admin-form-urbanismo)* e os números de carbono e
   crescimento em "Projeção de Crescimento (10 anos)" *(ver 43-admin-form-projecao e -p2)*.
6. Clicar em **"Salvar"**. Se algum nome estiver vazio, o envio para e as mensagens de obrigatório
   aparecem *(ver 45-admin-form-validacao)*.
7. Durante a gravação o botão vira "Salvando..." *(ver 45-admin-form-salvando)* — primeiro a imagem
   sobe para o bucket `tree-images`, depois a linha é inserida em `trees`.
8. O modal fecha, surge o toast "Árvore cadastrada com sucesso!" e a espécie já aparece na tabela
   com o novo ID *(ver 45-admin-toast-cadastrada e 45-admin-tabela-zz)*.

## Fluxo passo a passo — editar uma espécie

1. Localizar a espécie pela busca ou pela ordenação/paginação da tabela *(ver 41-admin-busca-ipe)*.
2. Clicar no ícone de lápis da linha. O modal abre com o título "Editar: <nome popular>" e todos os
   campos carregados do banco *(ver 46-admin-form-editar)*.
3. Expandir a seção desejada, alterar os valores e clicar em "Salvar".
4. O modal fecha e aparece o toast "Árvore atualizada com sucesso!"
   *(ver 46-admin-toast-atualizada)*. Para trocar a foto, remover a prévia no "✕" e escolher outra
   imagem antes de salvar.

## Fluxo passo a passo — desativar e reativar uma espécie

1. Na tabela, clicar na caixa da coluna **Status** da linha desejada.
2. A caixa desmarca na hora e aparece o toast "Árvore atualizada com sucesso!"
   *(ver 45-admin-status-desmarcado)*.
3. A espécie continua listada para administradores, mas some do catálogo, da recomendação e da
   escolha de árvores nos projetos. O exemplo real na base é a espécie #44 "Tuia", visível
   desmarcada em 41-admin-ordenacao-desc, e todo o bloco #26–#31 em 41-admin-paginacao-pagina2.
4. Clicar de novo na mesma caixa reativa a espécie, com o mesmo toast. O mesmo efeito pode ser
   obtido pela caixa "Disponibilizar árvore no catálogo (Ativa)" dentro do formulário.

## Fluxo passo a passo — excluir uma espécie

1. Clicar no ícone de lixeira da linha.
2. O diálogo abre e consulta quantos pontos de projetos usam a espécie — durante a consulta mostra
   "Verificando uso nos projetos..." *(ver 42-admin-excluir-verificando)*.
3. Se houver uso, o texto alerta quantos pontos serão afetados *(ver 42-admin-excluir-em-uso)*; se
   não houver, informa que a exclusão é permanente *(ver 46-admin-excluir-sem-uso)*.
4. "Cancelar" fecha sem alterar nada; **"Excluir"** apaga a linha e exibe o toast
   "Árvore excluída com sucesso!" *(ver 46-admin-toast-excluida)*.

## Fluxo passo a passo — tentativa de acesso por usuário comum

1. Com uma conta sem papel de administrador, digitar `/admin/arvores` na barra de endereços.
2. O `AdminRoute` mostra brevemente "Verificando permissões..." enquanto lê o perfil.
3. Como `profiles.role` é `'user'`, a rota devolve um redirecionamento para `/` e dispara o toast
   **"Acesso restrito a administradores."** *(ver 40-admin-acesso-negado)*.
4. Um visitante não autenticado é redirecionado para `/` sem toast (o aviso só é emitido quando há
   sessão sem permissão).

---

## Observações técnicas e divergências observadas

- **A proteção não é só de interface.** A tabela `trees` tem RLS: leitura pública apenas de linhas
  com `ativa = true` (administradores leem tudo) e políticas de `INSERT`, `UPDATE` e `DELETE`
  restritas a quem tem `role = 'admin'` em `profiles`. Mesmo que alguém contorne a tela, o banco
  recusa a gravação.
- **A busca da tabela não normaliza acentos** nem usa *debounce*: "ipe" e "ipê" devolvem conjuntos
  diferentes.
- **O placeholder de pinheiro só cobre `foto` nula.** Quando a URL existe mas a imagem falha ao
  carregar, a célula fica vazia (observado nas linhas #19 e #30).
- **O botão de confirmação do `ConfirmDialog` é sempre vermelho e escrito "Excluir"**, porque o
  componente foi desenhado para exclusões; ele é reaproveitado sem alteração em outros contextos
  (ver o capítulo de gestão da equipe).
- **O botão "Excluir" fica habilitado durante "Verificando uso nos projetos..."**, ou seja, é
  possível confirmar antes de o aviso de uso aparecer.
- **A exclusão de uma espécie não remove a imagem do bucket `tree-images`**: o arquivo enviado
  permanece órfão no Storage. (O arquivo criado nesta documentação foi removido manualmente.)
- **O aviso do diálogo cobre só os pontos de projeto.** No banco, `points.tree_id` é uma chave
  estrangeira `ON DELETE SET NULL` — daí a frase "esses pontos ficarão sem árvore associada" — mas
  os favoritos dos usuários (`user_favorites.tree_id`) são `ON DELETE CASCADE` e somem em silêncio,
  sem menção no diálogo.
- **`src/schemas/tree.ts` existe mas não é usado.** O arquivo define um esquema Zod (`treeSchema`)
  com as mesmas mensagens de erro ("Nome popular é obrigatório", "Máximo de 150 caracteres") e com
  validação de faixa 1–5 para as notas, porém o `TreeFormModal` valida com as regras embutidas do
  `react-hook-form`. O esquema também está desatualizado: não cobre os campos de projeção de 10 anos
  nem os campos BVOC, nem o campo `ativa`.
- **Campos numéricos vazios viram nulo, não zero** — há um comentário explícito no código
  registrando que o uso conjunto de `valueAsNumber` produzia `NaN` e quebrava a gravação; o mesmo
  vale para as listas suspensas, cuja opção "—" precisa converter texto vazio em nulo para não
  violar as restrições de domínio do PostgreSQL.
- **Os identificadores da tabela têm lacunas** (não existe espécie #24), o que confirma que a coluna
  "ID" é a chave primária real e não um contador de exibição.
- **Os textos de dica dos botões** (`title="Editar"`, `title="Excluir"`,
  `title="Desativar visualização"`) são dicas nativas do navegador e, por isso, não aparecem nas
  capturas de tela.
