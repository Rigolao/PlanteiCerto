# Visão Geral do Sistema

## O que é o PlanteiCerto

O PlanteiCerto é uma aplicação web de apoio à decisão para arborização urbana. Seu propósito central é responder, com base em dados estruturados de espécies arbóreas e nas restrições físicas do local de plantio, a uma pergunta prática: qual árvore plantar neste ponto específico da cidade. A própria tela de entrada do sistema enuncia esse objetivo como "Um sistema de recomendação de espécies arbóreas para calçadas urbanas, desenvolvido para apoiar cidadãos na escolha da árvore certa para o lugar certo" (`src/components/auth/IPProtectionGate.tsx:58`). O arquivo `README.md:3` descreve o produto de forma complementar, enfatizando o registro, o gerenciamento e a visualização de plantios e projetos ambientais.

O sistema foi desenvolvido em contexto acadêmico, vinculado à Universidade de Ribeirão Preto (UNAERP) e ao programa de pós-graduação stricto sensu em Tecnologia Ambiental. Essa vinculação está materializada no código: a tela de bloqueio exibe os logotipos institucionais da UNAERP e do Mestrado em Tecnologia Ambiental, com hiperlinks para `https://unaerp.br` e para a página do programa (`src/components/auth/IPProtectionGate.tsx:63-79`), e apresenta os contatos institucionais do autor e do orientador (`src/components/auth/IPProtectionGate.tsx:84-96`) — nomes e endereços que não são reproduzidos aqui, mas que estão no arquivo-fonte. A interface é integralmente em português do Brasil e não há camada de internacionalização: os textos estão embutidos nos componentes.

## Públicos e perfis de acesso

O sistema reconhece três perfis, implementados em duas camadas distintas. A autenticação é feita pelo GoTrue do Supabase e exposta ao aplicativo pelo `AuthContext` (`src/contexts/AuthContext.tsx`); a autorização administrativa é lida da tabela `profiles`, cujo campo `role` assume os valores `'user'` ou `'admin'` (`src/hooks/useProfile.ts:33`).

- **Visitante (não autenticado).** Acessa o catálogo de espécies, a comparação, o detalhamento de cada árvore, a página "Quem Somos" com os guias em PDF e o questionário de recomendação por inteiro, inclusive os resultados. Não tem favoritos nem projetos.
- **Usuário cadastrado.** Acrescenta favoritos (`user_favorites`), projetos de plantio georreferenciados, o painel de estatísticas do projeto, a exportação do relatório em PDF e a página de perfil com troca de senha e de avatar.
- **Administrador.** Acrescenta o painel administrativo em `/admin/arvores` e `/admin/equipe`: CRUD completo do catálogo de espécies, upload de imagens para o bucket `tree-images`, e promoção ou rebaixamento de outros usuários. Administradores também enxergam espécies inativas, porque a política de leitura da tabela `trees` libera `ativa = false` apenas para eles.

## Funcionalidades principais

O catálogo é o núcleo do sistema. O banco local contém **167 espécies**, das quais **146 estão ativas** (`ativa = true`) e visíveis para o público; as 21 restantes permanecem no banco mas só aparecem no painel administrativo. Sobre esse catálogo operam: busca textual insensível a acentos por nome popular ou científico, sete filtros avançados combinados por conjunção lógica (porte, copa, folhagem, nativas, sem espinhos, compatível com fiação, calçadas seguras), sete critérios de ordenação e rolagem infinita de seis em seis cartões (`src/pages/TreesPage.tsx:25`, `src/pages/TreesPage.tsx:79-122`).

A **comparação** permite selecionar até três espécies simultaneamente, com aviso explícito ao exceder o limite — "Você pode comparar no máximo 3 árvores por vez." (`src/pages/TreesPage.tsx:170`) — e apresenta um quadro lado a lado de dimensões, botânica, tolerâncias e uso urbano. Os **favoritos** são persistidos por usuário e filtráveis pelo parâmetro de URL `?favoritos=true` (`src/pages/TreesPage.tsx:48`), com atualização otimista no cliente (`src/hooks/useFavorites.ts:48-73`).

A **recomendação por questionário** é a funcionalidade que caracteriza o sistema como ferramenta de apoio à decisão. São 25 passos (22 entradas declaradas, das quais uma se desdobra em quatro subperguntas), organizados em cinco grupos temáticos; as respostas são enviadas a uma função de borda que aplica regras eliminatórias e depois pontua as espécies sobreviventes numa escala de 0 a 100. O capítulo dedicado ao algoritmo detalha cada regra e cada peso.

Os **projetos de plantio** permitem desenhar uma intervenção sobre imagem de satélite: o usuário clica no mapa, vincula uma espécie ao ponto e acumula um conjunto de plantios com coordenadas, observações e estatísticas agregadas (diversidade, cobertura de copa estimada, percentual de nativas). Desse conjunto nasce o **relatório em PDF**, gerado inteiramente no navegador com jsPDF e html2canvas, contendo cabeçalho, cartão do projeto, três indicadores ambientais, a imagem do mapa e a tabela de coordenadas (`src/lib/pdf.ts`).

A página "Quem Somos" (`src/pages/AboutPage.tsx`) publica o material metodológico: dois documentos de parametrização — "Parametrização Simplificada" e "Parametrização Técnica" (`src/pages/AboutPage.tsx:9-23`) — e dez guias de arborização numerados, todos servidos como PDFs públicos do Storage e renderizados dentro do aplicativo por um visualizador próprio baseado em `pdfjs-dist`.

## Pilha tecnológica e versões

As versões abaixo são as declaradas em `package.json` (faixas semânticas com `^`).

| Camada | Tecnologia | Versão declarada |
|---|---|---|
| Interface | React + React DOM | `^19.2.0` |
| Build | Vite | `^7.3.1` |
| Linguagem | TypeScript | `~5.9.3` |
| Estilo | Tailwind CSS + plugin Vite | `^4.2.1` |
| Roteamento | react-router-dom | `^7.13.1` |
| Estado de servidor | @tanstack/react-query | `^5.90.21` |
| Formulários | react-hook-form + @hookform/resolvers + zod | `^7.71.2` / `^5.2.2` / `^4.3.6` |
| Mapas | leaflet, react-leaflet, react-leaflet-cluster, leaflet.markercluster | `^1.9.4` / `^5.0.0` / `^4.0.0` / `^1.5.3` |
| PDF | jspdf, html2canvas, pdfjs-dist | `^4.2.0` / `^1.4.1` / `^6.0.227` |
| Notificações | sonner | `^2.0.7` |
| Ícones | lucide-react | `^0.577.0` |
| Backend | @supabase/supabase-js | `^2.99.2` |
| Telemetria | @vercel/analytics, @vercel/speed-insights | `^2.0.1` / `^2.0.0` |
| PWA | vite-plugin-pwa | `^1.2.0` |
| Testes | vitest + Testing Library | `^4.1.2` / `^16.3.2` |

O backend é o Supabase (PostgreSQL 17, PostgREST, GoTrue, Storage e Edge Runtime em Deno), hoje auto-hospedado em VPS, conforme o capítulo de infraestrutura.

## Estratégia PWA

O aplicativo é instalável. O `vite-plugin-pwa` está configurado com `registerType: 'autoUpdate'`, o que faz o service worker substituir a versão em cache sem intervenção do usuário (`vite.config.ts:22`). O manifesto declara nome "PlanteiCerto", `theme_color` `#226437`, `background_color` `#f7f9f7`, exibição `standalone`, orientação `portrait`, `lang: 'pt-BR'` e ícones de 192 e 512 pixels, incluindo variante `maskable` (`vite.config.ts:24-53`). O modo de desenvolvimento também registra o service worker (`devOptions.enabled = true`, `vite.config.ts:54-56`). No nível da interface, o componente `InstallPWABanner` (montado em `src/App.tsx:65`) oferece a instalação quando o navegador dispara o evento `beforeinstallprompt`.

## O portão de proteção intelectual

Toda a aplicação está envolvida por um portão de acesso, o componente `IPProtectionGate`, montado dentro do `ErrorBoundary` e acima de todas as rotas (`src/App.tsx:38-39`). O mecanismo é simples e inteiramente executado no cliente: o componente compara o campo de usuário com o literal `'admin'` e o campo de senha com a variável de ambiente `VITE_GATE_PASSWORD`, embutida no bundle em tempo de build; havendo coincidência, grava a chave `ip_unlocked` com valor `'true'` no `localStorage` e renderiza a aplicação (`src/components/auth/IPProtectionGate.tsx:10-30`). A senha não é reproduzida neste relatório. A tela exibe o aviso "Proteção Intelectual Ativa" e informa que o software está em processo de registro no INPI (`src/components/auth/IPProtectionGate.tsx:115-117`), e o erro apresentado em caso de falha é "Credenciais inválidas. Acesso negado.". Trata-se de uma barreira de divulgação, não de um controle de segurança — o capítulo de limitações discute essa distinção.

## Mapa de perfis por funcionalidade

| Funcionalidade | Visitante | Usuário cadastrado | Administrador |
|---|---|---|---|
| Catálogo, busca, filtros e ordenações | Sim | Sim | Sim (inclui inativas) |
| Detalhe da espécie e projeção de 10 anos | Sim | Sim | Sim |
| Comparação de até 3 espécies | Sim | Sim | Sim |
| Questionário de recomendação e resultados | Sim | Sim | Sim |
| Guias e documentos de parametrização | Sim | Sim | Sim |
| Favoritar espécies | Não | Sim | Sim |
| Criar, editar e excluir projetos | Não | Sim (apenas os próprios) | Sim (apenas os próprios) |
| Adicionar e editar pontos no mapa | Não | Sim (apenas nos próprios projetos) | Sim (apenas nos próprios) |
| Dashboard de estatísticas do projeto | Não | Sim | Sim |
| Relatório PDF do projeto | Não | Sim | Sim |
| Perfil, avatar e troca de senha | Não | Sim | Sim |
| Cadastrar, editar e excluir espécies | Não | Não | Sim |
| Upload de imagem de espécie | Não | Não | Sim |
| Listar usuários e alterar papéis | Não | Não | Sim |

A coluna do administrador quanto a projetos merece uma ressalva: a política de RLS concede leitura de todos os pontos a administradores (`Admins can read all points`), mas a interface não oferece nenhuma tela que exercite essa permissão — o painel administrativo cobre apenas espécies e equipe.
