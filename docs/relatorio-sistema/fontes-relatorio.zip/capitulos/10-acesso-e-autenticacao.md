# Acesso, navegação e autenticação

Este capítulo documenta a "porta de entrada" do PlanteiCerto: a tela de proteção intelectual que
antecede toda a aplicação, a barra de navegação (Header) e sua versão móvel (MobileDrawer), a
alternância entre tema claro e escuro, e o modal de autenticação (AuthModal) com todos os seus
modos — entrar, criar conta, confirmar e-mail, recuperar senha — além do encerramento de sessão e
das guardas de rota.

Arquivos-fonte principais: `src/components/auth/IPProtectionGate.tsx`,
`src/components/layout/Header.tsx`, `src/components/layout/MobileDrawer.tsx`,
`src/components/auth/AuthModal.tsx`, `src/components/ui/ConfirmationModal.tsx`,
`src/contexts/AuthContext.tsx`, `src/contexts/ThemeContext.tsx`,
`src/components/auth/ProtectedRoute.tsx` e `src/components/auth/AdminRoute.tsx`.

Todas as capturas foram feitas em ambiente local (Vite em `http://localhost:5173` + Supabase local),
com 146 espécies ativas cadastradas. A interface é integralmente em português do Brasil, sem
alternância de idioma.

---

## 1. Tela de proteção intelectual (gate)

O componente `IPProtectionGate` envolve **toda** a aplicação. Enquanto a chave `ip_unlocked` não
estiver gravada no `localStorage` do navegador, nenhuma rota é renderizada — nem a pública. É um
bloqueio de divulgação (o software está em processo de registro no INPI), e não um sistema de contas:
não há recuperação de senha, cadastro nem relação com os usuários do banco.

### Gate — estado ocioso

![Tela dividida: painel verde de marca à esquerda e formulário de acesso restrito à direita](../shots/10-gate-ocioso.png)

**Rota:** qualquer URL do sistema (foi usada `/`) — é a primeira tela exibida a quem nunca desbloqueou
o navegador · **Quem acessa:** qualquer visitante · **Viewport/tema:** desktop 1440×900, claro

**Elementos visíveis:**

- Layout em duas colunas. **Coluna esquerda (≈60 % da largura)**, sobre fundo verde-claro com uma
  textura botânica muito sutil: logotipo circular do PlanteiCerto (árvore com um "visto"), o
  título "PlanteiCerto" em serifada de grande porte, um filete separador e o parágrafo
  "Um sistema de recomendação de espécies arbóreas para calçadas urbanas, desenvolvido para apoiar
  cidadãos na escolha da árvore certa para o lugar certo."
- Ainda na coluna esquerda, um cartão branco translúcido com os logotipos institucionais **UNAERP**
  e **Mestrado e Doutorado em Tecnologia Ambiental** (ambos são links externos).
- Rodapé da coluna esquerda: "Para dúvidas ou liberação de acesso temporário, contate:" seguido de
  dois contatos — "Matheus Rigolão: mrssouza@unaerp.br" e "Dr. Murilo Daniel De Mello Innocentini:
  minnocentini@unaerp.br".
- **Coluna direita (fundo claro)**: ícone de cadeado em círculo, título "Acesso Restrito" e o
  subtítulo "Insira as credenciais administrativas para liberar a interface."
- Caixa de aviso com ícone de escudo: **"Proteção Intelectual Ativa"** — "Este software encontra-se
  em processo de registro no INPI. O acesso é restrito e monitorado para proteção de propriedade
  intelectual."
- Formulário com dois campos obrigatórios: **Usuário** (placeholder "Digite o usuário de acesso") e
  **Senha** (placeholder "Digite a senha de acesso", tipo `password`), e o botão verde de largura
  total **"Acessar Sistema"**.

**Ações possíveis / o que acontece:**

- Preencher usuário e senha corretos e clicar em "Acessar Sistema" → grava `ip_unlocked = "true"` no
  `localStorage` e renderiza imediatamente a aplicação (ver `10-gate-desbloqueado`).
- Credenciais erradas → mensagem de erro em vermelho, sem recarregar a página (ver `10-gate-erro`).
- Clicar nos logotipos → abre `unaerp.br` e a página do programa de pós-graduação em nova aba.

**Estados relacionados:** `10-gate-erro`, `10-gate-mobile`, `10-gate-desbloqueado`

> Observação: por se tratar de credencial de proteção de propriedade intelectual, o usuário e a senha
> reais **não** são reproduzidos neste relatório.

### Gate — credenciais inválidas

![Mesma tela com os campos preenchidos e uma faixa vermelha de erro acima do botão](../shots/10-gate-erro.png)

**Rota:** `/` (o gate não navega) · **Quem acessa:** qualquer visitante · **Viewport/tema:** desktop claro

**Elementos visíveis:**

- Campo **Usuário** preenchido com o valor digitado (na captura, `usuario-errado`) e campo **Senha**
  exibindo apenas pontos.
- Entre a senha e o botão, uma faixa de erro com fundo rosa-claro, borda e texto vermelhos, centralizada:
  **"Credenciais inválidas. Acesso negado."**
- O botão "Acessar Sistema" continua habilitado e a página não foi recarregada.

**Ações possíveis / o que acontece:**

- Corrigir os campos e reenviar → a mensagem desaparece e o sistema é liberado.
- Não há limite de tentativas, bloqueio temporário nem link de recuperação.

**Estados relacionados:** `10-gate-ocioso`

### Gate — mobile

![Mesma tela empilhada em uma coluna: marca em cima, formulário embaixo](../shots/10-gate-mobile.png)

**Rota:** `/` · **Quem acessa:** qualquer visitante · **Viewport/tema:** mobile 390×844, claro, captura de página inteira

**Elementos visíveis:**

- O layout deixa de ser em duas colunas e passa a ser empilhado: primeiro o bloco de marca (logotipo,
  "PlanteiCerto", o parágrafo de apresentação, o cartão com os dois logotipos institucionais e os
  contatos), depois o bloco "Acesso Restrito".
- No mobile, o separador vertical entre os logotipos some e os contatos ficam em duas linhas.
- O formulário mantém os mesmos campos e o botão "Acessar Sistema" ocupando toda a largura.

**Ações possíveis / o que acontece:** idênticas ao desktop.

**Estados relacionados:** `10-gate-ocioso`

### Gate — após o desbloqueio

![Catálogo de árvores carregado, com header, título "Encontre a árvore certa" e grade de cards](../shots/10-gate-desbloqueado.png)

**Rota:** `/` · **Quem acessa:** visitante que acabou de desbloquear · **Viewport/tema:** desktop claro

**Elementos visíveis:**

- O gate desaparece e a aplicação é renderizada: Header com logotipo, logotipos institucionais, links
  "Árvores" e "Quem Somos", botão verde "Entrar" e botão redondo de tema.
- Conteúdo do catálogo: título "Encontre a árvore **certa**", subtítulo, botão "Encontrar Árvore
  Recomendada", a barra de ferramentas e o contador **"Mostrando 6 de 146 árvores"**.

**Ações possíveis / o que acontece:**

- O desbloqueio fica registrado em `localStorage.ip_unlocked` e vale para todas as visitas seguintes
  naquele navegador; limpar os dados do site faz o gate reaparecer.

**Estados relacionados:** `13-catalogo-grid` (capítulo do catálogo)

## Fluxo passo a passo — desbloqueio do gate

1. O visitante abre qualquer URL do sistema e recebe a tela "Acesso Restrito" (ver `10-gate-ocioso`).
2. Digita usuário e senha administrativos nos dois campos.
3. Clica em **"Acessar Sistema"**.
4. Se as credenciais não conferirem, a faixa **"Credenciais inválidas. Acesso negado."** aparece e o
   visitante permanece na mesma tela (ver `10-gate-erro`).
5. Com as credenciais corretas, o navegador grava `ip_unlocked` e a aplicação é renderizada na rota
   solicitada — no exemplo, o catálogo (ver `10-gate-desbloqueado`).

---

## 2. Header e navegação

### Header — visitante não autenticado (tema claro)

![Faixa superior branca com logotipo, logos institucionais, links e botão Entrar](../shots/11-header-deslogado.png)

**Rota:** presente em `/`, `/quem-somos`, `/recomendacao`, `/projetos`, `/perfil` e `/reset-password`
· **Quem acessa:** visitante · **Viewport/tema:** desktop claro (recorte dos 120 px superiores)

**Elementos visíveis:**

- À esquerda: logotipo circular + a palavra "PlanteiCerto" (juntos funcionam como botão para `/`);
  depois de um filete vertical, os logotipos **UNAERP** e **Mestrado e Doutorado em Tecnologia
  Ambiental** (escondidos em telas menores que 640 px).
- À direita: link **"Árvores"** em verde e negrito com sublinhado (rota ativa), link **"Quem Somos"**
  em cinza, botão-pílula verde **"Entrar"** e botão redondo com ícone de lua (`title="Alternar tema"`).
- A barra é fixa no topo (`sticky`) e tem 64 px de altura.

**Ações possíveis / o que acontece:**

- "Árvores" → navega para `/`; "Quem Somos" → `/quem-somos`.
- "Entrar" → abre o AuthModal no modo login (ver `12-auth-login`).
- Botão de tema → alterna claro/escuro (ver `11-header-tema-escuro`).

**Estados relacionados:** `11-header-deslogado-dark`, `11-header-dropdown-usuario`

### Header — visitante não autenticado (tema escuro)

![Mesma faixa superior em fundo quase preto, com textos claros e ícone de sol](../shots/11-header-deslogado-dark.png)

**Rota:** idem · **Quem acessa:** visitante · **Viewport/tema:** desktop escuro

**Elementos visíveis:**

- Fundo da barra praticamente preto, com borda inferior escura; "PlanteiCerto" em branco.
- "Árvores" em verde-claro (ativo), "Quem Somos" em cinza-claro, botão "Entrar" em verde mais vivo
  e o botão de tema agora exibindo o ícone de **sol** (indicando "voltar para o claro").

**Ações possíveis / o que acontece:** idênticas ao tema claro.

**Estados relacionados:** `11-header-deslogado`, `13-catalogo-grid-dark`

### Alternância de tema — a mesma tela nos dois temas

![Catálogo no tema claro: fundo creme, cards brancos](../shots/11-header-tema-claro.png)

![Catálogo no tema escuro: fundo preto, cards cinza-escuros, títulos verde-claros](../shots/11-header-tema-escuro.png)

**Rota:** `/` · **Quem acessa:** qualquer pessoa (a preferência é por navegador) · **Viewport/tema:**
desktop — primeira captura clara, segunda após um clique no botão de tema

**Elementos visíveis:**

- No claro: fundo creme (`#faf9f5` aproximado), cards brancos, título "Encontre a árvore **certa**"
  em verde-escuro, chips de altura em verde-acinzentado e de folhagem em bege.
- No escuro: fundo preto, cards cinza-escuros com borda sutil, nomes populares em verde-claro,
  botões "Encontrar Árvore Recomendada" e "Entrar" em verde mais saturado. O conteúdo, os textos e o
  contador "Mostrando 6 de 146 árvores" são exatamente os mesmos.

**Ações possíveis / o que acontece:**

- Um clique no botão redondo alterna entre `light` e `dark` e grava a escolha em
  `localStorage.planteicerto-ui-theme`. O padrão de fábrica é `system` (segue o sistema operacional);
  a partir do primeiro clique a escolha passa a ser explícita.
- No mobile a alternância está no rodapé do drawer, como "Modo Claro"/"Modo Escuro".
- O painel administrativo (`/admin/*`) não exibe o botão de tema, mas respeita o tema já salvo.

**Estados relacionados:** `11-header-drawer-deslogado-mobile`, `13-catalogo-grid-dark`

### Dropdown do usuário autenticado

![Menu suspenso abaixo do avatar com nome, e-mail, Meu Perfil, Meus Projetos e Sair](../shots/11-header-dropdown-usuario.png)

**Rota:** qualquer rota com Header · **Quem acessa:** usuário autenticado sem privilégio de
administrador · **Viewport/tema:** desktop claro (recorte da metade direita do topo)

**Elementos visíveis:**

- No lugar do botão "Entrar": um avatar circular verde-claro com a inicial do nome ("U"), o nome
  truncado "Usuária Demon…" e uma seta para baixo que gira 180° quando o menu abre.
- Menu suspenso (cartão branco arredondado, 224 px): cabeçalho com **"Usuária Demonstração"** em
  negrito e **"usuario.demo@planteicerto.local"** em cinza menor; abaixo, separados por um filete,
  os itens **"Meu Perfil"** (ícone de pessoa) e **"Meus Projetos"** (ícone de pasta); novo filete; e
  **"Sair"** em vermelho com ícone de porta.
- Ao fundo aparece a barra de ferramentas do catálogo, com o botão **"Favoritos 3"** (visível apenas
  para quem está autenticado).

**Ações possíveis / o que acontece:**

- "Meu Perfil" → navega para `/perfil`; "Meus Projetos" → `/projetos`; ambos fecham o menu.
- "Sair" → fecha o menu e abre o modal de confirmação (ver `12-auth-logout-modal`).
- Clicar fora do menu o fecha.

**Estados relacionados:** `11-header-dropdown-admin`, `12-auth-logout-modal`

### Dropdown do administrador

![Mesmo menu, com um item adicional "Administração" com ícone de escudo](../shots/11-header-dropdown-admin.png)

**Rota:** qualquer rota com Header · **Quem acessa:** usuário cujo `profiles.role` é `admin`
· **Viewport/tema:** desktop claro

**Elementos visíveis:**

- Cabeçalho com "Administrador Demo" e "admin.demo@planteicerto.local".
- Itens: "Meu Perfil", "Meus Projetos" e, **exclusivo para administradores**, **"Administração"**
  com ícone de escudo; depois o filete e "Sair" em vermelho.
- O botão "Favoritos" não aparece ao fundo porque esta conta não possui favoritos.

**Ações possíveis / o que acontece:**

- "Administração" → navega para `/admin/arvores`, que usa outro layout (barra lateral própria).
- Para contas sem o papel de administrador o item simplesmente não é renderizado.

**Estados relacionados:** `11-header-dropdown-usuario`, `11-header-drawer-admin-mobile`

### MobileDrawer — visitante

![Painel lateral branco cobrindo 280 px à direita, com Início, Quem Somos, Modo Escuro e Fazer Login](../shots/11-header-drawer-deslogado-mobile.png)

**Rota:** `/` (o drawer existe em todas as rotas com Header) · **Quem acessa:** visitante
· **Viewport/tema:** mobile 390×844, claro

**Elementos visíveis:**

- No mobile, o Header mostra apenas o logotipo e um botão "hambúrguer"; tocá-lo abre esta folha
  deslizante presa à direita, sobre um fundo escurecido e desfocado.
- Topo do painel: logotipo + "PlanteiCerto" e um botão "×" para fechar.
- Navegação: **"Inicio (Arvores)"** (destacado em verde, rota atual, com ícone de casa) e
  **"Quem Somos"** (ícone de informação).
- Rodapé do painel: botão **"Modo Escuro"** (ícone de lua), botão verde de largura total
  **"Fazer Login"** e, abaixo de um filete, os logotipos UNAERP e do Mestrado.

**Ações possíveis / o que acontece:**

- "Fazer Login" → fecha o drawer e abre o AuthModal.
- "Modo Escuro" → alterna o tema sem fechar o drawer.
- Tocar no fundo escurecido ou no "×" fecha a folha. Mudar de rota também a fecha automaticamente.

**Estados relacionados:** `11-header-drawer-usuario-mobile`, `11-header-drawer-admin-mobile`

### MobileDrawer — usuária autenticada

![Mesmo painel, agora com Meus Projetos, Meu Perfil, o e-mail e o botão Sair da Conta](../shots/11-header-drawer-usuario-mobile.png)

**Rota:** `/` · **Quem acessa:** usuário autenticado · **Viewport/tema:** mobile claro

**Elementos visíveis:**

- Além de "Inicio (Arvores)" e "Quem Somos", surgem **"Meus Projetos"** (ícone de pasta) e
  **"Meu Perfil"** (ícone de pessoa).
- No rodapé: "Modo Escuro"; o rótulo em caixa alta **"LOGADO COMO"** seguido do e-mail
  "usuario.demo@planteicerto.…" (truncado); e o botão **"Sair da Conta"** com texto vermelho sobre
  fundo cinza-claro.

**Ações possíveis / o que acontece:**

- "Sair da Conta" → fecha o drawer e abre o mesmo modal de confirmação de logout do desktop.

**Estados relacionados:** `11-header-drawer-deslogado-mobile`, `12-auth-logout-modal`

### MobileDrawer — administrador

![Mesmo painel, com o item adicional "Painel Admin"](../shots/11-header-drawer-admin-mobile.png)

**Rota:** `/` · **Quem acessa:** administrador · **Viewport/tema:** mobile claro

**Elementos visíveis:**

- A lista ganha um quinto item: **"Painel Admin"** com ícone de escudo, abaixo de "Meu Perfil".
  (No desktop o mesmo item se chama "Administração" — os rótulos diferem entre os dois menus.)
- Rodapé com "LOGADO COMO admin.demo@planteicerto.l…" e "Sair da Conta".

**Ações possíveis / o que acontece:**

- "Painel Admin" → navega para `/admin/arvores` e fecha o drawer.

**Estados relacionados:** `11-header-dropdown-admin`

---

## 3. AuthModal — entrar, cadastrar e recuperar senha

### AuthModal — modo "Entrar"

![Modal centralizado sobre o catálogo desfocado, com botão do Google, campos de e-mail e senha](../shots/12-auth-login.png)

**Rota:** sobreposto à rota atual (aqui `/`) — aberto pelo botão "Entrar" do Header, por "Fazer Login"
no drawer ou ao tentar favoritar sem estar autenticado · **Quem acessa:** visitante
· **Viewport/tema:** desktop claro

**Elementos visíveis:**

- Fundo escurecido e desfocado sobre o catálogo; cartão branco arredondado com um "×" cinza no canto
  superior direito.
- Título **"Entrar"** em verde.
- Botão de largura total **"Continuar com Google"** com o logotipo colorido do Google.
- Separador horizontal com a palavra **"ou"** ao centro.
- Campo **E-mail** (rótulo "E-mail", placeholder "seu@email.com", obrigatório).
- Campo **Senha** (rótulo "Senha", placeholder "******", mínimo de 6 caracteres) com o link
  **"Esqueceu a senha?"** alinhado à direita do rótulo.
- Botão verde de largura total **"Entrar"**.
- Rodapé separado por filete: "Não tem conta? **Cadastre-se**".

**Ações possíveis / o que acontece:**

- Enviar credenciais válidas → o modal fecha sozinho e o Header passa a exibir avatar e nome.
- Credenciais inválidas → toast vermelho "E-mail ou senha incorretos." (ver `12-auth-login-erro`).
- Conta ainda não confirmada → toast "Confirme seu e-mail antes de fazer login." (comportamento
  previsto no código; **não capturado** neste relatório).
- Enquanto a requisição corre, o botão exibe "Processando…" e fica desabilitado.
- "Continuar com Google" troca o rótulo para "Redirecionando…" e inicia o OAuth do Supabase — no
  ambiente local não há provedor Google configurado, portanto **não foi exercitado**.
- "Cadastre-se" troca o modal para o modo de registro; "Esqueceu a senha?" leva ao modo de recuperação.
- A tecla `Esc` e um clique fora do cartão fecham o modal (e limpam os campos).

**Estados relacionados:** `12-auth-login-erro`, `12-auth-criar-conta`, `12-auth-recuperar-senha`

### AuthModal — erro de login

![Mesmo modal com e-mail preenchido e, no rodapé da tela, um toast vermelho](../shots/12-auth-login-erro.png)

**Rota:** sobreposto a `/` · **Quem acessa:** visitante · **Viewport/tema:** desktop claro

**Elementos visíveis:**

- Campo E-mail com "usuario.demo@planteicerto.local" e campo Senha preenchido (pontos).
- O modal **permanece aberto**, sem mensagem inline.
- Na parte inferior central da janela, um toast (biblioteca *sonner*, posição `bottom-center`, cores
  ricas) com fundo rosa-claro, ícone circular vermelho e o texto **"E-mail ou senha incorretos."**.

**Ações possíveis / o que acontece:**

- O toast some sozinho após alguns segundos; o usuário pode corrigir a senha e tentar de novo.

**Estados relacionados:** `12-auth-login`

### AuthModal — modo "Criar Conta"

![Modal com três campos: Nome Completo, E-mail e Senha, e botão Cadastrar](../shots/12-auth-criar-conta.png)

**Rota:** sobreposto a `/` · **Quem acessa:** visitante · **Viewport/tema:** desktop claro

**Elementos visíveis:**

- Título **"Criar Conta"**; botão "Continuar com Google" e separador "ou" iguais aos do login.
- Campo **Nome Completo** (placeholder "Ex: João Silva", limite de 80 caracteres).
- Campo **E-mail** (placeholder "seu@email.com") e campo **Senha** (placeholder "******", mínimo 6).
- Botão verde **"Cadastrar"**.
- Rodapé: "Já tem conta? **Entre aqui**".

**Ações possíveis / o que acontece:**

- Enviar com o nome em branco → toast "Preencha seu nome." e nada é enviado ao servidor.
- E-mail já cadastrado → toast "Este e-mail já está em uso. Tente fazer login." (o app consulta antes
  a função de borda `check-email-exists`).
- Cadastro bem-sucedido com confirmação de e-mail ativa → o modal passa para a tela "Confirme seu
  e-mail" (ver `12-auth-cadastro-confirme`).
- "Entre aqui" volta ao modo login.

**Estados relacionados:** `12-auth-cadastro-confirme`, `12-auth-login`

### AuthModal — modo "Recuperar Senha"

![Modal enxuto, apenas com o campo E-mail, o botão Enviar Instruções e o link Voltar para o login](../shots/12-auth-recuperar-senha.png)

**Rota:** sobreposto a `/` · **Quem acessa:** visitante · **Viewport/tema:** desktop claro

**Elementos visíveis:**

- Título **"Recuperar Senha"**. Não há botão do Google nem separador "ou" neste modo.
- Um único campo **E-mail** (placeholder "seu@email.com").
- Botão verde **"Enviar Instruções"**.
- Abaixo do filete, o link centralizado **"Voltar para o login"**.

**Ações possíveis / o que acontece:**

- Enviar → o Supabase dispara o e-mail de redefinição apontando para `/reset-password` e o modal
  passa à tela de sucesso (ver `12-auth-recuperar-enviado`).
- Se o serviço responder com limite de envios, aparece o toast "Muitas solicitações em pouco tempo.
  Aguarde 60 segundos e tente novamente."; outros erros geram "Ocorreu um erro ao recuperar a senha.
  Verifique o e-mail ou tente mais tarde." (**não capturados**).

**Estados relacionados:** `12-auth-recuperar-enviado`

### AuthModal — "E-mail enviado"

![Modal com ícone de envelope, título E-mail enviado e botão Entendido](../shots/12-auth-recuperar-enviado.png)

**Rota:** sobreposto a `/` · **Quem acessa:** visitante · **Viewport/tema:** desktop claro

**Elementos visíveis:**

- Cartão centralizado com um ícone grande de envelope em cinza.
- Título **"E-mail enviado"** em verde.
- Texto: **"Enviamos as instruções para você recuperar sua senha para usuario.demo@planteicerto.local.
  Verifique sua caixa de entrada."** — o endereço digitado é repetido literalmente.
- Botão verde de largura total **"Entendido"**.

**Ações possíveis / o que acontece:**

- "Entendido" (ou o "×") fecha o modal e devolve o estado interno ao modo login.
- O e-mail correspondente chega ao servidor de e-mails local com o assunto
  "Redefinição de senha — PlanteiCerto".

**Estados relacionados:** `12-auth-recuperar-senha`, `12-auth-mailpit`

### AuthModal — "Confirme seu e-mail" (após o cadastro)

![Modal com envelope, título Confirme seu e-mail e o endereço recém-cadastrado](../shots/12-auth-cadastro-confirme.png)

**Rota:** sobreposto a `/` · **Quem acessa:** pessoa que acabou de se cadastrar
· **Viewport/tema:** desktop claro

**Elementos visíveis:**

- Mesmo cartão da tela anterior, porém com título **"Confirme seu e-mail"** e o texto
  **"Enviamos um link de confirmação para novo.cadastro@planteicerto.local. Clique no link para
  ativar sua conta."**
- Botão **"Entendido"**.

**Ações possíveis / o que acontece:**

- A sessão **ainda não existe**: o Header continua mostrando "Entrar" até a confirmação.
- Tentar entrar antes de confirmar produz o toast "Confirme seu e-mail antes de fazer login."

**Estados relacionados:** `12-auth-mailpit`, `12-auth-cadastro-logado`

### Caixa de e-mails local (Mailpit) com a mensagem de confirmação

![Interface do Mailpit: lista de mensagens à esquerda e o e-mail HTML renderizado à direita](../shots/12-auth-mailpit.png)

**Rota:** `http://127.0.0.1:54324` (serviço de e-mail do Supabase local; **não faz parte do produto**)
· **Quem acessa:** apenas o ambiente de desenvolvimento · **Viewport/tema:** desktop

**Elementos visíveis:**

- Barra superior escura do Mailpit com "Mark unread", "Delete", "Download".
- Lista de mensagens à esquerda: a primeira, destacada, é **"Confirme seu cadastro — PlanteiCerto"**
  para `novo.cadastro@planteicerto.local`; abaixo aparecem mensagens
  **"Redefinição de senha — PlanteiCerto"** geradas pelo fluxo de recuperação.
- Cabeçalho da mensagem: De "Admin <admin@email.com>", Para "novo.cadastro@planteicerto.local",
  Assunto "Confirme seu cadastro — PlanteiCerto", data e tamanho (3,4 kB).
- Corpo HTML com identidade visual do sistema: faixa verde-escura com o logotipo e "PlanteiCerto",
  título **"Bem-vindo(a) ao PlanteiCerto, Novo Cadastro Demo!"**, um parágrafo de boas-vindas, o
  botão verde **"Confirmar Meu E-mail"**, a linha "Se você não criou uma conta no PlanteiCerto,
  ignore esta mensagem." e o rodapé "© 2026 PlanteiCerto. Democratizando a arborização urbana." /
  "Este é um e-mail automático, por favor não responda."

**Ações possíveis / o que acontece:**

- O botão "Confirmar Meu E-mail" aponta para o endpoint de verificação do serviço de autenticação,
  que valida o token e redireciona de volta para a aplicação já autenticado.

**Estados relacionados:** `12-auth-cadastro-confirme`, `12-auth-cadastro-logado`

### Sessão iniciada após confirmar o e-mail

![Faixa superior com avatar "N" e o nome "Novo Cadastro …" no lugar do botão Entrar](../shots/12-auth-cadastro-logado.png)

**Rota:** `/` (destino do redirecionamento após a verificação) · **Quem acessa:** usuário recém-confirmado
· **Viewport/tema:** desktop claro (recorte do topo)

**Elementos visíveis:**

- O botão "Entrar" foi substituído por um avatar circular com a inicial **"N"**, o nome
  **"Novo Cadastro …"** (truncado) e a seta do menu.
- Os links "Árvores" e "Quem Somos" e o botão de tema permanecem.

**Ações possíveis / o que acontece:**

- A sessão é criada automaticamente pelo link do e-mail — não é preciso digitar a senha de novo.
- A partir daqui as rotas `/projetos`, `/perfil` e o botão "Favoritos" ficam disponíveis.

**Estados relacionados:** `11-header-dropdown-usuario`

> A conta `novo.cadastro@planteicerto.local` foi criada apenas para esta documentação e **removida do
> banco ao final da execução**.

### Confirmação de saída ("Sair da conta")

![Modal pequeno com ícone de lixeira vermelho, título Sair da conta e botões Cancelar e Sair agora](../shots/12-auth-logout-modal.png)

**Rota:** sobreposto à rota atual · **Quem acessa:** usuário autenticado · **Viewport/tema:** desktop claro

**Elementos visíveis:**

- Cartão estreito centralizado, com ícone circular vermelho-claro contendo uma lixeira.
- Título **"Sair da conta"**.
- Texto **"Tem certeza que deseja encerrar sua sessão? Você precisará entrar novamente para gerenciar
  seus projetos."**
- Dois botões lado a lado: **"Cancelar"** (cinza, à esquerda) e **"Sair agora"** (vermelho, à direita).
- Ao fundo, o catálogo desfocado com o Header já exibindo a conta autenticada.

**Ações possíveis / o que acontece:**

- "Cancelar", `Esc` ou clique fora → fecha o modal **sem** encerrar a sessão (verificado: o Header
  continuou mostrando o usuário autenticado).
- "Sair agora" → encerra a sessão; o Header volta a exibir o botão "Entrar" e as rotas protegidas
  passam a redirecionar para `/`.

**Estados relacionados:** `11-header-dropdown-usuario`, `11-header-drawer-usuario-mobile`

## Fluxo passo a passo — login

1. A partir de qualquer tela pública, o visitante clica em **"Entrar"** no Header (ou em
   "Fazer Login" no drawer móvel).
2. O AuthModal abre no modo login (ver `12-auth-login`).
3. O visitante preenche **E-mail** e **Senha** e aciona o botão "Entrar"; durante o envio o rótulo
   vira "Processando…".
4. Se as credenciais estiverem erradas, o modal continua aberto e surge o toast
   **"E-mail ou senha incorretos."** (ver `12-auth-login-erro`).
5. Com credenciais válidas, o modal fecha automaticamente e o Header passa a exibir avatar, nome e a
   seta do menu do usuário (ver `11-header-dropdown-usuario`).

## Fluxo passo a passo — cadastro com confirmação por e-mail

1. No AuthModal em modo login, o visitante clica em **"Cadastre-se"** (ver `12-auth-login`).
2. Preenche **Nome Completo**, **E-mail** e **Senha** (mínimo de 6 caracteres) e clica em
   **"Cadastrar"** (ver `12-auth-criar-conta`).
3. O sistema verifica se o e-mail já existe; não existindo, cria a conta e envia a mensagem de
   confirmação. O modal passa para **"Confirme seu e-mail"**, repetindo o endereço informado
   (ver `12-auth-cadastro-confirme`).
4. A mensagem **"Confirme seu cadastro — PlanteiCerto"** chega à caixa de entrada, com o botão
   **"Confirmar Meu E-mail"** (ver `12-auth-mailpit`).
5. Ao abrir o link, o serviço de autenticação valida o token e devolve a pessoa à aplicação já
   autenticada: o Header exibe o avatar e o nome cadastrado (ver `12-auth-cadastro-logado`).

## Fluxo passo a passo — recuperação de senha (até "E-mail enviado")

1. No AuthModal em modo login, clicar em **"Esqueceu a senha?"**, ao lado do rótulo do campo Senha.
2. O modal passa ao modo **"Recuperar Senha"**, com um único campo de e-mail
   (ver `12-auth-recuperar-senha`).
3. Informar o endereço da conta e clicar em **"Enviar Instruções"**.
4. O modal exibe **"E-mail enviado"** com o endereço de destino e o botão "Entendido"
   (ver `12-auth-recuperar-enviado`).
5. A mensagem **"Redefinição de senha — PlanteiCerto"** chega à caixa de entrada (visível na listagem
   do Mailpit em `12-auth-mailpit`); o link leva à rota `/reset-password`, documentada no capítulo de
   perfil e redefinição de senha.

---

## 4. Guardas de rota e rota inexistente

As rotas são declaradas em `src/App.tsx`, todas carregadas sob demanda (`lazy`), com um indicador de
carregamento comum: um anel verde girando centralizado na tela.

| Rota | Página | Guarda |
|---|---|---|
| `/` | Catálogo (TreesPage) | pública |
| `/quem-somos` | AboutPage | pública |
| `/recomendacao` | RecommendationPage | pública |
| `/projetos` | ProjectsPage | `ProtectedRoute` |
| `/perfil` | ProfilePage | `ProtectedRoute` |
| `/reset-password` | ResetPasswordPage | `ProtectedRoute` (acessada pelo link do e-mail) |
| `/admin/arvores` | AdminTreesPage | `AdminRoute` |
| `/admin/equipe` | AdminUsersPage | `AdminRoute` |

- **`ProtectedRoute`**: enquanto a sessão é verificada, mostra um ícone de folha pulsando e o texto
  "Carregando..."; se não houver usuário, redireciona para `/` (sem mensagem).
- **`AdminRoute`**: enquanto verifica sessão e papel, mostra a mesma folha pulsando com o texto
  "Verificando permissões..."; usuário autenticado sem papel de administrador recebe o toast
  **"Acesso restrito a administradores."** e é redirecionado para `/`; visitante não autenticado é
  redirecionado sem toast. (Os estados dessas guardas são documentados em detalhe nos capítulos de
  projetos/perfil e do painel administrativo.)
- **`ErrorBoundary`** envolve tudo e, diante de um erro de renderização, exibe "Algo deu errado" /
  "Ocorreu um erro inesperado. Tente recarregar a página." com o botão "Tentar novamente"
  (**não capturado** — não foi possível provocar um erro de renderização sem alterar o código).

### Rota inexistente — página em branco

![Tela completamente vazia, sem header nem mensagem](../shots/11-header-rota-inexistente.png)

**Rota:** `/rota-que-nao-existe` (qualquer URL não declarada) · **Quem acessa:** qualquer pessoa
· **Viewport/tema:** desktop claro

**Elementos visíveis:**

- Nada além do fundo creme da aplicação: sem Header, sem mensagem, sem link de retorno. A leitura
  programática do corpo da página devolveu texto vazio (`""`).

**Ações possíveis / o que acontece:**

- Não há nenhuma ação disponível; a única saída é editar a URL ou usar o botão "voltar" do navegador.

**Lacuna identificada:** o sistema **não possui uma rota de erro 404**. Como as rotas são declaradas
individualmente e não existe `<Route path="*">`, qualquer endereço desconhecido produz uma página
totalmente vazia — inclusive sem a barra de navegação, o que impede o retorno pela própria interface.
