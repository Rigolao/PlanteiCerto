# Perfil do usuário e segurança

A página **Meu Perfil** (`/perfil`) concentra os poucos dados que o usuário controla sobre a própria conta: foto, nome de exibição e senha. É uma rota protegida (`ProtectedRoute`), acessível pelo menu do avatar no cabeçalho ("Meu Perfil") ou pelo menu lateral no celular. A tela é dividida em dois cartões: "Informações Públicas" e "Segurança".

Arquivos-fonte: `src/pages/ProfilePage.tsx`, `src/components/profile/AvatarUpload.tsx`, `src/components/profile/PasswordChangeForm.tsx` e `src/contexts/AuthContext.tsx` (funções `updateProfile` e `updatePassword`).

Pontos de comportamento relevantes:

- O **e-mail não é editável** — o campo aparece desabilitado com a explicação "O endereço de email não pode ser alterado.".
- O **nome** é limitado a 80 caracteres, com contador, e é obrigatório (`required`).
- A **foto** é enviada ao bucket `avatars` do Supabase Storage em `\<id do usuário\>/\<uuid\>.\<extensão\>`; a URL pública resultante é gravada nos metadados do usuário. Não existe opção de remover a foto depois — apenas substituir.
- O limite de 5 MB do avatar é verificado **somente no navegador**, antes do upload.
- O bloco "Método de Login" lista os provedores vinculados à conta (`identities`): pill "E-mail" e/ou pill "Google" com o logotipo colorido.
- O avatar exibido vem da **sessão** (metadados do usuário). Sessões abertas antes do upload continuam mostrando a inicial até serem renovadas — é exatamente o que se vê nas capturas de tema escuro e mobile mais adiante, feitas a partir de uma sessão anterior à troca da foto.

---

### Página de perfil completa

![Página Meu Perfil com os cartões Informações Públicas e Segurança](../shots/37-perfil-topo.png)

**Rota:** `/perfil` — menu do avatar → "Meu Perfil" · **Quem acessa:** usuário autenticado · **Viewport/tema:** desktop claro (captura de página inteira)

**Elementos visíveis:**
- Título "Meu Perfil".
- Cartão "**Informações Públicas**": à esquerda, avatar circular de 128 px com a inicial "P" e, abaixo, o link verde "Escolher nova foto". À direita, o campo "Email" desabilitado com "projetista.demo@planteicerto.local" e a nota "O endereço de email não pode ser alterado."; o bloco "Método de Login" com uma pill "✉ E-mail"; e o campo "Nome de Usuário" com "Projetista Demonstração" e o contador "23/80". No rodapé do cartão, o botão verde arredondado "**Salvar Perfil**".
- Cartão "**Segurança**": campos "Nova Senha" (placeholder "Mínimo de 6 caracteres") e "Confirmar Nova Senha" (placeholder "Repita a nova senha") lado a lado, e o botão escuro "**Alterar Senha**".

**Ações possíveis / o que acontece:**
- Clicar no avatar ou em "Escolher nova foto" abre o seletor de arquivos (`accept="image/*"`; o `input` fica oculto).
- "Salvar Perfil" envia nome e, se houver, a nova foto.
- "Alterar Senha" valida e chama `updatePassword`.

**Estados relacionados:** `37-perfil-avatar-hover`, `38-perfil-seguranca`, `38-perfil-dark`, `38-perfil-mobile`

---

### Avatar em placeholder

![Cartão Informações Públicas com avatar mostrando a inicial](../shots/37-perfil-avatar-inicial.png)

**Rota:** `/perfil` · **Quem acessa:** usuário autenticado sem foto · **Viewport/tema:** desktop claro (recorte do cartão)

**Elementos visíveis:**
- Círculo cinza-claro com a letra "**P**" em fonte grande — a primeira letra do nome, em maiúscula.
- Link "Escolher nova foto" logo abaixo.

**Ações possíveis / o que acontece:**
- Qualquer clique na área do círculo abre o seletor de arquivos.

**Estados relacionados:** `37-perfil-avatar-hover`, `37-perfil-com-foto`

---

### Sobreposição "Alterar Foto" (hover)

![Avatar escurecido com o texto Alterar Foto](../shots/37-perfil-avatar-hover.png)

**Rota:** `/perfil` → mouse sobre o avatar · **Quem acessa:** usuário autenticado · **Viewport/tema:** desktop claro (recorte do cartão)

**Elementos visíveis:**
- O círculo do avatar fica coberto por uma camada preta semitransparente com o texto branco "**Alterar Foto**" centralizado; a inicial "P" continua visível por trás.

**Ações possíveis / o que acontece:**
- Clique → seletor de arquivos.

**Estados relacionados:** `37-perfil-avatar-previa`

---

### Erro de tamanho do arquivo

![Mensagem vermelha Arquivo muito grande. Máximo: 5MB.](../shots/37-perfil-avatar-erro-tamanho.png)

**Rota:** `/perfil` → escolher um arquivo com mais de 5 MB · **Quem acessa:** usuário autenticado · **Viewport/tema:** desktop claro (recorte do cartão)

**Elementos visíveis:**
- Abaixo do link "Escolher nova foto", o texto vermelho "**Arquivo muito grande. Máximo: 5MB.**".
- O avatar **não muda**: continua com a inicial, porque o arquivo é rejeitado antes de virar prévia.

**Ações possíveis / o que acontece:**
- Escolher outro arquivo dentro do limite limpa a mensagem.
- A verificação é local (`file.size > 5 * 1024 * 1024`); não há aviso de formato inválido (o seletor já filtra por `image/*`).

**Estados relacionados:** `37-perfil-avatar-previa`

---

### Prévia da nova foto

![Avatar exibindo a prévia da imagem escolhida](../shots/37-perfil-avatar-previa.png)

**Rota:** `/perfil` → arquivo válido escolhido · **Quem acessa:** usuário autenticado · **Viewport/tema:** desktop claro (recorte do cartão)

**Elementos visíveis:**
- O círculo do avatar agora mostra a imagem escolhida, recortada e centralizada (`object-cover`); a sobreposição "Alterar Foto" continua aparecendo porque o cursor está sobre ela.
- Nada mais mudou: a prévia é local (`URL.createObjectURL`) e ainda não foi enviada.

**Ações possíveis / o que acontece:**
- Só "Salvar Perfil" confirma o envio; sair da página descarta a prévia.

**Estados relacionados:** `37-perfil-salvando`, `37-perfil-toast-salvo`

---

### Estado "Salvando..."

![Botão Salvando durante o envio do perfil](../shots/37-perfil-salvando.png)

**Rota:** `/perfil` → "Salvar Perfil" · **Quem acessa:** usuário autenticado · **Viewport/tema:** desktop claro (upload atrasado artificialmente para a captura)

**Elementos visíveis:**
- O botão do rodapé do cartão exibe "**Salvando...**", em verde esmaecido e desabilitado.
- O avatar da página já mostra a prévia; o avatar do cabeçalho ainda exibe a inicial "P" (a sessão em uso nesta captura é anterior à atualização dos metadados).
- O cartão "Segurança" continua acessível durante o envio.

**Ações possíveis / o que acontece:**
- Ao fim do upload, o app grava a URL pública nos metadados do usuário e emite o toast de sucesso.

**Estados relacionados:** `37-perfil-toast-salvo`

---

### Toast "Perfil atualizado com sucesso!"

![Página de perfil com toast verde de confirmação](../shots/37-perfil-toast-salvo.png)

**Rota:** `/perfil` · **Quem acessa:** usuário autenticado · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Toast verde "**Perfil atualizado com sucesso!**" na base da tela (aqui posicionado ao lado do botão "Alterar Senha", que fica no fim da página).
- O avatar do cartão **e** o do cabeçalho passaram a mostrar a foto enviada.

**Ações possíveis / o que acontece:**
- Em caso de falha, o app mostra "Erro ao atualizar perfil: <mensagem>" (não observado).

**Estados relacionados:** `37-perfil-com-foto`

---

### Perfil com foto salva

![Cartão Informações Públicas com a foto de perfil aplicada](../shots/37-perfil-com-foto.png)

**Rota:** `/perfil` (recarregada) · **Quem acessa:** usuário autenticado · **Viewport/tema:** desktop claro (recorte do cartão)

**Elementos visíveis:**
- Avatar circular com a imagem salva, carregada agora da URL pública do bucket `avatars`.
- Demais campos inalterados: e-mail desabilitado, pill "E-mail" em "Método de Login", nome com contador 23/80.

**Ações possíveis / o que acontece:**
- Trocar a foto repete o fluxo; não há botão para removê-la.

**Estados relacionados:** `37-perfil-topo`

---

### Cartão "Segurança"

![Cartão Segurança com os dois campos de senha](../shots/38-perfil-seguranca.png)

**Rota:** `/perfil` — parte inferior da página · **Quem acessa:** usuário autenticado com provedor de e-mail · **Viewport/tema:** desktop claro (recorte do cartão)

**Elementos visíveis:**
- Título "Segurança" com linha divisória.
- Dois campos do tipo senha, lado a lado: "Nova Senha" (placeholder "Mínimo de 6 caracteres") e "Confirmar Nova Senha" (placeholder "Repita a nova senha"), ambos obrigatórios.
- Botão escuro arredondado "**Alterar Senha**"; durante o envio ele vira "Alterando...".
- Não há campo de senha atual — a troca usa a sessão já autenticada.

**Ações possíveis / o que acontece:**
- Sucesso → toast "Senha alterada com sucesso!" e os dois campos são limpos (**não capturado**: trocar a senha real da conta demo invalidaria as demais capturas do relatório).
- Erro conhecido do backend → "A nova senha deve ser diferente da atual." (não capturado, pelo mesmo motivo); outros erros aparecem como "Erro ao alterar senha: <mensagem>".

**Estados relacionados:** `38-perfil-toast-senhas-diferentes`, `38-perfil-toast-senha-curta`

---

### Validação — senhas diferentes

![Toast As senhas não coincidem](../shots/38-perfil-toast-senhas-diferentes.png)

**Rota:** `/perfil` → preencher os dois campos com valores distintos → "Alterar Senha" · **Quem acessa:** usuário autenticado · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Toast vermelho-claro com ícone de alerta e o texto "**As senhas não coincidem.**", exibido ao lado do botão "Alterar Senha".
- Os dois campos permanecem preenchidos (mascarados) e nenhuma requisição é enviada.

**Ações possíveis / o que acontece:**
- Essa é a **primeira** validação do formulário do perfil: a comparação entre os campos acontece antes da verificação de tamanho.

**Estados relacionados:** `38-perfil-toast-senha-curta`

---

### Validação — senha curta

![Toast A senha deve ter no mínimo 6 caracteres](../shots/38-perfil-toast-senha-curta.png)

**Rota:** `/perfil` → digitar a mesma senha curta nos dois campos → "Alterar Senha" · **Quem acessa:** usuário autenticado · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Toast vermelho-claro "**A senha deve ter no mínimo 6 caracteres.**".
- Campos com três caracteres mascarados em cada um; nenhuma chamada ao servidor.

**Ações possíveis / o que acontece:**
- Corrigir o tamanho e reenviar.

**Estados relacionados:** `38-reset-erro-curta` (mesma regra, mensagem ligeiramente diferente na página de redefinição)

---

### Conta vinculada apenas ao Google

**NÃO CAPTURADO:** quando a conta não possui o provedor `email` entre suas identidades, o cartão "Segurança" não mostra o formulário de troca de senha e sim uma caixa cinza com ícone de informação e o texto "Sua conta usa o **Google** como método de login. Para alterar sua senha, acesse as configurações da sua conta Google." (`src/pages/ProfilePage.tsx`). Nesse caso, o bloco "Método de Login" exibiria a pill "Google" com o logotipo colorido em vez da pill "E-mail". As contas de demonstração do ambiente local são todas de e-mail/senha e o login social exige credenciais reais do Google, por isso o estado não pôde ser fotografado.

---

### Perfil no tema escuro

![Página de perfil no tema escuro](../shots/38-perfil-dark.png)

**Rota:** `/perfil` · **Quem acessa:** usuário autenticado · **Viewport/tema:** desktop escuro (captura de página inteira)

**Elementos visíveis:**
- Fundo preto, cartões cinza-escuro com borda sutil; "Salvar Perfil" em verde mais claro e "Alterar Senha" invertido (botão claro com texto escuro).
- O avatar aparece como placeholder "P" — esta sessão é anterior ao upload da foto, o que evidencia que o avatar vem dos metadados da sessão.

**Ações possíveis / o que acontece:**
- Sem diferenças funcionais.

**Estados relacionados:** `37-perfil-topo`

---

### Perfil em tela pequena

![Página de perfil em viewport móvel](../shots/38-perfil-mobile.png)

**Rota:** `/perfil` · **Quem acessa:** usuário autenticado · **Viewport/tema:** mobile (390 × 844) claro (captura de página inteira)

**Elementos visíveis:**
- Cabeçalho compacto (logo + hambúrguer).
- O cartão "Informações Públicas" passa a **uma coluna**: avatar centralizado no topo, link "Escolher nova foto" abaixo e, em seguida, os campos Email (com o texto cortado pela largura), Método de Login, Nome de Usuário e o botão "Salvar Perfil" alinhado à direita.
- No cartão "Segurança", os dois campos de senha ficam empilhados e o botão "Alterar Senha" ocupa a largura do texto, alinhado à esquerda.

**Ações possíveis / o que acontece:**
- Idênticas ao desktop.

**Estados relacionados:** `37-perfil-topo`

---

# Redefinição de senha por e-mail

Quem esqueceu a senha não passa pela página de perfil: o fluxo começa no `AuthModal`, segue por um e-mail transacional e termina na rota `/reset-password`. O link enviado pelo Supabase (GoTrue) autentica a pessoa automaticamente ao ser aberto — por isso a rota, apesar de protegida, é alcançável por quem "não sabe a senha".

Arquivos-fonte: `src/components/auth/AuthModal.tsx` (modo `forgot-password`), `src/contexts/AuthContext.tsx` (`resetPassword` → `supabase.auth.resetPasswordForEmail` com `redirectTo = <origem>/reset-password`) e `src/pages/ResetPasswordPage.tsx`.

---

### Modal "Recuperar Senha"

![AuthModal em modo Recuperar Senha com o e-mail preenchido](../shots/38-reset-solicitar.png)

**Rota:** `/` → botão "Entrar" no cabeçalho → link "Esqueceu a senha?" · **Quem acessa:** visitante não autenticado · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Modal centralizado sobre o catálogo desfocado, com "×" no canto.
- Título "**Recuperar Senha**"; ao contrário do modo de login, **não** há botão "Continuar com Google" nem separador "ou".
- Único campo: "E-mail", preenchido com "colega.demo@planteicerto.local".
- Botão verde de largura total "**Enviar Instruções**" e, após a linha divisória, o link "Voltar para o login".

**Ações possíveis / o que acontece:**
- "Enviar Instruções" dispara o e-mail de recuperação e troca o conteúdo do modal pela tela de confirmação.
- Excesso de tentativas → toast "Muitas solicitações em pouco tempo. Aguarde 60 segundos e tente novamente."; outros erros → "Ocorreu um erro ao recuperar a senha. Verifique o e-mail ou tente mais tarde." (nenhum capturado).
- Por segurança, o app não diferencia e-mail cadastrado de não cadastrado.

**Estados relacionados:** `38-reset-email-enviado`

---

### Confirmação "E-mail enviado"

![Modal com ícone de carta e a mensagem E-mail enviado](../shots/38-reset-email-enviado.png)

**Rota:** mesmo modal, após o envio · **Quem acessa:** visitante · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Ícone de envelope em cinza no topo.
- Título "**E-mail enviado**" e o texto "Enviamos as instruções para você recuperar sua senha para colega.demo@planteicerto.local. Verifique sua caixa de entrada.".
- Botão verde "**Entendido**", que fecha o modal.

**Ações possíveis / o que acontece:**
- Fechar o modal não interrompe nada: o link já está a caminho por e-mail.

**Estados relacionados:** `38-reset-form`

---

### O e-mail de recuperação

**NÃO CAPTURADO como imagem** (o e-mail não faz parte da interface web; no ambiente local ele é entregue no Mailpit). Conteúdo verificado na execução:

- **Assunto:** "Redefinição de senha — PlanteiCerto".
- **Corpo:** cabeçalho com o nome do produto, saudação "Olá, Colega da Equipe!" e o texto "Recebemos uma solicitação para redefinir a senha da sua conta no PlanteiCerto. Se foi você, basta clicar no botão abaixo para criar uma senha nova e segura.", seguido do botão "**Redefinir Minha Senha**".
- **Destino do botão:** endpoint de verificação do Supabase (`/auth/v1/verify`) com um token de uso único, `type=recovery` e `redirect_to` apontando para `/reset-password` na origem do aplicativo. Abrir o link cria a sessão e redireciona o navegador para a página de nova senha.

---

### Página "Nova Senha"

![Formulário Nova Senha com cadeado](../shots/38-reset-form.png)

**Rota:** `/reset-password` — alcançada pelo link do e-mail · **Quem acessa:** usuário autenticado pelo token de recuperação · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Cartão branco centralizado com ícone de **cadeado** dentro de um círculo verde-claro.
- Título "**Nova Senha**" e a linha de apoio "Crie uma nova senha segura para sua conta.".
- Campos "Senha" (placeholder "No mínimo 6 caracteres") e "Confirmar Senha" (placeholder "Repita a nova senha"), ambos obrigatórios.
- Botão verde de largura total "**Atualizar Senha**".
- No cabeçalho do site já aparece o avatar e o nome "Colega da Equi…": o link do e-mail autenticou a pessoa.

**Ações possíveis / o que acontece:**
- Enviar dispara as validações locais e, em seguida, `supabase.auth.updateUser`.
- Navegar para outra rota do site é possível (a sessão está ativa), mas a senha só muda se o formulário for enviado.

**Estados relacionados:** `38-reset-erro-curta`, `38-reset-erro-diferentes`, `39-reset-sucesso`

---

### Validação — senha curta

![Toast A senha deve ter pelo menos 6 caracteres](../shots/38-reset-erro-curta.png)

**Rota:** `/reset-password` → enviar com menos de 6 caracteres · **Quem acessa:** usuário com token válido · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Toast vermelho-claro na base: "**A senha deve ter pelo menos 6 caracteres.**" (note a diferença de redação em relação ao perfil, que diz "no mínimo").
- Os dois campos mostram três caracteres mascarados.

**Ações possíveis / o que acontece:**
- Nesta página a verificação de **tamanho vem primeiro**; só depois é comparada a confirmação — ordem inversa à do formulário do perfil.

**Estados relacionados:** `38-perfil-toast-senha-curta`

---

### Validação — senhas diferentes

![Toast As senhas não coincidem na página de nova senha](../shots/38-reset-erro-diferentes.png)

**Rota:** `/reset-password` → confirmação divergente · **Quem acessa:** usuário com token válido · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Toast "**As senhas não coincidem.**" na base da tela; campos preenchidos com dez caracteres mascarados cada.

**Ações possíveis / o que acontece:**
- Nenhuma requisição é enviada até que as duas regras passem.

**Estados relacionados:** `39-reset-alterando`

---

### Estado "Alterando..."

![Botão Alterando durante a troca de senha](../shots/39-reset-alterando.png)

**Rota:** `/reset-password` → envio válido · **Quem acessa:** usuário com token válido · **Viewport/tema:** desktop claro (requisição atrasada artificialmente)

**Elementos visíveis:**
- O botão exibe "**Alterando...**", esmaecido e desabilitado.
- O toast "As senhas não coincidem." da tentativa anterior ainda está visível na base — é resíduo do passo anterior, não uma mensagem deste envio.

**Ações possíveis / o que acontece:**
- Terminando com sucesso, o formulário é substituído pelo painel de confirmação; com erro, volta ao formulário e exibe um toast.

**Estados relacionados:** `39-reset-sucesso`

---

### Painel "Senha atualizada!"

![Painel verde confirmando a troca de senha](../shots/39-reset-sucesso.png)

**Rota:** `/reset-password` · **Quem acessa:** usuário com token válido · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- O formulário sumiu. No lugar, dentro do mesmo cartão (que mantém o cadeado e o título "Nova Senha"), um painel verde-claro com um **check** grande, o texto em negrito "**Senha atualizada!**" e a explicação "Sua senha foi alterada com sucesso. Redirecionando para o início...".
- Não há botão: o redirecionamento é automático.

**Ações possíveis / o que acontece:**
- Após 3 segundos o app navega para `/`.

**Estados relacionados:** `39-reset-redirecionado`

---

### Redirecionamento automático para o catálogo

![Catálogo de árvores já autenticado após a redefinição](../shots/39-reset-redirecionado.png)

**Rota:** `/` — destino do redirecionamento · **Quem acessa:** usuária recém-autenticada · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- Catálogo normal: hero "Encontre a árvore **certa**", botão "Encontrar Árvore Recomendada", barra de busca, ordenação "Nome (A → Z)", botões "Favoritos" e "Filtros Avançados", contador "Mostrando **6** de **146** árvores" e os primeiros cartões de espécie (Açoita-cavalo, Aldrago, Aldrago miúdo…).
- No cabeçalho, o avatar com a inicial "C" e o nome "Colega da Equi…": a sessão criada pelo link permanece ativa, ou seja, **a pessoa termina o fluxo já logada**.

**Ações possíveis / o que acontece:**
- A partir daqui a navegação é a normal do site; a próxima entrada usará a nova senha.

**Estados relacionados:** `38-reset-form`

---

## Fluxo passo a passo — atualizar o perfil com foto

1. O usuário abre o menu do avatar no cabeçalho e escolhe "Meu Perfil"; a página mostra os cartões "Informações Públicas" e "Segurança" (ver `37-perfil-topo`).
2. Sem foto, o avatar exibe a inicial do nome (ver `37-perfil-avatar-inicial`); ao passar o mouse aparece a sobreposição "Alterar Foto" (ver `37-perfil-avatar-hover`).
3. Clica no avatar (ou em "Escolher nova foto") e seleciona uma imagem. Arquivos acima de 5 MB são recusados na hora, com a mensagem "Arquivo muito grande. Máximo: 5MB." e sem alterar o avatar (ver `37-perfil-avatar-erro-tamanho`).
4. Com um arquivo válido, o círculo passa a mostrar a prévia local da imagem (ver `37-perfil-avatar-previa`). Nada foi enviado ainda.
5. Ajusta o "Nome de Usuário" se quiser (máx. 80 caracteres, com contador) e clica em "Salvar Perfil": o botão vira "Salvando..." (ver `37-perfil-salvando`).
6. A imagem é enviada ao bucket `avatars`, a URL pública é gravada nos metadados e surge o toast "Perfil atualizado com sucesso!"; o avatar do cabeçalho também é atualizado (ver `37-perfil-toast-salvo`).
7. Ao recarregar a página, a foto vem da URL pública do storage (ver `37-perfil-com-foto`). Sessões abertas em outros dispositivos continuarão mostrando a inicial até serem renovadas.

## Fluxo passo a passo — redefinir a senha por e-mail

1. Deslogado, o usuário clica em "Entrar" no cabeçalho e, no modal de login, no link discreto "Esqueceu a senha?".
2. O modal troca para "Recuperar Senha", com um único campo de e-mail; ele informa o endereço e clica em "Enviar Instruções" (ver `38-reset-solicitar`).
3. O modal confirma o envio com o ícone de carta, o texto "E-mail enviado" citando o endereço, e o botão "Entendido" (ver `38-reset-email-enviado`).
4. Na caixa de entrada chega a mensagem "Redefinição de senha — PlanteiCerto", com saudação personalizada e o botão "Redefinir Minha Senha".
5. O link abre o endpoint de verificação do Supabase, que valida o token de uso único, cria a sessão e redireciona para `/reset-password`. A página "Nova Senha" aparece com o cadeado e dois campos (ver `38-reset-form`); o cabeçalho já mostra a pessoa autenticada.
6. Senhas com menos de 6 caracteres são barradas com "A senha deve ter pelo menos 6 caracteres." (ver `38-reset-erro-curta`) e divergências entre os campos com "As senhas não coincidem." (ver `38-reset-erro-diferentes`).
7. Com os dois campos válidos, o botão passa a "Alterando..." (ver `39-reset-alterando`) e, concluída a atualização, o formulário dá lugar ao painel verde "Senha atualizada! / Sua senha foi alterada com sucesso. Redirecionando para o início..." (ver `39-reset-sucesso`).
8. Após 3 segundos o aplicativo leva a pessoa ao catálogo, já autenticada (ver `39-reset-redirecionado`).
