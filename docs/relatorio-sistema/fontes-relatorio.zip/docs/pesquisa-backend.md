I have everything. Here is the exhaustive factual basis.

---

# PlanteiCerto — Backend / Data Model / Business Logic Reference

Repo: `/Users/rigolao/Developer/PlanteiCerto` · Stack: React 19 + Vite 7 + TypeScript + TanStack Query 5 + Tailwind 4 + Leaflet 1.9 / react-leaflet 5, backend Supabase (Postgres 17), edge functions in Deno.

---

## 1. Database schema (`supabase/migrations/`)

Five migrations, applied in filename order. Older ones live in `supabase/_archive/migrations/` (history only, not applied).

### 1.1 `/Users/rigolao/Developer/PlanteiCerto/supabase/migrations/20260702000000_baseline_from_prod.sql` (717 lines)

Baseline dumped from production on 2026-07-02. Extensions: `pg_stat_statements`, `pgcrypto`, `supabase_vault`, `uuid-ossp`.

**Functions (all `SECURITY DEFINER`)**

| Function | Lang | Purpose |
|---|---|---|
| `public.get_my_role()` → `text` | sql, STABLE | `SELECT role FROM public.profiles WHERE id = auth.uid()` |
| `public.handle_new_user()` → trigger | plpgsql | On `auth.users` insert, creates `public.profiles` row with `nome` from `raw_user_meta_data->>'nome'` ‖ `'full_name'` ‖ `split_part(email,'@',1)` |
| `public.prevent_role_self_escalation()` → trigger | plpgsql | Raises `'Alteração de role não permitida'` if `OLD.role != NEW.role` and `get_my_role() <> 'admin'` |

**Triggers**: `enforce_role_protection` — `BEFORE UPDATE ON public.profiles FOR EACH ROW`.

**Tables**

`public.trees` (PK `id integer`, `serial` via `trees_id_seq`). Full column list:

| Column | Type | Constraint |
|---|---|---|
| `id` | integer | PK, default `nextval('trees_id_seq')` |
| `foto` | text | |
| `nome_cientifico` | text | NOT NULL |
| `nome_popular` | text | NOT NULL |
| `origem` | text | NOT NULL, CHECK ∈ {`Nativa BR`, `Exótica`} |
| `decidua_perenifolia` | text | CHECK ∈ {`Perenifólia`, `Decídua`, `Semidecídua`} |
| `epoca_floracao` | text | |
| `epoca_frutificacao` | text | |
| `altura_adulta_max_m` | numeric | |
| `porte_altura_classe` | text | CHECK ∈ {`Grande`, `Médio`, `Pequeno`} |
| `diametro_copa_adulto_max_m` | numeric | |
| `copa_classe` | text | CHECK ∈ {`Grande`, `Média`, `Pequena`} |
| `dap_adulto_max_cm` | numeric | |
| `altura_primeira_bifurcacao_m` | text | (text in DB; `nullableNumber` in the zod form schema) |
| `forma_copa` | text | |
| `faixa_serv_min_m_recomendada` | numeric | |
| `berco_area_min_m2_recomendada` | numeric | |
| `volume_solo_min_m3_recomendado` | numeric | |
| `compat_fiacao` | text | CHECK ∈ {`N`, `A`, `C`} |
| `potencial_dano_calcada_1a5` | smallint | CHECK 1–5 |
| `tolerancia_sol_pleno` | boolean | |
| `tolerancia_meia_sombra` | boolean | |
| `tolerancia_sombra` | boolean | |
| `tolerancia_seca_1a5` | smallint | CHECK 1–5 |
| `tolerancia_encharcamento_1a5` | smallint | CHECK 1–5 |
| `tolerancia_poluicao_atmosferica_1a5` | smallint | CHECK 1–5 |
| `tolerancia_compactacao_solo_1a5` | smallint | CHECK 1–5 |
| `tolerancia_ventos_fortes_1a5` | smallint | CHECK 1–5 |
| `potencial_sujeira_1a5` | smallint | CHECK 1–5 |
| `presenca_espinhos` | boolean | |
| `presenca_subst_irritantes` | boolean | |
| `atracao_fauna_1a5` | smallint | CHECK 1–5 |
| `tolerancia_poda_1a5` | smallint | CHECK 1–5 |
| `potencial_sombra_1a5` | smallint | CHECK 1–5 |
| `contribuicao_biodiversidade_1a5` | smallint | CHECK 1–5 |
| `ativa` | boolean | NOT NULL DEFAULT true |

…plus the 15 projection columns added later (§1.4).

`public.profiles` — `id uuid` PK → `auth.users(id)` ON DELETE CASCADE; `nome text`; `email text`; `role text NOT NULL DEFAULT 'user'`; `created_at timestamptz DEFAULT now()`. Table comment: "Perfis de usuário com controle de role (user/admin)".

`public.projects` — `id uuid` PK DEFAULT `uuid_generate_v4()`; `user_id uuid NOT NULL` → `auth.users(id)` CASCADE; `nome text NOT NULL`; `descricao text NOT NULL DEFAULT ''`; `centro_lat double precision NOT NULL DEFAULT -21.1767`; `centro_lng double precision NOT NULL DEFAULT -47.8208` (Ribeirão Preto/SP); `centro_zoom smallint NOT NULL DEFAULT 14`; `created_at timestamptz NOT NULL DEFAULT now()`.

`public.points` — `id uuid` PK DEFAULT `gen_random_uuid()`; `project_id uuid NOT NULL` → `projects(id)` ON DELETE CASCADE; `tree_id integer` → `trees(id)` **ON DELETE SET NULL**; `lat`/`lng double precision NOT NULL`; `observacao text NOT NULL DEFAULT ''`; `created_at timestamptz DEFAULT now()`.

`public.user_favorites` — `id uuid` PK; `user_id uuid NOT NULL` → `auth.users` CASCADE; `tree_id integer NOT NULL` → `trees` CASCADE; `created_at timestamptz NOT NULL DEFAULT now()`; **UNIQUE (`user_id`, `tree_id`)**.

**Indexes**: `idx_points_project_id`, `idx_points_tree_id`, `idx_projects_user_id`, `idx_trees_nome_popular`, `idx_trees_origem`, `idx_user_favorites_tree_id`, `idx_user_favorites_user_id` (all btree).

**Views**: none in any migration.

**RLS** — enabled on all five public tables. Policies:

| Table | Policy | Op | Predicate |
|---|---|---|---|
| trees | `Public read trees` | SELECT | `ativa = true` OR caller is admin (subselect on profiles) |
| trees | `Admin insert/update/delete trees` | I/U/D | `EXISTS (profiles WHERE id=auth.uid() AND role='admin')` |
| profiles | `Users can read own profile` | SELECT | `auth.uid() = id` |
| profiles | `Users can update own profile` | UPDATE | `auth.uid() = id` |
| profiles | `Admins can read all profiles` | SELECT | `get_my_role() = 'admin'` |
| profiles | `Admins can update any profile` | UPDATE | `get_my_role() = 'admin'` |
| projects | view/create/update/delete own | all | `auth.uid() = user_id` |
| points | `Users can manage own project points` | ALL | `EXISTS (projects WHERE projects.id = points.project_id AND projects.user_id = auth.uid())` |
| points | `Users can read own project points` | SELECT | same subselect |
| points | `Admins can read all points` | SELECT | `get_my_role() = 'admin'` |
| user_favorites | view/add/remove own | S/I/D | `auth.uid() = user_id` |

Grants: `ALL` on every table/sequence/function to `anon`, `authenticated`, `service_role` (RLS is the real gate).

### 1.2 `20260702000001_auth_storage_from_prod.sql`

Objects `supabase db dump` omits (they live in `auth`/`storage` schemas).

- Trigger `on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE public.handle_new_user()`.
- **Storage buckets** (all `public = true`, `ON CONFLICT DO NOTHING`): `avatars`, `criterios`, `guias`, `tree-images`.
- **10 `storage.objects` policies**:
  - `tree-images`: `Public read tree images` (SELECT, any), `Admin upload/update/delete tree images` (admin-only subselect on profiles).
  - `avatars`: `public_avatars` (SELECT any), `insert_avatars`/`update_avatars`/`delete_avatars` (role `authenticated`).
  - `guias`: `Public Read Guias` (SELECT), and `Temp Public Insert Guias` — **unauthenticated INSERT allowed**, explicitly flagged in the file as a parity reproduction that should be restricted.

### 1.3 `20260702000002_email_exists_rpc.sql`

`public.email_exists(p_email text) returns boolean`, `language sql stable security definer set search_path = ''`; does `exists(select 1 from auth.users where lower(email)=lower(trim(p_email)))`. Execute is **revoked from public/anon/authenticated**, granted only to `service_role`. Replaces the previous `auth.admin.listUsers({perPage:1000})` approach that missed users past page 1.

### 1.4 `20260802000000_add_projecao_10a_to_trees.sql` (221 lines)

Adds 15 columns to `public.trees` (all `ADD COLUMN IF NOT EXISTS`):

`dap_10a_cm`, `dap_10a_min_cm`, `dap_10a_max_cm`, `altura_10a_m`, `altura_10a_min_m`, `altura_10a_max_m`, `biomassa_aerea_10a_kg`, `carbono_armazenado_10a_kg`, `co2e_10a_kg`, `sobrevivencia_10a_pct`, `co2e_esperado_por_muda_10a_kg` — all `numeric`; `classe_bvoc text`, `evidencia_bvoc text`, `confianca_bvoc text`, `exibir_aviso_bvoc boolean DEFAULT false`.

New CHECKs (added guarded by `pg_constraint` existence test):
- `trees_sobrevivencia_10a_pct_check`: 0 ≤ value ≤ 100
- `trees_classe_bvoc_check`: ∈ {`baixo`,`moderado`,`alto`,`desconhecido`,`indeterminado`}
- `trees_confianca_bvoc_check`: ∈ {`baixa`,`baixa-média`,`média`,`média-alta`}

Column comments carry the formulas: `carbono_armazenado_10a_kg = biomassa × 0,47`; `co2e_10a_kg = carbono × 3,6667`; `co2e_esperado_por_muda_10a_kg` = CO₂e already weighted by survival. Backfill = one idempotent `UPDATE ... FROM (VALUES ...)` with **149 rows** keyed by `trees.id`.

### 1.5 `20260908000000_apply_lorenzi_v1_validated_structure.sql`

Editorial data correction from Lorenzi, *Árvores Brasileiras* vol. 1 (1992). Single `DO $$` block:
- 23 height corrections (`altura_adulta_max_m` + `porte_altura_classe`), each guarded by `AND tree.altura_adulta_max_m = expected_height_m`; raises an exception if the count ≠ 23.
- 13 habit corrections (`decidua_perenifolia`), same expected-value guard; raises if count ≠ 13.

Self-documenting rollback (restore the `expected_*` values). DAP and phenology deliberately untouched.

### 1.6 Seed & local config

- `/Users/rigolao/Developer/PlanteiCerto/supabase/seed.sql` — single `INSERT INTO public.trees (…51 columns…) VALUES` with **167 rows**, then `setval('trees_id_seq', 198, true)`.
- `/Users/rigolao/Developer/PlanteiCerto/supabase/config.toml` — API port 54321, DB 54322 (Postgres major 17), Studio 54323, Mailpit 54324, `max_rows = 1000`; storage `file_size_limit = 50MiB`; auth `site_url = http://localhost:5173`, `jwt_expiry 3600`, `minimum_password_length = 6`, Google OAuth enabled (`skip_nonce_check = true`), Apple disabled; custom email templates in `supabase/email_templates/{confirm_signup,reset_password,change_email}.html`; **both edge functions declared `verify_jwt = false`**.

---

## 2. Edge functions (`supabase/functions/`)

### 2.1 `recommend-trees` — `/Users/rigolao/Developer/PlanteiCerto/supabase/functions/recommend-trees/index.ts` (572 lines)

**Request**: `POST` JSON `{ answers: Record<string,string> }`. Handles `OPTIONS`. CORS allow-list from `ALLOWED_ORIGINS` env (comma-separated), fallback `['http://localhost:5173','http://localhost:4173']`; `Vary: Origin`.

**Response** 200: `{ trees: Array<Tree & { score:number; scoreBreakdown: {label,points,maxPoints}[] }>, eliminated_count: number, criteriaSummary: { eliminatory: string[]; classificatory: string[] } }`. Errors: 400 `{error:'Campo "answers" é obrigatório'}`, 500 `{error:'Erro ao buscar espécies'|'Erro interno', details}`.

**Algorithm**
1. Service-role client (`SUPABASE_URL` + `SUPABASE_SERVICE_ROLE_KEY`), `supabase.from('trees').select('*').eq('ativa', true)`. `totalCount = trees.length`.
2. Phase 1 — `passesEliminatoryRules`.
3. Phase 2 — `calculateScore` per survivor.
4. `scored.sort((a,b) => b.score - a.score)` — descending score only, **no tie-break** (`Array.sort` is stable in V8, so ties keep the DB row order).
5. Structured JSON logs: `recommendation_request` (answers_count), `recommendation_success` (total_trees, eliminated_count, trees_returned), `recommendation_error`.

**Range helper `rangeUpperBound`** (conservative upper bound): `lt_1`→1.0, `1_2`→2.0, `2_3`→3.0, `3_4`→4.0, `gt_4`→99, `gt_2`→99, default→99.

**ALL eliminatory rules** (lines 91–161; any one returning false discards the species):

| Answer condition | Column tested | Eliminates when |
|---|---|---|
| `q2_2` any value | `faixa_serv_min_m_recomendada` | `> rangeUpperBound(q2_2)` |
| `q2_3 === 'sim'` AND `q2_1` set | `faixa_serv_min_m_recomendada` | `> rangeUpperBound(q2_1) − 1.20` |
| `q2_4` any value | `berco_area_min_m2_recomendada` | `> rangeUpperBound(q2_4)` |
| `q2_5 === 'sim_convencional'` AND `q2_6 === 'lt_4'` | `compat_fiacao` | `=== 'N'` |
| `q2_5 === 'sim_protegida'` OR `q2_6 === 'gt_4'` (when q2_5 ≠ 'nao') | `compat_fiacao` + `porte_altura_classe` | `'N'` **and** porte `'Grande'` |
| `q2_7 ∈ {nenhum, lt_2}` | `copa_classe` | `=== 'Grande'` |
| `q2_8a === 'lt_6'` | `porte_altura_classe` | `=== 'Grande'` |
| `q2_8b === 'lt_4'` | `copa_classe` | `=== 'Grande'` |
| `q2_8c === 'lt_1_5'` | — | **every species** (unconditional `return false`, NBR 9050) |
| `q2_8d === 'lt_1_5'` | `potencial_dano_calcada_1a5` | `(?? 0) >= 4` |
| `q3_1 === 'sol_pleno'` | `tolerancia_sol_pleno` | `=== false` |
| `q3_1 === 'meia_sombra'` | `tolerancia_meia_sombra` | `=== false` |
| `q3_1 === 'sombra'` | `tolerancia_sombra` | `=== false` |
| `q3_2 === 'seco'` | `tolerancia_seca_1a5` | `<= 2` |
| `q3_2 === 'encharcado'` | `tolerancia_encharcamento_1a5` | `<= 3` |
| `q3_3 === 'ruim'` | `tolerancia_compactacao_solo_1a5` | `<= 3` |
| `q3_4 === 'nao'` | `tolerancia_seca_1a5` | `<= 2` |
| `q4_1 === 'sim'` | `potencial_sujeira_1a5` | `>= 3` |
| `q4_2 === 'sim'` | `presenca_espinhos` / `presenca_subst_irritantes` | either `=== true` |
| `q4_3 === 'sim'` | `atracao_fauna_1a5` | `>= 4` |

Note: `null` in a tested numeric column never eliminates (all comparisons are guarded with `!= null`); `null` booleans never eliminate either (tests are `=== false` / `=== true`).

**Scoring** — `const MAX_SCORE = 190;` with the source comment `// MAX_SCORE = 120 (G2+G3) + 10 (Q4.1) + 20 (Q4.2) + 10 (Q5.1) + 10 (Q5.2) + 10 (Q6.1) + 10 (Q6.2) = 190`. Final: `score = Math.round((raw / 190) * 100)` → 0–100. Each answered question pushes one `{label, points, maxPoints}` entry into `breakdown`; **unanswered questions contribute nothing and are not in the breakdown**, but `MAX_SCORE` stays 190, so partial questionnaires can't reach 100.

Exact weights:

| Question | maxPoints | Formula / value | Breakdown label |
|---|---|---|---|
| q3_1 `sol_pleno` | 20 | `tolerancia_sol_pleno === true ? 20 : === false ? 0 : 10` | "Insolação (sol pleno)" |
| q3_1 `meia_sombra` | 20 | same over `tolerancia_meia_sombra` | "Insolação (meia sombra)" |
| q3_1 `sombra` | 20 | same over `tolerancia_sombra` | "Insolação (sombra)" |
| q3_2 `seco` | 20 | `(tolerancia_seca_1a5 ?? 3) * 4` | "Tolerância à seca" |
| q3_2 `umido` | 20 | fixed **15** | "Umidade do solo" |
| q3_2 `encharcado` | 20 | `(tolerancia_encharcamento_1a5 ?? 3) * 4` | "Tolerância a encharcamento" |
| q3_3 `ruim` | 20 | `(tolerancia_compactacao_solo_1a5 ?? 3) * 4` | "Solo compactado/aterro" |
| q3_3 other | 20 | fixed **20** | "Qualidade do solo" |
| q3_4 `nao` | 10 | `(tolerancia_seca_1a5 ?? 3) * 2` | "Sem irrigação disponível" |
| q3_4 other | 10 | fixed **10** | "Irrigação disponível" |
| q4_1 `sim` | 15 | `(6 − (potencial_sujeira_1a5 ?? 3)) * 3` | "Potencial de sujeira" |
| q4_1 other | 15 | fixed **15** | "Queda de folhas/frutos" |
| q4_2 `sim` | 15 | no thorns **and** no irritants → **15**; exactly one absent → **7**; both present → **0** (null counts as absent) | "Sem espinhos/irritantes" / "…(parcial)" / "Presença de…" |
| q4_2 other | 15 | fixed **15** | "Espinhos/irritantes" |
| q4_3 `sim` | 10 | `(6 − (atracao_fauna_1a5 ?? 3)) * 2` | "Atração de insetos/abelhas" |
| q4_3 other | 10 | fixed **10** | "Atração de fauna" |
| q4_4 `nao` | 10 | `(tolerancia_poda_1a5 ?? 3) * 2` | "Tolerância a poda mínima" |
| q4_4 other | 10 | fixed **10** | "Manutenção profissional" |
| q1_1 `calcada` | 10 | `(6 − (potencial_dano_calcada_1a5 ?? 3)) * 2` | "Adequação à calçada" |
| q1_1 `canteiro_central` | 10 | `(tolerancia_poluicao_atmosferica_1a5 ?? 3) * 2` | "Tolerância à poluição (canteiro)" |
| q1_1 `praca_parque` | 10 | `(atracao_fauna_1a5 ?? 3) * 2` | "Contribuição ecológica (praça)" |
| q1_1 `rotatorio` | 10 | `(tolerancia_ventos_fortes_1a5 ?? 3) * 2` | "Tolerância a ventos (rotatória)" |
| q1_2 (multi) | 20 | `quota = 20 / n_objetivos`; sum then `Math.round` | "Objetivo(s) de plantio" |
| q5_1 `sim` | 10 | `origem === 'Nativa BR' ? 10 : 0` | "Espécie nativa" |
| q5_1 `nao` | 10 | fixed **10** | "Origem da espécie" |
| q5_2 `sim` | 10 | `(atracao_fauna_1a5 ?? 3) * 2` | "Atração de fauna (preferência)" |
| q5_2 `nao` | 10 | fixed **10** | "Atração de fauna" |
| q3_5 `sim` | 10 | `(tolerancia_ventos_fortes_1a5 ?? 3) * 2` | "Tolerância a ventos fortes" |
| q3_5 `nao` | 10 | fixed **10** | "Exposição ao vento" |
| q3_6 `sim` | 10 | `(potencial_sombra_1a5 ?? 3) * 2` | "Potencial de sombra (ilha de calor)" |
| q3_6 `nao` | 10 | fixed **10** | "Potencial de sombra" |

q1_2 per-objective contribution (each over its `quota`):
- `sombra`: `(potencial_sombra_1a5 ?? 3)/5 × quota`
- `embelezamento`: `(atracao_fauna_1a5 ?? 3)/5 × quota` — explicit proxy, comment: species with good flowering tend to attract fauna
- `fauna`: `(atracao_fauna_1a5 ?? 3)/5 × quota`
- `baixa_manutencao`: `decidua_perenifolia === 'Perenifólia'` → full quota, else `((6 − (potencial_sujeira_1a5 ?? 3))/5) × quota`
- `qualidade_ar`: `(contribuicao_biodiversidade_1a5 ?? 3)/5 × quota`
- `nativas`: `origem === 'Nativa BR'` ? quota : 0

Null-handling conventions: null 1–5 scales default to **3**; null booleans in insolation score **10** (half).

**`criteriaSummary`** — built by `buildCriteriaSummary(answers)` (lines 430–497) purely from the answers, independent of any tree. Two string arrays of human-readable Portuguese labels:

*eliminatory* (pushed in this order): `Faixa de serviço: {< 1m|1–2m|2–3m|3–4m|> 4m}`; `Faixa acessível de 1,20m obrigatória`; `Berço disponível: {< 1m²|1–2m²|> 2m²}`; `Fiação convencional`; `Fiação isolada/protegida`; `Fiação a < 4m`; `Sem recuo da edificação`; `Recuo < 2m`; `Esquina a < 6m`; `Poste a < 4m`; `Guia rebaixada a < 1,5m`; `Boca-de-lobo a < 1,5m`; `Insolação: {sol pleno|meia sombra|sombra} (tolerância obrigatória)`; `Solo seco (tolerância_seca ≥ 3 exigida)`; `Solo encharcado (tolerância_encharcamento ≥ 4 exigida)`; `Solo compactado (tolerância_compactação ≥ 4 exigida)`; `Sem irrigação no 1º ano (tolerância_seca ≥ 3 exigida)`; `Queda de resíduos: elimina potencial_sujeira ≥ 3`; `Espinhos/irritantes: elimina espécies com presença`; `Atração de insetos: elimina atracao_fauna ≥ 4`.

*classificatory*: `Insolação: {Sol pleno (> 6h)|Meia sombra (3–6h)|Sombra (< 3h)}`; `Umidade: {Solo seco|Solo úmido|Solo encharcado}`; `Solo compactado/aterro`; `Sem irrigação no 1º ano`; `Queda de resíduos é problema`; `Espinhos/irritantes são problema`; `Evitar atração de insetos`; `Sem poda profissional`; `Local: {Calçada|Canteiro central|Praça/parque|Rotatória}`; `Objetivo(s): {…}` (joined labels); `Preferência por nativas`; `Preferência por espécies atrativas à fauna`; `Local exposto a ventos fortes`; `Necessidade de sombra (ilha de calor)`.

The function's `Tree` interface duplicates `src/types/tree.ts` including the 10-year projection fields, with the comment that they do **not** enter scoring today — they come along in `select('*')` and are returned to the client.

### 2.2 `check-email-exists` — `/Users/rigolao/Developer/PlanteiCerto/supabase/functions/check-email-exists/index.ts` (95 lines)

**Request** `POST {email: string}` → **Response** `{exists: boolean}` (200). Errors: 403 `Origem não autorizada.` (server-side origin check, because Kong may overwrite CORS with `*`), 429 `Muitas tentativas. Aguarde um minuto.`, 400 `E-mail inválido.` / `Requisição inválida.`, 500 `Erro ao verificar e-mail.`.

Algorithm: in-memory per-IP rate limit `RATE_LIMIT = 10` per `RATE_WINDOW_MS = 60_000` keyed on first `x-forwarded-for` hop (resets on cold start); validate `typeof email === 'string' && length ≤ 320 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/`; service-role client with `autoRefreshToken:false, persistSession:false`; `rpc('email_exists', {p_email: email})`.

---

## 3. `src/data/questionnaire.ts` (354 lines)

Types: `QuestionType = 'eliminatorio' | 'classificatorio' | 'misto'`; `Question = {id, group: 1|2|3|4|5, groupLabel, type, text, helpText?, options: {value,label}[], multiSelect?, showIf?: {questionId, values[]}, subQuestions?}`.

**The implemented questionnaire has 5 groups, not 6** — the 6-group table in `docs/recomendacao-classificacao.md` is the older spec numbering (its G1 = space is the code's Group 2, its G6 = "Outros Fatores" was folded into Group 3 as `q3_5`/`q3_6`). Worth flagging in the report text.

`flattenQuestions()` replaces a parent question by its `subQuestions` (so `q2_8` never renders itself; only `q2_8a…d` do). 20 leaf questions total, 19 of them normally visible (`q2_6` is conditional).

**Group 1 — "Contexto e Objetivos"**
- `q1_1` · classificatorio · "Qual o tipo de local de plantio?" → `calcada` ("Calçada em frente a lote/residência"), `canteiro_central` ("Canteiro central de avenida"), `praca_parque` ("Praça ou parque (área interna)"), `rotatorio` ("Rotatória ou trevo viário")
- `q1_2` · classificatorio · **multiSelect** · "Qual o principal objetivo com a árvore? (escolha até 2)" · helpText "Selecione até 2 opções." → `sombra` ("Sombra e conforto térmico"), `embelezamento` ("Embelezamento e floração"), `fauna` ("Atração de fauna (aves/polinizadores)"), `baixa_manutencao` ("Baixa manutenção / pouca sujeira"), `qualidade_ar` ("Melhorar qualidade do ar e biodiversidade"), `nativas` ("Valorizar espécies nativas da região")

**Group 2 — "Espaço e Interferências"** (all `eliminatorio`)
- `q2_1` "Qual a largura total da calçada (m)?" → `lt_1`, `1_2`, `2_3`, `3_4`, `gt_4`
- `q2_2` "Qual a largura efetiva da faixa de serviço (m)?" · help "Faixa onde a árvore será plantada, entre o meio-fio e a faixa livre." → same 5 options
- `q2_3` "É necessário manter faixa livre acessível de 1,20 m (ABNT NBR 9050)?" · help "Calçadas com fluxo de pedestres precisam de faixa livre mínima de 1,20 m." → `sim`/`nao`
- `q2_4` "Qual a dimensão disponível para o berço/cova (m²)?" → `lt_1` ("Menos de 1 m²"), `1_2` ("1 a 2 m²"), `gt_2` ("Mais de 2 m²")
- `q2_5` "Existe fiação aérea no local?" → `nao` ("Não há fiação"), `sim_convencional`, `sim_protegida` ("Sim, isolada/protegida")
- `q2_6` "Qual a distância até a fiação aérea (m)?" · **`showIf: {questionId:'q2_5', values:['sim_convencional','sim_protegida']}`** → `lt_4`, `gt_4`
- `q2_7` "Qual o recuo da edificação em relação à calçada?" → `nenhum` ("Sem recuo (construção na divisa)"), `lt_2`, `gt_2`
- `q2_8` "Distâncias de segurança" — container, `options: []`, with 4 **subQuestions** (all eliminatorio, all citing "Cartilha de Arborização, p.16"):
  - `q2_8a` "…distância até a esquina mais próxima (m)?" min 6 m → `lt_6`, `gt_6`
  - `q2_8b` "…até o poste de iluminação mais próximo (m)?" min 4 m → `lt_4`, `gt_4`
  - `q2_8c` "…até a guia rebaixada (rampa de acessibilidade) mais próxima (m)?" min 1,5 m → `lt_1_5`, `gt_1_5`
  - `q2_8d` "…até a boca-de-lobo ou caixa de inspeção mais próxima (m)?" min 1,5 m → `lt_1_5`, `gt_1_5`

**Group 3 — "Condições Ecológicas e Ambientais"**
- `q3_1` · **misto** · "Qual a condição de insolação do local?" → `sol_pleno` ("Sol pleno (mais de 6h de sol direto)"), `meia_sombra` ("Meia sombra (3 a 6h de sol)"), `sombra` ("Sombra (menos de 3h de sol)")
- `q3_2` · misto · "Como é a umidade do solo no local?" → `seco` ("Seco (bem drenado)"), `umido` ("Úmido (moderado)"), `encharcado` ("Encharcado (alagável)")
- `q3_3` · misto · "Qual a qualidade do solo?" → `bom` ("Bom (solo natural, permeável)"), `ruim` ("Ruim (compactado, entulho, aterro)")
- `q3_4` · misto · "Haverá irrigação regular no primeiro ano?" → `sim`/`nao`
- `q3_5` · classificatorio · "O local é muito exposto a ventos fortes?" → `sim` ("Sim, local ventoso"), `nao` ("Não, local abrigado")
- `q3_6` · classificatorio · "O local sofre com ilha de calor (necessidade de sombra extra)?" → `sim` ("Sim, priorizar espécies com alto potencial de sombra"), `nao`

**Group 4 — "Preferências e Manutenção"**
- `q4_1` · misto · "A queda de folhas, flores ou frutos é um problema no local?" → `sim` ("Sim, quero minimizar sujeira"), `nao` ("Não, sem restrição")
- `q4_2` · misto · "A presença de espinhos ou substâncias irritantes é um problema?" → `sim` ("Sim, quero evitar"), `nao`
- `q4_3` · misto · "É necessário evitar atração de abelhas ou insetos?" → `sim` ("Sim, quero minimizar"), `nao`
- `q4_4` · classificatorio · "Haverá poda profissional periódica?" → `sim` ("Sim, haverá manutenção profissional"), `nao` ("Não, manutenção mínima")

**Group 5 — "Preferências Botânicas"** (both classificatorio)
- `q5_1` "Há preferência por espécies nativas do Brasil?" → `sim` ("Sim, priorizar nativas"), `nao` ("Não é uma prioridade")
- `q5_2` "Há preferência por espécies que atraiam fauna (aves, polinizadores)?" → `sim` ("Sim, priorizar"), `nao`

Driver `/Users/rigolao/Developer/PlanteiCerto/src/pages/RecommendationPage.tsx`: phases `questions | loading | results`; `visibleSteps` re-filters `showIf` on every answer change; multi-select caps at 2 (`current.length < 2`) and is serialized as a comma-joined string; "Próximo" disabled until the current question is answered; last step opens a confirmation modal ("Finalizar questionário?") before `mutateAsync`; `totalAnalyzed = trees.length + eliminated_count`; on error it silently returns to `questions`.

---

## 4. `src/types/*.ts`

`/Users/rigolao/Developer/PlanteiCerto/src/types/tree.ts` — `interface Arvore` mirrors the `trees` table with narrowed literal unions: `origem: 'Nativa BR' | 'Exótica'`, `decidua_perenifolia: 'Perenifólia'|'Decídua'|'Semidecídua'`, `porte_altura_classe: 'Grande'|'Médio'|'Pequeno'|null`, `copa_classe: 'Grande'|'Média'|'Pequena'|null`, `compat_fiacao: 'N'|'A'|'C'|null`, `altura_primeira_bifurcacao_m: string | null`, `ativa?: boolean`, plus the 15 optional projection fields. Also exports `type ClasseBvoc = 'baixo'|'moderado'|'alto'|'desconhecido'|'indeterminado'`, `type ConfiancaBvoc = 'baixa'|'baixa-média'|'média'|'média-alta'`, and `type FiltroAtributo = 'todos' | 'nativas' | 'sem_espinhos'`. Comment explains the projection fields are optional because palms (e.g. Jerivá) don't follow DAP allometry and the static fallback lacks them.

`/Users/rigolao/Developer/PlanteiCerto/src/types/project.ts` — `CentroMapa {lat,lng,zoom}`; `PontoPendente {id: string /* front-end temp */, lat, lng}`; `Ponto {id, project_id, tree_id: number, lat, lng, observacao, created_at?}`; `Projeto {id, user_id, nome, descricao, centro_lat, centro_lng, centro_zoom, created_at, pontos?: Ponto[], points?: {count:number}[]}`.

`/Users/rigolao/Developer/PlanteiCerto/src/types/recommendation.ts` — `Answers = Record<string,string>`; `ScoreCriterion {label, points, maxPoints}`; `RecommendedTree extends Arvore {score, scoreBreakdown}`; `CriteriaSummary {eliminatory: string[], classificatory: string[]}`; `RecommendationResult {trees, eliminated_count, criteriaSummary}`.

`/Users/rigolao/Developer/PlanteiCerto/src/types/auth.ts` — `UserProfile {id, nome, email, avatar_url?, providers?: string[]}` (session-derived); `Profile {id, nome: string|null, email: string|null, role: 'admin'|'user', created_at}` (DB row).

Zod form schemas: `/Users/rigolao/Developer/PlanteiCerto/src/schemas/tree.ts` (full admin tree form, `rating1to5 = number().min(1).max(5).nullable().optional()`), `project.ts` (nome 3–100, descricao ≤ 500), `profile.ts` (nome 1–80), `password.ts` (≥ 6 chars + confirmation match).

---

## 5. Hooks (`src/hooks/`)

| Hook | File | Query/mutation | Cache key | staleTime | Fallback / notes |
|---|---|---|---|---|---|
| `useTrees` | `useTrees.ts` | `supabase.from('trees').select('*').order('id')` | `['trees']` | 15 min | `initialData`-style default `staticTrees` (22 species in `src/data/trees.ts`); returns `staticTrees` if Supabase unconfigured, on error, or on empty result. Returns `{trees, loading}` |
| `useTreeFilters` | `useTreeFilters.ts` | pure client-side `useMemo`, no network | — | — | **Currently unused** — no importer in `src/` |
| `useRecommendation` | `useRecommendation.ts` | `useMutation` → `supabase.functions.invoke('recommend-trees', {body:{answers}})` | none (mutation) | — | Throws `'Supabase não está configurado'` when unconfigured |
| `useProfile` | `useProfile.ts` | `profiles.select('*').eq('id', user.id).single()` | `['profile', user?.id]` | 5 min | `enabled: !!user && isSupabaseConfigured()`; on error logs and returns `null`; exposes `isAdmin = profile?.role === 'admin'` |
| `useProjects` | `useProjects.ts` | query `projects.select('*, points(count)').eq('user_id').order('created_at', {ascending:false})` | `['projects', user?.id]` | default (0) | `enabled: !!user`; mutations: `createProject` (inserts with hard-coded center −21.1767 / −47.8208, zoom 14), `deleteProject`, `updateProject(nome,descricao)`, `updateMapCenter(lat,lng,zoom)`; all invalidate `['projects', user?.id]`; toasts via `sonner`; public wrappers swallow errors and return `null`/`false` |
| `useProjectPoints` | `useProjectPoints.ts` | **not React Query** — `useState` + `useEffect`/`useCallback`: `points.select('*').eq('project_id').order('created_at')` | — | — | `addPoint(treeId,lat,lng,observacao)`, `removePoint(id)`, `updatePoint(id,treeId,observacao)` — each mutates local state directly and toasts; `refetch` exposed |
| `useFavorites` | `useFavorites.ts` | `user_favorites.select('tree_id').eq('user_id')` → `Set<number>` | `['favorites', user?.id]` | 5 min | Toggle mutation with **optimistic update** (`onMutate` snapshot → `onError` rollback → `onSettled` invalidate) |
| `useAdminUsers` | `useAdminUsers.ts` | `profiles.select('*').order('created_at', {ascending:true})` | `['admin-users']` | 2 min | Returns `[]` on error (after `toast.error`). `useUpdateRole` mutation updates `profiles.role`, invalidates `['admin-users']` **and** `['profile']` |
| `useAdminTrees` | `useAdminTrees.ts` | 4 exports: `useCreateTree` (insert), `useUpdateTree` (update by id), `useDeleteTree` (delete by id) — all invalidate `['trees']` and toast; `useTreeUsageCount(treeId)` → `points.select('*',{count:'exact',head:true}).eq('tree_id')`, key `['tree-usage', treeId]`, staleTime 30 s, `enabled: treeId !== null`, returns 0 on error; `useUploadTreeImage` → `storage.from('tree-images').upload(crypto.randomUUID().ext)` then `getPublicUrl` | | | Admin pages read the catalog through `useTrees` (same `['trees']` cache) |

Client: `/Users/rigolao/Developer/PlanteiCerto/src/lib/supabase.ts` — creates a real client only when `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` are both non-empty; otherwise a placeholder client against `https://placeholder.supabase.co`; exports `isSupabaseConfigured()`.

---

## 6. Growth projection — "projeção de crescimento em 10 anos"

**Commit `cb8b8a7`** (2026-08-02, "feat: projeção de crescimento em 10 anos por espécie") — touched 8 files: the migration, `scripts/gerar_migration_projecao_10a.py` (350 lines), `scripts/mapa_projecao_10a.csv` (150 lines), `src/types/tree.ts` (+22), `src/components/trees/TreeDetailModal.tsx` (+110), `src/components/admin/TreeFormModal.tsx` (+94), `supabase/functions/recommend-trees/index.ts` (+17), regenerated `supabase/seed.sql`.

**Data source and scenario.** Spreadsheet from the advisor (`dados_app_projecao_10_anos_especies_cartilha.xlsx`). Fixed scenario for every row — seedling of **DAP 3 cm / height 1.5 m**, "boas condições", 10-year horizon. Because those three are constant, they are *not* columns; they are hard-coded UI text (`CENARIO_PROJECAO` in the modal). Coverage: 149 backfilled rows / 167 trees (145 of 146 active; **Jerivá excluded — a palm, doesn't follow DAP allometry**).

**Species mapping.** `scripts/mapa_projecao_10a.csv` (columns `tree_id, ativa, nome_popular_banco, nome_cientifico_banco, especie_id, nome_cientifico_planilha, metodo`) is explicit and versioned because the DB uses older taxonomy (e.g. *Tabebuia chrysotricha*) and the spreadsheet the updated one (*Handroanthus chrysotrichus*); 30 species match only by synonym. `metodo` records whether the match came via `nome_popular` or `nome_cientifico`. `scripts/gerar_migration_projecao_10a.py` has modes to (re)build the CSV from the xlsx, emit the SQL migration, and regenerate `seed.sql` (needed because `db reset` runs migrations *before* seed, so the migration's backfill would miss a zeroed DB).

**Formulas** (documented as SQL column comments): `carbono_armazenado_10a_kg = biomassa_aerea_10a_kg × 0,47`; `co2e_10a_kg = carbono × 3,6667`; `co2e_esperado_por_muda_10a_kg` = CO₂e already discounted by `sobrevivencia_10a_pct`. Min/max columns carry the spreadsheet's uncertainty band. BVOC (biogenic volatile organic compounds) classification comes mostly from i-Tree genus factors, with `evidencia_bvoc` strings such as "fator de gênero i-Tree", "sem fator localizado", or direct-measurement notes, and `confianca_bvoc` + `exibir_aviso_bvoc` driving a low-evidence caveat in the UI.

**Display** — `/Users/rigolao/Developer/PlanteiCerto/src/components/trees/TreeDetailModal.tsx` lines 21–125: component `ProjecaoSection` renders only `if (arvore.dap_10a_cm != null)`. Header "PROJEÇÃO EM 10 ANOS" with a `TrendingUp` icon; a 2-column grid of `ProjecaoTile`s: DAP (2 decimals + "entre X e Y cm"), Altura (2 decimals + range), "CO₂e capturado" (kg), "CO₂e esperado por muda" (detail "já descontada a mortalidade"), "Sobrevivência" (%), "Biomassa aérea" (detail "N kg de carbono"). Then a pill "Emissão de BVOC: {Baixa|Moderada|Alta|Desconhecida|Indeterminada}" (`CLASSE_BVOC_LABEL`), then — when `exibir_aviso_bvoc` — an `Info` note "Classificação de BVOC com evidência limitada (evidência) — confiança X.", then the fixed scenario sentence. Numbers formatted `toLocaleString('pt-BR', {maximumFractionDigits})`. The admin form (`TreeFormModal.tsx`) gained a matching section; that commit also fixed two form bugs (`NumberField` mixing `valueAsNumber` with `setValueAs` producing `NaN`, and "—" selects writing `''` which violates the enum CHECKs).

**Commit `9f112b4`** (2026-08-10, "Ordenação de 10 anos") added two sort options — `TreesToolbar.tsx` options `mais_co2e` "Maior captura de CO₂ (10 anos)" and `maior_crescimento` "Maior crescimento em altura (10 anos)"; implemented in `TreesPage.tsx` lines 115–119 as `(b.co2e_esperado_por_muda_10a_kg ?? 0) − (a…)` and `(b.altura_10a_m ?? 0) − (a…)` (species without projection sort last).

The recommendation edge function returns these columns but **does not score on them**.

---

## 7. Filters

Two independent filter implementations exist.

**(a) `useTreeFilters` + `Drawer` — the legacy pair, both currently dead code.**
`/Users/rigolao/Developer/PlanteiCerto/src/hooks/useTreeFilters.ts`: state `termoBusca` + `filtroAtivo: FiltroAtributo`, one `useMemo`. Search normalizes with `.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim()` (accent-insensitive) and matches `nome_popular` **OR** `nome_cientifico`; then `nativas` → `origem === 'Nativa BR'`, `sem_espinhos` → `presenca_espinhos === false`. `FiltroAtributo` is a single-choice radio-style enum (`todos|nativas|sem_espinhos`), so attribute filters are mutually exclusive there; search AND attribute combine with AND. `/Users/rigolao/Developer/PlanteiCerto/src/components/layout/Drawer.tsx` renders those three as `FilterButton`s labelled "≡ Todas as Árvores", "Nativas do Brasil", "Sem Espinhos". Neither has an importer: `useTreeFilters` is referenced only by its own definition, and `Drawer.tsx` is not imported anywhere — the live drawer is `MobileDrawer.tsx` (navigation/theme/auth only, no filters), mounted from `Header.tsx`.

**(b) The live filter set — `TreesToolbar` + `TreesPage`.**
`/Users/rigolao/Developer/PlanteiCerto/src/components/trees/TreesToolbar.tsx` defines `AdvancedFilters { porte: string; copa: string; folhagem: string; nativas: boolean; sem_espinhos: boolean; compat_fiacao: boolean; calcada_segura: boolean }` with `defaultAdvancedFilters` all empty/false. Applied in `/Users/rigolao/Developer/PlanteiCerto/src/pages/TreesPage.tsx` lines 79–122, **all combined with AND**, in this order, over a base already narrowed by `a.ativa !== false`:

1. `termoBusca` — same accent-normalized search over `nome_popular` OR `nome_cientifico` (the single OR in the chain). Search field is an `<input>` in the toolbar, placeholder "Buscar por nome ou espécie...".
2. `nativas` → `origem === 'Nativa BR'`
3. `sem_espinhos` → `presenca_espinhos === false`
4. `porte` → `porte_altura_classe === value`
5. `copa` → `copa_classe === value`
6. `folhagem` → `decidua_perenifolia === value`
7. `compat_fiacao` → `compat_fiacao === 'C'`
8. `calcada_segura` → `(potencial_dano_calcada_1a5 ?? 5) <= 2`
9. `showFavoritesOnly` (URL param `?favoritos=true`) → `favoriteIds.has(a.id)`

Then sorting: `nome_az` (default, `localeCompare(…, 'pt-BR')`), `nome_za`, `maior_porte` / `menor_porte` (rank maps Grande/Médio/Pequeno, unknown → 3, i.e. last), `mais_sombra` (`potencial_sombra_1a5` desc), `mais_co2e`, `maior_crescimento`. `activeAdvancedCount` counts non-empty/non-false values; `activeFilters` builds removable chips (`EmptyStateFilters`); infinite scroll via `IntersectionObserver`, `ITEMS_PER_PAGE = 6`, `rootMargin: '200px'`, reset on any filter/sort change.

Admin table `/Users/rigolao/Developer/PlanteiCerto/src/components/admin/TreeDataTable.tsx` has its own sortable columns (`sortField` default `'id'`, `'asc'`; nulls always sort last in asc; `ativa` normalized to `a.ativa !== false` before comparison) and pagination.

---

## 8. Map

`/Users/rigolao/Developer/PlanteiCerto/src/components/map/ProjectMap.tsx` (149 lines) — `MapContainer` centered on `project.centro_lat/lng`, zoom `project.centro_zoom`, `minHeight: 300px`.

**Tile provider: Esri ArcGIS Online, two stacked `TileLayer`s**, both `crossOrigin="anonymous"` (required so `html2canvas` can rasterize them for the PDF):
1. `https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}` — satellite base.
2. `https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}` at `opacity={0.7}` — street/place labels over the imagery.

Attribution: "© Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community".

**Clustering** — `MarkerClusterGroup` from `react-leaflet-cluster` with `chunkedLoading` and `maxClusterRadius={50}`; the whole marker tree is memoized on `[points, pendingPoints, trees, project.id, onSelectPoint, disableClustering]`; prop `disableClustering` bypasses the group (used when rendering for PDF capture). `MapBoundsFitter` auto-frames: 1 point → `setView(…, 16)`, N points → `fitBounds(L.latLngBounds(...), {padding:[50,50], maxZoom:16})`.

**Point lifecycle** — `MapClickHandler.tsx` wires `useMapEvents({click, moveend})`. A map click calls `onAddPendingPoint(lat,lng)` → `ProjectEditor` pushes a `PontoPendente` with a local random id (`Math.random().toString(36).substr(2,9)`), rendered as an amber "Pendente" pin. The user then links a species via `TreeSelectionDialog` → `addPoint(treeId, lat, lng, observacao)` inserts into `points` and the pending pin is dropped. Editing an existing point calls `updatePoint(id, treeId, observacao)`; deleting calls `removePoint(id)`. There is **no drag-to-move**: markers are not `draggable`; relocation means delete + re-add. `moveend` calls `onUpdateMapCenter(projectId, center.lat, center.lng, zoom)`, persisting the viewport to `projects.centro_*` on every pan/zoom. Leaving with unsaved pending points triggers a `window.confirm`.

**Icons/colors** — `/Users/rigolao/Developer/PlanteiCerto/src/components/map/TreeMarker.tsx`: `L.divIcon` (not image markers), `iconSize [120,50]`, `iconAnchor [60,50]`, HTML `<div class="marker-pin"><div class="marker-pin-head">{nome_popular}</div><div class="marker-pin-tail"></div></div>`, wrapper class `marker-arvore-wrapper marker-ponto-{pointId}`. So the **pin label is the species' popular name**, styled by CSS in `src/index.css`; there is no per-species color scheme. Pending points get inline amber (`#f59e0b` head, `#d97706` border, tail `border-top-color:#f59e0b`) and the tooltip "Ponto Pendente: Vincule uma árvore na lista". Selection highlight is injected as a `<style>` block in `ProjectMap` targeting `.marker-ponto-{selectedPointId}`: blue `#3b82f6`, `scale(1.15) translateY(-2px)`, `z-index: 1000`. Tooltip text = `nome_popular` or `nome_popular - observacao`.

Support components: `MapSearchBox.tsx` (address search), `MyLocationButton.tsx` (geolocation).

---

## 9. PDF export — `/Users/rigolao/Developer/PlanteiCerto/src/lib/pdf.ts` (348 lines)

One export: `generateProjectPDF(project, points, trees, mapElement)`. **It is the project report, not the recommendation result** — the only call site is `/Users/rigolao/Developer/PlanteiCerto/src/components/projects/ProjectEditor.tsx:40` (button "Relatório"; it waits `1600 ms` before capture so tiles finish loading, shows a spinner, `alert()`s on failure).

jsPDF A4 portrait, mm, margin 16 mm. Palette `COLORS` mirrors the app tokens (primary `#226437` = `[34,100,55]`).

Content, in order:
1. **Header**: "PlanteiCerto" 18 pt bold, subtitle "Relatório de Arborização Urbana", right-aligned `Doc: {dd/mm/aaaa}` (pt-BR), 0.2 mm rule at y=24.
2. **Project card** (rounded, secondary fill): `project.nome` in primary 14 pt, wrapped `descricao`, and the line `"{N} árvores mapeadas | Coordenadas: {centro_lat.toFixed(4)}, {centro_lng.toFixed(4)}"`.
3. **"Estatísticas e Impacto Ambiental"** — three stat boxes computed by iterating `points` and joining to `trees` by `tree_id`: **DIVERSIDADE** = `especiesUnicas.size`; **COBERTURA DE COPA** = `Math.round(Σ π·(diametro_copa_adulto_max_m/2)²)` m²; **ORIGEM (NATIVAS)** = `Math.round(nativasCount/points.length × 100)` %.
4. **Map image** — `html2canvas(mapElement, {useCORS:true, scale:2, backgroundColor:null})` with `ignoreElements` dropping `.leaflet-control-container`, `.leaflet-control`, `.absolute`; exported as JPEG q0.85, aspect preserved, height capped at 90 mm, X-centered, thin rounded border. On failure, a grey placeholder box reading "Visualização do mapa indisponível neste relatório."
5. **"Lista de Plantio e Coordenadas"** — table with columns ESPÉCIE (popular bold + scientific italic), ORIGEM ("Brasil" in primary bold if `origem === 'Nativa BR'`, else "Exótica"), LAT(Y) / LNG(X) (`toFixed(6)` on two lines), ALTURA MÁX, COPA MÁX (or "—"). Row height 15 mm, page break at `pageH − 25` with the header redrawn on each new page. Points whose `tree_id` doesn't resolve are skipped.
6. **Footer** on every page: "PlanteiCerto - Democratizando a arborização urbana" · "Página N" · "www.planteicerto.com.br".

Download name: `Relatorio_{nome com espaços → _}.pdf`.

The same copa math powers the on-screen dashboard `/Users/rigolao/Developer/PlanteiCerto/src/components/projects/ProjectStatsModal.tsx` (adds exotic count/%, and Pequeno/Médio/Grande tallies matched case-insensitively). Methodology is written up in `/Users/rigolao/Developer/PlanteiCerto/docs/estimativa-cobertura-copa.md` (Área = π·r², worked example: 5 m crown → ≈19.63 → displayed 20 m²).

There is also `src/components/ui/PdfViewer.tsx` (client-side `pdfjs-dist` rendering, replacing an `<iframe>`, commits `e66a6b7`/`d013775`) used for the guides on the About page.

---

## 10. Auth

**`/Users/rigolao/Developer/PlanteiCerto/src/contexts/AuthContext.tsx` (181 lines)** — `AuthProvider` holds `user: UserProfile | null`, `session`, `loading`. On mount (only if `isSupabaseConfigured()`): `supabase.auth.getSession()` + `onAuthStateChange` subscription, both mapping the session into `UserProfile` with `nome = user_metadata.full_name ?? user_metadata.nome ?? email.split('@')[0] ?? 'Usuário'`, `avatar_url = user_metadata.avatar_url ?? picture`, `providers = identities.map(i => i.provider)`. Unsubscribes on unmount.

| Method | Behaviour |
|---|---|
| `signIn(email, password)` | `auth.signInWithPassword` → `{error: message|null}` |
| `signUp(nome, email, password)` | First invokes the `check-email-exists` edge function; if `exists` → returns `'Este e-mail já está cadastrado. Tente fazer login.'` (a thrown check is swallowed and signup proceeds). Then `auth.signUp({options:{data:{nome}}})`. Secondary guard: empty `data.user.identities` array ⇒ same "already registered" message. Returns `needsConfirmation = !data.session` |
| `signInWithGoogle()` | `auth.signInWithOAuth({provider:'google', options:{redirectTo: window.location.origin}})` |
| `resetPassword(email)` | `auth.resetPasswordForEmail(email, {redirectTo: \`${window.location.origin}/reset-password\`})` |
| `updatePassword(password)` | `auth.updateUser({password})` |
| `updateProfile(nome, avatarFile?)` | Optional upload to `storage.from('avatars')` at path `{user.id}/{crypto.randomUUID()}.{ext}` with `upsert:true`, then `getPublicUrl`, then `auth.updateUser({data:{nome, avatar_url?}})`. try/catch returns `{error: message}` |
| `signOut()` | `auth.signOut()` then clears `user` and `session` locally |

`useAuth()` throws "useAuth must be used within an AuthProvider" outside the provider.

**Redirect URLs** — client-side: `window.location.origin` (Google) and `${origin}/reset-password` (recovery). Server side, `supabase/config.toml` sets `site_url = http://localhost:5173` with `additional_redirect_urls` for `localhost:5173`, `127.0.0.1:5173` and their `/reset-password` variants; production values live in the VPS `.env` (`SITE_URL=https://www.planteicerto.com.br`, additional URLs covering `www`, apex, both `/reset-password`, and localhost dev) — `INFRAESTRUTURA.md` records that a wrong `SITE_URL` broke Google OAuth right after cutover, and that the compose template ships a wrong `GOOGLE_REDIRECT_URI` (missing `/auth/v1`).

**`ProtectedRoute`** (`src/components/auth/ProtectedRoute.tsx`) — while `loading`, renders a "Carregando..." leaf spinner; if `!user`, `<Navigate to="/" state={{from: location}} replace />`; else `<Outlet/>`.

**`AdminRoute`** (`src/components/auth/AdminRoute.tsx`) — combines `useAuth` + `useProfile`; `loading = authLoading || (!!user && profileLoading)`; while loading shows "Verificando permissões..."; fires a one-shot `toast.error('Acesso restrito a administradores.')` (guarded by a `useRef`) when a logged-in non-admin hits it; `!user` → `/` with `state.from`; `!isAdmin` → `/` (replace); else `<Outlet/>`.

**Routes** (`src/App.tsx`, all pages lazy-loaded, wrapped in `ErrorBoundary` → `IPProtectionGate`): public `/` (TreesPage), `/quem-somos`, `/recomendacao`; under `ProtectedRoute`: `/projetos`, `/reset-password`, `/perfil`; under `AdminRoute` + `AdminLayout`: `/admin/arvores`, `/admin/equipe`. Also mounts `Toaster`, `InstallPWABanner`, Vercel `Analytics` and `SpeedInsights`.

**`IPProtectionGate`** (`src/components/auth/IPProtectionGate.tsx`) — a temporary intellectual-property gate in front of the whole app: hard-coded username `admin` plus `import.meta.env.VITE_GATE_PASSWORD`, unlock flag persisted in `localStorage['ip_unlocked']`. Client-side only; not a security control (commit `625a01e` "Tela de bloqueio intelectual - temporário", `e553112` moved it from sessionStorage to localStorage).

---

## 11. Deployment, Vercel config, self-hosting ops

**`/Users/rigolao/Developer/PlanteiCerto/vercel.json`** — SPA rewrite `/(.*)` → `/index.html`; security headers on all routes: `X-Frame-Options: DENY`, `X-Content-Type-Options: nosniff`, `Referrer-Policy: strict-origin-when-cross-origin`, `Permissions-Policy: camera=(), microphone=(), geolocation=()`, `Strict-Transport-Security: max-age=63072000; includeSubDomains`, and a CSP: `default-src 'self'`; `script-src 'self' 'unsafe-inline'`; `style-src 'self' 'unsafe-inline'`; `img-src 'self' data: blob: https:`; `connect-src 'self' https://*.supabase.co wss://*.supabase.co https://api.planteicerto.com.br wss://api.planteicerto.com.br https://va.vercel-scripts.com https://vitals.vercel-insights.com`; `font-src 'self'`; `frame-src https://*.supabase.co https://api.planteicerto.com.br blob:`; `frame-ancestors 'none'`; `worker-src 'self' blob:`; `manifest-src 'self'`. (Commits `ae4206f` opened CSP to the VPS API; `c5b753e` added `blob:` to `frame-src` for client-rendered PDFs.)

**CI** — `/Users/rigolao/Developer/PlanteiCerto/.github/workflows/ci.yml`, on push/PR to `master`, Node 20: `npm ci` → `npm audit --audit-level=high` → `npm run lint` → `npx tsc --noEmit` → `npm run test:ci` (vitest) → `npm run build`. Plus a Husky `pre-commit` hook (commit `14a1d74`).

**PWA** — `vite.config.ts` uses `vite-plugin-pwa` (`registerType: 'autoUpdate'`, manifest name PlanteiCerto, `theme_color #226437`, `background_color #f7f9f7`, standalone/portrait, `lang pt-BR`, 192/512/maskable icons) and manual chunks `vendor-map` (leaflet), `vendor-pdf` (jspdf + html2canvas), `vendor-react`.

**There is no `ops/` directory.** The VPS/self-hosting material lives in three docs (no secrets reproduced below; all real credentials live only in the VPS `.env`, explicitly never versioned):

- **`/Users/rigolao/Developer/PlanteiCerto/INFRAESTRUTURA.md`** — the migration from Supabase Cloud to a self-hosted Supabase on a Hostinger KVM 2 VPS (São Paulo, Ubuntu 24.04), frontend staying on Vercel. Stack = the official `supabase/supabase` `docker/` tree plus two overlays: `docker-compose.s3.yml` (MinIO as Storage backend) and `docker-compose.caddy.yml` (reverse proxy + automatic Let's Encrypt TLS). API domain `api.planteicerto.com.br` (A record at registro.br). Contains a runbook (apply migration via `docker cp` + `psql`; deploy an edge function via `scp` into `volumes/functions/` then `docker compose … up -d --force-recreate --no-deps functions`; note that `restart` alone does not re-read `.env`), Storage notes (4 public buckets; the native S3-protocol endpoint returns `SignatureDoesNotMatch` — upstream `supabase/storage` issues #572/#495/#569/#646 — workaround is the plain Storage REST API with `x-upsert`), Auth notes (SMTP via Brevo with SPF/DKIM/DMARC; email templates must be public URLs in self-hosted Docker, unlike the CLI's `content_path`), the two **post-cutover bugs** that `supabase db dump` silently omits (missing `on_auth_user_created` trigger → every `profiles` query 406/PGRST116; `storage.objects` with RLS on and zero policies → all UI uploads blocked while service_role kept working) with a post-restore checklist expecting **1 trigger and 10 policies**, MCP access only through an SSH tunnel with an IP-restricted `/mcp` Kong route, backup design (`pg_dump -Fc` + tar of the MinIO volume, pulled nightly at 03:00 by a Mac `launchd` agent over a command-restricted SSH key, 14-day retention, restore tested against `supabase/postgres:17.6.1.136`), hardening (`ufw` 22/80/443 only, key-only SSH, fail2ban, 2 GB swap, unattended-upgrades), an explicit note that several secrets passed through chat sessions during setup and **still need rotation**, and the cutover log (done 2026-07-21; Cloud kept alive as rollback = revert the Vercel env vars).
- **`/Users/rigolao/Developer/PlanteiCerto/docs/runbook-storage-minio.md`** (commit `0b7b650`) — incident runbook for Storage HTTP 500: on 2026-09-09 `supabase-minio-1` was `Exited (255)` while `supabase-storage` stayed healthy and timed out on `http://minio:9000`; diagnosis commands, recovery (`docker compose … up -d minio` reusing volume `supabase_minio-data`), and a strong warning not to restore buckets or `db.dump` before comparing counts and SHA-256 (153 payloads / 233 metadata objects, none empty, hashes matched the backup).
- **`/Users/rigolao/Developer/PlanteiCerto/DESENVOLVIMENTO.md`** — fully local dev with `npx supabase start` (~10 containers): API 54321, Studio 54323, Mailpit 54324, Postgres 54322; env must go in `.env.development.local` (Vite prioritizes `.env.development` over `.env.local`); `npx supabase functions serve` for hot-reloaded edge functions.
- `/Users/rigolao/Developer/PlanteiCerto/MIGRATION_INSTRUCTIONS.md` is historical (2026-03-17 flattening of the nested tree schema, destructive, dev-only) and superseded by the baseline migration.

---

## Discrepancies worth stating explicitly in the report

1. **`docs/recomendacao-classificacao.md` (2026-03-22) uses the old question numbering** — its groups G1…G6 map to today's `q2_*` (space), `q3_*` (ecology), `q4_*` (preferences), `q1_*` (context), `q5_*` (botanical), and `q3_5`/`q3_6` (wind, heat island). The weights and formulas still match the code exactly; only the ids and the "6 groups" count differ from `questionnaire.ts`, which declares 5 groups.
2. The same doc still says "com apenas 4 espécies no banco" — the catalog now holds 167 rows (146 active).
3. `useTreeFilters.ts` and `layout/Drawer.tsx` are unreferenced; the shipped filtering is `TreesToolbar.AdvancedFilters` + `TreesPage`.
4. The `Temp Public Insert Guias` storage policy allows unauthenticated INSERT into the `guias` bucket — flagged in the migration's own comment as pending restriction.
5. `MAX_SCORE` is a constant 190 regardless of how many questions were answered, so a partially answered questionnaire mathematically cannot reach 100 %.
