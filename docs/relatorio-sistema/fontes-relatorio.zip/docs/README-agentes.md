# Guia para os agentes de captura e redação — Relatório do Sistema PlanteiCerto

Objetivo do produto: um PDF (pt-BR) que documenta TODAS as telas, estados e fluxos do sistema PlanteiCerto,
para ser anexado a um projeto do ChatGPT e servir de base para uma dissertação. O ChatGPT extrai TEXTO do PDF;
imagens sozinhas não servem. Cada captura precisa de descrição textual rica escrita **para quem não vê a imagem**.

## Ambiente (já está tudo no ar — não subir nada, não rodar `supabase`, não editar o repositório)

| Item | Valor |
|---|---|
| App (Vite dev) | `http://localhost:5173` — usar SEMPRE esta origem (não 127.0.0.1) |
| Supabase local | API `http://127.0.0.1:54321`, Studio `:54323`, Mailpit `:54324` (todos os e-mails de auth caem lá) |
| Repositório (somente leitura) | `/Users/rigolao/Developer/PlanteiCerto` |
| Diretório de trabalho | `$SCRATCH = /private/tmp/claude-501/-Users-rigolao-Developer-PlanteiCerto/0c58d9cc-1a17-4e7b-aa5c-9d14ecb887e1/scratchpad` |
| Dados | 167 espécies (146 ativas), fotos apontando para o storage de produção (funcionam); 12 PDFs de guias/critérios no storage local |
| Tela de gate | `IPProtectionGate` envolve tudo; o harness pula via `localStorage.ip_unlocked`. Credenciais reais só no flow do gate: usuário `admin`, senha em `GATE.password` (config.mjs). **Nunca escrever a senha no capítulo.** |

### Contas demo (senha de todas: `Demo!2026`) — storageState pronto em `$SCRATCH/state/<chave>.json`

| chave | e-mail | nome | papel | uso |
|---|---|---|---|---|
| `user` | usuario.demo@planteicerto.local | Usuária Demonstração | user | catálogo, favoritos (ids 1, 99, 145), recomendação |
| `projetista` | projetista.demo@planteicerto.local | Projetista Demonstração | user | dona dos 2 projetos demo |
| `admin` | admin.demo@planteicerto.local | Administrador Demo | **admin** | painel admin |
| `colega` | colega.demo@planteicerto.local | Colega da Equipe | user | zero projetos; alvo de promover/rebaixar; fluxo de reset de senha |

Projetos da `projetista`: **"Arborização Rua Prudente de Moraes"** (6 pontos: Oiti id 1, Ipê-amarelo 145, Dedaleira 131, Resedá 2, Jerivá 41, Ipê-roxo-de-bola 99; centro -21.17668/-47.82145 zoom 18) e **"Praça Sete de Setembro (em planejamento)"** (0 pontos). **Não apagar nem alterar esses dois**; criar os seus próprios para testes e removê-los no `finally`.

Espécies úteis: 41 Jerivá (palmeira, **sem** projeção 10 anos), 1 Oiti (foto Wikimedia), 99 Ipê-roxo-de-bola, 145 Ipê-amarelo, 131 Dedaleira, 2 Resedá. Ids 32 e outras 20 estão `ativa=false` (invisíveis para não-admin).

## Harness (`$SCRATCH/harness/`) — usar SEMPRE; não criar outro browser na mão

```js
import { newContext, goto, shot, shotToast, waitForTiles, waitForImages, ensureAuth, captureDownload, finish } from '../harness/shot.mjs';
import { ACCOUNTS, GATE, BASE, API } from '../harness/config.mjs';
import { rest, restAnon, sql, count } from '../harness/supa.mjs';         // dados (service_role) e SQL via docker
import { waitForMessageTo, verifyLink } from '../harness/mailpit.mjs';    // e-mails
import { STEPS, runWizard, ANSWERS_PADRAO, ANSWERS_FIACAO, ANSWERS_ZERO } from '../harness/wizard.mjs'; // agente B

const ctx = await newContext({ agent: 'A', theme: 'light', viewport: 'desktop', auth: 'user', gate: true });
// theme 'light'|'dark' · viewport 'desktop' (1440×900) | 'mobile' (390×844, touch) · auth 'none'|'user'|'projetista'|'admin'|'colega'
// gate:false só para fotografar a própria tela de bloqueio
const page = await ctx.newPage();
await goto(page, '/', { waitFor: 'text=Mostrando' });          // espera rota lazy + imagens
await shot(page, '11-catalogo-grid', { title: 'Catálogo — grade padrão', flow: 'catalogo', fullPage: true });
await shotToast(page, () => page.click('button:has-text("Comparar")'), '12-comparar-toast', { title: '...' });
await ctx.close(); await finish();
```

Regras do `shot()`:
- Nome do id: `NN-<area>-<slug>[-dark][-mobile]` (NN sequencial dentro da sua área; areas por agente abaixo). Sem acentos/espaços.
- **Nunca lança.** Falha → entrada `status:"failed"` no manifesto `$SCRATCH/manifests/<agente>.json` e log `✘ NÃO CAPTURADO`. No capítulo, escrever `**NÃO CAPTURADO:** <motivo>` no lugar da imagem e seguir.
- Modais/diálogos/toasts/menus: **viewport** (`fullPage:false`, padrão). Páginas longas: `fullPage:true` (acima de 3200 px o helper fatia em `-p1`, `-p2`… — referencie todas as partes).
- Elemento isolado: `{ element: '[role="dialog"]' }` etc.
- Mapa: sempre `await waitForTiles(page)` antes do shot.
- Toast do sonner dura ~4 s: use `shotToast(page, acao, id)` (o waiter é criado antes da ação).
- `<select>` nativo aberto NÃO aparece em screenshot headless: liste as opções em texto e capture o efeito da escolha (`page.selectOption`).
- Hover: `await page.hover(sel); await page.waitForTimeout(300)`.
- Mobile: `newContext({ viewport: 'mobile' })` — só para telas cujo layout muda de verdade.
- Dark: `newContext({ theme: 'dark' })` — 1 captura representativa por página (id com sufixo `-dark`).
- Sessão expirando (JWT 1 h): `await ensureAuth(page, 'user')` no início de cada flow autenticado.
- Seletores: o app NÃO tem `data-testid`. Use texto pt-BR (`page.getByRole('button', { name: 'Entrar' })`, `page.locator('button', { hasText: '...' })`), placeholders (`page.getByPlaceholder('seu@email.com')`, `'******'`, `'Ex: João Silva'`) e CSS. Leia o componente no repo quando o seletor não for óbvio.
- Um arquivo `.mjs` por fluxo em `$SCRATCH/flows/<letra><nn>-<nome>.mjs`, rodado com `cd $SCRATCH && node flows/x.mjs`. Idempotente (sobrescreve os mesmos ids). Toda mutação de dados que você criar deve ser desfeita no `finally`.
- Não rode `npx playwright install`. Não instale pacotes. Não altere arquivos do repositório nem do harness (se precisar de algo no harness, replique localmente no seu flow).
- Confira cada PNG gerado abrindo-o (ferramenta Read) antes de descrevê-lo — descreva o que está na imagem de fato.

## Entregáveis de cada agente

1. `$SCRATCH/capitulos/NN-<nome>.md` — capítulo(s) em pt-BR (Markdown GFM; tabelas OK; sem HTML bruto).
2. `$SCRATCH/manifests/<agente>.json` — gerado automaticamente pelo `shot()`.
3. Ao final, uma resposta curta: nº de capturas ok/failed, lista dos `NÃO CAPTURADO` com motivo, e observações relevantes sobre o sistema descobertas na prática.

### Template obrigatório por tela/estado

```markdown
### <Nome da tela / estado>

![<alt curto>](../shots/<id>.png)

**Rota:** `/caminho` — <como se chega até aqui> · **Quem acessa:** visitante | usuário autenticado | administrador · **Viewport/tema:** desktop claro

**Elementos visíveis:**
- <componente/texto literal entre aspas, posição, estado (habilitado/desabilitado), contadores>

**Ações possíveis / o que acontece:**
- <ação> → <resultado observado, toast literal, navegação>

**Estados relacionados:** <ids de outras capturas>
```

Por fluxo: `## Fluxo passo a passo — <nome>` com passos numerados citando ids `(ver 11-catalogo-grid)`.
Comece cada capítulo com `# <Título>` (vira capítulo do PDF) e um parágrafo de contexto (o que a página faz, para quem, arquivo-fonte principal em `src/...`).
Cite textos literais da UI entre aspas. Nunca invente comportamento: se não observou, diga que não foi capturado/observado.
Não inclua nada de arquivos `.env*` (chaves, tokens, senha do gate), nem IP/host/SSH da VPS.

## Áreas (prefixo dos ids) por agente
A: `gate, header, auth, catalogo, especie, comparar, sobre` · B: `rec` · C: `projetos, editor, relatorio, perfil, reset` · D: `admin, equipe` · orquestrador: `pdfgen, smoke`.
Numeração NN sugerida: A 10–19, B 20–29, C 30–39, D 40–49 (ex.: `13-sobre-guias`).

## Referências prontas (ler antes de começar)
- `$SCRATCH/docs/inventario-telas.md` — inventário de todas as telas/estados por página (checklist de cobertura).
- `$SCRATCH/docs/pesquisa-backend.md` — banco, RLS, edge function, questionário, hooks, mapa, PDF, auth, infra.
- `$SCRATCH/artefatos/questionario.md`, `especies.csv`, `colunas-trees.md`, `esquema-banco.md` — dumps do banco local.
