// Sonda: chama a edge function recommend-trees direto para os 3 cenários e imprime contagens/top-5.
import { API, ANON } from '../harness/config.mjs';
import { ANSWERS_PADRAO, ANSWERS_FIACAO, ANSWERS_ZERO, STEPS } from '../harness/wizard.mjs';

console.log('STEPS:', STEPS.length, STEPS.map(s => s.id).join(','));

async function call(name, answersObj) {
  // O app serializa multi-select como string separada por vírgula.
  const answers = Object.fromEntries(Object.entries(answersObj).map(([k, v]) => [k, [].concat(v).join(',')]));
  const t0 = Date.now();
  const res = await fetch(`${API}/functions/v1/recommend-trees`, {
    method: 'POST',
    headers: { apikey: ANON, Authorization: `Bearer ${ANON}`, 'Content-Type': 'application/json', Origin: 'http://localhost:5173' },
    body: JSON.stringify({ answers }),
  });
  const text = await res.text();
  let d; try { d = JSON.parse(text); } catch { d = text; }
  console.log(`\n### ${name} (${res.status}, ${Date.now() - t0}ms)`);
  if (!d || !d.trees) { console.log(text.slice(0, 500)); return; }
  console.log('compatíveis:', d.trees.length, '| eliminadas:', d.eliminated_count, '| total analisado:', d.trees.length + d.eliminated_count);
  console.log('criteriaSummary.eliminatory:', JSON.stringify(d.criteriaSummary.eliminatory));
  console.log('criteriaSummary.classificatory:', JSON.stringify(d.criteriaSummary.classificatory));
  for (const t of d.trees.slice(0, 8)) {
    const top = (t.scoreBreakdown || []).filter(c => c.points > 0).sort((a, b) => b.points - a.points || b.maxPoints - a.maxPoints);
    console.log(`  ${t.score} pts · ${t.nome_popular} (${t.nome_cientifico}) id=${t.id} porte=${t.porte_altura_classe} origem=${t.origem} | top3: ${top.slice(0, 3).map(c => `${c.label} ${c.points}/${c.maxPoints}`).join(' | ')} | +${Math.max(0, top.length - 3)} outros`);
  }
  if (d.trees[0]) console.log('  breakdown completo do 1º:', JSON.stringify(d.trees[0].scoreBreakdown));
}

await call('ANSWERS_PADRAO', ANSWERS_PADRAO);
await call('ANSWERS_FIACAO', ANSWERS_FIACAO);
await call('ANSWERS_ZERO', ANSWERS_ZERO);
