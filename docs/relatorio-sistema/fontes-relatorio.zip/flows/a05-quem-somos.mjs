// Agente A — Flow 05: página "Quem Somos" (/quem-somos) e o visualizador de PDF
// (metodologia, documentos de parametrização, 10 guias, PdfViewer: carregando, renderizado,
// paginação e erro) + versão mobile.
import { newContext, goto, shot, waitForImages, finish, setAgent } from '../harness/shot.mjs';

setAgent('A');

async function hideDevtools(ctx) {
  await ctx.addInitScript(() => {
    const css = 'button[aria-label="Open Tanstack query devtools"],.tsqd-open-btn-container,.tsqd-parent-container{display:none !important}';
    const add = () => { const s = document.createElement('style'); s.textContent = css; document.head.appendChild(s); };
    if (document.head) add(); else document.addEventListener('DOMContentLoaded', add);
  });
}

async function step(nome, fn) {
  try { await fn(); } catch (e) { console.warn(`⚠ passo "${nome}" falhou: ${String(e.message).split('\n')[0]}`); }
}

/** Rola até o texto informado ficar no topo da tela e captura o viewport. */
async function secao(page, texto, id, titulo) {
  await page.evaluate((t) => {
    const el = [...document.querySelectorAll('h2,h3')].find(e => e.textContent.trim().startsWith(t));
    if (el) window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - 90, behavior: 'instant' });
  }, texto);
  await page.waitForTimeout(600);
  await shot(page, id, { title: titulo, flow: 'sobre' });
}

async function main() {
  const ctx = await newContext({ agent: 'A', auth: 'none' });
  await hideDevtools(ctx);
  const page = await ctx.newPage();
  await goto(page, '/quem-somos', { waitFor: 'text=Guias de Arborização' });
  await waitForImages(page);

  const alturaPagina = await page.evaluate(() => document.documentElement.scrollHeight);
  console.log('altura total de /quem-somos:', alturaPagina, 'px');

  await shot(page, '16-sobre-topo', {
    title: 'Página "Quem Somos" completa', flow: 'sobre', fullPage: true,
  });
  await secao(page, 'Metodologia e Critérios', '16-sobre-metodologia',
    'Seção "Metodologia e Critérios de Avaliação" — 3 cartões de escalas');
  await secao(page, 'Documentos de Parametrização', '16-sobre-parametrizacao',
    'Bloco "Documentos de Parametrização" — 2 botões de PDF');
  await secao(page, 'Guias de Arborização', '16-sobre-guias',
    'Seção "Guias de Arborização" — grade com os 10 guias');

  // --- PdfViewer: estado "Carregando..." (resposta do PDF atrasada em 6 s) ---
  await step('PdfViewer carregando', async () => {
    await page.route('**/storage/v1/object/public/guias/guia3.pdf', r => setTimeout(() => r.continue(), 6000));
    await page.click('button:has-text("3 - Planejando o plantio")');
    await page.waitForTimeout(1200);
    await shot(page, '16-sobre-pdf-carregando', {
      title: 'PdfViewer — estado "Carregando..." (requisição do PDF retardada)', flow: 'sobre',
    });
  });

  // --- PdfViewer: página renderizada + barra de paginação ---
  await step('PdfViewer renderizado', async () => {
    await page.waitForSelector('canvas', { timeout: 30000 });
    await page.waitForTimeout(2500);
    await shot(page, '16-sobre-pdf-pagina', {
      title: 'PdfViewer — guia 3 renderizado no canvas, com barra de paginação "1 / 7"', flow: 'sobre',
    });
    await page.click('button:has-text("→")');
    await page.waitForTimeout(2500);
    await shot(page, '16-sobre-pdf-paginacao', {
      title: 'PdfViewer — após avançar para a página 2 de 7', flow: 'sobre',
    });
    const paginador = await page.locator('canvas').locator('xpath=../..').locator('div:has(button)').last().innerText().catch(() => '');
    console.log('barra de paginação:', JSON.stringify(paginador.replace(/\s+/g, ' ').trim()));
    await page.click('button:has(svg.lucide-x), button:right-of(:text("Abrir em nova aba"))').catch(() => {});
    await page.waitForTimeout(800);
  });

  // --- PdfViewer: erro (guia 9 respondendo 404) ---
  await step('PdfViewer erro', async () => {
    if (await page.locator('text=Abrir em nova aba').count()) {
      await page.keyboard.press('Escape').catch(() => {});
      await page.mouse.click(40, 500); // clica no overlay para fechar
      await page.waitForTimeout(700);
    }
    await page.route('**/storage/v1/object/public/guias/guia9.pdf', r => r.fulfill({ status: 404, body: 'not found' }));
    await page.click('button:has-text("9 - Extração de árvores urbanas")');
    await page.waitForSelector('text=Não foi possível carregar o PDF.', { timeout: 20000 });
    await page.waitForTimeout(600);
    await shot(page, '16-sobre-pdf-erro', {
      title: 'PdfViewer — erro "Não foi possível carregar o PDF." (arquivo indisponível)', flow: 'sobre',
    });
  });
  await ctx.close();

  // --- mobile ---
  const ctxM = await newContext({ agent: 'A', auth: 'none', viewport: 'mobile' });
  await hideDevtools(ctxM);
  const pm = await ctxM.newPage();
  await goto(pm, '/quem-somos', { waitFor: 'text=Guias de Arborização' });
  await waitForImages(pm);
  await shot(pm, '16-sobre-mobile', {
    title: '"Quem Somos" no mobile (coluna única)', flow: 'sobre', fullPage: true,
  });
  await ctxM.close();
}

try { await main(); } finally { await finish(); }
