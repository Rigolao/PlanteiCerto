// Agente C — flow 03: geração do relatório PDF do projeto (6 pontos).
import fs from 'node:fs';
import path from 'node:path';
import { newContext, goto, shot, waitForTiles, ensureAuth, captureDownload, finish } from '../harness/shot.mjs';
import { DIRS } from '../harness/config.mjs';
import { rest } from '../harness/supa.mjs';

const CHEIO = 'Arborização Rua Prudente de Moraes';
const ALVO = path.join(DIRS.artefatos, 'Relatorio_projeto_demo.pdf');
const log = [];
let ctx, centros = [];
const note = s => { log.push(s); console.log('· ' + s); };

try {
  ({ data: centros } = await rest('/projects?select=id,nome,centro_lat,centro_lng,centro_zoom'));

  ctx = await newContext({ agent: 'C', theme: 'light', viewport: 'desktop', auth: 'projetista' });
  const page = await ctx.newPage();
  page.on('dialog', async d => { note(`window.${d.type()}: "${d.message()}"`); await d.accept(); });
  page.on('download', d => note(`nome sugerido pelo app: ${d.suggestedFilename()}`));

  await goto(page, '/projetos', { waitFor: 'h1:has-text("Meus Projetos")' });
  await ensureAuth(page, 'projetista');
  await page.locator('div[role="button"]', { hasText: CHEIO }).first().click();
  await page.locator('span:has-text("Pontos do Projeto"):visible').first().waitFor({ timeout: 25000 });
  await waitForTiles(page);

  const dest = await captureDownload(page, async () => {
    const gerando = page.locator('button:has-text("Gerando..."):visible').first().waitFor({ timeout: 10000 }).catch(() => null);
    await page.locator('button:has-text("Relatório"):visible').first().click();
    await gerando;
    await shot(page, '35-relatorio-gerando', {
      title: 'Botão "Gerando..." e mapa com os marcadores desagrupados durante a captura', flow: 'relatorio', settle: 150,
    });
  }, 'Relatorio_projeto_demo.pdf', { timeout: 90000 });

  const bytes = fs.statSync(dest).size;
  note(`PDF salvo em ${dest} (${(bytes / 1024).toFixed(1)} KB)`);
  if (bytes < 20 * 1024) note('ATENÇÃO: PDF menor que 20 KB');

  await page.waitForTimeout(1500);
  await waitForTiles(page);
  await shot(page, '35-relatorio-pos-download', {
    title: 'Editor logo após a geração — botão volta a "Relatório"', flow: 'relatorio',
  });
  await ctx.close();

  // ─── extração do texto do PDF ───
  const pdfjs = await import('/Users/rigolao/Developer/PlanteiCerto/node_modules/pdfjs-dist/legacy/build/pdf.mjs');
  const doc = await pdfjs.getDocument({ data: new Uint8Array(fs.readFileSync(ALVO)), useSystemFonts: true }).promise;
  note(`páginas no PDF: ${doc.numPages}`);
  let txt = '';
  for (let i = 1; i <= doc.numPages; i++) {
    const pg = await doc.getPage(i);
    const vp = pg.getViewport({ scale: 1 });
    const tc = await pg.getTextContent();
    // agrupa por linha (mesma coordenada Y, tolerância 2)
    const linhas = new Map();
    for (const it of tc.items) {
      if (!it.str.trim()) continue;
      const y = Math.round(it.transform[5] / 2) * 2;
      if (!linhas.has(y)) linhas.set(y, []);
      linhas.get(y).push({ x: it.transform[4], s: it.str });
    }
    const ordenadas = [...linhas.entries()].sort((a, b) => b[0] - a[0])
      .map(([, itens]) => itens.sort((a, b) => a.x - b.x).map(i => i.s).join(' ').replace(/\s+/g, ' ').trim());
    txt += `\n===== PÁGINA ${i} (${Math.round(vp.width)}×${Math.round(vp.height)} pt) =====\n` + ordenadas.join('\n') + '\n';
  }
  const saida = path.join(DIRS.artefatos, 'Relatorio_projeto_demo.txt');
  fs.writeFileSync(saida, txt.trim() + '\n');
  note(`texto extraído em ${saida} (${txt.length} caracteres)`);
  console.log(txt);
} catch (e) {
  console.error('[c03] ERRO:', e.message);
} finally {
  try { if (ctx) await ctx.close(); } catch {}
  try {
    for (const c of centros) {
      await rest(`/projects?id=eq.${c.id}`, {
        method: 'PATCH', body: { centro_lat: c.centro_lat, centro_lng: c.centro_lng, centro_zoom: c.centro_zoom },
      });
    }
    const { data: pts } = await rest('/points?select=id');
    console.log('pontos no banco:', pts.length);
  } catch (e) { console.error('falha na limpeza:', e.message); }
  console.log('\n--- notas ---\n' + log.join('\n'));
  await finish();
}
