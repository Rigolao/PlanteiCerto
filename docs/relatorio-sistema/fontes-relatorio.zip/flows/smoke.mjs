// Smoke do harness: abre o catálogo com gate destravado e captura.
import { newContext, goto, shot, finish } from '../harness/shot.mjs';
const ctx = await newContext({ agent: 'orq', auth: 'none' });
const page = await ctx.newPage();
await goto(page, '/', { waitFor: 'text=Mostrando' });
const counter = await page.locator('text=/Mostrando \\d+ de \\d+/').first().innerText().catch(() => '(sem contador)');
console.log('contador:', counter);
await shot(page, '00-smoke-catalogo', { title: 'Smoke: catálogo', fullPage: false });
await ctx.close();
await finish();
