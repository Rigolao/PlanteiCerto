// Agente A — Flow 02: Header/navegação, alternância de tema, MobileDrawer, dropdown do usuário,
// modal de logout e todos os modos do AuthModal (login, erro, cadastro real com confirmação
// por e-mail via Mailpit, recuperação de senha).
import { newContext, goto, shot, shotToast, finish, setAgent, ensureAuth } from '../harness/shot.mjs';
import { ACCOUNTS, MAILPIT, API, SERVICE_ROLE } from '../harness/config.mjs';
import { waitForMessageTo, verifyLink } from '../harness/mailpit.mjs';
import { adminFindUser } from '../harness/supa.mjs';

setAgent('A');

const NOVO = { email: 'novo.cadastro@planteicerto.local', nome: 'Novo Cadastro Demo', senha: 'Demo!2026' };

async function hideDevtools(ctx) {
  await ctx.addInitScript(() => {
    const css = 'button[aria-label="Open Tanstack query devtools"],.tsqd-open-btn-container,.tsqd-parent-container{display:none !important}';
    const add = () => { const s = document.createElement('style'); s.textContent = css; document.head.appendChild(s); };
    if (document.head) add(); else document.addEventListener('DOMContentLoaded', add);
  });
}

const HEADER_CLIP = { x: 0, y: 0, width: 1440, height: 120 };

async function step(nome, fn) {
  try { await fn(); } catch (e) { console.warn(`⚠ passo "${nome}" falhou: ${String(e.message).split('\n')[0]}`); }
}

/** Apaga o usuário criado no cadastro de demonstração. */
async function apagarNovoUsuario() {
  const u = await adminFindUser(NOVO.email).catch(() => null);
  if (!u) { console.log('limpeza: usuário', NOVO.email, 'não existe (nada a apagar)'); return; }
  const res = await fetch(`${API}/auth/v1/admin/users/${u.id}`, {
    method: 'DELETE',
    headers: { apikey: SERVICE_ROLE, Authorization: `Bearer ${SERVICE_ROLE}` },
  });
  console.log('limpeza: DELETE user', u.id, '->', res.status);
}

async function main() {
  // Garante que o e-mail de cadastro não existe antes do teste (idempotência).
  await apagarNovoUsuario();

  // ============ 1. Header deslogado + alternância de tema (desktop) ============
  const ctx = await newContext({ agent: 'A', auth: 'none' });
  await hideDevtools(ctx);
  const page = await ctx.newPage();
  await goto(page, '/', { waitFor: 'text=Mostrando' });
  await page.mouse.move(720, 880); // tira o mouse de cima dos cards

  await shot(page, '11-header-deslogado', {
    title: 'Header — visitante não autenticado (faixa superior)',
    flow: 'header', clip: HEADER_CLIP,
  });
  await shot(page, '11-header-tema-claro', {
    title: 'Catálogo no tema claro (antes de alternar o tema)',
    flow: 'header',
  });

  await step('alternar tema', async () => {
    await page.click('button[title="Alternar tema"]');
    await page.waitForTimeout(700);
    await shot(page, '11-header-tema-escuro', {
      title: 'Mesma tela após clicar no botão "Alternar tema" (tema escuro)',
      flow: 'header',
    });
    await page.click('button[title="Alternar tema"]'); // volta ao claro
    await page.waitForTimeout(500);
  });

  // ============ 2. AuthModal: login, erro, cadastro, recuperação ============
  await step('AuthModal login', async () => {
    await page.locator('header button', { hasText: 'Entrar' }).first().click();
    await page.waitForSelector('form button[type="submit"]');
    await page.waitForTimeout(500);
    await shot(page, '12-auth-login', { title: 'AuthModal — modo "Entrar"', flow: 'auth' });
  });

  await step('AuthModal erro de login', async () => {
    await page.getByPlaceholder('seu@email.com').fill(ACCOUNTS.user.email);
    await page.getByPlaceholder('******').fill('senha-errada-123');
    await shotToast(page, () => page.locator('form button[type="submit"]').click(),
      '12-auth-login-erro', { title: 'AuthModal — toast "E-mail ou senha incorretos."', flow: 'auth' });
    await page.keyboard.press('Escape');
    // espera o toast do sonner sumir para não contaminar as próximas capturas
    await page.waitForSelector('[data-sonner-toast]', { state: 'detached', timeout: 10000 }).catch(() => {});
    await page.waitForTimeout(600);
  });

  await step('AuthModal criar conta', async () => {
    await page.locator('header button', { hasText: 'Entrar' }).first().click();
    await page.waitForSelector('form button[type="submit"]');
    await page.locator('p:has-text("Não tem conta?")').click();
    await page.waitForSelector('text=Criar Conta');
    await page.waitForTimeout(500);
    await shot(page, '12-auth-criar-conta', { title: 'AuthModal — modo "Criar Conta"', flow: 'auth' });
  });

  await step('AuthModal recuperar senha', async () => {
    await page.locator('p:has-text("Já tem conta?")').click();
    await page.waitForSelector('button:has-text("Esqueceu a senha?")');
    await page.click('button:has-text("Esqueceu a senha?")');
    await page.waitForSelector('text=Recuperar Senha');
    await page.waitForTimeout(500);
    await shot(page, '12-auth-recuperar-senha', { title: 'AuthModal — modo "Recuperar Senha"', flow: 'auth' });
  });

  await step('AuthModal e-mail enviado', async () => {
    await page.getByPlaceholder('seu@email.com').fill(ACCOUNTS.user.email);
    await page.locator('form button[type="submit"]').click();
    await page.waitForSelector('text=E-mail enviado', { timeout: 15000 });
    await page.waitForTimeout(500);
    await shot(page, '12-auth-recuperar-enviado', {
      title: 'AuthModal — confirmação "E-mail enviado" após pedir recuperação de senha', flow: 'auth',
    });
    await page.click('button:has-text("Entendido")');
  });
  await ctx.close();

  // ============ 3. Header deslogado no tema escuro ============
  const ctxD = await newContext({ agent: 'A', auth: 'none', theme: 'dark' });
  await hideDevtools(ctxD);
  const pageD = await ctxD.newPage();
  await goto(pageD, '/', { waitFor: 'text=Mostrando' });
  await shot(pageD, '11-header-deslogado-dark', {
    title: 'Header — visitante não autenticado, tema escuro', flow: 'header', clip: HEADER_CLIP,
  });
  await ctxD.close();

  // ============ 4. MobileDrawer: deslogado, usuário, admin ============
  for (const [auth, slug, titulo] of [
    ['none', 'deslogado', 'visitante'],
    ['user', 'usuario', 'usuária autenticada'],
    ['admin', 'admin', 'administrador'],
  ]) {
    const c = await newContext({ agent: 'A', auth, viewport: 'mobile' });
    await hideDevtools(c);
    const p = await c.newPage();
    await step(`drawer ${slug}`, async () => {
      await goto(p, '/', { waitFor: 'text=Mostrando' });
      if (auth !== 'none') await ensureAuth(p, auth);
      await p.locator('header button.md\\:hidden, header button:below(:text("PlanteiCerto"))').first().click({ timeout: 5000 })
        .catch(async () => { await p.locator('header > div > button').last().click(); });
      await p.waitForSelector('text=Inicio (Arvores)', { timeout: 8000 });
      await p.waitForTimeout(700);
      await shot(p, `11-header-drawer-${slug}-mobile`, {
        title: `MobileDrawer aberto — ${titulo}`, flow: 'header',
      });
    });
    await c.close();
  }

  // ============ 5. Dropdown do usuário + modal de logout ============
  const ctxU = await newContext({ agent: 'A', auth: 'user' });
  await hideDevtools(ctxU);
  const pageU = await ctxU.newPage();
  await goto(pageU, '/', { waitFor: 'text=Mostrando' });
  await ensureAuth(pageU, 'user');
  await step('dropdown usuário', async () => {
    await pageU.locator('nav button', { hasText: ACCOUNTS.user.nome }).first().click();
    await pageU.waitForSelector('text=Meu Perfil');
    await pageU.waitForTimeout(400);
    await shot(pageU, '11-header-dropdown-usuario', {
      title: 'Dropdown do usuário autenticado (sem privilégios de admin)', flow: 'header', clip: { x: 640, y: 0, width: 800, height: 380 },
    });
  });
  await step('modal de logout', async () => {
    await pageU.getByRole('button', { name: 'Sair', exact: true }).click();
    await pageU.waitForSelector('text=Sair da conta');
    await pageU.waitForTimeout(600);
    await shot(pageU, '12-auth-logout-modal', {
      title: 'ConfirmationModal "Sair da conta" (capturado e cancelado)', flow: 'auth',
    });
    await pageU.click('button:has-text("Cancelar")');
    await pageU.waitForTimeout(500);
    const aindaLogado = await pageU.locator('header button:has-text("Entrar")').count() === 0;
    console.log('após cancelar o logout, continua logado?', aindaLogado);
  });
  await ctxU.close();

  // ============ 6. Dropdown do administrador ============
  const ctxA = await newContext({ agent: 'A', auth: 'admin' });
  await hideDevtools(ctxA);
  const pageA = await ctxA.newPage();
  await goto(pageA, '/', { waitFor: 'text=Mostrando' });
  await ensureAuth(pageA, 'admin');
  await step('dropdown admin', async () => {
    await pageA.locator('nav button', { hasText: ACCOUNTS.admin.nome }).first().click();
    await pageA.waitForSelector('text=Administração');
    await pageA.waitForTimeout(400);
    await shot(pageA, '11-header-dropdown-admin', {
      title: 'Dropdown do administrador — inclui o item "Administração"', flow: 'header', clip: { x: 640, y: 0, width: 800, height: 380 },
    });
  });
  await ctxA.close();

  // ============ 7. Cadastro real com confirmação por e-mail ============
  const ctxN = await newContext({ agent: 'A', auth: 'none' });
  await hideDevtools(ctxN);
  const pageN = await ctxN.newPage();
  const t0 = Date.now() - 5000;
  await goto(pageN, '/', { waitFor: 'text=Mostrando' });

  await step('cadastro → Confirme seu e-mail', async () => {
    await pageN.locator('header button', { hasText: 'Entrar' }).first().click();
    await pageN.waitForSelector('form button[type="submit"]');
    await pageN.locator('p:has-text("Não tem conta?")').click();
    await pageN.getByPlaceholder('Ex: João Silva').fill(NOVO.nome);
    await pageN.getByPlaceholder('seu@email.com').fill(NOVO.email);
    await pageN.getByPlaceholder('******').fill(NOVO.senha);
    await pageN.locator('form button[type="submit"]').click();
    await pageN.waitForSelector('text=Confirme seu e-mail', { timeout: 25000 });
    await pageN.waitForTimeout(500);
    await shot(pageN, '12-auth-cadastro-confirme', {
      title: 'AuthModal — "Confirme seu e-mail" após o cadastro', flow: 'auth',
    });
  });

  let link = null;
  await step('Mailpit — e-mail de confirmação', async () => {
    const { summary, links } = await waitForMessageTo(NOVO.email, { timeoutMs: 25000, sinceMs: t0 });
    link = verifyLink(links);
    console.log('assunto do e-mail:', summary.Subject, '| link de verificação encontrado:', !!link);
    const mp = await ctxN.newPage();
    await mp.goto(`${MAILPIT}/view/${summary.ID}`, { waitUntil: 'domcontentloaded' });
    await mp.waitForTimeout(2500);
    await shot(mp, '12-auth-mailpit', {
      title: 'Mailpit (caixa de e-mails local) exibindo a mensagem de confirmação de cadastro',
      flow: 'auth', route: '/view/<id> (Mailpit :54324)',
    });
    await mp.close();
  });

  await step('confirmação → estado logado', async () => {
    if (!link) throw new Error('link de verificação não encontrado');
    await pageN.goto(link, { waitUntil: 'domcontentloaded' });
    await pageN.waitForTimeout(2500);
    await pageN.waitForSelector('text=/Mostrando \\d+ de \\d+/', { timeout: 20000 });
    await pageN.waitForTimeout(1200);
    await shot(pageN, '12-auth-cadastro-logado', {
      title: 'Após abrir o link de confirmação: sessão iniciada (header com o nome do novo usuário)',
      flow: 'auth', clip: HEADER_CLIP,
    });
    const nome = await pageN.locator('nav button span').first().innerText().catch(() => '(n/d)');
    console.log('nome exibido no header após confirmar:', nome);
  });
  await ctxN.close();

  // ============ 8. Rota inexistente (lacuna: sem página 404) ============
  const ctxR = await newContext({ agent: 'A', auth: 'none' });
  await hideDevtools(ctxR);
  const pageR = await ctxR.newPage();
  await step('rota inexistente', async () => {
    await pageR.goto('http://localhost:5173/rota-que-nao-existe', { waitUntil: 'domcontentloaded' });
    await pageR.waitForTimeout(2500);
    const txt = (await pageR.locator('body').innerText()).trim();
    console.log('conteúdo da rota inexistente:', JSON.stringify(txt.slice(0, 120)));
    await shot(pageR, '11-header-rota-inexistente', {
      title: 'Rota inexistente — página em branco, sem Header e sem 404', flow: 'header',
    });
  });
  await ctxR.close();
}

try {
  await main();
} finally {
  await apagarNovoUsuario().catch(e => console.warn('limpeza falhou:', e.message));
  await finish();
}
