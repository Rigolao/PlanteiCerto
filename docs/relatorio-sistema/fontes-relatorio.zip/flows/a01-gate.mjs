// Agente A — Flow 01: tela de proteção intelectual (IPProtectionGate).
// Estados: ocioso, erro de credenciais, mobile, pós-desbloqueio.
import { newContext, goto, shot, finish, setAgent } from '../harness/shot.mjs';
import { GATE } from '../harness/config.mjs';

setAgent('A');

// O botão flutuante do React Query Devtools (só existe no dev server) não faz parte
// da interface do produto — escondido em todas as capturas.
export async function hideDevtools(ctx) {
  await ctx.addInitScript(() => {
    const css = 'button[aria-label="Open Tanstack query devtools"],.tsqd-open-btn-container,.tsqd-parent-container{display:none !important}';
    const add = () => { const s = document.createElement('style'); s.textContent = css; document.head.appendChild(s); };
    if (document.head) add(); else document.addEventListener('DOMContentLoaded', add);
  });
}

async function main() {
  // --- desktop claro: ocioso + erro ---
  const ctx = await newContext({ agent: 'A', auth: 'none', gate: false });
  await hideDevtools(ctx);
  const page = await ctx.newPage();
  await goto(page, '/', { waitFor: 'text=Acesso Restrito' });
  await shot(page, '10-gate-ocioso', {
    title: 'Tela de proteção intelectual — estado ocioso',
    flow: 'gate', fullPage: true,
  });

  // erro: credenciais inválidas
  try {
    await page.fill('#username', 'usuario-errado');
    await page.fill('#password', 'senha-errada');
    await page.click('button:has-text("Acessar Sistema")');
    await page.waitForSelector('text=Credenciais inválidas. Acesso negado.', { timeout: 5000 });
    await shot(page, '10-gate-erro', {
      title: 'Gate — erro "Credenciais inválidas. Acesso negado."',
      flow: 'gate', fullPage: true,
    });
  } catch (e) { console.warn('erro no passo de credenciais inválidas:', e.message); }

  // --- desbloqueio real (usa as credenciais do gate; nunca registradas no capítulo) ---
  try {
    await page.fill('#username', GATE.user);
    await page.fill('#password', GATE.password);
    await page.click('button:has-text("Acessar Sistema")');
    await page.waitForSelector('text=/Mostrando \\d+ de \\d+/', { timeout: 20000 });
    await page.waitForTimeout(800);
    await shot(page, '10-gate-desbloqueado', {
      title: 'Gate — após desbloqueio: catálogo liberado',
      flow: 'gate', fullPage: false,
    });
    const unlocked = await page.evaluate(() => localStorage.getItem('ip_unlocked'));
    console.log('localStorage.ip_unlocked =', unlocked);
  } catch (e) { console.warn('erro no desbloqueio:', e.message); }
  await ctx.close();

  // --- mobile ---
  const ctxM = await newContext({ agent: 'A', auth: 'none', gate: false, viewport: 'mobile' });
  await hideDevtools(ctxM);
  const pageM = await ctxM.newPage();
  await goto(pageM, '/', { waitFor: 'text=Acesso Restrito' });
  await shot(pageM, '10-gate-mobile', {
    title: 'Gate — layout mobile (390×844)',
    flow: 'gate', fullPage: true,
  });
  await ctxM.close();
}

try { await main(); } finally { await finish(); }
