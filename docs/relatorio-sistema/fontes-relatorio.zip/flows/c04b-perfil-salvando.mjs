// Agente C — complemento do flow 04: recaptura do estado "Salvando..." do perfil
// (atrasa o upload do avatar para que o estado transitório fique visível).
import path from 'node:path';
import { newContext, goto, shot, ensureAuth, finish } from '../harness/shot.mjs';
import { ROOT } from '../harness/config.mjs';

const FOTO = path.join(ROOT, 'shots', '00-smoke-catalogo.png');
let ctx;
try {
  ctx = await newContext({ agent: 'C', theme: 'light', viewport: 'desktop', auth: 'projetista' });
  const page = await ctx.newPage();
  await goto(page, '/perfil', { waitFor: 'h1:has-text("Meu Perfil")' });
  await ensureAuth(page, 'projetista');
  await page.setInputFiles('input[type=file]', FOTO);
  await page.waitForTimeout(1000);
  await page.route('**/storage/v1/object/avatars/**', r => setTimeout(() => { r.continue().catch(() => {}); }, 4000));
  const salvando = page.locator('button:has-text("Salvando...")').waitFor({ timeout: 8000 }).catch(() => null);
  await page.locator('button:has-text("Salvar Perfil")').click();
  await salvando;
  const txt = await page.locator('form button[type="submit"]').innerText().catch(() => '?');
  console.log('rótulo do botão no momento da captura:', JSON.stringify(txt));
  await shot(page, '37-perfil-salvando', {
    title: 'Botão "Salvando..." durante o envio do perfil', flow: 'perfil', settle: 120,
  });
  await page.waitForSelector('[data-sonner-toast]', { timeout: 25000 }).catch(() => {});
  await page.unroute('**/storage/v1/object/avatars/**').catch(() => {});
  await page.waitForTimeout(1000);
} catch (e) {
  console.error('[c04b] ERRO:', e.message);
} finally {
  try { if (ctx) await ctx.close(); } catch {}
  await finish();
}
