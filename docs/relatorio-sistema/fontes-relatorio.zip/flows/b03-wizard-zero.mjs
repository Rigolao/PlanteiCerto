// Agente B · flow 3 — cenário sem resultados (guia rebaixada a < 1,5 m elimina todas as espécies).
import { newContext, goto, shot, finish, ensureAuth } from '../harness/shot.mjs';
import { runWizard, ANSWERS_ZERO } from '../harness/wizard.mjs';

const log = [];
const safe = async (label, fn) => { try { return await fn(); } catch (e) { console.warn(`! ${label}: ${String(e.message).split('\n')[0]}`); log.push(`ERRO ${label}: ${String(e.message).split('\n')[0]}`); return null; } };

const ctx = await newContext({ agent: 'B', theme: 'light', viewport: 'desktop', auth: 'user' });
const page = await ctx.newPage();

try {
  await goto(page, '/', { waitFor: 'text=Mostrando' });
  await ensureAuth(page, 'user');
  await goto(page, '/recomendacao', { waitFor: 'h3.font-display' });

  await runWizard(page, ANSWERS_ZERO, { confirm: true });
  await page.waitForSelector('text=Nenhuma espécie compatível encontrada', { timeout: 60000 });
  await page.waitForTimeout(700);

  await safe('zero', async () => {
    const titulo = (await page.locator('h2:has-text("Nenhuma espécie compatível encontrada")').innerText()).trim();
    const sub = (await page.locator('h2:has-text("Nenhuma espécie") + p').innerText()).trim();
    const chips = await page.locator('h2:has-text("Filtros eliminatórios aplicados") + div span').allInnerTexts().catch(() => []);
    const botoes = await page.locator('div.flex.flex-col.sm\\:flex-row > button').allInnerTexts().catch(() => []);
    log.push(`zero: "${titulo}" / "${sub}"`);
    log.push(`chips eliminatórios (${chips.length}): ${chips.join(' · ')}`);
    log.push(`botões: ${botoes.join(' | ')}`);
    log.push(`cartão "Como as espécies foram avaliadas" presente? ${await page.locator('button:has-text("Como as espécies foram avaliadas")').count()}`);
    await shot(page, '21-rec-zero-resultados', { title: 'Nenhuma espécie compatível encontrada (com chips eliminatórios)', flow: 'rec-zero' });

    const clip = await page.evaluate(() => {
      const h = [...document.querySelectorAll('h2')].find((x) => x.textContent.includes('Filtros eliminatórios aplicados'));
      if (!h) return null;
      const r = h.parentElement.getBoundingClientRect();
      return { x: Math.max(0, Math.round(r.left - 10)), y: Math.max(0, Math.round(r.top - 10)), width: Math.min(window.innerWidth, Math.round(r.width + 20)), height: Math.round(r.height + 20) };
    });
    if (clip) await shot(page, '21-rec-zero-chips', { clip, title: 'Cartão "Filtros eliminatórios aplicados" no estado vazio', flow: 'rec-zero' });
  });

  await safe('limpar-refazer', async () => {
    await page.locator('button', { hasText: /^Limpar e Refazer$/ }).first().click();
    await page.waitForSelector('h3.font-display', { timeout: 10000 });
    await page.waitForTimeout(500);
    const h = (await page.locator('text=/^Pergunta \\d+ de \\d+$/').first().innerText()).trim();
    const q = (await page.locator('h3.font-display').first().innerText()).trim();
    const proximo = page.locator('button', { hasText: /^Próximo$/ }).last();
    const marcadas = await page.locator('div.space-y-2\\.5 > button.border-\\[\\#a8c5a9\\]').count();
    log.push(`"Limpar e Refazer": ${h} — "${q}" · Próximo disabled=${await proximo.isDisabled()} · opções marcadas=${marcadas}`);
    await shot(page, '21-rec-limpar-refazer', { title: 'Após "Limpar e Refazer" — questionário zerado no passo 1', flow: 'rec-zero' });
  });
} finally {
  console.log('\n--- LOG b03 ---\n' + log.join('\n'));
  await ctx.close();
  await finish();
}
