// Agente D — flow d02: TreeFormModal (cadastro, seções, RatingInput, ImageUpload,
// validação, edição, toggle de status e exclusão) usando a espécie de demonstração "Zz".
import { newContext, goto, shot, shotToast, ensureAuth, finish } from '../harness/shot.mjs';
import { ROOT, API, SERVICE_ROLE } from '../harness/config.mjs';
import { sql } from '../harness/supa.mjs';
import path from 'node:path';

const MODAL = '.rounded-2xl.shadow-2xl';
const SEARCH = 'input[placeholder="Buscar por nome popular ou científico..."]';
const CONT = 'form .overflow-y-auto';
const ZZ_SCI = 'Zz Especimen demonstrativo';
const ZZ_POP = 'Zz Espécie de Teste';
const IMG = path.join(ROOT, 'shots', '00-smoke-catalogo.png');

async function hideDevtools(ctx) {
  await ctx.addInitScript(() => {
    const css = 'button[aria-label="Open Tanstack query devtools"],.tsqd-open-btn-container,.tsqd-parent-container{display:none !important}';
    const add = () => { const s = document.createElement('style'); s.textContent = css; document.head.appendChild(s); };
    if (document.head) add(); else document.addEventListener('DOMContentLoaded', add);
  });
}
async function step(nome, fn) {
  try { await fn(); } catch (e) { console.warn(`⚠ passo "${nome}" falhou: ${String(e.message).split('\n')[0]}`); }
}

/** Deixa aberta apenas a FormSection com o título informado. */
async function openOnly(page, titulo) {
  await page.evaluate((t) => {
    const cont = document.querySelector('form .overflow-y-auto');
    for (const sec of cont.children) {
      const btn = sec.querySelector('button');
      if (!btn) continue;
      const nome = btn.querySelector('span')?.textContent?.trim();
      const aberta = sec.children.length > 1;
      if ((nome === t) !== aberta) btn.click();
    }
  }, titulo);
  await page.waitForTimeout(350);
}

/** Rola o container do modal para o topo da seção; devolve medidas. */
async function scrollToSection(page, titulo, extra = 0) {
  return page.evaluate(([t, ex]) => {
    const cont = document.querySelector('form .overflow-y-auto');
    const sec = [...cont.children].find((c) => c.querySelector('button span')?.textContent?.trim() === t);
    if (!sec) return null;
    cont.scrollTop += sec.getBoundingClientRect().top - cont.getBoundingClientRect().top + ex;
    return { secH: Math.round(sec.getBoundingClientRect().height), contH: cont.clientHeight, scrollTop: Math.round(cont.scrollTop), scrollH: cont.scrollHeight };
  }, [titulo, extra]);
}

async function rectOf(page, fn, arg, pad = 10) {
  const r = await page.evaluate(fn, arg);
  if (!r) return undefined;
  const vp = page.viewportSize();
  const x = Math.max(0, r.x - pad), y = Math.max(0, r.y - pad);
  return { x, y, width: Math.min(vp.width - x, r.width + pad * 2), height: Math.min(vp.height - y, r.height + pad * 2) };
}

const rectDoCampo = (t) => {
  const lab = [...document.querySelectorAll('form label')].find((l) => l.textContent.trim() === t);
  if (!lab) return null;
  const b = lab.parentElement.getBoundingClientRect();
  return { x: b.x, y: b.y, width: b.width, height: b.height };
};

async function byLabel(page, texto) {
  const h = await page.evaluateHandle((t) => {
    const lab = [...document.querySelectorAll('form label')].find((l) => l.textContent.trim() === t);
    return lab ? lab.parentElement.querySelector('input, select') : null;
  }, texto);
  const el = h.asElement();
  if (!el) throw new Error(`campo não encontrado: ${texto}`);
  return el;
}
const fillLabel = async (page, t, v) => (await byLabel(page, t)).fill(String(v));
const selectLabel = async (page, t, v) => (await byLabel(page, t)).selectOption(v);
const setCheckbox = (page, texto, valor) => page.evaluate(([t, v]) => {
  const span = [...document.querySelectorAll('form label span')].find((s) => s.textContent.trim() === t);
  const input = span?.parentElement.querySelector('input[type="checkbox"]');
  if (input && input.checked !== v) input.click();
}, [texto, valor]);
const setRating = (page, texto, n) => page.evaluate(([t, v]) => {
  const lab = [...document.querySelectorAll('form label')].find((l) => l.textContent.trim() === t);
  const btn = [...(lab?.parentElement.querySelectorAll('button') ?? [])].find((b) => b.textContent.trim() === String(v));
  btn?.click();
}, [texto, n]);

const ctx = await newContext({ agent: 'D', theme: 'light', viewport: 'desktop', auth: 'admin' });
await hideDevtools(ctx);

try {
  const page = await ctx.newPage();
  await goto(page, '/', { waitFor: 'text=Mostrando' });
  await ensureAuth(page, 'admin');
  await goto(page, '/admin/arvores', { waitFor: 'text=Gerenciar Árvores' });

  // busca fixada em "Zz" para que a nova espécie apareça sozinha assim que for criada
  await page.fill(SEARCH, 'Zz');
  await page.waitForTimeout(400);

  await page.locator('button', { hasText: 'Cadastrar Nova Árvore' }).click();
  await page.waitForSelector(`${MODAL} h2`, { state: 'visible' });
  await page.waitForTimeout(500);
  console.log('titulo modal:', await page.locator(`${MODAL} h2`).innerText());
  console.log('seções:', await page.evaluate(() => [...document.querySelectorAll('form .overflow-y-auto > div > button span')].map((s) => s.textContent)));

  // ---------- 6 seções do formulário ----------
  const secoes = [
    ['43-admin-form-dados-basicos', 'Dados Básicos', 'Formulário de cadastro — seção "Dados Básicos"'],
    ['43-admin-form-morfologia', 'Morfologia', 'Formulário — seção "Morfologia"'],
    ['43-admin-form-tolerancias', 'Tolerâncias Ecológicas', 'Formulário — seção "Tolerâncias Ecológicas"'],
    ['43-admin-form-fenologia', 'Fenologia', 'Formulário — seção "Fenologia"'],
    ['43-admin-form-urbanismo', 'Urbanismo & Riscos', 'Formulário — seção "Urbanismo & Riscos"'],
    ['43-admin-form-projecao', 'Projeção de Crescimento (10 anos)', 'Formulário — seção "Projeção de Crescimento (10 anos)"'],
  ];
  for (const [id, titulo, legenda] of secoes) {
    await step(`secao ${titulo}`, async () => {
      if (id !== '43-admin-form-dados-basicos') await openOnly(page, titulo);
      const info = await scrollToSection(page, titulo);
      console.log(id, JSON.stringify(info));
      await shot(page, id, { title: legenda, flow: 'admin-form', element: MODAL });
      if (info && info.secH > info.contH) {
        await scrollToSection(page, titulo, info.secH - info.contH + 24);
        await shot(page, `${id}-p2`, { title: `${legenda} (continuação, rolagem interna)`, flow: 'admin-form', element: MODAL });
      }
    });
  }

  // ---------- RatingInput ----------
  await step('rating', async () => {
    await openOnly(page, 'Tolerâncias Ecológicas');
    await scrollToSection(page, 'Tolerâncias Ecológicas');
    await setRating(page, 'Tolerância à Seca', 4);
    await page.waitForTimeout(300);
    await shot(page, '44-admin-rating-valor', {
      title: 'RatingInput com nota 4 selecionada e botão "Limpar"', flow: 'admin-form',
      clip: await rectOf(page, rectDoCampo, 'Tolerância à Seca', 12),
    });
  });

  // ---------- ImageUpload ----------
  await step('upload', async () => {
    await openOnly(page, 'Dados Básicos');
    await scrollToSection(page, 'Dados Básicos');
    await page.locator('form label:has(input[type="file"])').scrollIntoViewIfNeeded();
    await page.waitForTimeout(200);
    await shot(page, '44-admin-upload-vazio', {
      title: 'ImageUpload — área de arrastar/soltar vazia', flow: 'admin-form',
      clip: await rectOf(page, rectDoCampo, 'Foto', 10),
    });

    const dt = await page.evaluateHandle(() => new DataTransfer());
    await page.dispatchEvent('form label:has(input[type="file"])', 'dragenter', { dataTransfer: dt });
    await page.dispatchEvent('form label:has(input[type="file"])', 'dragover', { dataTransfer: dt });
    await page.waitForTimeout(300);
    await shot(page, '44-admin-upload-dragover', {
      title: 'ImageUpload — estado "arrastando sobre a área"', flow: 'admin-form',
      clip: await rectOf(page, rectDoCampo, 'Foto', 10),
    });
    await page.dispatchEvent('form label:has(input[type="file"])', 'dragleave', { dataTransfer: dt });
    await page.waitForTimeout(200);

    await page.setInputFiles('form input[type="file"]', { name: 'grande.png', mimeType: 'image/png', buffer: Buffer.alloc(6 * 1024 * 1024) });
    await page.waitForSelector('text=Arquivo muito grande. Máximo: 5MB.', { state: 'visible' });
    await shot(page, '44-admin-upload-erro-tamanho', {
      title: 'ImageUpload — erro "Arquivo muito grande. Máximo: 5MB."', flow: 'admin-form',
      clip: await rectOf(page, rectDoCampo, 'Foto', 10),
    });

    await page.setInputFiles('form input[type="file"]', IMG);
    await page.waitForSelector('form img[alt="Preview"]', { state: 'visible' });
    await page.waitForTimeout(400);
    await shot(page, '44-admin-upload-previa', {
      title: 'ImageUpload — prévia da imagem com botão ✕ de remoção', flow: 'admin-form',
      clip: await rectOf(page, rectDoCampo, 'Foto', 10),
    });
  });

  // ---------- validação ----------
  await step('validacao', async () => {
    await page.locator(`${MODAL} button[type="submit"]`).click();
    await page.waitForSelector('text=Nome popular é obrigatório', { state: 'visible' });
    await scrollToSection(page, 'Dados Básicos');
    await shot(page, '45-admin-form-validacao', {
      title: 'Validação: "Nome popular é obrigatório" / "Nome científico é obrigatório"', flow: 'admin-form', element: MODAL,
    });
  });

  // ---------- preenchimento completo ----------
  await step('preencher', async () => {
    await openOnly(page, 'Dados Básicos');
    await fillLabel(page, 'Nome Popular *', ZZ_POP);
    await fillLabel(page, 'Nome Científico *', ZZ_SCI);
    await selectLabel(page, 'Origem', 'Nativa BR');
    await selectLabel(page, 'Folhagem', 'Semidecídua');

    await openOnly(page, 'Morfologia');
    await fillLabel(page, 'Altura Máxima (m)', 12);
    await selectLabel(page, 'Porte', 'Médio');
    await fillLabel(page, 'Diâmetro Copa (m)', 8);
    await selectLabel(page, 'Classe Copa', 'Média');
    await fillLabel(page, 'DAP Máximo (cm)', 40);
    await fillLabel(page, 'Alt. 1ª Bifurcação', 2.5);
    await fillLabel(page, 'Forma da Copa', 'Arredondada');

    await openOnly(page, 'Tolerâncias Ecológicas');
    await setCheckbox(page, 'Sol Pleno', true);
    await setCheckbox(page, 'Meia Sombra', true);
    for (const [lab, n] of [['Tolerância à Seca', 4], ['Tolerância ao Encharcamento', 2], ['Tolerância à Poluição', 3],
      ['Tolerância à Compactação', 3], ['Tolerância a Ventos Fortes', 4], ['Tolerância à Poda', 3],
      ['Atração da Fauna', 5], ['Potencial de Sombra', 4], ['Contribuição à Biodiversidade', 5]]) {
      await setRating(page, lab, n);
    }

    await openOnly(page, 'Fenologia');
    await fillLabel(page, 'Época de Floração', 'Set-Nov');
    await fillLabel(page, 'Época de Frutificação', 'Jan-Mar');

    await openOnly(page, 'Urbanismo & Riscos');
    await selectLabel(page, 'Compatibilidade Fiação', 'A');
    await setRating(page, 'Potencial Dano à Calçada', 2);
    await setRating(page, 'Potencial de Sujeira', 2);
    await fillLabel(page, 'Faixa de Serviço Mín. (m)', 2);
    await fillLabel(page, 'Área Berço Mín. (m²)', 1.5);
    await fillLabel(page, 'Volume Solo Mín. (m³)', 6);

    await openOnly(page, 'Projeção de Crescimento (10 anos)');
    await fillLabel(page, 'DAP aos 10 anos (cm)', 18);
    await fillLabel(page, 'Altura aos 10 anos (m)', 7);
    await fillLabel(page, 'Biomassa aérea (kg)', 120);
    await fillLabel(page, 'Carbono armazenado (kg C)', 56);
    await fillLabel(page, 'CO₂e (kg)', 205);
    await fillLabel(page, 'Sobrevivência (%)', 80);
    await selectLabel(page, 'Classe BVOC', 'baixo');
    await selectLabel(page, 'Confiança da Classe BVOC', 'média');
    await openOnly(page, 'Dados Básicos');
    await scrollToSection(page, 'Dados Básicos');
    await shot(page, '45-admin-form-preenchido', { title: 'Formulário preenchido antes de salvar', flow: 'admin-form', element: MODAL });
  });

  // ---------- salvar ----------
  await step('salvar', async () => {
    await page.route('**/rest/v1/trees*', async (r) => {
      if (r.request().method() === 'POST') await new Promise((res) => setTimeout(res, 4000));
      await r.continue();
    });
    const waitToast = page.waitForSelector('[data-sonner-toast]', { timeout: 30000 }).catch(() => null);
    await page.locator(`${MODAL} button[type="submit"]`).click();
    const salvando = await page.waitForSelector('button:has-text("Salvando...")', { timeout: 8000 }).catch(() => null);
    if (salvando) await shot(page, '45-admin-form-salvando', { title: 'Botão em estado "Salvando..."', flow: 'admin-form', element: MODAL, settle: 50 });
    else console.warn('✘ NÃO CAPTURADO 45-admin-form-salvando');
    const t = await waitToast;
    await page.waitForTimeout(600);
    if (t) console.log('toast criação:', await t.innerText().catch(() => '?'));
    await shot(page, '45-admin-toast-cadastrada', { title: 'Toast "Árvore cadastrada com sucesso!" e a nova linha na tabela', flow: 'admin-form' });
    await page.unroute('**/rest/v1/trees*');
    console.log('DB após criar:', sql(`select id, nome_popular, ativa, (foto is not null) as tem_foto from public.trees where nome_cientifico='${ZZ_SCI}'`));
  });

  await step('linha-nova', async () => {
    await page.waitForSelector(`table tbody tr:has-text("${ZZ_POP}")`, { state: 'visible' });
    await shot(page, '45-admin-tabela-zz', {
      title: 'Nova espécie listada na tabela administrativa', flow: 'admin-form',
      clip: await rectOf(page, () => {
        const t = document.querySelector('table');
        const b = t.getBoundingClientRect();
        return { x: b.x, y: b.y, width: b.width, height: b.height };
      }, null, 8),
    });
  });

  // ---------- toggle de status (Ativa) ----------
  await step('status', async () => {
    const linha = page.locator('table tbody tr', { hasText: ZZ_POP }).first();
    await shotToast(page, () => linha.locator('input[type="checkbox"]').click(), '45-admin-status-desmarcado', {
      title: 'Checkbox "Status" desmarcado → toast "Árvore atualizada com sucesso!"', flow: 'admin-form',
    });
    await page.waitForTimeout(800);
    console.log('ativa após toggle:', sql(`select ativa from public.trees where nome_cientifico='${ZZ_SCI}'`));
  });

  // ---------- edição ----------
  await step('editar', async () => {
    // espera o toast anterior sumir para não vazar no rodapé da captura do modal
    await page.waitForSelector('[data-sonner-toast]', { state: 'detached', timeout: 12000 }).catch(() => {});
    await page.waitForTimeout(500);
    const linha = page.locator('table tbody tr', { hasText: ZZ_POP }).first();
    await linha.locator('button[title="Editar"]').click();
    await page.waitForSelector(`${MODAL} h2`, { state: 'visible' });
    await page.waitForTimeout(600);
    console.log('titulo edicao:', await page.locator(`${MODAL} h2`).innerText());
    await shot(page, '46-admin-form-editar', { title: 'Modal de edição pré-preenchido', flow: 'admin-form', element: MODAL });

    await openOnly(page, 'Morfologia');
    await scrollToSection(page, 'Morfologia');
    await fillLabel(page, 'Altura Máxima (m)', 14);
    await page.waitForTimeout(200);
    const waitToast = page.waitForSelector('[data-sonner-toast]', { timeout: 20000 }).catch(() => null);
    await page.locator(`${MODAL} button[type="submit"]`).click();
    const t = await waitToast;
    await page.waitForTimeout(600);
    if (t) console.log('toast edição:', await t.innerText().catch(() => '?'));
    await shot(page, '46-admin-toast-atualizada', { title: 'Toast "Árvore atualizada com sucesso!" após editar', flow: 'admin-form' });
    console.log('DB após editar:', sql(`select altura_adulta_max_m, ativa from public.trees where nome_cientifico='${ZZ_SCI}'`));
  });

  // ---------- exclusão (espécie sem uso) ----------
  await step('excluir', async () => {
    const fotoUrl = sql(`select coalesce(foto,'') from public.trees where nome_cientifico='${ZZ_SCI}'`);
    const linha = page.locator('table tbody tr', { hasText: ZZ_POP }).first();
    await linha.locator('button[title="Excluir"]').click();
    await page.waitForSelector('text=Esta árvore não está sendo usada em nenhum projeto.', { state: 'visible' });
    console.log('titulo exclusao:', await page.locator(`${MODAL} h3`).innerText());
    await shot(page, '46-admin-excluir-sem-uso', { title: 'Diálogo de exclusão de espécie sem uso', flow: 'admin-form', element: MODAL });
    await shotToast(page, () => page.locator(`${MODAL} button`, { hasText: 'Excluir' }).click(), '46-admin-toast-excluida', {
      title: 'Toast "Árvore excluída com sucesso!"', flow: 'admin-form',
    });
    await page.waitForTimeout(800);
    console.log('DB após excluir:', sql(`select count(*) from public.trees where nome_cientifico='${ZZ_SCI}'`), '| foto era:', fotoUrl.replace(/^.*\/tree-images\//, 'tree-images/'));
  });
} catch (e) {
  console.error('ERRO no flow d02:', e.message);
} finally {
  try { sql(`delete from public.trees where nome_cientifico = '${ZZ_SCI}'`); } catch (e) { console.warn('limpeza Zz:', e.message); }
  // remove do bucket tree-images tudo que este flow subiu
  try {
    const nomes = sql(`select name from storage.objects where bucket_id='tree-images'`).split('\n').filter(Boolean);
    for (const n of nomes) {
      const res = await fetch(`${API}/storage/v1/object/tree-images/${n}`, { method: 'DELETE', headers: { apikey: SERVICE_ROLE, Authorization: `Bearer ${SERVICE_ROLE}` } });
      console.log('storage delete', n, res.status);
    }
  } catch (e) { console.warn('limpeza storage:', e.message); }
  try { await ctx.close(); } catch {}
  await finish();
  console.log('restou Zz?', sql(`select count(*) from public.trees where nome_cientifico = '${ZZ_SCI}'`));
  console.log('objetos tree-images:', sql(`select count(*) from storage.objects where bucket_id='tree-images'`));
  console.log('total trees:', sql('select count(*) from public.trees'));
}
