// Agente B · flow 1 — percurso completo do questionário de recomendação (cenário FIAÇÃO, 25 passos).
// Captura estados do wizard: passo vazio, multi-select, condicional q2_6, sub-perguntas, stepper, voltar,
// último passo, diálogo de confirmação.
import { newContext, goto, shot, finish, ensureAuth } from '../harness/shot.mjs';
import { runWizard, STEPS, ANSWERS_FIACAO } from '../harness/wizard.mjs';

const log = [];
const safe = async (label, fn) => { try { return await fn(); } catch (e) { console.warn(`! ${label}: ${String(e.message).split('\n')[0]}`); return null; } };

const ctx = await newContext({ agent: 'B', theme: 'light', viewport: 'desktop', auth: 'user' });
const page = await ctx.newPage();

try {
  await goto(page, '/', { waitFor: 'text=Mostrando' });
  await ensureAuth(page, 'user');
  await goto(page, '/recomendacao', { waitFor: 'h3.font-display' });

  // ---------- estado inicial: passo 1 sem resposta ----------
  await safe('passo1-vazio', async () => {
    const header = (await page.locator('text=/^Pergunta \\d+ de \\d+$/').first().innerText()).trim();
    const pct = (await page.locator('span.text-muted-foreground.font-medium').first().innerText()).trim();
    const proximo = page.locator('button', { hasText: /^Próximo$/ }).last();
    const disabled = await proximo.isDisabled();
    const temVoltar = await page.locator('button', { hasText: /^Voltar$/ }).count();
    log.push(`passo1 vazio: header="${header}" progresso="${pct}" Próximo disabled=${disabled} botãoVoltar=${temVoltar}`);
    await shot(page, '20-rec-passo1-vazio', {
      title: 'Questionário — passo 1 sem resposta ("Próximo" desabilitado)', flow: 'rec-questionario',
    });
  });

  // ---------- hooks por passo ----------
  const stepperClip = async () => page.evaluate(() => {
    window.scrollTo(0, 0);
    const b = document.querySelector('button[aria-label="Ir para pergunta 1"]');
    if (!b) return null;
    const r = b.parentElement.getBoundingClientRect();
    const h = [...document.querySelectorAll('span')].find((s) => /^Pergunta \d+ de \d+$/.test(s.textContent.trim()));
    const hr = h ? h.getBoundingClientRect() : r;
    return {
      x: Math.max(0, Math.round(r.left - 10)),
      y: Math.max(0, Math.round(hr.top - 12)),
      width: Math.min(window.innerWidth, Math.round(r.width + 20)),
      height: Math.round(r.bottom - hr.top + 24),
    };
  });

  const before = {
    q2_5: async (s, header) => {
      log.push(`q2_5 ANTES de responder: ${header}`);
      await shot(page, '20-rec-q2-5-antes', {
        title: 'Fiação aérea — antes de responder (total ainda 24 passos)', flow: 'rec-questionario',
      });
    },
  };

  const after = {
    q1_1: async (s, header) => {
      const proximo = page.locator('button', { hasText: /^Próximo$/ }).last();
      log.push(`q1_1 respondido: ${header} · Próximo disabled=${await proximo.isDisabled()}`);
      await shot(page, '20-rec-passo1-respondido', {
        title: 'Questionário — passo 1 respondido ("Calçada em frente a lote/residência")', flow: 'rec-questionario',
      });
    },
    q1_2: async (s, header) => {
      const btns = page.locator('div.space-y-2\\.5 > button');
      const n = await btns.count();
      const estados = [];
      for (let i = 0; i < n; i++) estados.push(`${(await btns.nth(i).innerText()).trim()}=${(await btns.nth(i).isDisabled()) ? 'desabilitado' : 'habilitado'}`);
      log.push(`q1_2 (${header}) opções: ${estados.join(' | ')}`);
      await shot(page, '20-rec-q1-2-multiselect', {
        title: 'Multi-select q1_2 — 2 objetivos marcados, demais desabilitados', flow: 'rec-questionario',
      });
    },
    q2_2: async (s, header) => {
      log.push(`q2_2 (${header}) helpText="${s.helpText ?? ''}"`);
      await shot(page, '20-rec-q2-2-helptext', {
        title: 'Grupo 2 — pergunta eliminatória com texto de ajuda (faixa de serviço)', flow: 'rec-questionario',
      });
    },
    q2_5: async (s, header) => {
      log.push(`q2_5 DEPOIS de responder "sim_convencional": ${header}`);
      await shot(page, '20-rec-q2-5-fiacao', {
        title: 'Fiação convencional selecionada — total salta para 25 passos', flow: 'rec-questionario',
      });
    },
    q2_6: async (s, header) => {
      log.push(`q2_6 (condicional) visível: ${header}`);
      await shot(page, '20-rec-q2-6-condicional', {
        title: 'Pergunta condicional q2_6 — distância até a fiação aérea', flow: 'rec-questionario',
      });
    },
    q2_8a: async (s, header) => { log.push(`q2_8a: ${header} · help="${s.helpText}"`); await shot(page, '20-rec-q2-8a-esquina', { title: 'Distâncias de segurança — esquina (mín. 6 m)', flow: 'rec-questionario' }); },
    q2_8b: async (s, header) => { log.push(`q2_8b: ${header} · help="${s.helpText}"`); await shot(page, '20-rec-q2-8b-poste', { title: 'Distâncias de segurança — poste de iluminação (mín. 4 m)', flow: 'rec-questionario' }); },
    q2_8c: async (s, header) => { log.push(`q2_8c: ${header} · help="${s.helpText}"`); await shot(page, '20-rec-q2-8c-guia', { title: 'Distâncias de segurança — guia rebaixada (mín. 1,5 m)', flow: 'rec-questionario' }); },
    q2_8d: async (s, header) => { log.push(`q2_8d: ${header} · help="${s.helpText}"`); await shot(page, '20-rec-q2-8d-bocalobo', { title: 'Distâncias de segurança — boca-de-lobo (mín. 1,5 m)', flow: 'rec-questionario' }); },
    q3_1: async (s, header) => {
      log.push(`q3_1: ${header}`);
      await shot(page, '20-rec-q3-1-insolacao', { title: 'Grupo 3 — insolação (pergunta mista: eliminatória + classificatória)', flow: 'rec-questionario' });
      const clip = await stepperClip();
      if (clip) await shot(page, '20-rec-stepper-zoom', { clip, title: 'Stepper no meio do percurso — respondidos, ativo e bloqueados', flow: 'rec-questionario' });
    },
    q3_2: async (s, header) => {
      // Demonstra o botão "Voltar": recua um passo, captura, avança de novo.
      log.push(`q3_2: ${header} — testando botão Voltar`);
      await page.locator('button', { hasText: /^Voltar$/ }).last().click();
      await page.waitForTimeout(400);
      const h2 = (await page.locator('text=/^Pergunta \\d+ de \\d+$/').first().innerText()).trim();
      const q = (await page.locator('h3.font-display').first().innerText()).trim();
      log.push(`  após "Voltar": ${h2} — "${q}"`);
      await shot(page, '20-rec-voltar', { title: 'Botão "Voltar" — retorno ao passo anterior com a resposta preservada', flow: 'rec-questionario' });
      await page.locator('button', { hasText: /^Próximo$/ }).last().click();
      await page.waitForTimeout(400);
      const h3t = (await page.locator('text=/^Pergunta \\d+ de \\d+$/').first().innerText()).trim();
      log.push(`  após "Próximo": ${h3t}`);
    },
    q4_2: async (s, header) => { log.push(`q4_2: ${header}`); await shot(page, '20-rec-q4-2-espinhos', { title: 'Grupo 4 — espinhos/substâncias irritantes', flow: 'rec-questionario' }); },
    q5_1: async (s, header) => { log.push(`q5_1: ${header}`); await shot(page, '20-rec-q5-1-nativas', { title: 'Grupo 5 — preferência por espécies nativas', flow: 'rec-questionario' }); },
    q5_2: async (s, header) => {
      const btn = page.locator('button', { hasText: /^(Próximo|Ver Resultados)$/ }).last();
      log.push(`q5_2 (último): ${header} · botão="${(await btn.innerText()).trim()}"`);
      await shot(page, '20-rec-ultimo-passo', { title: 'Último passo — botão "Ver Resultados"', flow: 'rec-questionario' });
    },
  };

  await runWizard(page, ANSWERS_FIACAO, {
    beforeAnswer: async (s, h) => { await before[s.id]?.(s, h); },
    afterAnswer: async (s, h) => { await after[s.id]?.(s, h); },
  });

  // ---------- diálogo de confirmação ----------
  await safe('dialogo', async () => {
    await page.waitForSelector('text=Finalizar questionário?', { timeout: 10000 });
    const txt = (await page.locator('h3:has-text("Finalizar questionário?")').locator('xpath=..').innerText()).replace(/\n+/g, ' | ');
    log.push(`diálogo: ${txt}`);
    await shot(page, '20-rec-dialogo-finalizar', { title: 'Diálogo "Finalizar questionário?"', flow: 'rec-questionario' });
  });

  await safe('revisar', async () => {
    await page.locator('button', { hasText: /^Revisar respostas$/ }).click();
    await page.waitForTimeout(500);
    const h = (await page.locator('text=/^Pergunta \\d+ de \\d+$/').first().innerText()).trim();
    log.push(`após "Revisar respostas": ${h} (volta ao questionário, diálogo fechado)`);
    await shot(page, '20-rec-revisar-respostas', { title: 'Após "Revisar respostas" — volta ao último passo respondido', flow: 'rec-questionario' });
  });

  await safe('reabrir-e-confirmar', async () => {
    await page.locator('button', { hasText: /^Ver Resultados$/ }).last().click();
    await page.waitForTimeout(400);
    await shot(page, '20-rec-dialogo-reaberto', { title: 'Diálogo reaberto após revisão, antes de confirmar', flow: 'rec-questionario' });
    await page.locator('button', { hasText: /^Ver Recomendações$/ }).click();
    await page.waitForSelector('text=Árvores Recomendadas', { timeout: 60000 });
    await page.waitForTimeout(800);
    const linha = (await page.locator('h1:has-text("Árvores Recomendadas")').locator('xpath=..').innerText()).replace(/\n+/g, ' ');
    log.push(`CENÁRIO FIAÇÃO resultado: ${linha}`);
    await shot(page, '21-rec-fiacao-topo', { title: 'Resultados do cenário com fiação convencional (topo)', flow: 'rec-resultados' });
    const cards = page.locator('div.grid > button');
    const n = await cards.count();
    const tops = [];
    for (let i = 0; i < Math.min(5, n); i++) tops.push((await cards.nth(i).innerText()).split('\n').slice(0, 4).join(' / '));
    log.push(`CENÁRIO FIAÇÃO cards=${n}; top5: ${tops.join('  ||  ')}`);
  });
} finally {
  console.log('\n--- LOG b01 ---\n' + log.join('\n'));
  await ctx.close();
  await finish();
}
