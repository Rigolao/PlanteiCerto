// Agente A — Flow 03: catálogo de espécies (TreesPage): hero, skeleton, grade, busca,
// ordenação, filtros avançados, estado vazio, favoritos, scroll infinito, mobile e dark.
import { newContext, goto, shot, shotToast, waitForImages, finish, setAgent, ensureAuth } from '../harness/shot.mjs';
import { BASE, ACCOUNTS } from '../harness/config.mjs';
import { rest } from '../harness/supa.mjs';

setAgent('A');

async function hideDevtools(ctx) {
  await ctx.addInitScript(() => {
    const css = 'button[aria-label="Open Tanstack query devtools"],.tsqd-open-btn-container,.tsqd-parent-container{display:none !important}';
    const add = () => { const s = document.createElement('style'); s.textContent = css; document.head.appendChild(s); };
    if (document.head) add(); else document.addEventListener('DOMContentLoaded', add);
  });
}

async function step(nome, fn) {
  try { await fn(); } catch (e) { console.warn(`⚠ passo "${nome}" falhou: ${String(e.message).split('\n')[0]}`); }
}

const contador = (page) => page.locator('text=/Mostrando \\d+ de \\d+/').first().innerText().catch(() => '(sem contador)');

let userId = null;
let favoritoExtra = null; // tree_id adicionado durante o flow (removido no finally)

async function favoritosDoUsuario() {
  const { data } = await rest(`/user_favorites?select=tree_id&user_id=eq.${userId}`);
  return data.map(r => r.tree_id).sort((a, b) => a - b);
}

async function main() {
  const prof = await rest(`/profiles?select=id&email=eq.${ACCOUNTS.user.email}`);
  userId = prof.data[0].id;
  console.log('favoritos iniciais:', await favoritosDoUsuario());

  // ============ 1. Visitante: hero, skeleton, grade, busca, ordenação, filtros ============
  const ctx = await newContext({ agent: 'A', auth: 'none' });
  await hideDevtools(ctx);

  // --- skeleton: atrasa a resposta de /rest/v1/trees em 4 s ---
  await step('skeleton', async () => {
    const sk = await ctx.newPage();
    await sk.route('**/rest/v1/trees*', r => setTimeout(() => r.continue(), 4000));
    await sk.goto(BASE + '/', { waitUntil: 'commit' });
    await sk.waitForTimeout(1400);
    await shot(sk, '13-catalogo-skeleton', {
      title: 'Catálogo carregando — 6 TreeCardSkeleton', flow: 'catalogo', route: '/',
    });
    await sk.close();
  });

  const page = await ctx.newPage();
  await goto(page, '/', { waitFor: 'text=Mostrando' });
  await page.mouse.move(1430, 880);

  await shot(page, '13-catalogo-hero', {
    title: 'Hero "Encontre a árvore certa" + CTA "Encontrar Árvore Recomendada"',
    flow: 'catalogo', clip: { x: 0, y: 0, width: 1440, height: 380 },
  });
  console.log('contador inicial:', await contador(page));
  await shot(page, '13-catalogo-grid', {
    title: 'Catálogo — grade padrão (página inteira)', flow: 'catalogo', fullPage: true,
  });

  await step('busca', async () => {
    await page.getByPlaceholder('Buscar por nome ou espécie...').fill('ipê');
    await page.waitForTimeout(900);
    await waitForImages(page);
    console.log('contador busca "ipê":', await contador(page));
    await shot(page, '13-catalogo-busca', {
      title: 'Busca por "ipê" — resultados filtrados', flow: 'catalogo',
    });
  });

  await step('ordenação', async () => {
    await page.getByPlaceholder('Buscar por nome ou espécie...').fill('');
    await page.waitForTimeout(600);
    const opts = await page.locator('select').first().locator('option').allTextContents();
    console.log('opções de ordenação:', JSON.stringify(opts));

    await page.locator('select').first().selectOption('mais_co2e');
    await page.waitForTimeout(900);
    await waitForImages(page);
    await shot(page, '13-catalogo-ordem-co2', {
      title: 'Ordenação "Maior captura de CO₂ (10 anos)"', flow: 'catalogo',
    });

    await page.locator('select').first().selectOption('maior_porte');
    await page.waitForTimeout(900);
    await waitForImages(page);
    await shot(page, '13-catalogo-ordem-porte', {
      title: 'Ordenação "Maior porte primeiro"', flow: 'catalogo',
    });

    await page.locator('select').first().selectOption('nome_az');
    await page.waitForTimeout(700);
  });

  await step('filtros avançados', async () => {
    await page.click('button:has-text("Filtros Avançados")');
    await page.waitForSelector('text=Critérios Específicos');
    await page.locator('label:has-text("Nativas do Brasil") input[type="checkbox"]').check();
    await page.locator('label:has-text("Sem Espinhos") input[type="checkbox"]').check();
    await page.waitForTimeout(900);
    await waitForImages(page);
    console.log('contador com 2 filtros:', await contador(page));
    await shot(page, '13-catalogo-filtros-avancados', {
      title: 'Painel "Critérios Específicos" com 2 filtros marcados', flow: 'catalogo',
    });
  });

  await step('estado vazio', async () => {
    await page.locator('label:has-text("Nativas do Brasil") input[type="checkbox"]').uncheck();
    await page.locator('label:has-text("Sem Espinhos") input[type="checkbox"]').uncheck();
    await page.getByPlaceholder('Buscar por nome ou espécie...').fill('zzzz');
    await page.locator('select').nth(1).selectOption('Grande'); // Porte da Árvore
    await page.waitForTimeout(900);
    await page.click('button:has-text("Filtros Avançados")'); // fecha o painel para o estado vazio caber na tela
    await page.waitForTimeout(600);
    await shot(page, '13-catalogo-vazio-filtros', {
      title: 'EmptyStateFilters — "Nenhuma árvore encontrada" com chips removíveis', flow: 'catalogo',
    });
    await page.click('button:has-text("Limpar todos os filtros")');
    await page.waitForTimeout(900);
  });

  await step('scroll infinito', async () => {
    await page.mouse.wheel(0, 4000);
    await page.waitForTimeout(1800);
    await page.mouse.wheel(0, 3000);
    await page.waitForTimeout(1800);
    await waitForImages(page);
    console.log('contador após rolar:', await contador(page));
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.waitForTimeout(700);
    await shot(page, '13-catalogo-scroll-infinito', {
      title: 'Scroll infinito — contador aumenta conforme novas páginas de 6 cards entram',
      flow: 'catalogo', clip: { x: 0, y: 240, width: 1440, height: 460 },
    });
  });

  await step('coração deslogado', async () => {
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.waitForTimeout(500);
    await shotToast(page,
      () => page.locator('article button[title="Adicionar aos favoritos"]').first().click(),
      '13-catalogo-favorito-deslogado',
      { title: 'Visitante clica no coração: toast "Faça login para favoritar árvores." + AuthModal', flow: 'catalogo' });
  });
  await ctx.close();

  // ============ 2. Usuária autenticada: favoritar e filtrar favoritos ============
  const ctxU = await newContext({ agent: 'A', auth: 'user' });
  await hideDevtools(ctxU);
  const pu = await ctxU.newPage();
  await goto(pu, '/', { waitFor: 'text=Mostrando' });
  await ensureAuth(pu, 'user');

  await step('favoritar um card', async () => {
    const antes = await favoritosDoUsuario();
    const card = pu.locator('article').first();
    const nome = await card.locator('h2').innerText();
    await card.locator('button[title="Adicionar aos favoritos"]').click();
    await pu.waitForTimeout(1800);
    const depois = await favoritosDoUsuario();
    favoritoExtra = depois.find(id => !antes.includes(id)) ?? null;
    console.log(`favoritou "${nome}" → tree_id ${favoritoExtra}; favoritos agora:`, depois);
    await pu.mouse.move(1430, 880);
    await pu.waitForTimeout(400);
    await shot(pu, '13-catalogo-favorito-ativo', {
      title: `Card "${nome}" com o coração preenchido (favoritado) e contador "Favoritos" em 4`,
      flow: 'catalogo', clip: { x: 0, y: 270, width: 1440, height: 560 },
    });
  });

  await step('filtro Favoritos', async () => {
    await pu.click('button:has-text("Favoritos")');
    await pu.waitForTimeout(1200);
    await waitForImages(pu);
    console.log('URL com filtro de favoritos:', pu.url());
    console.log('contador favoritos:', await contador(pu));
    await shot(pu, '13-catalogo-favoritos-ativo', {
      title: 'Filtro "Favoritos" ativo (?favoritos=true)', flow: 'catalogo', fullPage: true,
    });
  });

  await step('desfazer favorito extra', async () => {
    if (favoritoExtra == null) return;
    await pu.locator('article button[title="Remover dos favoritos"]').first().click();
    await pu.waitForTimeout(1500);
    console.log('favoritos após desfazer:', await favoritosDoUsuario());
  });
  await ctxU.close();

  // ============ 3. Mobile e dark ============
  const ctxM = await newContext({ agent: 'A', auth: 'none', viewport: 'mobile' });
  await hideDevtools(ctxM);
  const pm = await ctxM.newPage();
  await goto(pm, '/', { waitFor: 'text=Mostrando' });
  await shot(pm, '13-catalogo-grid-mobile', {
    title: 'Catálogo — layout mobile (1 card por linha)', flow: 'catalogo', fullPage: true,
  });
  await ctxM.close();

  const ctxD = await newContext({ agent: 'A', auth: 'none', theme: 'dark' });
  await hideDevtools(ctxD);
  const pd = await ctxD.newPage();
  await goto(pd, '/', { waitFor: 'text=Mostrando' });
  await pd.mouse.move(1430, 880);
  await shot(pd, '13-catalogo-grid-dark', {
    title: 'Catálogo — tema escuro', flow: 'catalogo', fullPage: true,
  });
  await ctxD.close();
}

try {
  await main();
} finally {
  // limpeza: garante que o favorito extra criado no flow foi removido
  try {
    if (favoritoExtra != null && userId) {
      const atuais = await favoritosDoUsuario();
      if (atuais.includes(favoritoExtra)) {
        await rest(`/user_favorites?user_id=eq.${userId}&tree_id=eq.${favoritoExtra}`, { method: 'DELETE' });
        console.log('limpeza: favorito extra', favoritoExtra, 'removido via REST');
      }
      console.log('favoritos finais:', await favoritosDoUsuario());
    }
  } catch (e) { console.warn('limpeza de favoritos falhou:', e.message); }
  await finish();
}
