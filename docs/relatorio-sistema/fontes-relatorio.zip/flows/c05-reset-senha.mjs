// Agente C — flow 05: redefinição de senha por e-mail (conta `colega`).
// Header "Entrar" -> "Esqueceu a senha?" -> e-mail -> Mailpit -> /reset-password -> nova senha.
// No finally: restaura a senha da colega para Demo!2026 e cria state/c05-done.flag
import fs from 'node:fs';
import path from 'node:path';
import { newContext, goto, shot, shotToast, finish } from '../harness/shot.mjs';
import { ACCOUNTS, ROOT } from '../harness/config.mjs';
import { adminFindUser, adminUpdateUser } from '../harness/supa.mjs';
import { waitForMessageTo, verifyLink } from '../harness/mailpit.mjs';

const COLEGA = ACCOUNTS.colega;
const NOVA = 'Demo!2026b';
const flagPath = path.join(ROOT, 'state', 'c05-done.flag');
const notes = [];
let ctx;

try {
  ctx = await newContext({ agent: 'C', theme: 'light', viewport: 'desktop', auth: 'none', gate: true });
  const page = await ctx.newPage();
  const since = Date.now() - 5000;

  await goto(page, '/', { waitFor: 'text=Mostrando' });

  // --- AuthModal em modo "Recuperar Senha" ---
  await page.locator('header button', { hasText: 'Entrar' }).first().click();
  await page.waitForSelector('button:has-text("Esqueceu a senha?")', { state: 'visible' });
  await page.locator('button:has-text("Esqueceu a senha?")').click();
  await page.waitForSelector('h2:has-text("Recuperar Senha")');
  await page.getByPlaceholder('seu@email.com').fill(COLEGA.email);
  await page.waitForTimeout(300);
  await shot(page, '38-reset-solicitar', {
    title: 'AuthModal — "Recuperar Senha" com e-mail preenchido', flow: 'reset',
  });

  // --- Envio -> tela "E-mail enviado" ---
  await page.locator('form button[type="submit"]').click();
  await page.waitForSelector('h2:has-text("E-mail enviado")', { timeout: 25000 });
  await page.waitForTimeout(400);
  await shot(page, '38-reset-email-enviado', {
    title: 'AuthModal — confirmação "E-mail enviado"', flow: 'reset',
  });
  await page.locator('button:has-text("Entendido")').click().catch(() => {});

  // --- E-mail no Mailpit ---
  const mail = await waitForMessageTo(COLEGA.email, { timeoutMs: 30000, sinceMs: since });
  const assunto = mail.summary?.Subject ?? '(sem assunto)';
  const corpo = (mail.message?.Text || '').replace(/\s+/g, ' ').trim().slice(0, 400);
  const link = verifyLink(mail.links);
  notes.push(`e-mail assunto: ${assunto}`);
  notes.push(`e-mail corpo: ${corpo}`);
  notes.push(`link: ${link ? link.replace(/token=[^&]+/, 'token=<REDACTED>') : '(nenhum)'}`);
  console.log('[mailpit]', assunto, '|', corpo);
  if (!link) throw new Error('link de recuperação não encontrado no e-mail');

  // --- Segue o link -> /reset-password ---
  await page.goto(link, { waitUntil: 'domcontentloaded', timeout: 30000 });
  await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {});
  await page.waitForSelector('h1:has-text("Nova Senha")', { timeout: 25000 });
  await page.waitForTimeout(500);
  notes.push(`url após o link: ${new URL(page.url()).pathname}`);
  await shot(page, '38-reset-form', {
    title: 'Página /reset-password — formulário "Nova Senha"', flow: 'reset',
  });

  const pwd = page.locator('input[placeholder="No mínimo 6 caracteres"]');
  const conf = page.locator('input[placeholder="Repita a nova senha"]');
  const submit = page.locator('form button[type="submit"]');

  // --- Validação: senha curta ---
  await pwd.fill('123');
  await conf.fill('123');
  await shotToast(page, () => submit.click(), '38-reset-erro-curta', {
    title: 'Validação — senha com menos de 6 caracteres', flow: 'reset',
  });
  await page.waitForTimeout(1200);

  // --- Validação: senhas diferentes ---
  await pwd.fill(NOVA);
  await conf.fill('Demo!2026c');
  await shotToast(page, () => submit.click(), '38-reset-erro-diferentes', {
    title: 'Validação — senhas não coincidem', flow: 'reset',
  });
  await page.waitForTimeout(1200);

  // --- Submissão real (com atraso artificial para flagrar "Alterando...") ---
  await pwd.fill(NOVA);
  await conf.fill(NOVA);
  await page.route('**/auth/v1/user**', route => setTimeout(() => { route.continue().catch(() => {}); }, 3500));
  const alterando = page.waitForSelector('button:has-text("Alterando...")', { timeout: 8000 }).catch(() => null);
  await submit.click();
  if (await alterando) {
    await shot(page, '39-reset-alterando', {
      title: 'Botão em estado "Alterando..."', flow: 'reset', settle: 150,
    });
  } else {
    console.warn('estado "Alterando..." não flagrado');
    notes.push('estado "Alterando..." não flagrado');
  }
  const ok = await page.waitForSelector('text=Senha atualizada!', { timeout: 25000 }).catch(() => null);
  await page.unroute('**/auth/v1/user**').catch(() => {});
  if (!ok) {
    const t = await page.locator('[data-sonner-toast]').allInnerTexts().catch(() => []);
    console.warn('[diag] sem painel de sucesso; toasts:', JSON.stringify(t));
    notes.push(`sem painel de sucesso; toasts: ${JSON.stringify(t)}`);
    throw new Error('painel "Senha atualizada!" não apareceu');
  }
  await page.waitForTimeout(300);
  await shot(page, '39-reset-sucesso', {
    title: 'Painel de sucesso "Senha atualizada!"', flow: 'reset',
  });

  // --- Redirecionamento automático após 3 s ---
  await page.waitForFunction(() => location.pathname === '/', null, { timeout: 12000 }).catch(() => {});
  await page.waitForSelector('text=Mostrando', { timeout: 20000 }).catch(() => {});
  await page.waitForTimeout(800);
  notes.push(`url após redirect: ${new URL(page.url()).pathname}`);
  await shot(page, '39-reset-redirecionado', {
    title: 'Catálogo após o redirecionamento automático (usuária já autenticada)', flow: 'reset',
  });
} catch (e) {
  console.error('[c05] ERRO:', e.message);
  notes.push(`ERRO: ${e.message}`);
} finally {
  try { if (ctx) await ctx.close(); } catch {}
  // restaura a senha da colega
  try {
    const u = await adminFindUser(COLEGA.email);
    if (u) { await adminUpdateUser(u.id, { password: 'Demo!2026' }); console.log('senha da colega restaurada'); notes.push('senha da colega restaurada para Demo!2026'); }
    else notes.push('ATENÇÃO: usuária colega não encontrada para restaurar senha');
  } catch (e) { console.error('falha ao restaurar senha:', e.message); notes.push(`falha ao restaurar senha: ${e.message}`); }
  fs.writeFileSync(flagPath, `${new Date().toISOString()}\n${notes.join('\n')}\n`);
  console.log('flag criado:', flagPath);
  await finish();
}
