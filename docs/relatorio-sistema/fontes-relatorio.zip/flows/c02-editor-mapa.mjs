// Agente C — flow 02: editor de projeto (mapa, pontos, busca, GPS, estatísticas).
// Uso: node flows/c02-editor-mapa.mjs          (tudo)
//      C02_PARTE=b node flows/c02-editor-mapa.mjs   (só projeto com 6 pontos + mobile + dark)
import { newContext, goto, shot, shotToast, waitForTiles, ensureAuth, finish } from '../harness/shot.mjs';
import { rest } from '../harness/supa.mjs';

const VAZIO = 'Praça Sete de Setembro (em planejamento)';
const CHEIO = 'Arborização Rua Prudente de Moraes';
const GEO = { latitude: -21.1767, longitude: -47.8208 };
const PARTE = (process.env.C02_PARTE || 'ab').toLowerCase();
const ctxs = [];
const log = [];
let idVazio, centrosOriginais = [];

async function nc(opts) { const c = await newContext({ agent: 'C', geolocation: GEO, ...opts }); ctxs.push(c); return c; }
function note(s) { log.push(s); console.log('· ' + s); }

async function abrirProjeto(page, nome) {
  await goto(page, '/projetos', { waitFor: 'h1:has-text("Meus Projetos")' });
  await page.locator('div[role="button"]', { hasText: nome }).first().click();
  await page.locator('span:has-text("Pontos do Projeto"):visible').first().waitFor({ timeout: 25000 });
  await waitForTiles(page);
}
const nPins = p => p.locator('.marker-arvore-wrapper:visible').count();
const nClusters = p => p.locator('.marker-cluster:visible').count();

try {
  const { data: projs } = await rest('/projects?select=id,nome,centro_lat,centro_lng,centro_zoom');
  centrosOriginais = projs.map(p => ({ ...p }));
  idVazio = projs.find(p => p.nome === VAZIO)?.id;

  const ctx = await nc({ theme: 'light', viewport: 'desktop', auth: 'projetista' });
  const page = await ctx.newPage();
  page.on('dialog', async d => { note(`window.${d.type()}: "${d.message()}"`); await d.accept(); });
  await goto(page, '/projetos', { waitFor: 'h1:has-text("Meus Projetos")' });
  await ensureAuth(page, 'projetista');

  // ═══════════ PARTE A — projeto vazio: ciclo de vida de um ponto ═══════════
  if (PARTE.includes('a')) {
    await abrirProjeto(page, VAZIO);
    note(`projeto vazio — Estatísticas desabilitado: ${await page.locator('button:has-text("Estatísticas")').isDisabled()}; ` +
         `Relatório desabilitado: ${await page.locator('button:has-text("Relatório")').isDisabled()}`);
    await shot(page, '32-editor-vazio', {
      title: 'Editor de projeto sem pontos — mapa, painel vazio e botões desabilitados', flow: 'editor',
    });

    // Clique no mapa -> ponto pendente
    const box = await page.locator('.leaflet-container:visible').first().boundingBox();
    await page.mouse.click(box.x + box.width / 2, box.y + box.height / 2);
    await page.waitForSelector('text=Aguardando vinculação', { timeout: 10000 });
    await waitForTiles(page);
    await shot(page, '32-editor-ponto-pendente', {
      title: 'Ponto pendente âmbar no mapa e seção "Aguardando vinculação" no painel', flow: 'editor',
    });

    // TreeSelectionDialog
    await page.locator('button:has-text("Vincular"):visible').first().click();
    await page.waitForSelector('h2:has-text("Selecionar Árvore")');
    await page.waitForTimeout(600);
    await shot(page, '33-editor-dialogo-fechado', { title: 'TreeSelectionDialog — combobox fechado', flow: 'editor' });

    const busca = page.getByPlaceholder('Buscar por nome ou espécie...');
    await busca.click();
    await page.waitForSelector('ul#tree-listbox', { timeout: 8000 });
    await page.waitForTimeout(900);
    note(`opções no dropdown: ${await page.locator('ul#tree-listbox li').count()}`);
    await shot(page, '33-editor-dropdown', { title: 'TreeSelectionDialog — dropdown aberto com miniaturas', flow: 'editor' });

    await busca.fill('zzzzz');
    await page.waitForSelector('text=Nenhuma árvore encontrada', { timeout: 8000 });
    await page.waitForTimeout(300);
    await shot(page, '33-editor-busca-vazia', { title: 'TreeSelectionDialog — busca sem resultados', flow: 'editor' });

    await busca.fill('Ipê-amarelo');
    await page.waitForSelector('ul#tree-listbox li[role="option"]', { timeout: 8000 });
    await page.locator('ul#tree-listbox li[role="option"]').first().click();
    await page.waitForTimeout(400);
    await page.getByPlaceholder('Comentário sobre esta muda ou local...').fill('Muda de teste para o relatório — calçada leste.');
    await page.waitForTimeout(400);
    await shot(page, '33-editor-especie-selecionada', {
      title: 'TreeSelectionDialog — espécie escolhida, prévia e observação preenchida', flow: 'editor',
    });

    await shotToast(page, () => page.locator('button:has-text("Confirmar Seleção")').click(), '33-editor-toast-adicionada', {
      title: 'Toast "Árvore adicionada com sucesso!"', flow: 'editor',
    });
    await page.waitForTimeout(2500);
    await waitForTiles(page);
    await shot(page, '33-editor-painel-1ponto', {
      title: 'Editor com um ponto vinculado — pin nomeado e linha no painel', flow: 'editor',
    });

    await page.locator('[data-point-id]:visible').first().locator('button[aria-haspopup="menu"]').click();
    await page.waitForSelector('[role="menu"]');
    await page.waitForTimeout(300);
    await shot(page, '33-editor-menu-ponto', { title: 'PointActionsMenu aberto ("Editar espécie" / "Remover")', flow: 'editor' });

    await page.locator('[role="menuitem"]:has-text("Editar espécie"):visible').first().click();
    await page.waitForSelector('h2:has-text("Selecionar Árvore")');
    await page.waitForTimeout(700);
    await shot(page, '33-editor-dialogo-edicao', {
      title: 'TreeSelectionDialog em modo edição (espécie e observação pré-preenchidas)', flow: 'editor',
    });
    await page.getByPlaceholder('Comentário sobre esta muda ou local...').fill('Observação revisada: berço 1,2 × 1,2 m.');
    await shotToast(page, () => page.locator('button:has-text("Confirmar Seleção")').click(), '33-editor-toast-atualizada', {
      title: 'Toast "Dados da árvore atualizados!"', flow: 'editor',
    });
    await page.waitForTimeout(2500);

    await page.locator('[data-point-id]:visible').first().locator('button[aria-haspopup="menu"]').click();
    await page.locator('[role="menuitem"]:has-text("Remover"):visible').first().click();
    await page.waitForSelector('h3:has-text("Remover árvore")');
    await page.waitForTimeout(500);
    await shot(page, '33-editor-remover-confirm', { title: 'ConfirmationModal "Remover árvore"', flow: 'editor' });
    await shotToast(page, () => page.locator('div.fixed button:has-text("Remover"):visible').last().click(), '33-editor-toast-removida', {
      title: 'Toast "Árvore removida do mapa."', flow: 'editor',
    });
    await page.waitForTimeout(2000);
    note(`pontos no projeto vazio após remoção: ${(await rest('/points?project_id=eq.' + idVazio + '&select=id')).data.length}`);

    // Diálogo nativo ao sair com ponto pendente
    const box2 = await page.locator('.leaflet-container:visible').first().boundingBox();
    await page.mouse.click(box2.x + box2.width / 2 + 80, box2.y + box2.height / 2 + 60);
    await page.waitForSelector('text=Aguardando vinculação', { timeout: 8000 });
    await page.locator('button:has-text("Descartar"):visible').first().click();
    await page.waitForTimeout(400);
    note(`após "Descartar": seção pendente visível? ${await page.locator('text=Aguardando vinculação').count() > 0}`);
    await page.mouse.click(box2.x + box2.width / 2 + 80, box2.y + box2.height / 2 + 60);
    await page.waitForSelector('text=Aguardando vinculação', { timeout: 8000 });
    await page.locator('.fixed.inset-0 button:visible').first().click();   // seta voltar -> window.confirm
    await page.waitForSelector('h1:has-text("Meus Projetos")', { timeout: 15000 }).catch(() => {});
  }

  // ═══════════ PARTE B — projeto com 6 pontos ═══════════
  if (PARTE.includes('b')) {
    await abrirProjeto(page, CHEIO);
    note(`abertura: ${await nPins(page)} pins soltos, ${await nClusters(page)} agrupamentos`);
    await shot(page, '34-editor-split', {
      title: 'Editor desktop — mapa satélite (marcadores agrupados) e painel com os 6 pontos', flow: 'editor',
    });

    // Zoom até o máximo permitido pela camada
    for (let i = 0; i < 4; i++) {
      const zi = page.locator('.leaflet-control-zoom-in:visible').first();
      if (await zi.getAttribute('aria-disabled') === 'true') { note(`zoom máximo atingido após ${i} cliques`); break; }
      await zi.click();
      await page.waitForTimeout(900);
      await waitForTiles(page);
    }
    note(`zoom máximo: ${await nPins(page)} pins soltos, ${await nClusters(page)} agrupamentos`);
    await shot(page, '34-editor-zoom-maximo', {
      title: 'Mapa no zoom máximo — pins nomeados e agrupamentos remanescentes', flow: 'editor',
    });

    // Abre um agrupamento (spiderfy)
    if (await nClusters(page)) {
      await page.locator('.marker-cluster:visible').first().click();
      await page.waitForTimeout(1500);
      await waitForTiles(page);
      note(`após abrir um agrupamento: ${await nPins(page)} pins soltos, ${await nClusters(page)} agrupamentos`);
      await shot(page, '34-editor-cluster-aberto', {
        title: 'Agrupamento aberto — marcadores individuais com o nome da espécie', flow: 'editor',
      });
    }

    // Tooltip de um pin
    const pin = page.locator('.marker-arvore-wrapper:visible').first();
    await pin.hover();
    await page.waitForTimeout(800);
    note(`tooltip: "${await page.locator('.leaflet-tooltip:visible').first().innerText().catch(() => '(sem tooltip)')}"`);
    await shot(page, '34-editor-tooltip-pin', { title: 'Tooltip de um marcador (nome popular — observação)', flow: 'editor' });

    // Ponto selecionado
    await pin.click();
    await page.waitForTimeout(900);
    await shot(page, '34-editor-ponto-selecionado', {
      title: 'Ponto selecionado — marcador azul e linha destacada no painel', flow: 'editor',
    });

    // MapSearchBox
    const campoBusca = page.locator('input[placeholder="Buscar endereço, CEP ou cidade..."]:visible').first();
    await campoBusca.fill('Ribeirão Preto');
    await page.waitForTimeout(300);
    await shot(page, '34-editor-busca-preenchida', { title: 'MapSearchBox com "Ribeirão Preto" digitado', flow: 'editor' });
    await campoBusca.press('Enter');
    await page.waitForTimeout(4500);
    await waitForTiles(page);
    const erroBusca = await page.locator('.bg-red-100:visible').first().innerText({ timeout: 1500 }).catch(() => null);
    note(`busca "Ribeirão Preto" -> ${erroBusca ? 'erro: ' + erroBusca : 'mapa reposicionado; campo limpo'}`);
    await shot(page, '34-editor-busca-resultado', { title: 'Mapa após a busca por "Ribeirão Preto"', flow: 'editor' });

    await campoBusca.fill('00000-000');
    await campoBusca.press('Enter');
    const erroCep = page.locator('.bg-red-100:visible').first();
    await erroCep.waitFor({ timeout: 25000 }).catch(() => {});
    note(`busca CEP 00000-000 -> "${await erroCep.innerText().catch(() => '(sem mensagem)')}"`);
    await page.waitForTimeout(300);
    await shot(page, '34-editor-busca-erro', { title: 'MapSearchBox — erro de busca por CEP inexistente', flow: 'editor' });
    await campoBusca.fill('');

    // MyLocationButton
    await shotToast(page, () => page.locator('button[title="Minha Localização"]:visible').first().click(), '34-editor-minha-localizacao', {
      title: 'Toast "Localização encontrada!" após usar o GPS', flow: 'editor',
    });
    await page.waitForTimeout(2500);
    await waitForTiles(page);

    // Dashboard populado
    await abrirProjeto(page, CHEIO);
    await page.locator('button:has-text("Estatísticas"):visible').first().click();
    await page.waitForSelector('h2:has-text("Dashboard do Projeto")');
    await page.waitForTimeout(1200);
    const dash = await page.locator('h2:has-text("Dashboard do Projeto")').locator('xpath=ancestor::div[3]').first().innerText().catch(() => '');
    note('dashboard: ' + dash.replace(/\n+/g, ' | ').slice(0, 400));
    await shot(page, '34-editor-estatisticas', { title: 'ProjectStatsModal populado — "Dashboard do Projeto"', flow: 'editor' });
    await page.locator('button:has-text("Fechar"):visible').first().click();
  }
  await ctx.close();

  // ═══════════ mobile ═══════════
  const ctxM = await nc({ theme: 'light', viewport: 'mobile', auth: 'projetista' });
  const pM = await ctxM.newPage();
  pM.on('dialog', async d => { note(`window.${d.type()} (mobile): "${d.message()}"`); await d.accept(); });
  await abrirProjeto(pM, CHEIO);
  await waitForTiles(pM);
  await shot(pM, '36-editor-sheet-minimo-mobile', {
    title: 'Editor mobile — mapa cheio e BottomSheet no snap mínimo (150 px)', flow: 'editor',
  });

  const arrastar = async (alvoPx) => {
    const box = await pM.locator('.cursor-grab:visible').first().boundingBox();
    if (!box) return false;
    const sy = box.y + box.height / 2;
    const ey = 844 - alvoPx;
    await pM.evaluate(async ([s, e]) => {
      const h = [...document.querySelectorAll('.cursor-grab')].find(el => el.offsetParent !== null);
      if (!h) return;
      const mk = (type, y) => new TouchEvent(type, {
        bubbles: true, cancelable: true,
        touches: type === 'touchend' ? [] : [new Touch({ identifier: 1, target: h, clientX: 100, clientY: y })],
      });
      h.dispatchEvent(mk('touchstart', s));
      for (let i = 1; i <= 12; i++) {
        h.dispatchEvent(mk('touchmove', s + ((e - s) * i) / 12));
        await new Promise(r => setTimeout(r, 20));
      }
      h.dispatchEvent(mk('touchend', e));
    }, [sy, ey]);
    await pM.waitForTimeout(900);
    return true;
  };

  if (await arrastar(Math.round(844 * 0.5))) {
    note(`altura do sheet (50%): ${await pM.locator('.cursor-grab:visible').first().evaluate(el => el.parentElement.style.height)}`);
    await shot(pM, '36-editor-sheet-meio-mobile', { title: 'Editor mobile — BottomSheet no snap intermediário (50%)', flow: 'editor' });
  }
  if (await arrastar(Math.round(844 * 0.9))) {
    note(`altura do sheet (90%): ${await pM.locator('.cursor-grab:visible').first().evaluate(el => el.parentElement.style.height)}`);
    await shot(pM, '36-editor-sheet-alto-mobile', { title: 'Editor mobile — BottomSheet no snap máximo (90%)', flow: 'editor' });
  }
  await ctxM.close();

  // ═══════════ dark ═══════════
  const ctxD = await nc({ theme: 'dark', viewport: 'desktop', auth: 'projetista' });
  const pD = await ctxD.newPage();
  pD.on('dialog', async d => { await d.accept(); });
  await abrirProjeto(pD, CHEIO);
  await waitForTiles(pD);
  await shot(pD, '36-editor-split-dark', { title: 'Editor de projeto — tema escuro', flow: 'editor' });
  await ctxD.close();
} catch (e) {
  console.error('[c02] ERRO:', e.message);
} finally {
  for (const c of ctxs) { try { await c.close(); } catch {} }
  try {
    if (idVazio) {
      const { data: sobra } = await rest(`/points?project_id=eq.${idVazio}&select=id`);
      for (const p of sobra) await rest(`/points?id=eq.${p.id}`, { method: 'DELETE' });
      if (sobra.length) console.log(`limpeza: removidos ${sobra.length} pontos do projeto vazio`);
    }
    for (const c of centrosOriginais) {
      await rest(`/projects?id=eq.${c.id}`, {
        method: 'PATCH',
        body: { centro_lat: c.centro_lat, centro_lng: c.centro_lng, centro_zoom: c.centro_zoom },
      });
    }
    const { data: fim } = await rest('/projects?select=nome,centro_lat,centro_lng,centro_zoom');
    console.log('centros restaurados:', JSON.stringify(fim));
    const { data: pts } = await rest('/points?select=project_id');
    console.log('total de pontos no banco:', pts.length);
  } catch (e) { console.error('falha na limpeza:', e.message); }
  console.log('\n--- notas ---\n' + log.join('\n'));
  await finish();
}
