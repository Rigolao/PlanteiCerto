// Agente B · flow 2 — resultados da recomendação (cenário PADRÃO, 24 passos).
// Loading, ResultScreen, critérios, grade, card, detalhe, editar respostas + variantes mobile/dark.
import { newContext, goto, shot, finish, ensureAuth, waitForImages } from '../harness/shot.mjs';
import { runWizard, ANSWERS_PADRAO } from '../harness/wizard.mjs';

const DELAY = Number(process.env.REC_DELAY_MS || 0);
const log = [];
const safe = async (label, fn) => { try { return await fn(); } catch (e) { console.warn(`! ${label}: ${String(e.message).split('\n')[0]}`); log.push(`ERRO ${label}: ${String(e.message).split('\n')[0]}`); return null; } };

/** Atrasa a resposta da edge function para tornar a fase de loading fotografável. */
async function installDelay(page) {
  if (!DELAY) return;
  await page.route('**/functions/v1/recommend-trees', async (route) => {
    await new Promise((r) => setTimeout(r, DELAY));
    await route.continue();
  });
}

async function topo(page) {
  const h = page.locator('h1:has-text("Árvores Recomendadas")').locator('xpath=..');
  return (await h.innerText()).replace(/\n+/g, ' ');
}

// ---------------------------------------------------------------- desktop claro
const ctx = await newContext({ agent: 'B', theme: 'light', viewport: 'desktop', auth: 'user' });
const page = await ctx.newPage();

try {
  await goto(page, '/', { waitFor: 'text=Mostrando' });
  await ensureAuth(page, 'user');
  await goto(page, '/recomendacao', { waitFor: 'h3.font-display' });
  await installDelay(page);

  await runWizard(page, ANSWERS_PADRAO, {});           // para no diálogo
  log.push('percurso PADRÃO concluído (24 passos), diálogo aberto');

  // ---------- loading ----------
  await safe('loading', async () => {
    const waiter = page.waitForSelector('text=Analisando', { timeout: 15000 });
    await page.locator('button', { hasText: /^Ver Recomendações$/ }).click();
    await waiter;
    await shot(page, '21-rec-loading', { settle: 0, title: 'Fase de carregamento — "Analisando espécies..."', flow: 'rec-resultados' });
    log.push(`loading capturado (delay artificial=${DELAY}ms)`);
  });

  await page.waitForSelector('text=Árvores Recomendadas', { timeout: 60000 });
  await page.waitForTimeout(600);
  await waitForImages(page);

  // ---------- topo ----------
  await safe('topo', async () => {
    const t = await topo(page);
    log.push(`CENÁRIO PADRÃO topo: ${t}`);
    const botoes = await page.locator('div.flex.flex-col.sm\\:flex-row > button').allInnerTexts().catch(() => []);
    log.push(`botões de ação: ${botoes.join(' | ')}`);
    await shot(page, '21-rec-topo', { title: 'ResultScreen — cabeçalho, contagem e ações', flow: 'rec-resultados' });
  });

  // ---------- cartão de critérios recolhido / expandido ----------
  const criteriaClip = async () => page.evaluate(() => {
    const b = [...document.querySelectorAll('button')].find((x) => x.textContent.includes('Como as espécies foram avaliadas'));
    if (!b) return null;
    const r = b.parentElement.getBoundingClientRect();
    return { x: Math.max(0, Math.round(r.left - 10)), y: Math.max(0, Math.round(r.top - 10)), width: Math.min(window.innerWidth, Math.round(r.width + 20)), height: Math.round(r.height + 20) };
  });

  await safe('criterios-recolhido', async () => {
    await page.evaluate(() => window.scrollTo(0, 0));
    const badge = (await page.locator('button:has-text("Como as espécies foram avaliadas") span').first().innerText()).trim();
    log.push(`cartão de critérios recolhido, badge="${badge}"`);
    const clip = await criteriaClip();
    await shot(page, '21-rec-criterios-recolhido', { clip, title: 'Cartão "Como as espécies foram avaliadas" recolhido', flow: 'rec-resultados' });
  });

  await safe('criterios-expandido', async () => {
    await page.locator('button:has-text("Como as espécies foram avaliadas")').click();
    await page.waitForTimeout(700);
    const clip = await criteriaClip();
    await shot(page, '21-rec-criterios-expandido', { clip, title: 'Critérios expandidos — chips eliminatórios (vermelhos) e classificatórios (verdes)', flow: 'rec-resultados' });
    const elim = await page.locator('p:has-text("Filtros eliminatórios") + div span').allInnerTexts().catch(() => []);
    const clas = await page.locator('p:has-text("Critérios de pontuação") + div span').allInnerTexts().catch(() => []);
    log.push(`chips eliminatórios (${elim.length}): ${elim.join(' · ')}`);
    log.push(`chips classificatórios (${clas.length}): ${clas.join(' · ')}`);
  });

  // ---------- grade completa ----------
  await safe('grade', async () => {
    await page.locator('button:has-text("Como as espécies foram avaliadas")').click(); // recolhe de novo
    await page.waitForTimeout(500);
    await page.evaluate(async () => {
      for (let y = 0; y < document.body.scrollHeight; y += 800) { window.scrollTo(0, y); await new Promise((r) => setTimeout(r, 90)); }
      window.scrollTo(0, 0);
    });
    await waitForImages(page);
    await page.waitForTimeout(500);
    const alt = await page.evaluate(() => document.documentElement.scrollHeight);
    log.push(`altura total da página de resultados: ${alt}px`);
    await shot(page, '21-rec-grade', { fullPage: true, title: 'Grade completa de espécies recomendadas', flow: 'rec-resultados' });
  });

  // ---------- zoom em 1 card ----------
  await safe('card-zoom', async () => {
    const card = page.locator('div.grid > button').first();
    const txt = (await card.innerText()).replace(/\n+/g, ' | ');
    log.push(`1º card: ${txt}`);
    await shot(page, '21-rec-card-zoom', { element: 'div.grid > button', title: 'Card de resultado em detalhe — score, pills e "Destaques da árvore"', flow: 'rec-resultados' });
  });

  // ---------- TreeDetailModal a partir de um resultado ----------
  await safe('detalhe', async () => {
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.locator('div.grid > button').first().click();
    await page.waitForSelector('text=Tolerâncias Ecológicas', { timeout: 15000 });
    await waitForImages(page);
    await page.waitForTimeout(600);
    await shot(page, '21-rec-detalhe-modal', { title: 'TreeDetailModal aberto a partir de um resultado', flow: 'rec-resultados' });
    await page.keyboard.press('Escape');
    await page.waitForTimeout(600);
  });

  // ---------- Editar Respostas ----------
  await safe('editar', async () => {
    await page.locator('button', { hasText: /^Editar Respostas$/ }).first().click();
    await page.waitForSelector('h3.font-display', { timeout: 10000 });
    await page.waitForTimeout(400);
    const h = (await page.locator('text=/^Pergunta \\d+ de \\d+$/').first().innerText()).trim();
    const q = (await page.locator('h3.font-display').first().innerText()).trim();
    log.push(`"Editar Respostas" retorna para: ${h} — "${q}" (NÃO volta ao passo 1)`);
    await shot(page, '21-rec-editar-volta', { title: '"Editar Respostas" — volta ao questionário no passo em que estava', flow: 'rec-resultados' });

    await page.locator('button[aria-label="Ir para pergunta 1"]').click();
    await page.waitForTimeout(500);
    const q1 = (await page.locator('h3.font-display').first().innerText()).trim();
    const sel = await page.locator('div.space-y-2\\.5 > button.border-\\[\\#a8c5a9\\]').allInnerTexts().catch(() => []);
    log.push(`passo 1 após editar: "${q1}" · opção marcada: ${sel.join(',') || '(não detectada via classe)'}`);
    await shot(page, '21-rec-editar-passo1', { title: 'Passo 1 com a resposta preservada após "Editar Respostas"', flow: 'rec-resultados' });
  });
} finally {
  await ctx.close();
}

// ---------------------------------------------------------------- mobile
await safe('mobile', async () => {
  const m = await newContext({ agent: 'B', theme: 'light', viewport: 'mobile', auth: 'user' });
  const mp = await m.newPage();
  try {
    await goto(mp, '/recomendacao', { waitFor: 'h3.font-display' });
    await runWizard(mp, ANSWERS_PADRAO, {
      afterAnswer: async (s) => {
        if (s.id === 'q3_1') await shot(mp, '21-rec-questionario-mobile', { title: 'Questionário em tela estreita (390 px)', flow: 'rec-mobile' });
      },
      confirm: true,
    });
    await mp.waitForSelector('text=Árvores Recomendadas', { timeout: 60000 });
    await mp.waitForTimeout(800);
    await waitForImages(mp);
    log.push(`mobile topo: ${await topo(mp)}`);
    await shot(mp, '21-rec-topo-mobile', { title: 'Resultados em tela estreita — topo', flow: 'rec-mobile' });
  } finally { await m.close(); }
});

// ---------------------------------------------------------------- dark
await safe('dark', async () => {
  const d = await newContext({ agent: 'B', theme: 'dark', viewport: 'desktop', auth: 'user' });
  const dp = await d.newPage();
  try {
    await goto(dp, '/recomendacao', { waitFor: 'h3.font-display' });
    await runWizard(dp, ANSWERS_PADRAO, {
      afterAnswer: async (s) => {
        if (s.id === 'q3_1') await shot(dp, '21-rec-questionario-dark', { title: 'Questionário em tema escuro', flow: 'rec-dark' });
      },
      confirm: true,
    });
    await dp.waitForSelector('text=Árvores Recomendadas', { timeout: 60000 });
    await dp.waitForTimeout(800);
    await waitForImages(dp);
    await dp.locator('button:has-text("Como as espécies foram avaliadas")').click();
    await dp.waitForTimeout(700);
    log.push(`dark topo: ${await topo(dp)}`);
    await shot(dp, '21-rec-topo-dark', { title: 'Resultados em tema escuro (critérios expandidos)', flow: 'rec-dark' });
  } finally { await d.close(); }
});

console.log('\n--- LOG b02 ---\n' + log.join('\n'));
await finish();
