// Agente D — flow d03: /admin/equipe (tabela de perfis, proteção da própria linha,
// promover e rebaixar a conta "colega"). Depende do flag state/c05-done.flag (agente C).
import { newContext, goto, shot, shotToast, ensureAuth, finish } from '../harness/shot.mjs';
import { sql } from '../harness/supa.mjs';
import fs from 'node:fs';
import path from 'node:path';
import { ROOT } from '../harness/config.mjs';

const MODAL = '.rounded-2xl.shadow-2xl';
const COLEGA = 'colega.demo@planteicerto.local';
const FLAG = path.join(ROOT, 'state', 'c05-done.flag');

async function hideDevtools(ctx) {
  await ctx.addInitScript(() => {
    const css = 'button[aria-label="Open Tanstack query devtools"],.tsqd-open-btn-container,.tsqd-parent-container{display:none !important}';
    const add = () => { const s = document.createElement('style'); s.textContent = css; document.head.appendChild(s); };
    if (document.head) add(); else document.addEventListener('DOMContentLoaded', add);
  });
}
async function step(nome, fn) {
  try { await fn(); } catch (e) { console.warn(`⚠ passo "${nome}" falhou: ${String(e.message).split('\n')[0]}`); }
}
async function rectOf(page, fn, arg, pad = 10) {
  const r = await page.evaluate(fn, arg);
  if (!r) return undefined;
  const vp = page.viewportSize();
  const x = Math.max(0, r.x - pad), y = Math.max(0, r.y - pad);
  return { x, y, width: Math.min(vp.width - x, r.width + pad * 2), height: Math.min(vp.height - y, r.height + pad * 2) };
}
const rectDaLinha = (txt) => {
  const tr = [...document.querySelectorAll('table tbody tr')].find((r) => r.textContent.includes(txt));
  if (!tr) return null;
  const b = tr.getBoundingClientRect();
  return { x: b.x, y: b.y, width: b.width, height: b.height };
};

console.log('flag c05 presente?', fs.existsSync(FLAG));
console.log('perfis antes:', sql('select email, role from public.profiles order by created_at'));

const ctx = await newContext({ agent: 'D', theme: 'light', viewport: 'desktop', auth: 'admin' });
await hideDevtools(ctx);
let ctxMobile, ctxDark;

try {
  const page = await ctx.newPage();
  await goto(page, '/', { waitFor: 'text=Mostrando' });
  await ensureAuth(page, 'admin');
  await goto(page, '/admin/equipe', { waitFor: 'text=Gerenciar Equipe' });
  await page.waitForSelector('table tbody tr', { state: 'visible' });
  console.log('contador:', await page.locator('p:has-text("registrados")').first().innerText().catch(() => '?'));

  await step('tabela', async () => {
    await shot(page, '47-equipe-tabela', { title: 'Painel admin — Gerenciar Equipe', flow: 'admin-equipe', fullPage: true });
  });

  await step('propria-linha', async () => {
    const linha = page.locator('table tbody tr', { hasText: '(você)' }).first();
    await linha.locator('button').hover();
    await page.waitForTimeout(600);
    console.log('title do botão próprio:', await linha.locator('button').getAttribute('title'));
    console.log('desabilitado?', await linha.locator('button').isDisabled());
    await shot(page, '47-equipe-propria-linha', {
      title: 'Linha do próprio administrador — botão desabilitado', flow: 'admin-equipe',
      clip: await rectOf(page, rectDaLinha, '(você)', 10),
    });
  });

  await step('promover', async () => {
    const linha = page.locator('table tbody tr', { hasText: 'Colega da Equipe' }).first();
    await linha.locator('button', { hasText: 'Promover' }).click();
    await page.waitForSelector(`${MODAL} h3`, { state: 'visible' });
    await page.waitForTimeout(500);
    console.log('dialogo promover:', await page.locator(`${MODAL} h3`).innerText(), '/', await page.locator(`${MODAL} p`).innerText());
    console.log('botões do diálogo:', await page.locator(`${MODAL} button`).allInnerTexts());
    await shot(page, '48-equipe-promover-dialogo', { title: 'ConfirmDialog de promoção a administrador', flow: 'admin-equipe', element: MODAL });
    await shotToast(page, () => page.locator(`${MODAL} button`, { hasText: 'Excluir' }).click(), '48-equipe-toast-promovido', {
      title: 'Toast "Usuário promovido a administrador!"', flow: 'admin-equipe',
    });
    await page.waitForTimeout(1000);
    console.log('role colega após promover:', sql(`select role from public.profiles where email='${COLEGA}'`));
    await shot(page, '48-equipe-tabela-colega-admin', {
      title: 'Tabela com a colega já marcada como Admin', flow: 'admin-equipe',
      clip: await rectOf(page, () => { const t = document.querySelector('table'); const b = t.getBoundingClientRect(); return { x: b.x, y: b.y, width: b.width, height: b.height }; }, null, 8),
    });
  });

  await step('rebaixar', async () => {
    await page.waitForSelector('[data-sonner-toast]', { state: 'detached', timeout: 12000 }).catch(() => {});
    const linha = page.locator('table tbody tr', { hasText: 'Colega da Equipe' }).first();
    await linha.locator('button', { hasText: 'Remover Admin' }).click();
    await page.waitForSelector(`${MODAL} h3`, { state: 'visible' });
    await page.waitForTimeout(500);
    console.log('dialogo rebaixar:', await page.locator(`${MODAL} h3`).innerText(), '/', await page.locator(`${MODAL} p`).innerText());
    await shot(page, '49-equipe-rebaixar-dialogo', { title: 'ConfirmDialog de remoção de privilégios', flow: 'admin-equipe', element: MODAL });
    await shotToast(page, () => page.locator(`${MODAL} button`, { hasText: 'Excluir' }).click(), '49-equipe-toast-rebaixado', {
      title: 'Toast "Privilégios de admin removidos."', flow: 'admin-equipe',
    });
    await page.waitForTimeout(1000);
    console.log('role colega após rebaixar:', sql(`select role from public.profiles where email='${COLEGA}'`));
    await page.waitForSelector('[data-sonner-toast]', { state: 'detached', timeout: 12000 }).catch(() => {});
    await shot(page, '49-equipe-tabela-final', { title: 'Estado final: colega novamente com papel "Usuário"', flow: 'admin-equipe', fullPage: true });
  });

  await step('mobile', async () => {
    ctxMobile = await newContext({ agent: 'D', theme: 'light', viewport: 'mobile', auth: 'admin' });
    await hideDevtools(ctxMobile);
    const p = await ctxMobile.newPage();
    await goto(p, '/admin/equipe', { waitFor: 'text=Gerenciar Equipe' });
    await p.waitForSelector('table tbody tr', { state: 'visible' });
    await shot(p, '49-equipe-tabela-mobile', { title: 'Gerenciar Equipe no mobile', flow: 'admin-equipe' });
    await ctxMobile.close(); ctxMobile = null;
  });

  await step('dark', async () => {
    ctxDark = await newContext({ agent: 'D', theme: 'dark', viewport: 'desktop', auth: 'admin' });
    await hideDevtools(ctxDark);
    const p = await ctxDark.newPage();
    await goto(p, '/admin/equipe', { waitFor: 'text=Gerenciar Equipe' });
    await p.waitForSelector('table tbody tr', { state: 'visible' });
    await shot(p, '49-equipe-tabela-dark', { title: 'Gerenciar Equipe no tema escuro', flow: 'admin-equipe', fullPage: true });
    await ctxDark.close(); ctxDark = null;
  });
} catch (e) {
  console.error('ERRO no flow d03:', e.message);
} finally {
  try { sql(`update public.profiles set role='user' where email='${COLEGA}'`); } catch (e) { console.warn('limpeza role:', e.message); }
  for (const c of [ctx, ctxMobile, ctxDark]) { try { if (c) await c.close(); } catch {} }
  await finish();
  console.log('perfis depois:', sql('select email, role from public.profiles order by created_at'));
}
