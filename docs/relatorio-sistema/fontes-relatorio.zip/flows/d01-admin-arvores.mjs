// Agente D — flow d01: /admin/arvores (listagem, tabela, guarda AdminRoute, mobile, dark).
import { newContext, goto, shot, ensureAuth, finish } from '../harness/shot.mjs';
import { BASE } from '../harness/config.mjs';
import { sql } from '../harness/supa.mjs';

const MODAL = '.rounded-2xl.shadow-2xl';
const SEARCH = 'input[placeholder="Buscar por nome popular ou científico..."]';
const ZZ_SCI = 'Zz Especimen demonstrativo';

// O botão flutuante do React Query Devtools só existe no dev server e não faz parte do produto.
async function hideDevtools(ctx) {
  await ctx.addInitScript(() => {
    const css = 'button[aria-label="Open Tanstack query devtools"],.tsqd-open-btn-container,.tsqd-parent-container{display:none !important}';
    const add = () => { const s = document.createElement('style'); s.textContent = css; document.head.appendChild(s); };
    if (document.head) add(); else document.addEventListener('DOMContentLoaded', add);
  });
}

async function step(nome, fn) {
  try { await fn(); } catch (e) { console.warn(`⚠ passo "${nome}" falhou: ${String(e.message).split('\n')[0]}`); }
}

async function clipOf(page, selector, pad = 12) {
  const box = await page.locator(selector).first().boundingBox();
  if (!box) return undefined;
  const vp = page.viewportSize();
  const x = Math.max(0, box.x - pad), y = Math.max(0, box.y - pad);
  return { x, y, width: Math.min(vp.width - x, box.width + pad * 2), height: Math.min(vp.height - y, box.height + pad * 2) };
}

async function paginationClip(page, pad = 10) {
  const r = await page.evaluate(() => {
    const sel = document.querySelector('#page-size');
    const box = sel && sel.closest('div.flex.items-center.justify-between');
    if (!box) return null;
    const b = box.getBoundingClientRect();
    return { x: b.x, y: b.y, width: b.width, height: b.height };
  });
  if (!r) return undefined;
  const vp = page.viewportSize();
  const x = Math.max(0, r.x - pad), y = Math.max(0, r.y - pad);
  return { x, y, width: Math.min(vp.width - x, r.width + pad * 2), height: Math.min(vp.height - y, r.height + pad * 2) };
}

const ctx = await newContext({ agent: 'D', theme: 'light', viewport: 'desktop', auth: 'admin' });
await hideDevtools(ctx);
let ctxUser, ctxMobile, ctxDark;

try {
  const page = await ctx.newPage();

  await goto(page, '/', { waitFor: 'text=Mostrando' });
  await ensureAuth(page, 'admin');
  await goto(page, '/admin/arvores', { waitFor: 'text=Gerenciar Árvores' });
  await page.waitForSelector('table tbody tr', { state: 'visible' });

  console.log('contador:', await page.locator('p:has-text("árvores cadastradas")').first().innerText().catch(() => '?'));
  console.log('rodapé:', await page.locator('p:has-text("Mostrando")').first().innerText().catch(() => '?'));

  await step('lista', async () => {
    await shot(page, '40-admin-arvores-lista', { title: 'Painel admin — Gerenciar Árvores', flow: 'admin-arvores', fullPage: true });
    await shot(page, '40-admin-sidebar', { title: 'AdminLayout — barra lateral', flow: 'admin-arvores', element: 'aside' });
  });

  await step('ordenacao', async () => {
    const hdr = page.getByRole('button', { name: /Nome Popular/ });
    await hdr.click(); await page.waitForTimeout(300);
    await shot(page, '41-admin-ordenacao-asc', { title: 'Ordenação por Nome Popular (crescente)', flow: 'admin-arvores' });
    await shot(page, '41-admin-ordenacao-asc-zoom', { title: 'Zoom: cabeçalho com seta ↑', flow: 'admin-arvores', clip: await clipOf(page, 'table thead tr', 6) });
    await hdr.click(); await page.waitForTimeout(300);
    await shot(page, '41-admin-ordenacao-desc', { title: 'Ordenação por Nome Popular (decrescente)', flow: 'admin-arvores' });
    await shot(page, '41-admin-ordenacao-desc-zoom', { title: 'Zoom: cabeçalho com seta ↓', flow: 'admin-arvores', clip: await clipOf(page, 'table thead tr', 6) });
    await page.getByRole('button', { name: /^ID/ }).click();
    await page.waitForTimeout(300);
  });

  await step('paginacao', async () => {
    await shot(page, '41-admin-paginacao-rodape', { title: 'Rodapé de paginação', flow: 'admin-arvores', clip: await paginationClip(page) });
    await page.selectOption('#page-size', '15');
    await page.waitForTimeout(400);
    await shot(page, '41-admin-paginacao-15', { title: 'Paginação com 15 itens por página', flow: 'admin-arvores', fullPage: true });
    // clique DOM: o rodapé fica na borda inferior e pode ficar fora do alcance do mouse virtual
    await page.evaluate(() => {
      const sel = document.querySelector('#page-size');
      const box = sel.closest('div.flex.items-center.justify-between');
      const btns = box.querySelectorAll('button');
      btns[btns.length - 1].click();
    });
    await page.waitForTimeout(500);
    console.log('rodapé p2:', await page.locator('p:has-text("Mostrando")').first().innerText().catch(() => '?'));
    await shot(page, '41-admin-paginacao-pagina2', { title: 'Segunda página (15 por página)', flow: 'admin-arvores', fullPage: true });
    await page.selectOption('#page-size', '5');
    await page.waitForTimeout(300);
  });

  await step('busca', async () => {
    await page.fill(SEARCH, 'ipê');
    await page.waitForTimeout(500);
    console.log('busca ipê →', await page.locator('p:has-text("Mostrando")').first().innerText().catch(() => '?'));
    await shot(page, '41-admin-busca-ipe', { title: 'Busca por "ipê"', flow: 'admin-arvores', fullPage: true });
    await page.fill(SEARCH, 'xyzabc');
    await page.waitForSelector('text=Nenhuma árvore encontrada para esta busca.', { state: 'visible' });
    await shot(page, '41-admin-busca-sem-resultado', { title: 'Busca sem resultados', flow: 'admin-arvores' });
    await page.fill(SEARCH, '');
    await page.waitForTimeout(300);
  });

  await step('sem-foto', async () => {
    // Nenhuma das 167 espécies do banco tem foto nula: criamos a espécie de demonstração
    // (inativa) só para fotografar o placeholder de pinheiro e a apagamos em seguida.
    sql(`insert into public.trees (nome_popular, nome_cientifico, origem, decidua_perenifolia, ativa, foto)
         select 'Zz Espécie de Teste', '${ZZ_SCI}', 'Nativa BR', 'Perenifólia', false, null
         where not exists (select 1 from public.trees where nome_cientifico = '${ZZ_SCI}')`);
    await goto(page, '/admin/arvores', { waitFor: 'text=Gerenciar Árvores' });
    await page.waitForSelector('table tbody tr', { state: 'visible' });
    const hdr = page.getByRole('button', { name: /Nome Popular/ });
    await hdr.click(); await hdr.click();       // desc → "Zz Espécie de Teste" na 1ª linha
    await page.waitForTimeout(500);
    await shot(page, '41-admin-sem-foto', {
      title: 'Coluna Foto: miniaturas × ícone de pinheiro (espécie sem foto)', flow: 'admin-arvores',
      clip: await clipOf(page, 'table', 6),
    });
    sql(`delete from public.trees where nome_cientifico = '${ZZ_SCI}'`);
  });

  await step('excluir-em-uso', async () => {
    await goto(page, '/admin/arvores', { waitFor: 'text=Gerenciar Árvores' });
    // a contagem de pontos é instantânea no Supabase local; atrasamos a resposta
    // para conseguir fotografar o estado "Verificando uso nos projetos...".
    await page.route('**/rest/v1/points*', async (r) => { await new Promise((res) => setTimeout(res, 3500)); await r.continue(); });
    await page.fill(SEARCH, 'Oiti');
    await page.waitForTimeout(500);
    const linha = page.locator('table tbody tr', { hasText: 'Oiti' }).first();
    const waitVerif = page.waitForSelector('text=Verificando uso nos projetos...', { timeout: 8000 }).catch(() => null);
    await linha.locator('button[title="Excluir"]').click();
    if (await waitVerif) {
      await shot(page, '42-admin-excluir-verificando', { title: 'Exclusão — "Verificando uso nos projetos..."', flow: 'admin-arvores', element: MODAL, settle: 0 });
    } else {
      console.warn('✘ NÃO CAPTURADO 42-admin-excluir-verificando: estado transitório não observado');
    }
    await page.waitForSelector('text=Atenção: Esta árvore está sendo usada', { state: 'visible' });
    await shot(page, '42-admin-excluir-em-uso', { title: 'Exclusão de espécie usada em projetos', flow: 'admin-arvores', element: MODAL });
    console.log('titulo dialogo:', await page.locator(`${MODAL} h3`).first().innerText().catch(() => '?'));
    console.log('mensagem em uso:', await page.locator(`${MODAL} p`).first().innerText().catch(() => '?'));
    await page.locator(`${MODAL} button`, { hasText: 'Cancelar' }).click();
    await page.waitForTimeout(400);
    await page.unroute('**/rest/v1/points*');
  });

  await step('loading-tabela', async () => {
    const p = await ctx.newPage();
    await p.route('**/rest/v1/trees*', async (r) => { await new Promise((res) => setTimeout(res, 6000)); await r.continue(); });
    await p.goto(BASE + '/admin/arvores', { waitUntil: 'domcontentloaded' }).catch(() => {});
    const ok = await p.waitForSelector('text=Carregando árvores...', { timeout: 15000 }).catch(() => null);
    if (ok) await shot(p, '40-admin-loading-tabela', { title: 'Carregando árvores...', flow: 'admin-arvores', settle: 100, route: '/admin/arvores' });
    else console.warn('✘ NÃO CAPTURADO 40-admin-loading-tabela');
    await p.close();
  });

  await step('guard-loading', async () => {
    const p = await ctx.newPage();
    await p.route('**/rest/v1/profiles*', async (r) => { await new Promise((res) => setTimeout(res, 6000)); await r.continue(); });
    await p.goto(BASE + '/admin/arvores', { waitUntil: 'domcontentloaded' }).catch(() => {});
    const ok = await p.waitForSelector('text=Verificando permissões...', { timeout: 15000 }).catch(() => null);
    if (ok) await shot(p, '40-admin-guard-verificando', { title: 'AdminRoute — "Verificando permissões..."', flow: 'admin-arvores', settle: 100, route: '/admin/arvores' });
    else console.warn('✘ NÃO CAPTURADO 40-admin-guard-verificando');
    await p.close();
  });

  await step('acesso-negado', async () => {
    ctxUser = await newContext({ agent: 'D', theme: 'light', viewport: 'desktop', auth: 'user' });
    await hideDevtools(ctxUser);
    const p = await ctxUser.newPage();
    await goto(p, '/', { waitFor: 'text=Mostrando' });              // aquece o cache de assets
    const waitToast = p.waitForSelector('[data-sonner-toast]', { timeout: 20000 }).catch(() => null);
    await p.goto(BASE + '/admin/arvores', { waitUntil: 'domcontentloaded' }).catch(() => {});
    const t = await waitToast;
    if (t) {
      await shot(p, '40-admin-acesso-negado', { title: 'Usuária comum em /admin/arvores — redirecionada com toast', flow: 'admin-arvores', settle: 300 });
      console.log('toast:', await t.innerText().catch(() => '?'), '| url final:', p.url());
    } else {
      console.warn('✘ NÃO CAPTURADO 40-admin-acesso-negado: toast não apareceu (url:', p.url(), ')');
    }
    await ctxUser.close(); ctxUser = null;
  });

  await step('mobile', async () => {
    ctxMobile = await newContext({ agent: 'D', theme: 'light', viewport: 'mobile', auth: 'admin' });
    await hideDevtools(ctxMobile);
    const p = await ctxMobile.newPage();
    await goto(p, '/admin/arvores', { waitFor: 'text=Gerenciar Árvores' });
    await p.waitForSelector('table tbody tr', { state: 'visible' });
    await shot(p, '40-admin-arvores-mobile', { title: 'Painel de espécies no mobile', flow: 'admin-arvores' });
    await p.locator('header button').last().click();
    await p.waitForTimeout(700);
    await shot(p, '40-admin-sidebar-mobile', { title: 'Folha lateral do admin (mobile)', flow: 'admin-arvores' });
    await ctxMobile.close(); ctxMobile = null;
  });

  await step('dark', async () => {
    ctxDark = await newContext({ agent: 'D', theme: 'dark', viewport: 'desktop', auth: 'admin' });
    await hideDevtools(ctxDark);
    const p = await ctxDark.newPage();
    await goto(p, '/admin/arvores', { waitFor: 'text=Gerenciar Árvores' });
    await p.waitForSelector('table tbody tr', { state: 'visible' });
    await shot(p, '40-admin-arvores-dark', { title: 'Painel de espécies no tema escuro', flow: 'admin-arvores', fullPage: true });
    await ctxDark.close(); ctxDark = null;
  });
} catch (e) {
  console.error('ERRO no flow d01:', e.message);
} finally {
  try { sql(`delete from public.trees where nome_cientifico = '${ZZ_SCI}'`); } catch (e) { console.warn('limpeza Zz:', e.message); }
  for (const c of [ctx, ctxUser, ctxMobile, ctxDark]) { try { if (c) await c.close(); } catch {} }
  await finish();
  console.log('restou Zz?', sql(`select count(*) from public.trees where nome_cientifico = '${ZZ_SCI}'`));
  console.log('total trees:', sql('select count(*) from public.trees'));
}
