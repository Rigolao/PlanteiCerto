// Agente C — flow 01: lista de projetos e CRUD (`projetista`).
import { newContext, goto, shot, shotToast, ensureAuth, finish } from '../harness/shot.mjs';
import { rest } from '../harness/supa.mjs';

const TESTE = 'Projeto de Teste (captura)';
const DESC = 'Projeto criado apenas para ilustrar o fluxo de cadastro no relatório.';
const ctxs = [];

async function nc(opts) { const c = await newContext({ agent: 'C', ...opts }); ctxs.push(c); return c; }

try {
  // ───────────────────────── desktop claro, projetista ─────────────────────────
  const ctx = await nc({ theme: 'light', viewport: 'desktop', auth: 'projetista' });
  const page = await ctx.newPage();
  await goto(page, '/projetos', { waitFor: 'h1:has-text("Meus Projetos")' });
  await ensureAuth(page, 'projetista');

  // 1) Skeleton de carregamento (atrasa o GET dos projetos e recarrega)
  await page.route('**/rest/v1/projects*', r => setTimeout(() => { r.continue().catch(() => {}); }, 4000));
  page.reload({ waitUntil: 'commit' }).catch(() => {});
  await page.waitForTimeout(1100);
  await shot(page, '30-projetos-skeleton', {
    title: 'Lista de projetos — esqueleto de carregamento', flow: 'projetos', route: '/projetos',
  });
  await page.waitForSelector('h1:has-text("Meus Projetos")', { timeout: 30000 });
  await page.unroute('**/rest/v1/projects*').catch(() => {});
  await page.waitForTimeout(600);

  // 2) Lista com os dois projetos demo
  await shot(page, '30-projetos-lista', {
    title: 'Lista de projetos — projeto com pontos e projeto vazio', flow: 'projetos',
  });
  console.log('subtítulo:', await page.locator('h1:has-text("Meus Projetos") + p').innerText().catch(() => '?'));

  // 3) Hover na linha (ações Editar/Excluir)
  const linhaDemo = page.locator('div[role="button"]', { hasText: 'Arborização Rua Prudente de Moraes' }).first();
  await linhaDemo.hover();
  await page.waitForTimeout(400);
  await shot(page, '30-projetos-linha-hover', {
    title: 'Linha de projeto com as ações Editar/Excluir reveladas no hover', flow: 'projetos',
  });

  // 4) ProjectModal "Novo Projeto" vazio
  await page.locator('div[role="button"]', { hasText: 'Novo projeto' }).first().click();
  await page.waitForSelector('h2:has-text("Novo Projeto")');
  await page.waitForTimeout(500);
  await shot(page, '31-projetos-modal-novo', {
    title: 'Modal "Novo Projeto" vazio (contadores 0/100 e 0/500)', flow: 'projetos',
  });

  // 5) Preenchido
  await page.getByPlaceholder('Nome do projeto (ex: Arborização da Rua das Flores)').fill(TESTE);
  await page.getByPlaceholder('Descrição (opcional)').fill(DESC);
  await page.waitForTimeout(300);
  await shot(page, '31-projetos-modal-preenchido', {
    title: 'Modal "Novo Projeto" preenchido com nome e descrição', flow: 'projetos',
  });

  // 6/7) "Salvando..." + toast de criação
  await page.route('**/rest/v1/projects*', r => {
    if (r.request().method() === 'POST') setTimeout(() => { r.continue().catch(() => {}); }, 3000);
    else r.continue().catch(() => {});
  });
  const salvando = page.waitForSelector('button:has-text("Salvando...")', { timeout: 8000 }).catch(() => null);
  await page.locator('form button[type="submit"]').click();
  if (await salvando) {
    await shot(page, '31-projetos-salvando', { title: 'Botão do modal em estado "Salvando..."', flow: 'projetos', settle: 120 });
  } else console.warn('estado "Salvando..." não flagrado');
  await page.waitForSelector('[data-sonner-toast]', { timeout: 15000 }).catch(() => null);
  await shot(page, '31-projetos-toast-criado', { title: 'Toast "Projeto criado com sucesso!"', flow: 'projetos', settle: 150 });
  await page.unroute('**/rest/v1/projects*').catch(() => {});
  await page.waitForSelector(`text=${TESTE}`, { timeout: 15000 });
  await page.waitForTimeout(1500);

  // 8/9) Editar
  const linhaTeste = page.locator('div[role="button"]', { hasText: TESTE }).first();
  await linhaTeste.hover();
  await linhaTeste.locator('button[title="Editar projeto"]').first().click();
  await page.waitForSelector('h2:has-text("Editar Projeto")');
  await page.waitForTimeout(500);
  await shot(page, '31-projetos-modal-editar', {
    title: 'Modal "Editar Projeto" pré-preenchido', flow: 'projetos',
  });
  await page.getByPlaceholder('Nome do projeto (ex: Arborização da Rua das Flores)').fill(`${TESTE} v2`);
  await shotToast(page, () => page.locator('form button[type="submit"]').click(), '31-projetos-toast-atualizado', {
    title: 'Toast "Projeto atualizado com sucesso!"', flow: 'projetos',
  });
  await page.waitForTimeout(1500);

  // 10/11) Excluir
  const linhaTeste2 = page.locator('div[role="button"]', { hasText: `${TESTE} v2` }).first();
  await linhaTeste2.hover();
  await linhaTeste2.locator('button[title="Excluir projeto"]').first().click();
  await page.waitForSelector('h3:has-text("Excluir projeto")');
  await page.waitForTimeout(500);
  await shot(page, '31-projetos-excluir-confirm', {
    title: 'ConfirmationModal "Excluir projeto"', flow: 'projetos',
  });
  await shotToast(page, () => page.locator('button:has-text("Sim, excluir projeto")').click(), '31-projetos-toast-removido', {
    title: 'Toast "Projeto removido com sucesso!"', flow: 'projetos',
  });
  await page.waitForTimeout(1200);
  await ctx.close();

  // ───────────────────────── zero projetos (colega) ─────────────────────────
  const ctxZero = await nc({ theme: 'light', viewport: 'desktop', auth: 'colega' });
  const pZero = await ctxZero.newPage();
  await goto(pZero, '/projetos', { waitFor: 'text=Novo projeto' }).catch(() => {});
  await ensureAuth(pZero, 'colega');
  if (!(await pZero.locator('text=Novo projeto').count())) await goto(pZero, '/projetos', { waitFor: 'text=Novo projeto' });
  await pZero.waitForTimeout(500);
  console.log('zero-subtítulo:', await pZero.locator('h1:has-text("Meus Projetos") + p').innerText().catch(() => '?'));
  await shot(pZero, '30-projetos-vazio', {
    title: 'Lista de projetos sem nenhum projeto (usuária sem projetos)', flow: 'projetos',
  });
  await ctxZero.close();

  // ───────────────────────── mobile ─────────────────────────
  const ctxM = await nc({ theme: 'light', viewport: 'mobile', auth: 'projetista' });
  const pM = await ctxM.newPage();
  await goto(pM, '/projetos', { waitFor: 'h1:has-text("Meus Projetos")' });
  await pM.waitForTimeout(600);
  await shot(pM, '30-projetos-lista-mobile', { title: 'Lista de projetos — mobile (390×844)', flow: 'projetos' });
  await ctxM.close();

  // ───────────────────────── dark ─────────────────────────
  const ctxD = await nc({ theme: 'dark', viewport: 'desktop', auth: 'projetista' });
  const pD = await ctxD.newPage();
  await goto(pD, '/projetos', { waitFor: 'h1:has-text("Meus Projetos")' });
  await pD.waitForTimeout(600);
  await shot(pD, '30-projetos-lista-dark', { title: 'Lista de projetos — tema escuro', flow: 'projetos' });
  await ctxD.close();
} catch (e) {
  console.error('[c01] ERRO:', e.message);
} finally {
  for (const c of ctxs) { try { await c.close(); } catch {} }
  // limpeza: remove qualquer projeto de teste que tenha sobrado
  try {
    const { data } = await rest(`/projects?nome=like.${encodeURIComponent('Projeto de Teste (captura)%')}&select=id,nome`);
    for (const p of data ?? []) {
      await rest(`/projects?id=eq.${p.id}`, { method: 'DELETE' });
      console.log('removido projeto de teste:', p.nome);
    }
    const { data: restantes } = await rest('/projects?select=nome&order=created_at');
    console.log('projetos restantes:', JSON.stringify(restantes));
  } catch (e) { console.error('falha na limpeza:', e.message); }
  await finish();
}
