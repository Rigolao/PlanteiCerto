// Agente A — Flow 04: card em hover, seleção para comparação (TreesCompareBar, limite de 3),
// CompareModal (desktop e abas mobile) e TreeDetailModal (com e sem projeção em 10 anos).
import { newContext, goto, shot, shotToast, waitForImages, finish, setAgent } from '../harness/shot.mjs';

setAgent('A');

const PANEL = 'div.bg-card.rounded-2xl.shadow-2xl';

async function hideDevtools(ctx) {
  await ctx.addInitScript(() => {
    const css = 'button[aria-label="Open Tanstack query devtools"],.tsqd-open-btn-container,.tsqd-parent-container{display:none !important}';
    const add = () => { const s = document.createElement('style'); s.textContent = css; document.head.appendChild(s); };
    if (document.head) add(); else document.addEventListener('DOMContentLoaded', add);
  });
}

async function step(nome, fn) {
  try { await fn(); } catch (e) { console.warn(`⚠ passo "${nome}" falhou: ${String(e.message).split('\n')[0]}`); }
}

/** Abre o modal de detalhe da espécie cujo nome popular é exatamente `nome`. */
async function abrirEspecie(page, nome) {
  await page.getByPlaceholder('Buscar por nome ou espécie...').fill(nome);
  await page.waitForTimeout(1000);
  await waitForImages(page);
  await page.locator('article', { has: page.locator(`h2:text-is("${nome}")`) }).first().click();
  await page.waitForSelector(PANEL, { state: 'visible' });
  await page.waitForTimeout(1200);
  await waitForImages(page);
}

/** Rola o overlay do modal e captura em partes (-p1, -p2, ...). Retorna os ids gerados. */
async function capturarModalEmPartes(page, idBase, titulo, flow) {
  const info = await page.evaluate((sel) => {
    const panel = document.querySelector(sel);
    const overlay = panel.parentElement;
    return { panelH: panel.getBoundingClientRect().height, vh: window.innerHeight, scrollH: overlay.scrollHeight };
  }, PANEL);
  const passo = info.vh - 90;
  const partes = Math.max(1, Math.min(5, Math.ceil((info.panelH + 60) / passo)));
  console.log(`modal "${idBase}": altura ${Math.round(info.panelH)}px, viewport ${info.vh}px → ${partes} parte(s)`);
  const ids = [];
  for (let i = 0; i < partes; i++) {
    await page.evaluate(([sel, top]) => {
      document.querySelector(sel).parentElement.scrollTop = top;
    }, [PANEL, i * passo]);
    await page.waitForTimeout(500);
    const id = partes === 1 ? idBase : `${idBase}-p${i + 1}`;
    await shot(page, id, { title: `${titulo}${partes > 1 ? ` (parte ${i + 1} de ${partes})` : ''}`, flow });
    ids.push(id);
  }
  return ids;
}

async function main() {
  // ============ 1. Desktop: hover, comparação, CompareModal ============
  const ctx = await newContext({ agent: 'A', auth: 'none' });
  await hideDevtools(ctx);
  const page = await ctx.newPage();
  await goto(page, '/', { waitFor: 'text=Mostrando' });

  await step('card em hover', async () => {
    await page.locator('article').first().hover();
    await page.waitForTimeout(500);
    await shot(page, '14-especie-card-hover', {
      title: 'TreeCard sob o cursor (primeiro card elevado) ao lado de um card em repouso',
      flow: 'especie', clip: { x: 16, y: 355, width: 740, height: 460 },
    });
  });

  await step('chip Comparando', async () => {
    await page.locator('article').first().locator('button:has-text("Comparar")').click();
    await page.waitForTimeout(600);
    await page.mouse.move(1430, 200);
    await page.waitForTimeout(400);
    await shot(page, '15-comparar-chip-ativo', {
      title: 'Card selecionado: chip "+ Comparar" vira "Comparando" e o card ganha anel verde',
      flow: 'comparar', clip: { x: 16, y: 355, width: 740, height: 460 },
    });
    await shot(page, '15-comparar-barra-1', {
      title: 'TreesCompareBar com 1 espécie — botão mostra "Escolha +" (desabilitado)',
      flow: 'comparar', clip: { x: 380, y: 640, width: 680, height: 260 },
    });
  });

  await step('barra com 2 e 3', async () => {
    await page.locator('article').nth(1).locator('button:has-text("Comparar")').click();
    await page.waitForTimeout(700);
    await shot(page, '15-comparar-barra-2', {
      title: 'TreesCompareBar com 2 espécies — botão "Comparar" habilitado',
      flow: 'comparar', clip: { x: 380, y: 640, width: 680, height: 260 },
    });
    await page.locator('article').nth(2).locator('button:has-text("Comparar")').click();
    await page.waitForTimeout(700);
    await shot(page, '15-comparar-barra-3', {
      title: 'TreesCompareBar com 3 espécies (limite atingido)',
      flow: 'comparar', clip: { x: 380, y: 640, width: 680, height: 260 },
    });
  });

  // O CompareModal é capturado ANTES do toast de limite: o sonner fica visível ~4 s
  // e contaminaria as capturas do modal.
  await step('CompareModal desktop', async () => {
    await page.locator('button:has-text("Comparar")').last().click();
    await page.waitForSelector('text=Comparação Lado a Lado');
    await page.waitForTimeout(1500);
    await waitForImages(page);
    await capturarModalEmPartes(page, '15-comparar-modal',
      'CompareModal (desktop) — 3 espécies lado a lado', 'comparar');
    await page.keyboard.press('Escape');
    await page.waitForTimeout(800);
  });

  await step('toast do limite', async () => {
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.waitForTimeout(500);
    await shotToast(page,
      () => page.locator('article').nth(3).locator('button:has-text("Comparar")').click(),
      '15-comparar-toast-limite',
      { title: 'Toast "Você pode comparar no máximo 3 árvores por vez." ao tentar a 4ª espécie', flow: 'comparar' });
  });
  await ctx.close();

  // ============ 2. CompareModal mobile — 4 abas ============
  const ctxM = await newContext({ agent: 'A', auth: 'none', viewport: 'mobile' });
  await hideDevtools(ctxM);
  const pm = await ctxM.newPage();
  await goto(pm, '/', { waitFor: 'text=Mostrando' });
  await step('CompareModal mobile', async () => {
    // no mobile são usadas 2 espécies para que cada aba caiba em uma tela
    for (const i of [0, 1]) {
      await pm.locator('article').nth(i).locator('button:has-text("Comparar")').click();
      await pm.waitForTimeout(500);
    }
    await pm.locator('button:has-text("Comparar")').last().click();
    await pm.waitForSelector('text=Comparação Lado a Lado');
    await pm.waitForTimeout(1500);
    await waitForImages(pm);
    for (const [aba, slug] of [['Dimensões', 'dimensoes'], ['Botânica', 'botanica'], ['Tolerâncias', 'tolerancias'], ['Uso Urbano', 'urbano']]) {
      await pm.locator(`button:text-is("${aba}")`).click();
      await pm.waitForTimeout(700);
      await pm.evaluate((sel) => { document.querySelector(sel).parentElement.scrollTop = 0; }, PANEL);
      await pm.waitForTimeout(400);
      await shot(pm, `15-comparar-modal-${slug}-mobile`, {
        title: `CompareModal no mobile — aba "${aba}" (2 espécies)`, flow: 'comparar',
      });
    }
  });
  await ctxM.close();

  // ============ 3. TreeDetailModal com projeção (Ipê-roxo-de-bola) ============
  const ctxD = await newContext({ agent: 'A', auth: 'none' });
  await hideDevtools(ctxD);
  const pd = await ctxD.newPage();
  await goto(pd, '/', { waitFor: 'text=Mostrando' });

  await step('detalhe com projeção', async () => {
    await abrirEspecie(pd, 'Ipê-roxo-de-bola');
    const temProjecao = await pd.locator('text=Projeção em 10 anos').count();
    console.log('Ipê-roxo-de-bola — seção de projeção presente?', temProjecao > 0);
    await capturarModalEmPartes(pd, '14-especie-detalhe',
      'TreeDetailModal do Ipê-roxo-de-bola (espécie com projeção de 10 anos)', 'especie');
    await pd.keyboard.press('Escape');
    await pd.waitForTimeout(700);
  });

  await step('detalhe sem projeção (Jerivá)', async () => {
    await abrirEspecie(pd, 'Jerivá');
    const temProjecao = await pd.locator('text=Projeção em 10 anos').count();
    console.log('Jerivá — seção de projeção presente?', temProjecao > 0);
    await capturarModalEmPartes(pd, '14-especie-jeriva',
      'TreeDetailModal do Jerivá (palmeira, sem seção de projeção)', 'especie');
    await pd.keyboard.press('Escape');
    await pd.waitForTimeout(700);
  });
  await ctxD.close();

  // ============ 4. TreeDetailModal no tema escuro ============
  const ctxDk = await newContext({ agent: 'A', auth: 'none', theme: 'dark' });
  await hideDevtools(ctxDk);
  const pk = await ctxDk.newPage();
  await goto(pk, '/', { waitFor: 'text=Mostrando' });
  await step('detalhe dark', async () => {
    await abrirEspecie(pk, 'Oiti');
    await shot(pk, '14-especie-detalhe-dark', {
      title: 'TreeDetailModal no tema escuro (Oiti) — topo do modal', flow: 'especie',
    });
  });
  await ctxDk.close();
}

try { await main(); } finally { await finish(); }
