// Agente C — flow 04: página de perfil e segurança (`projetista`).
import path from 'node:path';
import { newContext, goto, shot, shotToast, ensureAuth, finish } from '../harness/shot.mjs';
import { ROOT } from '../harness/config.mjs';

const FOTO = path.join(ROOT, 'shots', '00-smoke-catalogo.png');
const ctxs = [];
const log = [];
const note = s => { log.push(s); console.log('· ' + s); };
async function nc(o) { const c = await newContext({ agent: 'C', ...o }); ctxs.push(c); return c; }

try {
  const ctx = await nc({ theme: 'light', viewport: 'desktop', auth: 'projetista' });
  const page = await ctx.newPage();
  await goto(page, '/perfil', { waitFor: 'h1:has-text("Meu Perfil")' });
  await ensureAuth(page, 'projetista');
  await page.waitForTimeout(500);

  const cardPublico = page.locator('div.bg-card.border.rounded-2xl').first();
  const cardSeguranca = page.locator('div.bg-card.border.rounded-2xl').last();
  const avatar = page.locator('div.w-32.h-32').first();

  await shot(page, '37-perfil-topo', { title: 'Página "Meu Perfil" completa', flow: 'perfil', fullPage: true });
  await shot(page, '37-perfil-avatar-inicial', {
    title: 'Cartão "Informações Públicas" com avatar em placeholder (inicial do nome)', flow: 'perfil', element: 'div.bg-card.border.rounded-2xl',
  });

  // hover no avatar -> "Alterar Foto"
  await avatar.hover();
  await page.waitForTimeout(500);
  await shot(page, '37-perfil-avatar-hover', {
    title: 'Avatar em hover exibindo a sobreposição "Alterar Foto"', flow: 'perfil', element: 'div.bg-card.border.rounded-2xl',
  });

  // erro de tamanho (> 5 MB)
  await page.setInputFiles('input[type=file]', {
    name: 'grande.png', mimeType: 'image/png', buffer: Buffer.alloc(6 * 1024 * 1024),
  });
  await page.waitForSelector('text=Arquivo muito grande', { timeout: 8000 });
  note(`erro de tamanho: "${await page.locator('p.text-destructive').first().innerText()}"`);
  await page.waitForTimeout(300);
  await shot(page, '37-perfil-avatar-erro-tamanho', {
    title: 'Mensagem "Arquivo muito grande. Máximo: 5MB."', flow: 'perfil', element: 'div.bg-card.border.rounded-2xl',
  });

  // upload válido -> prévia
  await page.setInputFiles('input[type=file]', FOTO);
  await page.waitForTimeout(1200);
  await shot(page, '37-perfil-avatar-previa', {
    title: 'Prévia da nova foto de perfil antes de salvar', flow: 'perfil', element: 'div.bg-card.border.rounded-2xl',
  });

  // salvar -> "Salvando..." + toast
  const salvando = page.locator('button:has-text("Salvando...")').waitFor({ timeout: 6000 }).catch(() => null);
  const toast = page.waitForSelector('[data-sonner-toast]', { timeout: 20000 }).catch(() => null);
  await page.locator('button:has-text("Salvar Perfil")').click();
  await salvando;
  await shot(page, '37-perfil-salvando', { title: 'Botão "Salvando..." durante o envio do perfil', flow: 'perfil', settle: 120 });
  await toast;
  await shot(page, '37-perfil-toast-salvo', { title: 'Toast "Perfil atualizado com sucesso!"', flow: 'perfil', settle: 150 });
  note(`toast do salvamento: "${await page.locator('[data-sonner-toast]').first().innerText().catch(() => '?')}"`);
  await page.waitForTimeout(4500);

  // avatar salvo + pills de método de login
  await goto(page, '/perfil', { waitFor: 'h1:has-text("Meu Perfil")' });
  await page.waitForTimeout(800);
  await shot(page, '37-perfil-com-foto', {
    title: 'Perfil já com a foto salva e pill "E-mail" em Método de Login', flow: 'perfil', element: 'div.bg-card.border.rounded-2xl',
  });
  note(`pills de método de login: ${await page.locator('span.inline-flex.items-center.gap-1\\.5').allInnerTexts().then(a => JSON.stringify(a)).catch(() => '?')}`);

  // seção Segurança
  await shot(page, '38-perfil-seguranca', {
    title: 'Seção "Segurança" com o formulário de troca de senha', flow: 'perfil', element: 'div.bg-card.border.rounded-2xl:last-of-type',
  });

  const nova = page.getByPlaceholder('Mínimo de 6 caracteres');
  const rep = page.getByPlaceholder('Repita a nova senha');
  await nova.fill('SenhaNova123');
  await rep.fill('OutraCoisa456');
  await shotToast(page, () => page.locator('button:has-text("Alterar Senha")').click(), '38-perfil-toast-senhas-diferentes', {
    title: 'Toast "As senhas não coincidem."', flow: 'perfil',
  });
  await page.waitForTimeout(4500);

  await nova.fill('123');
  await rep.fill('123');
  await shotToast(page, () => page.locator('button:has-text("Alterar Senha")').click(), '38-perfil-toast-senha-curta', {
    title: 'Toast "A senha deve ter no mínimo 6 caracteres."', flow: 'perfil',
  });
  await nova.fill(''); await rep.fill('');
  await ctx.close();

  // dark
  const ctxD = await nc({ theme: 'dark', viewport: 'desktop', auth: 'projetista' });
  const pD = await ctxD.newPage();
  await goto(pD, '/perfil', { waitFor: 'h1:has-text("Meu Perfil")' });
  await pD.waitForTimeout(700);
  await shot(pD, '38-perfil-dark', { title: 'Página de perfil — tema escuro', flow: 'perfil', fullPage: true });
  await ctxD.close();

  // mobile (layout do cartão muda para coluna)
  const ctxM = await nc({ theme: 'light', viewport: 'mobile', auth: 'projetista' });
  const pM = await ctxM.newPage();
  await goto(pM, '/perfil', { waitFor: 'h1:has-text("Meu Perfil")' });
  await pM.waitForTimeout(700);
  await shot(pM, '38-perfil-mobile', { title: 'Página de perfil — mobile', flow: 'perfil', fullPage: true });
  await ctxM.close();
} catch (e) {
  console.error('[c04] ERRO:', e.message);
} finally {
  for (const c of ctxs) { try { await c.close(); } catch {} }
  console.log('\n--- notas ---\n' + log.join('\n'));
  await finish();
}
