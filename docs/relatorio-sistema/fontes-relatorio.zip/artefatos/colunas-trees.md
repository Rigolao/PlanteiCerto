# Colunas da tabela public.trees (extraído do banco local após as 5 migrations)

| # | Coluna | Tipo | Nulo? | Default | Comentário |
|---|---|---|---|---|---|
| 1 | `id` | integer | NO | `nextval('trees_id_seq'::regclass)` |  |
| 2 | `foto` | text | YES |  |  |
| 3 | `nome_cientifico` | text | NO |  |  |
| 4 | `nome_popular` | text | NO |  |  |
| 5 | `origem` | text | NO |  |  |
| 6 | `decidua_perenifolia` | text | YES |  |  |
| 7 | `epoca_floracao` | text | YES |  |  |
| 8 | `epoca_frutificacao` | text | YES |  |  |
| 9 | `altura_adulta_max_m` | numeric | YES |  |  |
| 10 | `porte_altura_classe` | text | YES |  |  |
| 11 | `diametro_copa_adulto_max_m` | numeric | YES |  |  |
| 12 | `copa_classe` | text | YES |  |  |
| 13 | `dap_adulto_max_cm` | numeric | YES |  |  |
| 14 | `altura_primeira_bifurcacao_m` | text | YES |  |  |
| 15 | `forma_copa` | text | YES |  |  |
| 16 | `faixa_serv_min_m_recomendada` | numeric | YES |  |  |
| 17 | `berco_area_min_m2_recomendada` | numeric | YES |  |  |
| 18 | `volume_solo_min_m3_recomendado` | numeric | YES |  |  |
| 19 | `compat_fiacao` | text | YES |  |  |
| 20 | `potencial_dano_calcada_1a5` | smallint | YES |  |  |
| 21 | `tolerancia_sol_pleno` | boolean | YES |  |  |
| 22 | `tolerancia_meia_sombra` | boolean | YES |  |  |
| 23 | `tolerancia_sombra` | boolean | YES |  |  |
| 24 | `tolerancia_seca_1a5` | smallint | YES |  |  |
| 25 | `tolerancia_encharcamento_1a5` | smallint | YES |  |  |
| 26 | `tolerancia_poluicao_atmosferica_1a5` | smallint | YES |  |  |
| 27 | `tolerancia_compactacao_solo_1a5` | smallint | YES |  |  |
| 28 | `tolerancia_ventos_fortes_1a5` | smallint | YES |  |  |
| 29 | `potencial_sujeira_1a5` | smallint | YES |  |  |
| 30 | `presenca_espinhos` | boolean | YES |  |  |
| 31 | `presenca_subst_irritantes` | boolean | YES |  |  |
| 32 | `atracao_fauna_1a5` | smallint | YES |  |  |
| 33 | `tolerancia_poda_1a5` | smallint | YES |  |  |
| 34 | `potencial_sombra_1a5` | smallint | YES |  |  |
| 35 | `contribuicao_biodiversidade_1a5` | smallint | YES |  |  |
| 36 | `ativa` | boolean | NO | `true` |  |
| 37 | `dap_10a_cm` | numeric | YES |  | DAP projetado aos 10 anos (cm), cenario boas condicoes, muda inicial 3 cm |
| 38 | `dap_10a_min_cm` | numeric | YES |  |  |
| 39 | `dap_10a_max_cm` | numeric | YES |  |  |
| 40 | `altura_10a_m` | numeric | YES |  | Altura projetada aos 10 anos (m), cenario boas condicoes, muda inicial 1,5 m |
| 41 | `altura_10a_min_m` | numeric | YES |  |  |
| 42 | `altura_10a_max_m` | numeric | YES |  |  |
| 43 | `biomassa_aerea_10a_kg` | numeric | YES |  |  |
| 44 | `carbono_armazenado_10a_kg` | numeric | YES |  | Carbono na biomassa aerea aos 10 anos (kg C) = biomassa x 0,47 |
| 45 | `co2e_10a_kg` | numeric | YES |  | CO2 equivalente aos 10 anos (kg) = carbono x 3,6667 |
| 46 | `sobrevivencia_10a_pct` | numeric | YES |  |  |
| 47 | `co2e_esperado_por_muda_10a_kg` | numeric | YES |  | CO2e esperado por muda plantada aos 10 anos (kg), ja ponderado pela sobrevivencia |
| 48 | `classe_bvoc` | text | YES |  | Classe de emissao de compostos organicos volateis biogenicos |
| 49 | `evidencia_bvoc` | text | YES |  |  |
| 50 | `confianca_bvoc` | text | YES |  |  |
| 51 | `exibir_aviso_bvoc` | boolean | YES | `false` | Sinaliza que a classificacao BVOC tem baixa evidencia e merece ressalva na UI |

## Constraints CHECK

| Constraint | Definição |
|---|---|
| `trees_atracao_fauna_1a5_check` | `CHECK (((atracao_fauna_1a5 >= 1) AND (atracao_fauna_1a5 <= 5)))` |
| `trees_classe_bvoc_check` | `CHECK ((classe_bvoc = ANY (ARRAY['baixo'::text, 'moderado'::text, 'alto'::text, 'desconhecido'::text, 'indeterminado'::text])))` |
| `trees_compat_fiacao_check` | `CHECK ((compat_fiacao = ANY (ARRAY['N'::text, 'A'::text, 'C'::text])))` |
| `trees_confianca_bvoc_check` | `CHECK ((confianca_bvoc = ANY (ARRAY['baixa'::text, 'baixa-média'::text, 'média'::text, 'média-alta'::text])))` |
| `trees_contribuicao_biodiversidade_1a5_check` | `CHECK (((contribuicao_biodiversidade_1a5 >= 1) AND (contribuicao_biodiversidade_1a5 <= 5)))` |
| `trees_copa_classe_check` | `CHECK ((copa_classe = ANY (ARRAY['Grande'::text, 'Média'::text, 'Pequena'::text])))` |
| `trees_decidua_perenifolia_check` | `CHECK ((decidua_perenifolia = ANY (ARRAY['Perenifólia'::text, 'Decídua'::text, 'Semidecídua'::text])))` |
| `trees_origem_check` | `CHECK ((origem = ANY (ARRAY['Nativa BR'::text, 'Exótica'::text])))` |
| `trees_porte_altura_classe_check` | `CHECK ((porte_altura_classe = ANY (ARRAY['Grande'::text, 'Médio'::text, 'Pequeno'::text])))` |
| `trees_potencial_dano_calcada_1a5_check` | `CHECK (((potencial_dano_calcada_1a5 >= 1) AND (potencial_dano_calcada_1a5 <= 5)))` |
| `trees_potencial_sombra_1a5_check` | `CHECK (((potencial_sombra_1a5 >= 1) AND (potencial_sombra_1a5 <= 5)))` |
| `trees_potencial_sujeira_1a5_check` | `CHECK (((potencial_sujeira_1a5 >= 1) AND (potencial_sujeira_1a5 <= 5)))` |
| `trees_sobrevivencia_10a_pct_check` | `CHECK (((sobrevivencia_10a_pct >= (0)::numeric) AND (sobrevivencia_10a_pct <= (100)::numeric)))` |
| `trees_tolerancia_compactacao_solo_1a5_check` | `CHECK (((tolerancia_compactacao_solo_1a5 >= 1) AND (tolerancia_compactacao_solo_1a5 <= 5)))` |
| `trees_tolerancia_encharcamento_1a5_check` | `CHECK (((tolerancia_encharcamento_1a5 >= 1) AND (tolerancia_encharcamento_1a5 <= 5)))` |
| `trees_tolerancia_poda_1a5_check` | `CHECK (((tolerancia_poda_1a5 >= 1) AND (tolerancia_poda_1a5 <= 5)))` |
| `trees_tolerancia_poluicao_atmosferica_1a5_check` | `CHECK (((tolerancia_poluicao_atmosferica_1a5 >= 1) AND (tolerancia_poluicao_atmosferica_1a5 <= 5)))` |
| `trees_tolerancia_seca_1a5_check` | `CHECK (((tolerancia_seca_1a5 >= 1) AND (tolerancia_seca_1a5 <= 5)))` |
| `trees_tolerancia_ventos_fortes_1a5_check` | `CHECK (((tolerancia_ventos_fortes_1a5 >= 1) AND (tolerancia_ventos_fortes_1a5 <= 5)))` |
