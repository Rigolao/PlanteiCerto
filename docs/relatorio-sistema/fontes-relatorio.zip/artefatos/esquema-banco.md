# Esquema do banco (extraído do banco local)

## Tabelas públicas

### points

id:uuid, project_id:uuid, tree_id:integer, lat:double precision, lng:double precision, observacao:text, created_at:timestamp with time zone

### profiles

id:uuid, nome:text, email:text, role:text, created_at:timestamp with time zone

### projects

id:uuid, user_id:uuid, nome:text, descricao:text, centro_lat:double precision, centro_lng:double precision, centro_zoom:smallint, created_at:timestamp with time zone

### trees

id:integer, foto:text, nome_cientifico:text, nome_popular:text, origem:text, decidua_perenifolia:text, epoca_floracao:text, epoca_frutificacao:text, altura_adulta_max_m:numeric, porte_altura_classe:text, diametro_copa_adulto_max_m:numeric, copa_classe:text, dap_adulto_max_cm:numeric, altura_primeira_bifurcacao_m:text, forma_copa:text, faixa_serv_min_m_recomendada:numeric, berco_area_min_m2_recomendada:numeric, volume_solo_min_m3_recomendado:numeric, compat_fiacao:text, potencial_dano_calcada_1a5:smallint, tolerancia_sol_pleno:boolean, tolerancia_meia_sombra:boolean, tolerancia_sombra:boolean, tolerancia_seca_1a5:smallint, tolerancia_encharcamento_1a5:smallint, tolerancia_poluicao_atmosferica_1a5:smallint, tolerancia_compactacao_solo_1a5:smallint, tolerancia_ventos_fortes_1a5:smallint, potencial_sujeira_1a5:smallint, presenca_espinhos:boolean, presenca_subst_irritantes:boolean, atracao_fauna_1a5:smallint, tolerancia_poda_1a5:smallint, potencial_sombra_1a5:smallint, contribuicao_biodiversidade_1a5:smallint, ativa:boolean, dap_10a_cm:numeric, dap_10a_min_cm:numeric, dap_10a_max_cm:numeric, altura_10a_m:numeric, altura_10a_min_m:numeric, altura_10a_max_m:numeric, biomassa_aerea_10a_kg:numeric, carbono_armazenado_10a_kg:numeric, co2e_10a_kg:numeric, sobrevivencia_10a_pct:numeric, co2e_esperado_por_muda_10a_kg:numeric, classe_bvoc:text, evidencia_bvoc:text, confianca_bvoc:text, exibir_aviso_bvoc:boolean

### user_favorites

id:uuid, user_id:uuid, tree_id:integer, created_at:timestamp with time zone

## Políticas RLS (public + storage)

| Tabela | Política | Comando | Roles | USING | WITH CHECK |
|---|---|---|---|---|---|
| public.points | Admins can read all points | SELECT | public | `(get_my_role() = 'admin'::text)` | `` |
| public.points | Users can manage own project points | ALL | public | `(EXISTS ( SELECT 1` | `` |
|    FROM projects | undefined | undefined | undefined | `` | `` |
|   WHERE ((projects.id = points.project_id) AND (projects.user_id = auth.uid())))) |  | undefined | undefined | `` | `` |
| public.points | Users can read own project points | SELECT | public | `(EXISTS ( SELECT 1` | `` |
|    FROM projects | undefined | undefined | undefined | `` | `` |
|   WHERE ((projects.id = points.project_id) AND (projects.user_id = auth.uid())))) |  | undefined | undefined | `` | `` |
| public.profiles | Admins can read all profiles | SELECT | public | `(get_my_role() = 'admin'::text)` | `` |
| public.profiles | Admins can update any profile | UPDATE | public | `(get_my_role() = 'admin'::text)` | `` |
| public.profiles | Users can read own profile | SELECT | public | `(auth.uid() = id)` | `` |
| public.profiles | Users can update own profile | UPDATE | public | `(auth.uid() = id)` | `` |
| public.projects | Users can create own projects | INSERT | public | `` | `(auth.uid() = user_id)` |
| public.projects | Users can delete own projects | DELETE | public | `(auth.uid() = user_id)` | `` |
| public.projects | Users can update own projects | UPDATE | public | `(auth.uid() = user_id)` | `` |
| public.projects | Users can view own projects | SELECT | public | `(auth.uid() = user_id)` | `` |
| public.trees | Admin delete trees | DELETE | public | `(EXISTS ( SELECT 1` | `` |
|    FROM profiles | undefined | undefined | undefined | `` | `` |
|   WHERE ((profiles.id = auth.uid()) AND (profiles.role = 'admin'::text)))) |  | undefined | undefined | `` | `` |
| public.trees | Admin insert trees | INSERT | public | `` | `(EXISTS ( SELECT 1` |
|    FROM profiles | undefined | undefined | undefined | `` | `` |
|   WHERE ((profiles.id = auth.uid()) AND (profiles.role = 'admin'::text)))) | undefined | undefined | undefined | `` | `` |
| public.trees | Admin update trees | UPDATE | public | `(EXISTS ( SELECT 1` | `` |
|    FROM profiles | undefined | undefined | undefined | `` | `` |
|   WHERE ((profiles.id = auth.uid()) AND (profiles.role = 'admin'::text)))) |  | undefined | undefined | `` | `` |
| public.trees | Public read trees | SELECT | public | `((ativa = true) OR (EXISTS ( SELECT 1` | `` |
|    FROM profiles | undefined | undefined | undefined | `` | `` |
|   WHERE ((profiles.id = auth.uid()) AND (profiles.role = 'admin'::text))))) |  | undefined | undefined | `` | `` |
| public.user_favorites | Users can add favorites | INSERT | public | `` | `(auth.uid() = user_id)` |
| public.user_favorites | Users can remove favorites | DELETE | public | `(auth.uid() = user_id)` | `` |
| public.user_favorites | Users can view own favorites | SELECT | public | `(auth.uid() = user_id)` | `` |
| storage.objects | Admin delete tree images | DELETE | public | `((bucket_id = 'tree-images'::text) AND (EXISTS ( SELECT 1` | `` |
|    FROM profiles | undefined | undefined | undefined | `` | `` |
|   WHERE ((profiles.id = auth.uid()) AND (profiles.role = 'admin'::text))))) |  | undefined | undefined | `` | `` |
| storage.objects | Admin update tree images | UPDATE | public | `((bucket_id = 'tree-images'::text) AND (EXISTS ( SELECT 1` | `` |
|    FROM profiles | undefined | undefined | undefined | `` | `` |
|   WHERE ((profiles.id = auth.uid()) AND (profiles.role = 'admin'::text))))) |  | undefined | undefined | `` | `` |
| storage.objects | Admin upload tree images | INSERT | public | `` | `((bucket_id = 'tree-images'::text) AND (EXISTS ( SELECT 1` |
|    FROM profiles | undefined | undefined | undefined | `` | `` |
|   WHERE ((profiles.id = auth.uid()) AND (profiles.role = 'admin'::text))))) | undefined | undefined | undefined | `` | `` |
| storage.objects | Public Read Guias | SELECT | public | `(bucket_id = 'guias'::text)` | `` |
| storage.objects | Public read tree images | SELECT | public | `(bucket_id = 'tree-images'::text)` | `` |
| storage.objects | Temp Public Insert Guias | INSERT | public | `` | `(bucket_id = 'guias'::text)` |
| storage.objects | delete_avatars | DELETE | authenticated | `(bucket_id = 'avatars'::text)` | `` |
| storage.objects | insert_avatars | INSERT | authenticated | `` | `(bucket_id = 'avatars'::text)` |
| storage.objects | public_avatars | SELECT | public | `(bucket_id = 'avatars'::text)` | `` |
| storage.objects | update_avatars | UPDATE | authenticated | `(bucket_id = 'avatars'::text)` | `` |

## Triggers

| Tabela | Trigger | Evento | Ação |
|---|---|---|---|
| auth.users | on_auth_user_created | AFTER INSERT | `EXECUTE FUNCTION handle_new_user()` |
| public.profiles | enforce_role_protection | BEFORE UPDATE | `EXECUTE FUNCTION prevent_role_self_escalation()` |

## Funções (schema public)

| Função | Retorno | Linguagem | Segurança |
|---|---|---|---|
| email_exists | boolean | sql | SECURITY DEFINER |
| get_my_role | text | sql | SECURITY DEFINER |
| handle_new_user | trigger | plpgsql | SECURITY DEFINER |
| prevent_role_self_escalation | trigger | plpgsql | SECURITY DEFINER |

## Buckets de storage

| Bucket | Público | Limite | MIME permitidos |
|---|---|---|---|
| avatars | true |  |  |
| criterios | true |  |  |
| guias | true |  |  |
| tree-images | true | undefined | undefined |
